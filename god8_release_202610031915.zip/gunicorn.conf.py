# v2.0.23: gevent lets chat WebSocket connections stay open without consuming
# the four request threads that were previously shared with draw/prediction APIs.
workers = 1
worker_class = 'gevent'
worker_connections = 300
timeout = 60
keepalive = 5
