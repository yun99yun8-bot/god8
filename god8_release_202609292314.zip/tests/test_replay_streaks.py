import os
import sys
import unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from replay_streaks import summarize

STAMP = datetime(2026, 9, 29, 0, 0, tzinfo=timezone.utc)


def settled(n, a, b, result):
    return (f'2026-09-29:{n:04d}', [a,b], result, STAMP, STAMP+timedelta(seconds=30))


class ReplayStreaksTests(unittest.TestCase):
    def test_first_and_second_have_independent_wrong_runs(self):
        chronological=[settled(1,3,4,3),settled(2,3,4,4),
                       settled(3,3,4,5),settled(4,3,4,3),settled(5,3,4,3)]
        first,second=summarize(list(reversed(chronological)))['candidates']
        self.assertEqual((first['shortestWrong'],first['longestWrong'],first['averageWrong']),
                         (0,2,1))
        self.assertEqual((first['shortestWait'],first['averageWait']), (1,2))
        self.assertEqual(first['currentWrong'],0)
        self.assertEqual(first['longestObservedWrong'],2)
        self.assertIsNone(second['shortestWrong'])
        self.assertEqual(second['currentWrong'],3)

    def test_gap_or_invalid_never_counts_as_loss(self):
        sequence=[settled(1,3,4,3),settled(2,3,4,5),
                  settled(4,3,4,5),settled(5,3,4,3),settled(6,3,4,None),
                  settled(7,3,4,5)]
        one=summarize(list(reversed(sequence)))['candidates'][0]
        self.assertEqual(one['brokenGaps'],1)
        self.assertEqual(one['invalidRows'],1)
        self.assertEqual(one['completedRuns'],0)
        self.assertIsNone(one['currentWrong'])
        self.assertEqual(one['currentLowerBound'],1)

    def test_ten_round_risk_rate_excludes_short_censored_run(self):
        rows=[settled(1,3,4,3)] + [settled(i,3,4,5) for i in range(2,12)]
        rows += [settled(12,3,4,3), settled(13,3,4,5)]
        first=summarize(list(reversed(rows)))['candidates'][0]
        self.assertEqual((first['completedRuns'],first['longestWrong']), (1,10))
        self.assertEqual((first['withinTen'],first['tenEligible'],first['tenRate']), (0,1,0))
        self.assertEqual(first['currentWrong'],1)

    def test_unresolved_ten_losses_are_known_failure(self):
        rows=[settled(1,3,4,3)]+[settled(i,3,4,5) for i in range(2,12)]
        one=summarize(list(reversed(rows)))['candidates'][0]
        self.assertEqual((one['completedRuns'],one['knownTenFailures'],one['tenRate']),
                         (0,1,0))

    def test_own_route_and_no_previous_page_changes(self):
        from web import app
        client=app.test_client()
        self.assertEqual(client.get('/chase').status_code,200)
        self.assertIn('baseAmount',client.get('/chase').get_data(as_text=True))
        self.assertIn('href="/chase"',client.get('/').get_data(as_text=True))
        with patch('web.rows',return_value=[]):
            response=client.get('/api/chase/replay-streaks')
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.get_json()['sampleRows'],0)


if __name__=='__main__':
    unittest.main()
