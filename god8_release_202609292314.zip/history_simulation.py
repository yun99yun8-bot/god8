"""Walk-forward, single-count-only historical sequence replication.

No target result (or any result after it) is used to construct its forecast.
All gaps and invalid rows break the sequence, rather than silently bridging time.
"""
from collections import Counter, defaultdict, deque

from omission_research import issue
from streak_research import issue_index


def _chronological(rows):
    parsed = [(issue_index(key), key, value, numbers) for key, value, numbers in rows]
    parsed.sort(key=lambda row: row[0])
    return parsed


def _valid(value):
    return type(value) is int and 0 <= value <= 7


def _choose(history, counters, sources, overall, min_support=8):
    total = sum(overall.values())
    for length in (4, 3, 2):
        if len(history) < length:
            continue
        key = tuple(history[-length:])
        votes = counters[length].get(key, Counter())
        support = sum(votes.values())
        if support >= max(min_support, length * 3):
            # A 2/2 match is far too fragile; blend the matched successors
            # with the prior distribution before ranking either candidate.
            prior = {k: overall[k]/total for k in range(8)}
            ranked = sorted(range(8), key=lambda k:
                            (-(votes[k] + 16*prior[k])/(support+16), -overall[k], k))
            return ranked[:2], {'length': length, 'sequence': list(key),
                                'support': support, 'minimumSupport': max(min_support,length*3),
                                'votes': {str(k): votes[k] for k in ranked[:2]},
                                'sources': {str(k): sources[length].get((key, k), [])[-3:]
                                            for k in ranked[:2]}}
    ranked = sorted(range(8), key=lambda k: (-overall[k], k))
    return ranked[:2], {'length': 0, 'sequence': [], 'support': total,
                        'minimumSupport': min_support,
                        'votes': {str(k): overall[k] for k in ranked[:2]}, 'sources': {}}


def simulate(rows, minimum_training=100, recent_limit=30):
    """Rows may be unsorted. Invalid/missing periods break matching and are skipped in scoring."""
    if minimum_training < 1:
        raise ValueError('minimum_training must be positive')
    indexed = _chronological(rows)
    counters = {length: defaultdict(Counter) for length in (2, 3, 4)}
    sources = {length: defaultdict(list) for length in (2, 3, 4)}
    overall = Counter()
    history = []
    previous = None
    rank_hits = [0, 0]
    both_hits = 0
    baseline_hits = [0, 0]
    by_method = Counter()
    examples = []
    last_200 = deque(maxlen=200)
    evaluated = 0
    skipped = 0
    missing = 0
    newest = None
    for at, key, actual, numbers in indexed:
        if previous is not None and at != previous + 1:
            history = []
            missing += max(0, at - previous - 1)
        previous = at
        if not _valid(actual):
            history = []
            skipped += 1
            continue
        if len(history) >= 2 and sum(overall.values()) >= minimum_training:
            choices, match = _choose(history, counters, sources, overall)
            baseline = sorted(range(8), key=lambda k: (-overall[k], k))[:2]
            evaluated += 1
            rank_hits[0] += actual == choices[0]
            rank_hits[1] += actual == choices[1]
            both_hits += actual in choices
            baseline_hits[0] += actual == baseline[0]
            baseline_hits[1] += actual in baseline
            last_200.append((actual == choices[0], actual == choices[1],
                             actual in choices, actual == baseline[0], actual in baseline))
            by_method[str(match['length'])] += 1
            record = {'issue': issue(at), 'predictions': choices, 'actual': actual,
                      'numbers': numbers if isinstance(numbers, list) else None,
                      'firstHit': actual == choices[0], 'secondHit': actual == choices[1],
                      'eitherHit': actual in choices, 'match': match}
            examples.append(record)
            if len(examples) > recent_limit:
                examples.pop(0)
        # Register the known successor only AFTER scoring this issue.
        for length in (2, 3, 4):
            if len(history) >= length:
                context = tuple(history[-length:])
                counters[length][context][actual] += 1
                examples_for_result = sources[length][(context, actual)]
                examples_for_result.append({'issue': issue(at), 'single': actual,
                                            'numbers': numbers if isinstance(numbers, list) else None})
                if len(examples_for_result) > 3:
                    examples_for_result.pop(0)
        overall[actual] += 1
        history.append(actual)
        if len(history) > 4:
            history.pop(0)
        newest = at
    preview = None
    if newest is not None and len(history) >= 2 and sum(overall.values()) >= minimum_training:
        choices, match = _choose(history, counters, sources, overall)
        preview = {'issue': issue(newest + 1), 'predictions': choices, 'match': match,
                   'note': '仅为数据库最新期之后的相邻期候选；若历史数据落后，不代表实时开奖前锁定。'}
    recent_n = len(last_200)
    recent_rates = [sum(row[i] for row in last_200)/recent_n if recent_n else None
                    for i in range(5)]
    return {'stored': len(indexed), 'valid': sum(overall.values()), 'invalid': skipped,
            'missing':missing,
            'evaluated': evaluated, 'first': {'hits': rank_hits[0],
                        'rate': rank_hits[0]/evaluated if evaluated else None},
            'second': {'hits': rank_hits[1],
                       'rate': rank_hits[1]/evaluated if evaluated else None},
            'either': {'hits': both_hits, 'rate': both_hits/evaluated if evaluated else None},
            'baseline': {'firstHits': baseline_hits[0], 'firstRate': baseline_hits[0]/evaluated if evaluated else None,
                         'eitherHits': baseline_hits[1], 'eitherRate': baseline_hits[1]/evaluated if evaluated else None},
            'recent200':{'verified':recent_n,'firstRate':recent_rates[0],
                         'secondRate':recent_rates[1], 'eitherRate':recent_rates[2],
                         'baselineFirstRate':recent_rates[3],
                         'baselineEitherRate':recent_rates[4]},
            'methodCounts': dict(by_method), 'recent': list(reversed(examples)),
            'preview': preview, 'minimumTraining': minimum_training,
            'note': '严格逐期滚动：只用当期以前的有效开奖结果找2–4期相同序列；复现至少8–12次才采用，并混合既往总体分布。样本不足退回此前频数，缺期和无效结果中断序列。最近200期成绩与同期简单基线分别列示；历史表现不保证未来命中。'}
