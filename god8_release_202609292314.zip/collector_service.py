"""One collector service: fixed 10,000-round history plus uninterrupted live capture."""
import json
import threading
import time
from datetime import datetime, timezone

from core import (DB, TRAIN_N, fetch_block_range, fetch_latest, from_index,
                  get_meta, init_db, pindex, period_key, save_block,
                  save_blocks_batch, save_period, set_meta, target_block)
from god8_flow import first_complete_index
from monitor_collector import HEAD_UPDATED, run_forever
import monitor_collector as monitor
from audit_service import queued_repairs
from live_replay import advance as advance_replay
from lab_live import advance as advance_lab
from platform_calibration import reconcile_forever


def last_finished_index(head):
    index = first_complete_index(head + 1) - 1
    while target_block(*from_index(index)) > head:
        index -= 1
    return index


def seed_window():
    """Freeze round identities before either live or historic writes can begin."""
    saved = get_meta('historical_capture') or {}
    if 'firstBlock' in saved:
        return saved
    head = fetch_latest()['number']
    end_index = last_finished_index(head)
    start_index = end_index - TRAIN_N + 1
    first_block = target_block(*from_index(start_index)) - 19
    last_block = target_block(*from_index(end_index))
    planned = {'firstIndex':start_index, 'lastIndex':end_index,
               'firstBlock':first_block, 'lastBlock':last_block,
               'nextBlock':first_block, 'status':'collecting',
               'capturedAt':datetime.now(timezone.utc).isoformat()}
    origin = {'index':start_index,
              'period':period_key(*from_index(start_index)),
              'source':'frozen-10000-history-window', 'noBackwardFetch':True,
              'recordedAt':planned['capturedAt']}
    with DB() as c:
        q = c.cursor()
        q.execute('SELECT pg_advisory_xact_lock(%s)', (80086422,))
        q.execute('''INSERT INTO meta(k,v) VALUES('god8_origin',%s::jsonb)
                     ON CONFLICT(k) DO NOTHING''', (json.dumps(origin),))
        q.execute('''INSERT INTO meta(k,v) VALUES('historical_capture',%s::jsonb)
                     ON CONFLICT(k) DO NOTHING''', (json.dumps(planned),))
        q.execute("SELECT v FROM meta WHERE k='historical_capture'")
        result = q.fetchone()[0]
        q.close()
    if (result['firstIndex'] != start_index and
            (get_meta('god8_origin') or {}).get('index') != result['firstIndex']):
        raise RuntimeError('history window and origin disagree')
    set_meta('chain_head', {'block':head, 'seenAt':planned['capturedAt'],
                            'source':'collector-bootstrap'})
    return result


def queue_missing(start, end):
    with DB() as c:
        q = c.cursor()
        q.execute('''INSERT INTO repair_queue(block_number,last_error)
                     SELECT n,'historical range missing' FROM generate_series(%s,%s) n
                     WHERE NOT EXISTS (SELECT 1 FROM raw_blocks WHERE block_number=n)
                     ON CONFLICT DO NOTHING''', (start,end))
        q.close()


def counted(start, end):
    with DB() as c:
        q = c.cursor()
        q.execute('SELECT COUNT(*) FROM raw_blocks WHERE block_number BETWEEN %s AND %s',
                  (start,end))
        count = q.fetchone()[0]
        q.close()
    return count


def backfill_forever():
    while True:
        window = get_meta('historical_capture') or {}
        if window.get('status') == 'raw-complete':
            return
        start, end = window['firstBlock'], window['lastBlock']
        cursor = max(start, min(end+1, int(window['nextBlock'])))
        try:
            if cursor <= end:
                # Range requests amortize HTTP and DB cost. Never advance over
                # missing heights without putting them into the repair queue.
                monitor=get_meta('monitor_stats',{}) or {}
                if monitor.get('status')=='retrying' and '429' in monitor.get('lastError',''):
                    # Give the live head priority when the shared node quota is exhausted.
                    time.sleep(3)
                    continue
                last = min(end, cursor + 99)
                found = fetch_block_range(cursor,last)
                save_blocks_batch(found.values())
                if len(found) != last - cursor + 1:
                    queue_missing(cursor,last)
                cursor = last + 1
                progress = counted(start,end) if (cursor-start)%1000<100 or cursor>end else window.get('rawBlocks',0)
                set_meta('historical_capture', {**{k:v for k,v in window.items() if k!='error'}, 'nextBlock':cursor,
                    'rawBlocks':progress, 'status':'collecting',
                    'updatedAt':datetime.now(timezone.utc).isoformat()})
            else:
                count = counted(start,end)
                if count == end - start + 1:
                    set_meta('historical_capture', {**{k:v for k,v in window.items() if k!='error'},'nextBlock':end+1,
                        'rawBlocks':count,'status':'raw-complete',
                        'updatedAt':datetime.now(timezone.utc).isoformat()})
                    return
                queue_missing(start,end)
                set_meta('historical_capture', {**window,'rawBlocks':count,
                    'status':'repairing-gaps',
                    'updatedAt':datetime.now(timezone.utc).isoformat()})
                time.sleep(2)
        except Exception as exc:
            set_meta('historical_capture', {**window,'nextBlock':cursor,
                'status':'retrying','error':str(exc)[:300],
                'updatedAt':datetime.now(timezone.utc).isoformat()})
            time.sleep(3)


def build_live_period(ds,no):
    """Use already captured blocks first; request only if the 20-group row is incomplete."""
    tb=target_block(ds,no)
    ok,missing=save_period(ds,no,'collector-live')
    source='cached-blocks'
    if not ok and missing:
        batch=fetch_block_range(tb-19,tb)
        save_blocks_batch(batch.values())
        ok,missing=save_period(ds,no,'collector-live')
        source='range-repair'
    if not ok:
        if missing:queue_missing(tb-19,tb)
        return False
    with DB() as c:
        q=c.cursor()
        q.execute('SELECT block_time FROM raw_blocks WHERE block_number=%s',(tb,))
        stamp=q.fetchone()
        q.close()
    now=datetime.now(timezone.utc)
    latency=round(max(0,(now-stamp[0]).total_seconds()),3) if stamp and stamp[0] else None
    set_meta('collector_live_latency',{'period':period_key(ds,no),
        'targetBlock':tb,'source':source,'blockToSavedSeconds':latency,
        'savedAt':now.isoformat()})
    return True


def live_periods_forever():
    window = get_meta('historical_capture') or {}
    cursor = max(window['lastIndex'],
                 int((get_meta('collector_live_cursor') or {}).get('index',window['lastIndex'])))
    fallback_head=None
    last_fallback=0
    while True:
        try:
            now=time.monotonic()
            if now-last_fallback>=2 or fallback_head is None:
                fallback_head=(get_meta('chain_head') or {}).get('block')
                last_fallback=now
            head=max((h for h in (monitor.HEAD_NUMBER,fallback_head) if h is not None),default=None)
            if head is not None:
                index = cursor + 1
                ds, no = from_index(index)
                tb = target_block(ds,no)
                if tb <= head:
                    if build_live_period(ds,no):
                        cursor = index
                        set_meta('collector_live_cursor',{'index':cursor,
                             'period':period_key(ds,no), 'targetBlock':tb,
                             'updatedAt':datetime.now(timezone.utc).isoformat()})
        except Exception as exc:
            set_meta('collector_live_error', {'error':str(exc)[:300],
                'at':datetime.now(timezone.utc).isoformat()})
        HEAD_UPDATED.wait(timeout=.4)
        HEAD_UPDATED.clear()


def repairs_forever():
    while True:
        try:
            window = get_meta('historical_capture') or {}
            queued_repairs(12, window.get('firstBlock',0))
            with DB() as c:
                q=c.cursor()
                q.execute('SELECT COUNT(*) FROM repair_queue')
                missing=q.fetchone()[0]
                q.close()
            set_meta('audit_stats',{'status':'repairing',
                'queuedMissingBlocks':missing,
                'reportedAt':datetime.now(timezone.utc).isoformat()})
        except Exception as exc:
            set_meta('audit_repair_error',{'error':str(exc)[:300]})
        time.sleep(2)


def replay_forever():
    while True:
        try:
            advance_replay()
        except Exception as exc:
            set_meta('replay_error', {'error':str(exc)[:300],
                                     'at':datetime.now(timezone.utc).isoformat()})
        try:
            advance_lab()
        except Exception as exc:
            set_meta('lab_error', {'error':str(exc)[:300],
                                  'at':datetime.now(timezone.utc).isoformat()})
        time.sleep(2)


def main():
    init_db()
    while True:
        try:
            seed_window()
            break
        except Exception as exc:
            set_meta('collector_boot_error',{'error':str(exc)[:300]})
            time.sleep(5)
    for target in (backfill_forever,live_periods_forever,repairs_forever,replay_forever,reconcile_forever):
        threading.Thread(target=target,name=target.__name__,daemon=True).start()
    # This thread continuously samples the live head, even after history finishes.
    run_forever()


if __name__ == '__main__':
    main()
