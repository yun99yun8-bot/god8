from pathlib import Path

import manual_tail_center as mt

ROOT = Path(__file__).resolve().parents[1]


def test_manual_result_issue_is_derived_from_the_actual_result_block():
    for tail in range(10):
        anchor = mt.manual_anchor_block(tail)
        assert mt.manual_period_key(anchor, tail) == '2026-10-02:0337'
        assert mt._issue_no(mt.manual_period_key(anchor, tail)) == '2610020337'
        assert mt.manual_period_key(anchor + 20, tail) == '2026-10-02:0338'


def test_frontend_clock_does_not_overwrite_actual_result_issue():
    js = (ROOT / 'static' / 'app.js').read_text(encoding='utf8')
    tick = js[js.index('function tickManualIssueClock'):js.index('function renderManualLiveSnapshot')]
    assert "document.getElementById('periodValue')" not in tick
    live = js[js.index('function renderManualLiveSnapshot'):js.index('function renderManualSnapshot')]
    assert "period.textContent=latest.issue?`第${latest.issue}期开奖`" in live


def test_manual_clock_uses_platform_period_numbers_one_to_1440():
    js = (ROOT / 'static' / 'app.js').read_text(encoding='utf8')
    body = js[js.index('function manualIssueClockParts'):js.index('function tickManualIssueClock')]
    assert 'Number(parts.hour)*60+Number(parts.minute)+1' in body
    assert 'Number(nextParts.hour)*60+Number(nextParts.minute)+1' in body


def test_prediction_payload_exposes_exact_target_issue():
    source = (ROOT / 'manual_tail_center.py').read_text(encoding='utf8')
    view = source[source.index('def _forecast_view'):source.index('def report')]
    assert "'targetBlock': target_block_no" in view
    assert "'targetPeriod': target_period" in view
    assert "'targetIssue': _issue_no(target_period)" in view
    js = (ROOT / 'static' / 'app.js').read_text(encoding='utf8')
    assert "f.targetIssue?f.targetIssue+'期':'下一期'" in js
