import inspect
from pathlib import Path
from unittest.mock import patch

import manual_tail_center as mt

ROOT=Path(__file__).resolve().parents[1]


def test_manual_page_clones_home_cards_and_inline_tail_picker():
    html=(ROOT/'templates/manual_tail.html').read_text(encoding='utf8')
    assert 'class="home-dashboard manual-home-dashboard"' in html
    assert 'id="manualTailButtons"' in html
    assert html.index('class="draw-block"') < html.index('id="manualTailButtons"')
    for needle in ('id="liveReplayChoices"','id="homeOmission"','id="recent"','id="todayOverdueSummary"'):
        assert needle in html


def test_backfill_uses_persistent_cursors_not_not_exists_scans():
    source=inspect.getsource(mt.backfill_step)+inspect.getsource(mt._raw_batch)+inspect.getsource(mt._legacy_batch)
    assert 'rawCursor' in source and 'legacyCursor' in source
    assert 'block_number>%s' in source
    assert 'NOT EXISTS' not in inspect.getsource(mt._raw_batch)
    assert 'NOT EXISTS' not in inspect.getsource(mt._legacy_batch)


def test_pause_resume_preserves_backfill_cursors():
    saved=[]
    state={'rawCursor':123,'legacyCursor':456,'processed':99,'status':'paused','enabled':False}
    with patch.object(mt,'get_meta',return_value=state), patch.object(mt,'set_meta',side_effect=lambda k,v:saved.append((k,v))):
        result=mt.set_backfill_enabled(True)
    assert result['rawCursor']==123
    assert result['legacyCursor']==456
    assert result['enabled'] is True
    assert saved[-1][1]['rawCursor']==123


def test_manual_prediction_uses_same_simulation_engine():
    source=inspect.getsource(mt._engine_preview)
    assert 'simulate(' in source
    assert "historyScope': 'selected-tail-only-all-history'" in source
    assert 'evaluation_window=250' in source


def test_render_worker_start_command_unchanged():
    text=(ROOT/'render.yaml').read_text(encoding='utf8')
    assert 'name: god8-worker-ai' in text
    assert 'startCommand: python worker_ai.py' in text
