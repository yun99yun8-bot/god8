import inspect
from pathlib import Path

import manual_tail_center as mt

ROOT = Path(__file__).resolve().parents[1]


def test_platform_reference_anchor_is_exact():
    # User/platform reference: 2026-10-02 issue 0337 uses block 86739339 on 9-tail.
    assert mt.manual_anchor_block(9) == 86739339
    assert mt.manual_period_key(86739339, 9) == '2026-10-02:0337'
    assert mt._issue_no(mt.manual_period_key(86739339, 9)) == '2610020337'
    assert mt.manual_period_key(86739319, 9) == '2026-10-02:0336'
    assert mt.manual_period_key(86739299, 9) == '2026-10-02:0335'
    assert mt.manual_period_index(86739329, 9) is None


def test_all_tails_share_the_same_platform_issue_and_correct_twenty_block_lane():
    # Official issue 0337 target is 86739342. Manual selection chooses the
    # nearest block ending in the requested tail, with a -5 tie preferring earlier.
    expected = {0:86739340,1:86739341,2:86739342,3:86739343,4:86739344,
                5:86739345,6:86739346,7:86739337,8:86739338,9:86739339}
    for tail, anchor in expected.items():
        assert mt.manual_anchor_block(tail) == anchor
        assert anchor % 10 == tail
        assert mt.manual_period_key(anchor, tail) == '2026-10-02:0337'
        assert mt.manual_period_key(anchor - 20, tail) == '2026-10-02:0336'
        assert mt.manual_period_key(anchor + 20, tail) == '2026-10-02:0338'
        assert mt.manual_period_index(anchor - 10, tail) is None
        assert mt.manual_period_index(anchor + 10, tail) is None


def test_manual_source_filters_wrong_same_tail_lane_out():
    cte = mt._source_cte()
    assert 'MOD(block_number - %s, 20)=0' in cte
    for tail in range(10):
        anchor = mt.manual_anchor_block(tail)
        assert (anchor - anchor) % 20 == 0
        assert (anchor + 10 - anchor) % 20 == 10
        assert (anchor + 20 - anchor) % 20 == 0


def test_omission_is_based_on_valid_issue_sequence_not_raw_tail_blocks():
    source = inspect.getsource(mt.report)
    assert 'ROW_NUMBER() OVER(ORDER BY block_number)' in source
    assert 'single_count BETWEEN 0 AND 7' in source
    assert 's.total-COALESCE(v.last_rn,0)' in source
    seq = [1, 2, 1, 3]
    total = len(seq)
    last = {s: max((i for i, x in enumerate(seq, 1) if x == s), default=0) for s in range(8)}
    gaps = {s: total - last[s] for s in range(8)}
    assert gaps[1] == 1
    assert gaps[2] == 2
    assert gaps[3] == 0
    assert gaps[0] == 4


def test_prediction_settlement_uses_exact_next_issue_only():
    source = inspect.getsource(mt.settle_predictions)
    assert 'p.source_block+20' in source
    assert "p.evidence->>'engineVersion'=%s" in source
    assert 'm.block_number>p.source_block' not in source


def test_manual_history_returns_real_issue_numbers():
    source = inspect.getsource(mt.history)
    assert "'issue': _issue_no(key)" in source
    js = (ROOT / 'static/app.js').read_text(encoding='utf8')
    assert 'row.issue||row.period' in js
    html = (ROOT / 'templates/manual_tail.html').read_text(encoding='utf8')
    assert '最近100期同尾结果' in html


def test_old_wrong_lane_predictions_are_not_reused():
    source = inspect.getsource(mt.prediction_step) + inspect.getsource(mt._forecast_view)
    assert "engineVersion'='manual-period-v5-issue-synced-replay'" in source
    assert "COALESCE(manual_tail_predictions.evidence->>'engineVersion','')<>'manual-period-v5-issue-synced-replay'" in inspect.getsource(mt.prediction_step)
    # Settlement uses the current engine constant and never skips over a missing next issue.
    settle = inspect.getsource(mt.settle_predictions)
    assert "p.evidence->>'engineVersion'=%s" in settle
    assert 'p.source_block+20' in settle
    assert 'm.block_number>p.source_block' not in settle
