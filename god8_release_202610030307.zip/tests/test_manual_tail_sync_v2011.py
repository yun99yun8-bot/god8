from pathlib import Path
import manual_tail_center as mt

ROOT = Path(__file__).resolve().parents[1]


def test_manual_engine_is_replay_first_v4():
    assert mt.MANUAL_ENGINE_VERSION == 'manual-period-v5-issue-synced-replay'
    src=(ROOT/'history_simulation.py').read_text(encoding='utf8')
    assert 'Exact-sequence replay is never used with fewer than four synchronized periods.' in src
    assert "selectionPolicy': 'adaptive-no-exact-replay'" in src


def test_prediction_clock_uses_latest_result_receipt_not_settlement():
    src=(ROOT/'manual_tail_center.py').read_text(encoding='utf8')
    body=src[src.index('def prediction_step'):src.index('def _forecast_view')]
    assert 'age = (now - result_at).total_seconds()' in body
    assert 'reference = settled[0]' not in body
    assert 'pg_try_advisory_xact_lock' in body


def test_forecast_view_cannot_analyze_forever_after_deadline():
    src=(ROOT/'manual_tail_center.py').read_text(encoding='utf8')
    body=src[src.index('def _forecast_view'):src.index('def report')]
    assert "if age < ANALYSIS_SECONDS:" in body
    assert body.rstrip().endswith("return 'waiting', None")


def test_collector_has_exact_manual_target_and_prediction_safety_net():
    src=(ROOT/'collector_service.py').read_text(encoding='utf8')
    assert 'def manual_tail_fast_forever()' in src
    assert 'save_block(fetch_block(due))' in src
    assert 'fetch_block(upcoming,timeout=2.0)' in src
    assert 'def manual_prediction_forever()' in src
    main=src[src.index('def main():'):]
    assert 'manual_tail_fast_forever' in main
    assert 'manual_prediction_forever' in main


def test_manual_page_refreshes_subsecond_and_surfaces_live_sync():
    js=(ROOT/'static'/'app.js').read_text(encoding='utf8')
    assert 'setInterval(refreshManualTailLive,300)' in js
    assert 'setInterval(()=>refreshManualTailSnapshot(false),1500)' in js
    assert '开奖结果实时同步' in js
    assert '预测未锁定 · 正在自动检查复现引擎' in js
