async function get(url) { const r=await fetch(url); if(!r.ok)throw Error('查询失败');return r.json(); }
function element(tag, text, cls='') {const n=document.createElement(tag);n.textContent=text;n.className=cls;return n;}
function showError(id,e){document.getElementById(id).textContent='读取失败：'+e.message;}
async function checkCenter(){
  const status=document.getElementById('checkHealth');
  try{
    const response=await fetch('/health',{cache:'no-store'});
    const report=await response.json();
    status.dataset.state=response.ok&&report.databaseConnected?'ready':'pending';
    status.textContent=`Web：${report.ok?'运行中':'异常'} · 数据库：${report.databaseConnected?'已连接':'未连接'} · 版本：${report.version||'未知'}`;
  }catch(e){status.dataset.state='pending';status.textContent='健康检查暂时不可用，请打开下方原始检查链接核对。'}
  const recent=document.getElementById('checkRecent200');
  if(!recent)return;
  try{
    const report=await get('/api/omission/recommend200');
    if(!Array.isArray(report.items)||report.items.length!==8)throw Error('缺少八类统计');
    recent.dataset.state=report.complete?'ready':'pending';
    recent.textContent=`最近200期筛选：${report.status||'待核对'} · 有效 ${report.valid}/${report.window} · 缺期 ${report.missing||0} · 无效 ${report.invalid||0} · 候选 ${report.candidates.map(x=>'单'+x.single).join('、')||'暂无'} · 起止期号 ${report.firstIssue||'—'}–${report.lastIssue||'—'}`;
  }catch(e){recent.dataset.state='pending';recent.textContent='最近200期筛选自检失败：'+e.message}
}
let displayedBlock=0,displayedPeriod='',liveRequestPending=false,nextLiveRequest=0;
const SPRITE_PREDICT_KEY='god8-sprite-predict-switch-v1';
let memoryPeriod='',memoryBusy=false,nextMemoryRequest=0,spritePredictEnabled=false,spriteModeRevision=0;
function readSpritePredictionMode(){
  try{const value=localStorage.getItem(SPRITE_PREDICT_KEY);if(value==='on'||value==='off')return value==='on'}catch(e){}
  try{return document.cookie.split(';').some(x=>x.trim()==='god8_sprite_predict=on')}catch(e){return false}
}
function saveSpritePredictionMode(enabled){
  try{localStorage.setItem(SPRITE_PREDICT_KEY,enabled?'on':'off')}catch(e){}
  try{document.cookie=`god8_sprite_predict=${enabled?'on':'off'}; path=/; max-age=31536000; SameSite=Lax`}catch(e){}
}
function applySpritePredictionMode(enabled,persist=false){
  spritePredictEnabled=!!enabled;spriteModeRevision++;
  setHomePredictionMode(spritePredictEnabled);
  if(persist)saveSpritePredictionMode(spritePredictEnabled);
}
function setHomePredictionMode(enabled){
  // Main two-choice forecast is always-on. The sprite switch controls only
  // optional memory/toast reminders and must never hide or stop live replay.
  const idle=document.getElementById('homeReplayIdle'),active=document.getElementById('homeReplayActive');
  if(!idle||!active)return;
  idle.hidden=true;active.hidden=false;
}

async function refreshPatternMemory(){
  if(!displayedPeriod||memoryPeriod===displayedPeriod||memoryBusy||document.hidden||Date.now()<nextMemoryRequest)return;
  memoryBusy=true;nextMemoryRequest=Date.now()+2000;
  const requestMode=spritePredictEnabled,revision=spriteModeRevision;
  try{const report=await get('/api/pattern-memory/live'+(requestMode?'?predict=1':''));if(revision===spriteModeRevision){updateHomeMemoryStatus(report.period);if(report.period===displayedPeriod){memoryPeriod=report.period;window.chasePatternMemory?.(report)}}}
  catch(e){updateHomeMemoryStatus(null,true)}
  finally{memoryBusy=false}
}
function updateHomeMemoryStatus(memoryPeriodKey,failed=false){
  const box=document.getElementById('homeMemoryStatus');if(!box)return;
  if(failed){box.textContent='历史复刻：读取暂不可用';box.dataset.state='pending';return}
  if(!displayedPeriod){box.textContent='历史复刻：等待开奖数据';box.dataset.state='pending';return}
  const synced=memoryPeriodKey===displayedPeriod;
  box.textContent=synced?`历史复刻已读取最新期 ${displayedPeriod}`:`最新开奖 ${displayedPeriod} · 复刻至 ${memoryPeriodKey||'等待首期'}，继续同步中`;
  box.dataset.state=synced?'ready':'pending';
}
function showLatest(latest){
  if(!latest||Number(latest.block)<displayedBlock)return false;
  const changed=latest.period!==displayedPeriod;
  displayedBlock=Number(latest.block);displayedPeriod=latest.period;
  if(changed)updateHomeMemoryStatus(null);
  document.getElementById('periodValue').textContent=latest.issue;
  document.getElementById('singleValue').textContent=latest.single??'--';
  document.getElementById('blockValue').textContent=latest.block;
  document.getElementById('numberGrid').replaceChildren(...ballsWithSeparator(Array.isArray(latest.numbers)?latest.numbers:[],latest.issue));
  return changed;
}
async function refreshLive(){
  if(liveRequestPending||document.hidden||!document.getElementById('periodValue'))return;
  liveRequestPending=true;
  // Under short database/CPU pressure a valid response may take over 2.8s.
  // Aborting every such response left the page on the prior draw until the
  // slower history request happened to complete.
  const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),8000);
  try{
    const r=await fetch('/api/live',{cache:'no-store',signal:controller.signal});
    if(!r.ok)throw Error('实时查询失败');
    const live=await r.json(),changed=showLatest(live.latest);
    window.god8ObservedHead=Number.isFinite(Number(live.head))?Number(live.head):null;
    const shown=document.getElementById('liveReplayChoices');
    if(shown&&shown.dataset.targetBlock&&window.god8ObservedHead>=Number(shown.dataset.targetBlock)){
      shown.replaceChildren();delete shown.dataset.targetBlock;
      const notice=document.getElementById('liveReplay');
      if(notice){notice.hidden=false;notice.classList.remove('analyzing');notice.textContent='等待开奖结果核对';}
    }
    window.chaseLiveHealth?.(live);
    const badge=document.getElementById('drawSync');
    if(badge){
      const headAge=live.headSeenAt?Math.max(0,((live.serverEpochMs||Date.now())-Date.parse(live.headSeenAt))/1000):null;
      if(headAge!==null&&headAge>=12){
        const limited=/\b(?:429|403)\b/.test(live.monitor?.lastError||'');
        badge.textContent=`${limited?'节点限流':'链头延迟'} ${Math.floor(headAge)} 秒`;
        badge.dataset.state='pending';
      }
      else if(live.newest&&live.newest.single===null&&(!live.latest||live.newest.block>live.latest.block)){badge.textContent='本期无有效号码';badge.dataset.state='pending';}
      else if(live.nextTargetBlock!=null&&live.head>=live.nextTargetBlock){badge.textContent='同步中';badge.dataset.state='pending';}
      else if(live.latest){badge.textContent='已更新';badge.dataset.state='ready';}
      else{badge.textContent='等待数据';badge.dataset.state='pending';}
    }
    const timing=document.getElementById('drawTiming');
    if(timing){const seconds=live.latency?.period===live.latest?.period?live.latency.blockToSavedSeconds:null;timing.textContent=seconds==null?'':`区块→入库 ${Number(seconds).toFixed(1)} 秒`;}
    if(changed&&displayedBlock){memoryPeriod='';nextMemoryRequest=0;window.chasePatternPending?.();refreshLiveReplay();setTimeout(refreshHome,900);setTimeout(refreshPatternMemory,1300)}
  }catch(e){window.chaseLiveHealth?.({error:'实时开奖接口暂时不可用'});const badge=document.getElementById('drawSync');if(badge){badge.textContent='连接中';badge.dataset.state='pending'}}
  finally{clearTimeout(timeout);liveRequestPending=false}
}
function scheduleLiveRefresh(){
  if(!document.getElementById('periodValue')||document.hidden)return;
  const now=Date.now(),adjusted=Math.floor((now+clockDelta)/1000)+clockOffset;
  const remaining=60-(((adjusted%60)+60)%60);
  // Keep the fast refresh window wide enough for slow chain/database arrivals.
  // A target block can arrive anywhere in the minute; do not leave a 3s blind spot.
  const interval=remaining<=15||remaining>=30?550:900;
  if(now>=nextLiveRequest){nextLiveRequest=now+interval;refreshLive()}
}
function initHome(){applySpritePredictionMode(readSpritePredictionMode());refreshHome();refreshLive();refreshLiveReplay();document.getElementById('recentPrev')?.addEventListener('click',()=>changeHomeRecent(-1));document.getElementById('recentNext')?.addEventListener('click',()=>changeHomeRecent(1));setInterval(refreshHome,12000);setInterval(scheduleLiveRefresh,250);setInterval(refreshLiveReplay,1000);setInterval(refreshPatternMemory,2000);document.addEventListener('visibilitychange',()=>{if(!document.hidden){nextLiveRequest=0;refreshLive();refreshLiveReplay();refreshPatternMemory()}});window.addEventListener('pageshow',()=>{if(!document.hidden){nextLiveRequest=0;refreshLive();refreshLiveReplay()}})}
const CHASE_KEY='god8-paper-chase-v1';
function chaseIndex(period){
  if(!/^\d{4}-\d{2}-\d{2}:\d{4}$/.test(period||''))return null;
  const [date,no]=period.split(':'),day=Date.parse(date+'T00:00:00Z');
  return Number.isFinite(day)&&Number(no)>=1&&Number(no)<=1440?Math.floor(day/86400000)*1440+Number(no)-1:null;
}
function chaseSave(state){try{localStorage.setItem(CHASE_KEY,JSON.stringify(state))}catch(e){}}
function chaseLoad(){try{const s=JSON.parse(localStorage.getItem(CHASE_KEY));return s&&['0','7','either'].includes(s.target)&&Number.isInteger(s.remaining)&&s.remaining>=0&&s.remaining<=100&&Number.isInteger(s.nextIndex)&&Array.isArray(s.rows)?s:null}catch(e){return null}}
function chaseHit(single,target){return single!=null&&(target==='either'?(single===0||single===7):single===Number(target))}
function chaseWrongStreak(rows,target){let wrong=0;for(let i=rows.length-1;i>=0;i--){if(chaseHit(rows[i].single,target))break;wrong++}return wrong}
function spriteOverdueEvents(report){
  if(!report?.sourceComplete||!report.valid||!Array.isArray(report.items))return [];
  return report.items.filter(x=>x.overdueLatest?.active===true&&x.level==='超期'&&
    Number.isInteger(x.gap)&&Number.isInteger(x.threshold)&&x.gap>x.threshold&&
    /^\d{4}-\d{2}-\d{2}:\d{4}$/.test(x.overdueLatest.startIssue||''))
    .map(x=>({key:`${report.day}:${x.single}:${x.overdueLatest.startIssue}`,single:x.single,gap:x.gap,threshold:x.threshold}));
}
function spriteToastAutoClose(events){return events.length>0&&events.every(x=>x.single===0||x.single===7)}
function spriteMemoryView(report,predictionStarted){
  const practice=report?.practice||{},recent=report?.recent16,replay=report?.replay;
  const observed=`历史已记录 ${practice.highFrequencyEpisodes??0} 段单1/单6密集期；其中 ${practice.preceded07InFour??0} 段在前4期出现单0/单7。`;
  if(!predictionStarted)return {message:observed+' 仅复刻练习，不生成预判。',reason:''};
  const evidence=replay?`历史复现 ${replay.matchedPositions}/${replay.length}位相同；${replay.highFrequencyCases}/${replay.samples} 段后续10期单1/6至少4次。`:
    recent?`最近10期单1/6已出现 ${recent.hits} 次。`:'连续有效数据不足。';
  const reason=report?.highFrequency?(report.status==='replay'?'单1/单6高发期相似记忆提醒（非必出）':'单1/单6近期活跃提醒（已发生）'):'';
  return {message:`${report?.notice||'等待历史复现'} ${evidence} 历史比例不保证下一期。`,reason};
}
function chaseRender(rows,target,status){
  const metrics=document.getElementById('chaseMetrics'),list=document.getElementById('chaseRows');
  if(!metrics||!list)return;
  const valid=rows.filter(x=>Number.isInteger(x.single)&&x.single>=0&&x.single<=7),hits=valid.filter(x=>chaseHit(x.single,target)).length;
  let streak=0,longest=0;for(const x of valid){streak=chaseHit(x.single,target)?0:streak+1;longest=Math.max(longest,streak)}
  metrics.textContent=`已核对 ${valid.length} 期 · 命中 ${hits} 次 · 最长连续未中 ${longest} 期 · 当前连续未中 ${streak} 期`;
  list.replaceChildren(...rows.slice(-30).reverse().map(x=>{
    const row=element('div',`${x.issue} · ${x.single==null?'无效/待核':'单'+x.single} · ${x.single==null?'不计入':chaseHit(x.single,target)?'命中':'未中'}`,'chase-row');
    if(chaseHit(x.single,target))row.classList.add('hit');return row;
  }));
  document.getElementById('chaseStatus').textContent=status;
}
function initChaseFloat(){
  const box=document.getElementById('chaseFloat'),launcher=document.getElementById('chaseLauncher');if(!box)return;
  let state=chaseLoad(),busy=false,lastLive=Date.now(),healthReason='',recordReason='',omissionReason='',memoryReason='',toastTimer,lastReason=null;
  let predictionStarted=spritePredictEnabled,lastMemoryReport=null;
  const forecastToast=document.getElementById('spriteForecastToast'),forecastAckKey='god8-sprite-forecast-ack-v1';
  let forecastActive=null,forecastQueue=[];
  function forecastAcknowledged(){try{const a=JSON.parse(localStorage.getItem(forecastAckKey));return Array.isArray(a)?a:[]}catch(e){return []}}
  function showForecastToast(){
    if(!predictionStarted||forecastActive||!forecastQueue.length)return;
    forecastActive=forecastQueue.shift();const {report,replay}=forecastActive;
    document.getElementById('spriteForecastToastBody').textContent=`${report.period} · 历史${replay.matchedPositions}/${replay.length}位相似 ${replay.samples} 段，其中 ${replay.highFrequencyCases} 段在随后10期单1/单6合计至少出现4次。`;
    forecastToast.hidden=false;
  }
  document.getElementById('spriteForecastToastClose').onclick=()=>{
    if(forecastActive){try{localStorage.setItem(forecastAckKey,JSON.stringify([...new Set([...forecastAcknowledged(),forecastActive.key])].slice(-80)))}catch(e){}}
    forecastActive=null;forecastToast.hidden=true;showForecastToast();
  };
  function queueForecastToast(report){
    if(!predictionStarted||report.status!=='replay'||!report.highFrequency||!report.replay)return;
    const replay=report.replay,key=`${report.period}:${replay.length}:${replay.matchedPositions}`;
    if(forecastAcknowledged().includes(key)||forecastActive?.key===key||forecastQueue.some(x=>x.key===key))return;
    forecastQueue.push({key,report,replay});showForecastToast();
  }
  const eventKey='god8-sprite-events-v1';
  function logAlert(reason){
    let history=[];try{history=JSON.parse(localStorage.getItem(eventKey))||[]}catch(e){}
    if(!Array.isArray(history))history=[];
    const item={at:new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(new Date()),message:reason||'状态恢复正常'};
    history=[item,...history].slice(0,8);
    try{localStorage.setItem(eventKey,JSON.stringify(history))}catch(e){}
    document.getElementById('spriteEventRows').replaceChildren(...history.map(x=>element('p',`${x.at} · ${x.message}`)));
  }
  try{const previous=JSON.parse(localStorage.getItem(eventKey))||[];if(Array.isArray(previous))document.getElementById('spriteEventRows').replaceChildren(...previous.slice(0,8).map(x=>element('p',`${x.at} · ${x.message}`)))}catch(e){}
  function alertState(){
    const threshold=state?.alertAfter||10,wrong=state?chaseWrongStreak(state.rows,state.target):0;
    const reason=recordReason||healthReason||omissionReason||memoryReason||(state?.remaining>0&&wrong>=threshold?`连续未中 ${wrong} 期，已达到你设置的 ${threshold} 期提醒线`:null);
    launcher.dataset.alert=reason?'warning':'normal';box.dataset.alert=reason?'warning':'normal';
    launcher.setAttribute('aria-label',reason?'智能精灵预警：'+reason:'打开智能精灵，状态正常');
    document.getElementById('spriteAlert').textContent=reason?'● 预警 · '+reason:'● 正常 · 开奖同步与模拟记录正常';
    if(lastReason!==null&&lastReason!==reason)logAlert(reason);
    lastReason=reason||'';
  }
  window.chaseLiveHealth=live=>{
    lastLive=Date.now();healthReason='';
    if(!live.error){
      const lag=live.latency?.period===live.latest?.period&&live.latency?.blockToSavedSeconds!=null?`${Number(live.latency.blockToSavedSeconds).toFixed(1)}秒`:'待测量';
      const source=live.latest?.provisional?'目标块先行':'整期已入库';
      document.getElementById('spriteTelemetry').textContent=`链头 ${live.head??'—'} · 最新 ${live.latest?.issue??'—'} · ${source} · 区块到保存 ${lag}`;
    }
    if(live.error)healthReason=live.error;
    else if(live.newest?.single==null&&live.newest?.block>live.latest?.block)healthReason='最新期无有效号码，等待核对';
    else if(Number.isFinite(Date.parse(live.headSeenAt||''))&&live.serverEpochMs-Date.parse(live.headSeenAt)>12000)healthReason='链头超过12秒未更新，请检查采集服务';
    else if(live.nextTargetBlock!=null&&live.head>=live.nextTargetBlock){
      const seen=Date.parse(live.headSeenAt||'');
      if(live.head>=live.nextTargetBlock+2||(Number.isFinite(seen)&&live.serverEpochMs-seen>5000))healthReason='目标区块已出现，但新一期仍未入库';
    }
    alertState();
  };
  function renderPatternMemory(report){
    const view=spriteMemoryView(report,predictionStarted);
    const practice=report.practice||{};
    document.getElementById('spriteMemory').textContent=view.message;
    document.getElementById('spritePeriod').textContent=report.period?report.period.replace(/-/g,'').replace(':',' · 第')+'期':'等待最新期';
    document.getElementById('spritePracticeCount').textContent=practice.highFrequencyEpisodes??'—';
    document.getElementById('spriteLatest16').textContent=report.recent16?`${report.recent16.hits}/10`:'待核';
    document.getElementById('spritePracticeDetail').textContent=`历史密集段前4期见单0/单7：${practice.preceded07InFour??0} 段 · 仅作观察`;
    document.getElementById('spriteGaugeFill').style.width=report.recent16?`${report.recent16.hits*10}%`:'0%';
    memoryReason=view.reason;
    alertState();
  }
  window.chasePatternMemory=report=>{lastMemoryReport=report;renderPatternMemory(report);queueForecastToast(report)};
  window.chasePatternPending=()=>{
    lastMemoryReport=null;memoryReason='';
    document.getElementById('spriteMemory').textContent=predictionStarted?'新一期复刻仍在核对，暂不显示预判':'新一期复刻练习中；不生成预判';
    document.getElementById('spritePeriod').textContent=displayedPeriod.replace(/-/g,'').replace(':',' · 第')+'期 · 核对中';
    alertState();
  };
  function showPredictionSwitch(){
    predictionStarted=spritePredictEnabled;
    memoryPeriod='';nextMemoryRequest=0;
    setHomePredictionMode(predictionStarted);
    document.getElementById('spritePredictToggle').textContent=predictionStarted?'停止预判':'开始预判';
    document.getElementById('spritePredictToggle').setAttribute('aria-pressed',String(predictionStarted));
    document.getElementById('spriteMode').textContent=predictionStarted?'智能提醒已开启 · 两组预判自动运行':'智能提醒关闭 · 两组预判仍自动运行';
    box.dataset.mode=predictionStarted?'predict':'practice';launcher.dataset.mode=box.dataset.mode;
    if(!predictionStarted){forecastActive=null;forecastQueue=[];forecastToast.hidden=true}
    if(!predictionStarted&&lastMemoryReport)renderPatternMemory(lastMemoryReport);
    else{memoryReason='';document.getElementById('spriteMemory').textContent=predictionStarted?'读取当前期记忆中，暂不显示预判':'正在读取旧期到最新一期的复刻记录；仅复刻练习，不生成预判。';alertState()}
    lastMemoryReport=null;refreshPatternMemory();refreshLiveReplay();
  }
  // Only this switch writes its state. Refreshes, collector updates, the paper
  // chase and visits to other pages cannot start or stop prediction.
  document.getElementById('spritePredictToggle').onclick=()=>{
    applySpritePredictionMode(!spritePredictEnabled,true);showPredictionSwitch();
  };
  showPredictionSwitch();
  window.addEventListener('storage',event=>{
    if(event.key!==SPRITE_PREDICT_KEY)return;
    applySpritePredictionMode(event.newValue==='on');showPredictionSwitch();
  });
  window.addEventListener('pageshow',()=>{
    const saved=readSpritePredictionMode();
    if(saved!==spritePredictEnabled){applySpritePredictionMode(saved);showPredictionSwitch()}
  });
  const toast=document.getElementById('spriteToast'),storageKey='god8-sprite-overdue-ack-v2';
  let visibleEvents=[];
  function acknowledged(){try{const items=JSON.parse(localStorage.getItem(storageKey));return Array.isArray(items)?items:[]}catch(e){return []}}
  function saveAcknowledged(keys){try{localStorage.setItem(storageKey,JSON.stringify([...new Set([...acknowledged(),...keys])].slice(-64)))}catch(e){}}
  function closeToast(manual){
    if(manual)saveAcknowledged(visibleEvents.map(x=>x.key));
    toast.hidden=true;visibleEvents=[];clearTimeout(toastTimer);
  }
  document.getElementById('spriteToastClose').onclick=()=>closeToast(true);
  window.chaseOverdueNotice=report=>{
    const events=spriteOverdueEvents(report);
    omissionReason=!report.sourceComplete?'当日遗漏数据有缺期或无效结果，暂停超期提醒':
      events.length?events.map(x=>`单${x.single}遗漏${x.gap}期`).join('、')+' 已超期': '';
    alertState();
    if(!events.length)return;
    const known=new Set([...acknowledged(),...visibleEvents.map(x=>x.key)]);
    const fresh=events.filter(x=>!known.has(x.key));if(!fresh.length)return;
    visibleEvents.push(...fresh);
    const auto=spriteToastAutoClose(visibleEvents);
    document.getElementById('spriteToastTitle').textContent=visibleEvents.map(x=>`单${x.single}遗漏${x.gap}期（阈值${x.threshold}）`).join('、')+' · 已超期';
    document.getElementById('spriteToastHint').textContent=auto?'单0/单7提醒将在12秒后自动收起':'请点右上角 × 手动关闭此提醒';
    toast.hidden=false;clearTimeout(toastTimer);
    if(auto){saveAcknowledged(visibleEvents.map(x=>x.key));toastTimer=setTimeout(()=>closeToast(false),12000)}
  };
  function open(value){box.hidden=!value;launcher.setAttribute('aria-expanded',String(value));if(value)launcher.hidden=true;else launcher.hidden=false}
  launcher.onclick=()=>open(true);document.getElementById('chaseMinimize').onclick=()=>open(false);
  const windowLayoutKey='god8-sprite-window-v2';
  const saved=(()=>{try{return JSON.parse(localStorage.getItem(windowLayoutKey))||{}}catch(e){return {}}})();
  if(Number.isFinite(saved.x)&&Number.isFinite(saved.y)){box.style.left=Math.max(0,Math.min(saved.x,innerWidth-70))+'px';box.style.top=Math.max(0,Math.min(saved.y,innerHeight-60))+'px';box.style.right='auto';box.style.bottom='auto'}
  if(Number.isFinite(saved.w))box.style.width=Math.min(Math.max(saved.w,260),innerWidth)+'px';
  if(Number.isFinite(saved.h))box.style.height=Math.min(Math.max(saved.h,250),innerHeight)+'px';
  const persist=()=>{if(box.hidden)return;const r=box.getBoundingClientRect();try{localStorage.setItem(windowLayoutKey,JSON.stringify({x:r.left,y:r.top,w:r.width,h:r.height}))}catch(e){}};
  new ResizeObserver(persist).observe(box);
  const head=document.getElementById('chaseDrag');let drag=null;
  head.addEventListener('pointerdown',e=>{if(e.target.closest('button'))return;const r=box.getBoundingClientRect();drag={x:e.clientX-r.left,y:e.clientY-r.top};head.setPointerCapture(e.pointerId)});
  head.addEventListener('pointermove',e=>{if(!drag)return;box.style.left=Math.max(0,Math.min(e.clientX-drag.x,innerWidth-box.offsetWidth))+'px';box.style.top=Math.max(0,Math.min(e.clientY-drag.y,innerHeight-45))+'px';box.style.right='auto';box.style.bottom='auto'});
  head.addEventListener('pointerup',()=>{drag=null;persist()});head.addEventListener('pointercancel',()=>{drag=null;persist()});
  const grip=document.getElementById('chaseResize');let sizing=null;
  grip.addEventListener('pointerdown',e=>{const r=box.getBoundingClientRect();sizing={x:e.clientX,y:e.clientY,w:r.width,h:r.height};grip.setPointerCapture(e.pointerId);e.preventDefault()});
  grip.addEventListener('pointermove',e=>{if(!sizing)return;const r=box.getBoundingClientRect();box.style.width=Math.max(260,Math.min(sizing.w+e.clientX-sizing.x,innerWidth-r.left))+'px';box.style.height=Math.max(250,Math.min(sizing.h+e.clientY-sizing.y,innerHeight-r.top))+'px'});
  grip.addEventListener('pointerup',()=>{sizing=null;persist()});grip.addEventListener('pointercancel',()=>{sizing=null;persist()});
  function selection(){const target=document.getElementById('chaseTarget').value,periods=Number(document.getElementById('chasePeriods').value),alertAfter=Number(document.getElementById('chaseAlertAfter').value);if(!Number.isInteger(periods)||periods<1||periods>100)throw Error('期数须为1–100');if(!Number.isInteger(alertAfter)||alertAfter<1||alertAfter>100)throw Error('连错提醒须为1–100期');return {target,periods,alertAfter}}
  function show(){document.getElementById('chaseStop').hidden=!state;document.getElementById('chaseStart').disabled=!!state;if(state){document.getElementById('chaseTarget').value=state.target;document.getElementById('chaseAlertAfter').value=state.alertAfter||10;chaseRender(state.rows,state.target,`实时模拟：剩余 ${state.remaining} 期；按连续期号核对，缺期暂停。`)}alertState()}
  document.getElementById('chaseBacktest').onclick=async()=>{try{const {target,periods}=selection(),data=await get('/api/history?count=100');const rows=data.rows.slice(0,periods).reverse().map(r=>({issue:r.issue,single:r.single}));chaseRender(rows,target,`历史回看 ${rows.length}/${periods} 期（并非未来预测）；无效期不计入命中率。`)}catch(e){document.getElementById('chaseStatus').textContent=e.message}};
  document.getElementById('chaseStart').onclick=async()=>{try{const {target,periods,alertAfter}=selection(),live=await get('/api/live');const index=chaseIndex(live.newest?.period||live.latest?.period);if(index==null)throw Error('暂无期号，稍后重试');state={target,remaining:periods,nextIndex:index+1,alertAfter,rows:[]};recordReason='';chaseSave(state);show();open(true)}catch(e){document.getElementById('chaseStatus').textContent=e.message}};
  document.getElementById('chaseStop').onclick=()=>{state=null;recordReason='';try{localStorage.removeItem(CHASE_KEY)}catch(e){}document.getElementById('chaseStop').hidden=true;document.getElementById('chaseStart').disabled=false;document.getElementById('chaseStatus').textContent='已结束本次纸面追踪。';alertState()};
  async function update(){if(!state||state.remaining===0||busy||document.hidden)return;busy=true;try{
    const data=await get('/api/history?count=100'),byIndex=new Map(data.rows.map(r=>[chaseIndex(r.period),r]));let moved=false;
    const top=chaseIndex(data.rows[0]?.period);recordReason='';
    while(state.remaining>0){const row=byIndex.get(state.nextIndex);if(!row){if(top!=null&&top>state.nextIndex)recordReason='期号存在缺口，已暂停模拟核对';break}
      if(!Number.isInteger(row.single)||row.single<0||row.single>7){recordReason='待核期无有效号码，已暂停模拟核对';break}
      state.rows.push({issue:row.issue,single:row.single});state.nextIndex++;state.remaining--;moved=true;
    }
    if(moved){chaseSave(state);show()}alertState();
    if(state.remaining===0){chaseRender(state.rows,state.target,'本次模拟完成；可结束后重新开始。')}
  }catch(e){recordReason='模拟记录同步暂不可用';alertState();document.getElementById('chaseStatus').textContent='同步暂不可用：'+e.message}finally{busy=false}}
  show();setInterval(update,2500);setInterval(()=>{if(Date.now()-lastLive>15000){healthReason='超过15秒未收到开奖状态';alertState()}},3000);update();
}
let replayRequestPending=false;
async function refreshLiveReplay(){
  const state=document.getElementById('liveReplay');
  if(!state||document.hidden||replayRequestPending)return;
  replayRequestPending=true;
  const ReplayAbort=typeof AbortController==='function'?AbortController:null;
  const replayController=ReplayAbort?new ReplayAbort():null;
  let replayTimeout=null;
  try{
    const replayOptions={cache:'no-store'};
    if(replayController)replayOptions.signal=replayController.signal;
    const replayFetch=fetch('/api/replay/live',replayOptions);
    const replayResponse=typeof setTimeout==='function'
      ? await Promise.race([replayFetch,new Promise((_,reject)=>{replayTimeout=setTimeout(()=>{if(replayController)replayController.abort();reject(Error('预判查询超时'))},6500)})])
      : await replayFetch;
    if(!replayResponse.ok)throw Error('预判查询失败');
    const report=await replayResponse.json();
    const cards=document.getElementById('liveReplayChoices');
    const stats=document.getElementById('liveReplayStats');
    const f=report.forecast,latest=report.latest;
    const n=report.stats?.verified||0;
    stats.textContent=n?`已核对 ${n} 期 · 第一项 ${pct(report.stats.firstRate)} · 第二项 ${pct(report.stats.secondRate)} · 任一项 ${pct(report.stats.eitherRate)}`:'真实开奖核对：暂无有效样本';

    // v2.0.20: prediction is a strict passenger of the same 60-second draw clock.
    // Never advance from an old result. At a new issue boundary, wait until the
    // exact new issue is really stored; a late result may take as long as needed.
    if(!clockSynced){
      cards.replaceChildren();delete cards.dataset.targetBlock;delete cards.dataset.period;
      state.hidden=false;state.classList.remove('analyzing');state.textContent='正在同步开奖时钟，请稍等…';
      return;
    }
    const gate=predictionDisplayGate(latest?.issue),cycle=gate.cycle;
    if(gate.delayed){
      cards.replaceChildren();delete cards.dataset.targetBlock;delete cards.dataset.period;
      state.hidden=false;state.classList.remove('analyzing');
      state.textContent='开奖结果延迟获取中，请稍等…';
      return;
    }

    // Result window: from the new 60-second cycle down through 46 seconds.
    // Only the prediction judged by this exact issue may remain on screen.
    if(gate.resultWindow){
      if(f&&f.settledAt&&f.issue===cycle.current&&Array.isArray(f.choices)){
        state.hidden=true;state.classList.remove('analyzing');
        delete cards.dataset.targetBlock;cards.dataset.period=f.period;
        cards.replaceChildren(...f.choices.map((single,i)=>{
          const hit=f.actual===single;
          const item=element('article','','prediction-result-card '+(hit?'hit':'settled'));
          item.dataset.single=String(single);
          const adaptiveOnly=f.match?.selectionPolicy==='adaptive-no-exact-replay';
          const mode=adaptiveOnly?'趋势 / 遗漏':(i===0?'历史复现':(f.match?.secondCandidateMode==='adaptive'?'趋势补位':'历史复现'));
          const head=element('div','','prediction-result-head');
          head.append(element('span',i===0?'预判一':'预判二','prediction-result-title'),element('em',mode,'prediction-mode-badge'));
          const value=element('strong','单'+single,'prediction-result-value');
          const footer=element('div','','prediction-result-footer');
          footer.append(element('span',f.actual==null?'等待有效结果':hit?'✓ 命中':'未命中',hit?'prediction-hit-label':'prediction-miss-label'));
          item.append(head,value,footer);return item;
        }));
      }else{
        cards.replaceChildren();delete cards.dataset.targetBlock;delete cards.dataset.period;
        state.hidden=false;state.classList.remove('analyzing');
        state.textContent='本期开奖结果已获取 · 正在核对上一期预判';
      }
      return;
    }

    // Forecast window: countdown 45..01. Only the forecast for the clock's next
    // issue may display; settled cards from the previous issue are forbidden.
    if(f&&!f.settledAt&&f.issue===cycle.next&&Array.isArray(f.choices)){
      if(f.targetBlock!=null&&window.god8ObservedHead!=null&&window.god8ObservedHead>=Number(f.targetBlock)){
        cards.replaceChildren();delete cards.dataset.targetBlock;delete cards.dataset.period;
        state.hidden=false;state.classList.remove('analyzing');state.textContent='开奖结果延迟获取中，请稍等…';
        return;
      }
      state.classList.remove('analyzing');state.hidden=false;
      state.textContent=`${f.issue} 期 · 两组预判已锁定`;
      if(f.targetBlock!=null)cards.dataset.targetBlock=String(f.targetBlock);else delete cards.dataset.targetBlock;
      cards.dataset.period=f.period;
      cards.replaceChildren(...f.choices.map((single,i)=>{
        const item=element('article','','prediction-result-card pending');item.dataset.single=String(single);
        const adaptiveOnly=f.match?.selectionPolicy==='adaptive-no-exact-replay';
        const mode=adaptiveOnly?'趋势 / 遗漏':(i===0?'历史复现':(f.match?.secondCandidateMode==='adaptive'?'趋势补位':'历史复现'));
        const head=element('div','','prediction-result-head');
        head.append(element('span',i===0?'预判一':'预判二','prediction-result-title'),element('em',mode,'prediction-mode-badge'));
        const value=element('strong','单'+single,'prediction-result-value');
        const footer=element('div','','prediction-result-footer');
        const reason=f.match?.reasons?.[String(single)]||[];
        footer.append(element('span',reason.length?reason.slice(0,1).join(''):'等待开奖核对','prediction-evidence'));
        item.append(head,value,footer);return item;
      }));
      return;
    }

    cards.replaceChildren();delete cards.dataset.targetBlock;delete cards.dataset.period;
    state.hidden=false;
    const rs=report.runtime?.status||'';
    const analyzing=report.phase==='analyzing'||rs==='analyzing'||rs==='simulating'||rs==='locked';
    state.classList.toggle('analyzing',analyzing);
    state.textContent=analyzing?'正在生成新一期预判':'正在准备新一期预判';
  }catch(e){state.textContent='预判暂时无法读取；正在自动重试。'}
  finally{if(replayTimeout!==null&&typeof clearTimeout==='function')clearTimeout(replayTimeout);replayRequestPending=false}
}

function renderStreaks(report,id){
  const box=document.getElementById(id);if(!box)return;
  if(report?.schemaVersion!=='chase-v2'||!Array.isArray(report?.conditions)||!report.conditions.length){box.textContent='当前无可核对的历史连续记录。';return}
  const c=report.current||{};
  const head=element('p',`最近期 ${report.lastPeriod||'—'} · 单3/4连出 ${c.run34??0} 期 · 单2/5未出 ${c.gap25??0} 期 · 单1/6未出 ${c.gap16??0} 期 · 单0/7未出 ${c.gap07??0} 期`,'regime-current');
  const cards=element('div','','regime-grid');
  for(const condition of report.conditions){
    const card=element('article','','regime-item'+(condition.active?' active':''));
    card.append(element('strong',condition.title+(condition.active?' · 当前触发':'')));
    card.append(element('small',`独立触发 ${condition.samples} 段（有效结果 ${report.periods} 期）`));
    for(const group of id==='streakFeedback'?(condition.groups||[]).slice(0,2):(condition.groups||[])){
      if(!group||typeof group!=='object')continue;
      const h=group.chase?.['30'];
      card.append(element('span',`${group.target} 首次出现：已观察 ${group.firstHitsObserved}/${condition.samples} 段；仍未出现 ${group.notYetHit} 段；已命中等待中位数 ${group.medianFirstHit??'—'} 期`));
      if(h)card.append(element('span',`追踪30期：${h.hits}/${h.eligible} 可验证段${h.unresolved?'（另有 '+h.unresolved+' 段未结）':''} · ${h.rate==null?'尚无足够观察期':pct(h.rate)}，随机起点基线 ${pct(h.baseline)} · ${h.verdict}`));
      if(id==='streakResearch'){
        const horizons=Object.keys(group.chase||{}).filter(x=>x!=='30'&&/^\d+$/.test(x)).sort((a,b)=>Number(a)-Number(b));
        if(!horizons.length)card.append(element('small','该条件尚无追踪窗口数据。'));
        for(const horizon of horizons){
          const item=group.chase[horizon];
          if(!item.eligible)card.append(element('small',`追踪${horizon}期：0段可验证 · ${item.unresolved??0}段未结；尚无完整观察期。`));
          else card.append(element('small',`追踪${horizon}期：${item.hits}/${item.eligible} 可验证 · ${item.unresolved} 段未结 · 原始比率 ${pct(item.rate)}${item.eligible<100?'（样本不足）':''}（基线 ${pct(item.baseline)}）`));
        }
      }
    }
    cards.append(card);
  }
  box.replaceChildren(head,cards);
}
function renderPatterns(report,id){
  const box=document.getElementById(id);if(!box)return;
  if(!report||!report.sample){box.textContent='暂时没有可统计的历史记录。';return}
  const lines=[];
  if(report.exact){const e=report.exact;lines.push(element('p',`最长相同前缀：${e.sequence.join('')}（${e.length}期），历史出现 ${e.samples} 次；后继 ${e.counts.map((n,i)=>n?`单${i} ${n}次`:null).filter(Boolean).join('、')}。`))}
  else lines.push(element('p','当前连续有效期内尚未找到相同的历史序列。'));
  if(report.supported){const a=report.supported;lines.push(element('p',`达到至少${report.minimumSupport}次的复现：${a.sequence.join('')}，历史后继 ${a.samples} 次；单1/6合计 ${pct(a.group16)}。`))}
  else lines.push(element('p','较长前缀没有足够历史样本；本次不把一次巧合用作首名概率。'));
  if(id==='patternResearch'){
    for(const k of [1,6,0,7]){
      const item=report.omissions?.find(x=>x.single===k);if(!item)continue;
      lines.push(element('p',`单${k} 当前连续遗漏 ${item.currentGap??'未能核对'} 期；历史已完成最长间隔 ${item.historicalMaxCompleted??'—'} 期；到达当前遗漏长度的旧间隔 ${item.atRisk} 段，下一期结束遗漏 ${item.nextHits} 段${item.nextRate==null?'（样本不足）':'（'+pct(item.nextRate)+'，仅为历史条件比例）'}。`));
    }
  }
  lines.push(element('small','长序列匹配往往样本很少；没有“最高遗漏后必出”的期限。预测成效只看后续开奖前锁定的独立期。','muted'));
  box.replaceChildren(...lines);
}
let homeRecentRows=[],homeRecentPage=1;
function renderHomeRecent(){
  const box=document.getElementById('recent');if(!box)return;
  const pages=Math.max(1,Math.ceil(homeRecentRows.length/20));
  homeRecentPage=Math.min(Math.max(1,homeRecentPage),pages);
  const begin=(homeRecentPage-1)*20;
  box.replaceChildren(...homeRecentRows.slice(begin,begin+20).map(x=>{const item=element('span',x.issue,'chip');item.append(element('b',x.single==null?'待核':'单'+x.single));return item}));
  const label=document.getElementById('recentPageLabel'),prev=document.getElementById('recentPrev'),next=document.getElementById('recentNext');
  if(label)label.textContent=`${homeRecentPage} / ${pages}`;
  if(prev)prev.disabled=homeRecentPage<=1;
  if(next)next.disabled=homeRecentPage>=pages;
}
function changeHomeRecent(delta){homeRecentPage+=delta;renderHomeRecent()}
async function refreshHome(){
  const [recentResult,omissionResult,detailResult]=await Promise.allSettled([
    get('/api/history?count=100&page=1'),get('/api/omission'),get('/api/omission/detail')]);
  if(recentResult.status==='fulfilled'){
    const a=recentResult.value;homeRecentRows=Array.isArray(a.rows)?a.rows:[];
    const latest=homeRecentRows[0];showLatest(latest);renderHomeRecent();
  }
  const strip=document.getElementById('homeOmission');
  if(strip&&omissionResult.status==='fulfilled'){
    const gaps=omissionResult.value;
    strip.replaceChildren(...Array.from({length:8},(_,i)=>{
      const item=element('span','','home-omission-item');
      item.append(element('small','单'+i),element('b',String(gaps.values?.[i]??0)));return item;
    }));
  }else if(strip)strip.textContent='遗漏暂时无法读取';
  const overdue=document.getElementById('todayOverdueSummary');
  if(detailResult.status==='fulfilled')window.god8SafetyNotice?.(detailResult.value);
  if(overdue&&detailResult.status==='fulfilled'){
    const items=(detailResult.value.items||[]).filter(x=>x.single>=2&&x.single<=5);
    overdue.replaceChildren(...items.map(x=>{
      const button=element('button','','compact-overdue-item');button.type='button';button.onclick=()=>showTodayOverdue(x.single);
      button.append(element('small','单'+x.single),element('strong',`${x.overdueCount??0}次`),element('span',x.gap==null?'当前遗漏 —':`当前遗漏 ${x.gap}期`));return button;
    }));
  }else if(overdue)overdue.textContent='今日超期暂时无法读取';
}
const RED=new Set([1,2,7,8,12,13,18,19,23,24,29,30,34,35,40,45,46]);
const BLUE=new Set([3,4,9,10,14,15,20,25,26,31,36,37,41,42,47,48]);
const ZODIAC=['马','蛇','龙','兔','虎','牛','鼠','猪','狗','鸡','猴','羊'];
function ball(number,issue){
  const n=Number(number), wrapper=element('span','', 'ball-wrap');
  if(!Number.isInteger(n)||n<1||n>49){wrapper.append(element('b','--','ball'));return wrapper}
  const color=RED.has(n)?'red':BLUE.has(n)?'blue':'green';
  wrapper.append(element('b',String(n).padStart(2,'0'),'ball '+color));
  const year=issue&&/^\d{10}$/.test(issue)?2000+Number(issue.slice(0,2)):2026;
  const zodiac=ZODIAC[((n-1-(year-2026))%12+12)%12];
  wrapper.append(element('small',zodiac,'zodiac'));return wrapper;
}
function ballsWithSeparator(numbers,issue){
  const all=[];for(let i=0;i<7;i++){
    if(i===6)all.push(element('span','｜','ball-separator'));
    all.push(ball(numbers?.[i],issue));
  }return all;
}
const OMIT_LIMITS=[200,30,10,7,7,10,30,200];
function renderOmissionAlerts(gaps){
  const box=document.getElementById('omissionAlerts');if(!box)return;
  const warnings=gaps.values.flatMap((gap,k)=>{
    if(gap==null)return [];
    const threshold=OMIT_LIMITS[k];
    const level=gap>threshold?'超期':gap>=threshold*.8?'接近阈值':null;
    return level?[element('span',`单${k} ${level}：遗漏${gap}期（阈值>${threshold}期）`,'alert-tag '+(level==='超期'?'alert-high':''))]:[];
  });
  const pending=gaps.values.map((gap,i)=>gap==null?'单'+i:null).filter(Boolean);
  box.replaceChildren(...(warnings.length?warnings:[element('span','已核对类别暂无遗漏阈值提示','alert-clear')]),
    ...(pending.length?[element('span',pending.join('、')+' 尚无法确定准确遗漏；请核对缺期或无效结果。','alert-data')]:[]));
}
let clockDelta=0,clockOffset=-3,clockSynced=false;
async function syncClock(){try{const began=Date.now(),c=await get('/api/clock'),ended=Date.now();clockDelta=c.serverEpochMs-(began+ended)/2;clockOffset=c.displayOffsetSeconds??-3;clockSynced=true;return true}catch(e){return clockSynced}}
function tickClock(){
  const now=Date.now()+clockDelta;
  const time=new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).format(new Date(now));
  document.querySelectorAll('.cnNow').forEach(x=>x.textContent=time);
  const countdown=document.getElementById('roundCountdown');
  if(countdown){const adjusted=Math.floor(now/1000)+clockOffset;
    const elapsed=((adjusted%60)+60)%60;
    countdown.textContent=String(60-elapsed).padStart(2,'0');
  }
}
syncClock().then(tickClock);setInterval(tickClock,1000);setInterval(syncClock,30000);
let page=1,historyCount='30',searching=false;
function drawRow(x){
  const tr=document.createElement('tr');if(x.center)tr.className='selected-issue';
  const issue=element('td','');issue.append(element('b',x.issue,'issue-label'));
  const result=element('td','');
  if(x.missing||x.single==null){result.textContent=x.missing?'本期未入库':'无有效号码（核对平台）'}
  else{
    const toggle=element('button','单'+x.single+'　∨','single-toggle');toggle.type='button';
    const detail=element('div','','draw-details');detail.hidden=true;
    detail.append(element('small',x.block==null?'区块：待核对':'区块：'+x.block,'issue-block'));
    if(Array.isArray(x.numbers)){
      const line=element('div','','row-balls');line.append(...ballsWithSeparator(x.numbers,x.issue));detail.append(line);
    }else detail.append(element('span','号码缺失，待核对'));
    toggle.setAttribute('aria-expanded','false');
    toggle.onclick=()=>{detail.hidden=!detail.hidden;toggle.setAttribute('aria-expanded',String(!detail.hidden));toggle.textContent='单'+x.single+(detail.hidden?'　∨':'　∧')};
    result.append(toggle,detail);
  }
  tr.append(issue,result);return tr;
}
async function loadHistory(p){
  try{
    if(p<1)return;
    searching=false;const a=await get('/api/history?page='+p+'&count='+encodeURIComponent(historyCount));page=p;
    document.getElementById('history').replaceChildren(...a.rows.map(drawRow));
    document.getElementById('historyTitle').textContent='历史开奖记录';
    document.getElementById('paging').textContent=`第 ${a.page} 页 / ${Math.max(1,Math.ceil(a.total/a.pageSize))} 页；显示 ${a.total} / 已保存 ${a.stored} 期`;
    document.getElementById('prev').disabled=a.page<=1;
    document.getElementById('next').disabled=a.page*a.pageSize>=a.total;
  }catch(e){showError('paging',e)}
}
function chooseCount(value){
  historyCount=String(value);document.querySelectorAll('[data-count]').forEach(b=>b.classList.toggle('active',b.dataset.count===historyCount));
  document.getElementById('searchMessage').textContent='';loadHistory(1);
}
async function searchIssue(event){
  event.preventDefault();const issue=document.getElementById('searchIssue').value.trim();
  try{
    const response=await fetch('/api/history/search?issue='+encodeURIComponent(issue));
    const a=await response.json();if(!response.ok)throw Error(a.error||'搜索失败');
    searching=true;document.getElementById('history').replaceChildren(...a.rows.map(drawRow));
    document.getElementById('historyTitle').textContent='期号 '+a.center+' 的上下十期';
    document.getElementById('paging').textContent='共21个期号位置，缺失期单独标出';
    document.getElementById('prev').disabled=true;document.getElementById('next').disabled=true;
    document.getElementById('searchMessage').textContent='已定位 '+a.center;
  }catch(e){showError('searchMessage',e)}
}
async function loadOmissionDetail(){
  try{const a=await get('/api/omission/detail');
    const rows=a.items.map(x=>{const tr=document.createElement('tr');
      tr.append(...['单'+x.single,x.count,x.gap+'期',x.lastIssue||'今日未见'].map(t=>element('td',t)));
      const runCell=element('td','');const button=element('button',(x.longest?.length??0)+'期　查看','run-link');
      button.type='button';button.onclick=()=>showOmissionRun(x.single);runCell.append(button);
      const overdueCell=element('td','');const overdueButton=element('button',`${x.overdueCount??0}段　查看`,'run-link');
      overdueButton.type='button';overdueButton.onclick=()=>showTodayOverdue(x.single);overdueCell.append(overdueButton);
      tr.append(runCell,overdueCell,element('td',x.level));
      if(x.level==='超期')tr.className='warning-row';return tr});
    document.getElementById('omissionRows').replaceChildren(...rows);
    document.getElementById('omissionDetailNote').textContent=`${a.day} 已保存 ${a.sample} 期，其中有效 ${a.valid??0} 期；今天八类合计出现 ${a.overdueTotal??0} 段超期。${a.note}`;
  }catch(e){showError('omissionDetailNote',e)}
}
async function loadRetainedOmission(){
  try{
    const a=await get('/api/omission/retained');
    document.getElementById('retainedOmissionRows').replaceChildren(...a.items.map(x=>{
      const tr=element('tr','');
      tr.append(...['单'+x.single,x.count,x.gap+'期',x.lastIssue||'留存期未见'].map(v=>element('td',v)));
      const cell=element('td',''),button=element('button',`${x.longest.length}期　查看`,'run-link');
      button.type='button';button.onclick=()=>showRetainedRun(x.single,1);cell.append(button);
      tr.append(cell,element('td',x.level));if(x.level==='超期')tr.className='warning-row';return tr;
    }));
    const missingSamples=(a.missingRanges||[]).map(x=>`${x.firstIssue}–${x.lastIssue}（${x.count}期）`).join('、');
    document.getElementById('retainedOmissionNote').textContent=
      `${a.oldestIssue||'—'} 至 ${a.newestIssue||'—'}，已保存 ${a.sample} 期，其中有效 ${a.valid} 期、缺失 ${a.missing} 期、号码无效 ${a.invalid} 期。遗漏仅按有效开奖记录顺序计算。${missingSamples?'缺期示例：'+missingSamples+'。':''}${a.invalidIssues?.length?'无效示例：'+a.invalidIssues.join('、')+'。':''}${a.note||''}`;
  }catch(e){showError('retainedOmissionNote',e)}
}
async function showRetainedRun(single,page){
  const box=document.getElementById('retainedRunDetail');box.hidden=false;box.replaceChildren(element('p','正在读取跨天遗漏区间…'));
  try{
    const a=await get(`/api/omission/retained/run?single=${single}&page=${page}`);
    const title=element('h3',`单${single} 留存期最长遗漏：${a.length}期`);
    const span=element('p',a.length?`${a.startIssue} — ${a.endIssue}${a.active?'（尚未结束）':'；下一次出现于 '+a.endedBy}`:'没有遗漏区间');
    const warning=element('p',a.sourceComplete?'每页最多100期；遗漏长度按有效开奖记录计算。':'该区间含缺失或无效记录；它们仅展示，不参与遗漏期数。','muted');
    const counts=element('div','','run-counts');counts.append(...a.counts.map((n,i)=>element('span',`单${i}：${n}次`,'chip')));
    const sequence=element('div','','run-sequence');sequence.append(...a.rows.map(x=>element('span',x.issue+'　'+(x.missing?'缺期':x.single==null?'无效号码':'单'+x.single),'chip')));
    const pagination=element('div','','history-pager');const prev=element('button','上一页'),next=element('button','下一页');
    prev.disabled=page<=1;next.disabled=page>=a.totalPages;prev.onclick=()=>showRetainedRun(single,page-1);next.onclick=()=>showRetainedRun(single,page+1);
    pagination.append(prev,element('span',`第 ${a.page}/${Math.max(1,a.totalPages)} 页`),next);
    box.replaceChildren(title,span,warning,counts,sequence,pagination);
    box.scrollIntoView({behavior:'smooth',block:'nearest'});
  }catch(e){box.textContent='跨天遗漏详情读取失败：'+e.message}
}
async function showOmissionRun(single){
  const box=document.getElementById('omissionRunDetail');box.hidden=false;box.replaceChildren(element('p','正在读取遗漏详情…'));
  try{
    const a=await get('/api/omission/run?single='+single);
    const title=element('h3',`单${single} 今日最长遗漏：${a.length}期`);
    const span=element('p',a.length?`${a.startIssue} — ${a.endIssue}${a.active?'（进行中）':'；下一次出现于 '+a.endedBy}`:'今天没有遗漏区间');
    const counts=element('div','','run-counts');
    counts.append(...a.counts.map((n,i)=>element('span',`单${i}：${n}次`,'chip')));
    const table=element('div','','run-sequence');
    table.append(...a.rows.map(x=>element('span',x.issue+'　'+(x.missing?'缺期':x.single==null?'未标记':'单'+x.single),'chip')));
    box.replaceChildren(title,span,counts,table);
    box.scrollIntoView({behavior:'smooth',block:'nearest'});
  }catch(e){box.textContent='遗漏详情读取失败：'+e.message}
}
async function showTodayOverdue(single,page=1){
  const box=document.getElementById('todayOverdueDetail');box.hidden=false;box.replaceChildren(element('p','正在读取超期详情…'));
  try{
    const a=await get(`/api/omission/today/overdue?single=${single}&page=${page}`);
    const list=element('div','','overdue-list');
    list.append(...(a.events.length?a.events.map((x)=>{
      const card=element('article','','overdue-item');
      card.append(element('strong',`${x.startIssue} — ${x.endIssue} · 超出阈值${x.excess}期（最长遗漏${x.peakGap}期）`),
        element('span',x.active?'进行中；尚未结束':`结束于 ${x.endedBy}，该期出现单${single}`));return card;
    }):[element('p',a.count?'该页暂无记录':'今天还没有超过阈值的遗漏段')]));
    const paging=element('div','','history-pager'),before=element('button','上一页'),after=element('button','下一页');
    before.disabled=page<=1;after.disabled=page>=a.totalPages;
    before.onclick=()=>showTodayOverdue(single,page-1);after.onclick=()=>showTodayOverdue(single,page+1);
    paging.append(before,element('span',`第 ${page}/${Math.max(1,a.totalPages)} 页，共 ${a.count} 段`),after);
    box.replaceChildren(element('h3',`单${single} 今天超期 ${a.count} 段（阈值>${a.threshold}期）`),list,paging,element('small',a.note,'muted'));
    box.scrollIntoView({behavior:'smooth',block:'nearest'});
  }catch(e){box.textContent='超期详情读取失败：'+e.message}
}
async function loadChaseAdvice(){
  const box=document.getElementById('chaseAdvice');
  try{const a=await get('/api/omission/chase');box.replaceChildren(...a.items.map(x=>{
    const card=element('article','','chase-item');
    card.append(element('strong',`单${x.single} · 当前遗漏 ${x.currentGap} 期`),
      element('span',`旧遗漏段达此长度：${x.episodes}段；之后10期出现：${x.hits}段（${pct(x.rate)}）`),
      element('small',`普通历史10期出现比例：${pct(x.baseline)}；${x.status}`));return card;
  }));document.getElementById('chaseNote').textContent=a.note;
  }catch(e){box.textContent='遗漏历史对比读取失败：'+e.message}
}
function initHistoryPage(){
  document.getElementById('historyCounts').addEventListener('click',e=>{const b=e.target.closest('[data-count]');if(b)chooseCount(b.dataset.count)});
  document.getElementById('countForm').addEventListener('submit',e=>{e.preventDefault();const input=document.getElementById('customCount');if(input.reportValidity())chooseCount(input.value)});
  document.getElementById('issueSearch').addEventListener('submit',searchIssue);
  document.getElementById('clearSearch').onclick=()=>{document.getElementById('searchMessage').textContent='';loadHistory(1)};
  loadHistory(1);
}

async function initStatisticsPage(){
  loadRetainedOmission();loadOmissionDetail();loadChaseAdvice();
  try{
    const [report,gaps]=await Promise.all([get('/api/statistics/research'),get('/api/omission')]);
    document.getElementById('statsOverview').textContent=`连续与序列报告：已保存最近 ${report.sample} 期；最近期 ${displayValue(report.streaks?.lastPeriod)||'—'}。统计基于现有历史，没有运行 AI 训练。`;
    renderStreaks(report.streaks,'streakResearch');
    renderPatterns(report.patterns,'patternResearch');
    renderOmissionAlerts(gaps);
  }catch(e){showError('statsOverview',e)}
}

const PLAY_OPTIONS={single:Array.from({length:8},(_,n)=>String(n)),number:Array.from({length:49},(_,n)=>String(n+1)),tail:Array.from({length:10},(_,n)=>String(n)),head:Array.from({length:5},(_,n)=>String(n)),wave:['红波','蓝波','绿波'],parity:['单','双'],size:['小','大']};
let blockTailHistoryPage=1,blockTailHistoryRequest=0;
function initPlaybookPage(){
  const form=document.getElementById('playbookForm');
  const tailForm=document.getElementById('blockTailForm');
  tailForm.addEventListener('submit',e=>{e.preventDefault();loadBlockTailOdds()});
  document.getElementById('blockTailPrev').onclick=()=>loadBlockTailHistory(blockTailHistoryPage-1);
  document.getElementById('blockTailNext').onclick=()=>loadBlockTailHistory(blockTailHistoryPage+1);
  const sync=()=>{
    if(form.elements.mode.value==='single')form.elements.kind.value='single';
    else if(form.elements.kind.value==='single')form.elements.kind.value='wave';
    const single=form.elements.mode.value==='single';
    for(const name of ['wave','parity','size']){
      form.elements[name].disabled=single;
      if(single)form.elements[name].value='';
    }
    const options=PLAY_OPTIONS[form.elements.kind.value];
    const selected=form.elements.value.value;
    form.elements.value.replaceChildren(...options.map(x=>{const o=element('option',form.elements.kind.value==='number'?x.padStart(2,'0'):x);o.value=x;return o}));
    if(options.includes(selected))form.elements.value.value=selected;
  };
  form.elements.mode.onchange=sync;form.elements.kind.onchange=sync;
  form.addEventListener('submit',e=>{e.preventDefault();loadPlaybook()});
  sync();loadPlaybook();loadBlockTailOdds();
}
async function loadBlockTailOdds(){
  const input=document.getElementById('blockTailInput');
  const summary=document.getElementById('blockTailSummary');
  const body=document.getElementById('blockTailRows');
  const note=document.getElementById('blockTailNote');
  const tail=Number(input.value);
  if(!/^\d$/.test(input.value)||!Number.isInteger(tail)){
    summary.textContent='请输入0至9的整数尾数';body.replaceChildren();
    blockTailHistoryRequest++;
    document.getElementById('blockTailHistory').replaceChildren();return;
  }
  loadBlockTailHistory(1);
  summary.textContent='正在读取该尾历史…';body.replaceChildren();
  try{
    const report=await get('/api/playbook/block-tail?tail='+tail);
    const bridge=report.legacyBridge||{};
    summary.textContent=`${tail}尾原始区块 · 新旧库合并共 ${report.totalBlocks} 个 · 本次统计最新 ${report.stored} 个（有效 ${report.valid}、无效 ${report.invalid}） · 最近区块 ${report.lastBlock??'暂无'}`+
      (bridge.legacyOnlyInSample?` · 已读取旧库 ${bridge.legacyOnlyInSample} 个，本次转入新库 ${bridge.materializedNow||0} 个`:``);
    const version=document.getElementById('blockTailVersionStatus');
    const synced=report.collectorVersion===report.webVersion;
    const mapping=report.currentMapping;
    version.textContent=`当前期 ${mapping?.issue??'—'} · 对应区块 ${mapping?.targetBlock??'—'}（${mapping?.tail??'—'}尾）。`+
      (synced?'Web 与采集服务代码版本一致；历史期号校准由采集服务后台执行。':`采集服务${report.collectorVersion||'尚未报告版本'}；Web ${report.webVersion}，请等待采集服务完成部署。`);
    version.dataset.state=synced?'ready':'pending';
    body.replaceChildren(...report.items.map(item=>{
      const tr=document.createElement('tr');
      [`单${item.single}`,`${pct(item.hitRate)} · ${item.hits}个`,pct(item.missRate),
       item.gap==null?'待核':`${item.gap}个`,
       item.historicalGapReachRate==null?'样本不足':`${pct(item.historicalGapReachRate)} · ${item.completedRuns}段`
      ].forEach(value=>tr.append(element('td',value)));
      return tr;
    }));
    note.textContent=report.note;
  }catch(e){summary.textContent='尾数查询失败：'+e.message;note.textContent='';}
}
async function loadBlockTailHistory(page){
  const tail=Number(document.getElementById('blockTailInput').value);
  if(!Number.isInteger(tail)||tail<0||tail>9||page<1)return;
  const status=document.getElementById('blockTailHistoryStatus');
  const box=document.getElementById('blockTailHistory');
  const previous=document.getElementById('blockTailPrev');
  const next=document.getElementById('blockTailNext');
  const request=++blockTailHistoryRequest;
  previous.disabled=next.disabled=true;
  status.textContent=`正在读取${tail}尾第 ${page} 页…`;
  try{
    const report=await get(`/api/playbook/block-tail/history?tail=${tail}&page=${page}`);
    if(request!==blockTailHistoryRequest)return;
    blockTailHistoryPage=report.page;
    box.replaceChildren(...report.rows.map(row=>{
      const card=document.createElement('details');card.className='tail-history-item';
      const summary=document.createElement('summary');
      summary.append(element('span',`区块 ${row.block}`),
        element('b',row.single==null?'无效结果':`单${row.single}`));
      card.append(summary,element('small',row.issue?`对应开奖 ${row.issue}`:row.legacySource?'旧库原始区块 · 已按哈希计算':'组内原始区块'));
      if(Array.isArray(row.numbers))card.append(element('p',row.numbers.map(n=>String(n).padStart(2,'0')).join(' · '),'tail-history-numbers'));
      return card;
    }));
    if(!report.rows.length)box.textContent='暂无该尾原始区块记录';
    const migrated=report.legacyBridge?.materializedNow||0;
    status.textContent=`${tail}尾原始区块 · 新旧库合并共 ${report.total} 个`+(migrated?` · 本页已转入新库 ${migrated} 个`:``);
    document.getElementById('blockTailPageLabel').textContent=`${report.page} / ${report.pages}`;
    previous.disabled=report.page<=1;
    next.disabled=report.page>=report.pages;
  }catch(e){if(request===blockTailHistoryRequest){status.textContent='历史读取失败：'+e.message;box.replaceChildren();}}
}
function initReplayPage(){
  document.getElementById('replayRefresh').onclick=loadHistoricalReplay;
  document.getElementById('labRefresh').onclick=loadLabBacktest;
  loadHistoricalReplay();loadLabBacktest();loadLabLive();setInterval(loadLabLive,4000);
}
async function loadLabLive(){
  const box=document.getElementById('labLive');if(!box||document.hidden)return;
  try{
    const a=await get('/api/replay/lab/live'),f=a.forecast;
    box.textContent=f?`${f.issue} 期 · 历史双候选 单${f.choices[0]}、单${f.choices[1]} · 自适应单码 单${f.aiPrediction}（${f.methodName}）${f.settledAt?' · 开奖单'+(f.actual??'无有效结果'):' · 开奖前已锁定'}`:'等待下一期的开奖前锁定预判';
    document.getElementById('labLiveStats').textContent=`真实核对 ${a.verified} 期 · 第一位 ${a.first.hits}/${a.verified}（${pct(a.first.rate)}） · 第二位 ${a.second.hits}/${a.verified}（${pct(a.second.rate)}） · 整体任一 ${a.either.hits}/${a.verified}（${pct(a.either.rate)}） · 自适应单码 ${a.ai.hits}/${a.verified}（${pct(a.ai.rate)}）`;
  }catch(e){box.textContent='真实核对暂不可用：'+e.message}
}
async function loadLabBacktest(){
  const summary=document.getElementById('labSummary'),button=document.getElementById('labRefresh');
  summary.textContent='正在逐期比较历史方法…';button.disabled=true;
  try{
    const a=await get('/api/replay/lab?window='+document.getElementById('labWindow').value);
    summary.textContent=`历史逐期核对 ${a.evaluated} 期：第一位 ${a.first.hits}/${a.evaluated}（${pct(a.first.rate)}），第二位 ${a.second.hits}/${a.evaluated}（${pct(a.second.rate)}），整体任一 ${a.either.hits}/${a.evaluated}（${pct(a.either.rate)}），自适应单码 ${a.ai.hits}/${a.evaluated}（${pct(a.ai.rate)}）。`;
    document.getElementById('labMethods').replaceChildren(...a.methods.map(m=>{
      const card=element('article','','lab-method');
      card.append(element('strong',m.name),element('span',`${m.hits}/${m.evaluated} · ${pct(m.rate)}`));return card;
    }));
    const insight=a.insight;
    document.getElementById('labInsight').textContent=insight?`当前自适应方法：${insight.name}；最近 ${insight.recentVerified} 次该方法可验证时命中 ${insight.recentHits} 次（${pct(insight.recentRate)}）。本次历史范围换法 ${insight.switches.length} 条可见记录；${insight.reason}`:'历史不足，暂不能比较方法。';
    document.getElementById('labSwitches').replaceChildren(...(insight?.switches||[]).map(x=>element('span',`${x.issue}：${x.from} → ${x.to}`,'chip')));
    document.getElementById('labPreview').textContent=a.preview?`库内下一期 ${a.preview.issue}：双候选 单${a.preview.predictions[0]}、单${a.preview.predictions[1]}；自适应单码 单${a.preview.aiPrediction}，方法 ${a.preview.aiMethod}。仅作预览，实时有效性看上方“开奖前锁定”。`:'连续样本不足，没有下一期预览。';
    document.getElementById('labRows').replaceChildren(...a.recent.map(x=>{
      const tr=element('tr','');tr.append(element('td',x.issue),
        element('td',`单${x.predictions[0]} ${x.firstHit?'✓':'×'}`),
        element('td',`单${x.predictions[1]} ${x.secondHit?'✓':'×'}`),
        element('td',`单${x.aiPrediction} · ${x.aiMethod} ${x.aiHit?'✓':'×'}`),
        element('td','单'+x.actual));return tr;
    }));
    document.getElementById('labNote').textContent=a.note;
  }catch(e){summary.textContent='多方法复盘失败：'+e.message}
  finally{button.disabled=false}
}
async function loadHistoricalReplay(){
  const summary=document.getElementById('replaySummary');
  summary.textContent='正在逐期复盘；10000期可能需要数秒…';
  document.getElementById('replayRefresh').disabled=true;
  try{
    const a=await get('/api/playbook/replay?window='+encodeURIComponent(document.getElementById('replayWindow').value));
    const recent=a.recent200||{}, delta=recent.eitherRate!=null&&recent.baselineEitherRate!=null?
      (100*(recent.eitherRate-recent.baselineEitherRate)).toFixed(1)+' 个百分点':'—';
    const metric=(label,value,sub)=>{const card=element('article','','evidence-metric');card.append(element('small',label),element('strong',value),element('span',sub));return card};
    const grid=element('div','','evidence-grid');grid.append(
      metric('第一候选',pct(a.first.rate),`${a.first.hits}/${a.evaluated} 期`),
      metric('第二候选',pct(a.second.rate),`${a.second.hits}/${a.evaluated} 期`),
      metric('两项任一',pct(a.either.rate),`${a.either.hits}/${a.evaluated} 期`),
      metric('最近200期对照',pct(recent.eitherRate),`同期频数基线 ${pct(recent.baselineEitherRate)} · 差 ${delta}`));
    summary.replaceChildren(element('div',`逐期核对 ${a.evaluated} 期 · 有效 ${a.valid} · 无效 ${a.invalid} · 缺口 ${a.missing||0}`,'evidence-status'),grid,
      element('p',`整个范围的简单频数基线：第一候选 ${pct(a.baseline.firstRate)}，两项任一 ${pct(a.baseline.eitherRate)}。最近对照覆盖 ${recent.verified||0} 期；不足以证明未来优势。`,'muted'));
    const preview=document.getElementById('replayPreview');
    if(a.preview){
      const methods=(a.preview.match.methods||[]).filter(x=>x.weight>=0.55).map(x=>`${x.label} ${pct(x.recentRate)}`).join(' · ');
      const evidence=a.preview.match.selectedEvidence||[];
      const replay=evidence.map(x=>`单${x.candidate}：${x.length}期同步 ${x.support}段中紧接出现${x.hits}次`).join('；');
      preview.textContent=`库内相邻期 ${a.preview.issue} · 单${a.preview.predictions[0]} / 单${a.preview.predictions[1]} · ${replay}${methods?' · '+methods:''}。${a.preview.note}`;
    }else preview.textContent='连续四期以上的历史片段缺少两种可核对的紧接结果，暂不生成下一期候选。';
    const table=document.getElementById('replayRows');table.replaceChildren(...a.recent.map(row=>{
      const tr=element('tr','');
      const provenance=row.match.length?row.predictions.map(k=>{
        const source=row.match.sources?.[String(k)]?.at(-1);
        return `单${k}：${source?source.issue+'（'+(source.numbers||[]).join('、')+'）':'无'}`;
      }).join(' / '):(row.match.methods||[]).slice(0,3).map(x=>x.label).join(' + ')||'趋势/遗漏证据不足';
      [['期号',row.issue],['第一候选',`单${row.predictions[0]} ${row.firstHit?'✓':'×'}`],
       ['第二候选',`单${row.predictions[1]} ${row.secondHit?'✓':'×'}`],
       ['实际',`单${row.actual} · ${(row.numbers||[]).join('、')||'号码未保存'}`],
       ['复刻来源',provenance],['核对',row.eitherHit?'任一命中':'未命中']].forEach(([label,value])=>{const cell=element('td',value);cell.dataset.label=label;tr.append(cell)});
      return tr;
    }));
    document.getElementById('replayNote').textContent=a.note;
  }catch(e){summary.textContent='复盘失败：'+e.message}
  finally{document.getElementById('replayRefresh').disabled=false}
}
async function loadPlaybook(){
  const form=document.getElementById('playbookForm');
  const summary=document.getElementById('playbookSummary');summary.textContent='正在计算历史记录…';
  try{
    const query=new URLSearchParams(new FormData(form));const a=await get('/api/playbook?'+query);
    summary.replaceChildren(element('strong',`匹配 ${a.hits}/${a.valid} 期（${pct(a.rate)}）`),
      element('p',`已存 ${a.stored} 期；有效 ${a.valid} 期，无效 ${a.invalid} 期；当前连续遗漏 ${a.currentGap==null?'不能核对（可能缺期）':a.currentGap+'期'}。`));
    const numbers=document.getElementById('matchingNumbers');
    numbers.replaceChildren(...(a.matchingNumbers.length?a.matchingNumbers.map(n=>element('span',a.mode==='single'?'单'+n:String(n).padStart(2,'0'),'chip')):[element('span','当前交集没有匹配号码','muted')]));
    document.getElementById('playbookCategories').replaceChildren(...a.options.map(x=>element('span',`${a.kind==='single'?'单':''}${x.value}：${x.hits}/${a.valid}（${pct(x.rate)}）`,'chip')));
    document.getElementById('playbookRecent').replaceChildren(...(a.recentHits.length?a.recentHits.map(key=>element('span',displayValue(key),'chip')):[element('span','无历史命中记录','muted')]));
    document.getElementById('playbookNote').textContent=a.note;
  }catch(e){summary.textContent='读取失败：'+e.message}
}

function displayValue(value){
  if(value==null)return '等待数据';
  if(typeof value!=='string')return value;
  if(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(value)){
    const d=new Date(value);
    if(!Number.isNaN(d.valueOf()))return new Intl.DateTimeFormat('zh-CN',{
      timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',
      hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).format(d)+' 北京时间';
  }
  return value.replace(/(\d{4})-(\d{2})-(\d{2}):(\d{4})/g,(_,y,m,d,n)=>y.slice(2)+m+d+n);
}
function infoLine(label,value){return element('p',`${label}：${displayValue(value)}`)}
async function servicePage(role){
  try{
    const a=await get('/api/services');const cards=document.getElementById('serviceCards');
    const descriptions={
      monitor:[['职责','抓取历史10000期及持续采集最新开奖'],['历史采集状态',a.worker.historicalCapture?.status],['历史起点期序号',a.worker.historicalCapture?.firstIndex],['历史终点期序号',a.worker.historicalCapture?.lastIndex],['已采区块',a.worker.historicalCapture?.rawBlocks],['已采集到区块',a.worker.historicalCapture?.nextBlock],['历史窗口末区块',a.worker.historicalCapture?.lastBlock],['最新开奖期',a.worker.live?.period],['最近入库期',a.liveLatency?.period],['目标区块至入库',a.liveLatency?.blockToSavedSeconds==null?'等待测量':a.liveLatency.blockToSavedSeconds+' 秒'],['入库路径',a.liveLatency?.source],['最新链头',a.monitor.latestBlock],['轮询间隔',a.monitor.pollIntervalSeconds==null?null:a.monitor.pollIntervalSeconds+' 秒'],['采集状态',a.monitor.status]],
      worker:[['职责','按期号回填并检查每段历史，AI练习已停用'],['进程状态',a.workerDirectHeartbeat?.status],['进程阶段',a.workerDirectHeartbeat?.phase],['进程心跳',a.workerDirectHeartbeat?.receivedAt||a.workerDirectHeartbeat?.reportedAt],['数据库状态',a.workerDirectHeartbeat?.databaseStatus],['数据库错误',a.workerDirectHeartbeat?.databaseError||a.workerDirectHeartbeat?.databaseHeartbeatError],['运行状态',a.workerHeartbeat?.status||a.workerStartupHeartbeat?.status],['运行版本',a.workerDirectHeartbeat?.version||a.workerHeartbeat?.version||a.workerRelease?.version||a.workerStartupHeartbeat?.version],['运行心跳',a.workerHeartbeat?.reportedAt],['启动状态',a.workerStartupHeartbeat?.status],['启动心跳',a.workerStartupHeartbeat?.reportedAt],['交接状态',a.workerHandoff?.status],['交接心跳',a.workerHandoff?.reportedAt],['手动尾数线程',a.db.manualTailWorker?.status],['手动尾数线程心跳',a.db.manualTailWorker?.reportedAt],['手动尾数线程错误',a.db.manualTailWorkerError?.error],['固定起点',a.worker.origin?.period],['历史区块状态',a.worker.historicalCapture?.status],['起点后累计完整期',a.worker.forward?.completedSinceOrigin],['首段进度',`${a.worker.complete||0}/${a.worker.total||10000}`],['最后建成期',a.worker.forward?.period]],
      audit:[['归属','采集服务器补缺；回填/AI服务器核查分段'],['补采队列',a.audit.repair.queuedMissingBlocks],['补缺状态',a.audit.repair.status],['阶段审计状态',a.audit.progress?.status||'等待'],['等待审计阶段',a.audit.progress?.stage],['该段起止期号',a.audit.progress?.firstPeriod&&`${a.audit.progress.firstPeriod} 至 ${a.audit.progress.lastPeriod}`],['数据库首末期',a.audit.progress?.savedFirstPeriod&&`${a.audit.progress.savedFirstPeriod} 至 ${a.audit.progress.savedLastPeriod}`],['回填已完成期',a.audit.progress?.forwardCompleted],['首段补齐状态',a.worker.recovery?.status],['首段待补期',a.worker.recovery?.missing],['本次核对进度',`${a.audit.progress?.checked??0}/${a.audit.progress?.total??10000}`],['最近阶段审计',a.audit.verification.pass===true?'PASS':(a.audit.verification.pass===false?'未通过':'未执行')],['本次错误数',a.audit.progress?.errorsSoFar??a.audit.progress?.errors],['审计错误',a.audit.progress?.error||a.audit.error?.error],['已审计期',a.audit.verification.checkedPeriods]],
      db:[['职责','四部门共享状态、60000期开奖期与独立手动尾数库'],['完整开奖期',a.db.periods],['上限',a.db.retention?.limit||60000],['最旧保留期',a.db.retention?.oldest],['最新保留期',a.db.retention?.newest],['开奖区块组',a.db.groups],['手动尾数库区块',a.db.manualTailBlocks],['手动尾数预测记录',a.db.manualTailPredictions],['手动尾数批量回填',a.db.manualTailBackfill?.enabled?'开启 / '+(a.db.manualTailBackfill?.status||'运行中'):'暂停'],['手动尾数自动审计',a.db.manualTailAudit?.pass===true?'PASS':(a.db.manualTailAudit?.pass===false?'进行中':'未执行')],['手动尾数实时同步',a.db.manualTailLive?.status],['待修复区块',a.db.queuedRepairs],['历史练习记录',a.db.simulations],['候选方案',a.db.models],['库容量',a.db.sizeBytes==null?null:(a.db.sizeBytes/1048576).toFixed(1)+' MiB']],
      ai:[['状态','已停用；旧训练记录保存在数据库，网页不再读取']]
    };
    cards.replaceChildren(...Object.entries(descriptions).filter(([key])=>role==='all'||key===role).map(([key,lines])=>{let box=element('section','');const names={worker:'god8-worker-ai',ai:'AI 阶段（god8-worker-ai）',monitor:'god8-collector',audit:'补缺与分段审计',db:'god8-db'};box.append(element('h2',names[key]));for(let [label,val] of lines)box.append(infoLine(label,val));return box}));
    document.getElementById('serviceNote').textContent='最近链头：'+(a.chain.block??'等待采集')+'；来源：'+(a.chain.source??'等待采集');
  }catch(e){showError('serviceNote',e)}
}

function pct(x){return typeof x==='number'?(100*x).toFixed(2)+'%':'—'}
async function aiPage(){
  try{
    const [models,report,streaks,diagnostic,patterns]=await Promise.all([get('/api/models'),get('/api/services'),get('/api/ai/streaks').catch(()=>null),get('/api/ai/diagnostic').catch(()=>null),get('/api/ai/patterns').catch(()=>null)]);
    try{renderStreaks(streaks,'streakResearch')}catch(e){document.getElementById('streakResearch').textContent='连续追踪报告格式未更新；方法和训练记录仍可查看。'}
    renderPatterns(patterns,'patternResearch');
    const status=report.ai.status;
    const complete=report.worker.complete||0,total=report.worker.total||10000;
    const processed=report.worker.aiStage?.processed??-1;
    const stageProgress=Math.max(0,(report.worker.forward?.completedSinceOrigin||0)-(processed+1)*10000);
    document.getElementById('aiStatus').textContent=`历史训练 ${complete}/${total}；已练习 ${status.finishedMethods||0}/${status.totalMethods||0} 种。实时影子验证：${status.status==='shadow-testing'?'运行中':status.status||'等待数据'}；下一阶段评估 ${stageProgress}/10000。第一方案 ${status.selectedTopTwo?.[0]?.method||'待定'}；第二方案 ${status.selectedTopTwo?.[1]?.method||'待定'}。开奖前锁定：${report.ai.lock.reason||'未开始'}。${status.lastSwitchReason||''}`;
    const diagnosticBox=document.getElementById('aiDiagnostic');
    if(diagnostic){
      const lines=[element('p',diagnostic.explanation),
        element('p',`已回填 ${diagnostic.completedSinceOrigin} 期 · 最近完成训练段 ${diagnostic.lastTrainedStage<0?'尚无':diagnostic.lastTrainedStage+1} · 下一训练段需累计 ${diagnostic.nextStageAt} 期，尚差 ${diagnostic.roundsUntilNextStage} 期`),
        element('p',`AI服务：${diagnostic.workerAlive?'心跳正常':'离线或心跳过期'}；开奖前锁定：${diagnostic.lock?.reason||'无记录'}`)];
      for(const x of diagnostic.candidates)lines.push(element('p',`${x.method||x.id}：开奖前有效验证 ${x.valid} 期，命中 ${x.hits} 期（${pct(x.rate)}）；锁定迟到 ${x.late} 期，待开奖 ${x.pending} 期。`));
      if(!diagnostic.candidates.length)lines.push(element('p','尚无可验证的 AI1 候选模型。'));
      if(status.validationLiftVsFixed3!=null)lines.push(element('p',`当前最优历史验证相对固定单3：${(100*status.validationLiftVsFixed3).toFixed(2)} 个百分点；须另看留出期和真实新期，不能当作实际提升。`));
      diagnosticBox.replaceChildren(...lines);
    }else diagnosticBox.textContent='诊断暂时不可用，请打开 /api/ai/diagnostic 核对。';
    const tbody=document.getElementById('aiModels');tbody.replaceChildren(...models.map(x=>{
      const row=document.createElement('tr');const valid=x.future;
      const data=[x.id,x.method,pct(x.metrics.validation?.accuracy),pct(x.metrics.holdout?.accuracy),`${valid.hits}/${valid.valid} (${pct(valid.rate)})`,`${valid.late}/${valid.pending}`,pct(valid.wilsonLower95)];
      row.append(...data.map(t=>element('td',t)));
      const cell=document.createElement('td');
      if(x.adopted)cell.textContent='已手动授权';
      else if(valid.eligible){const button=element('button','手动授权');button.onclick=()=>authorize(x.id);cell.append(button)}
      else cell.textContent='继续验证';
      row.append(cell);return row}));
    const methods=document.getElementById('methodSelect');
    const current=methods.value;
    const available=[...new Set(models.map(m=>m.method))];
    if(methods.options.length!==available.length){methods.replaceChildren(...available.map(m=>{const opt=element('option',m);opt.value=m;return opt}));methods.value=available.includes(current)?current:(available[0]||'')}
    if(methods.value)await loadSimulation();
    const switches=await get('/api/ai/switches');
    document.getElementById('switchRows').replaceChildren(...switches.map(s=>infoLine(s.at,s.reason)));
    document.getElementById('aiNote').textContent='候选方法共 '+models.length+' 种。历史达标仍须通过至少300期开奖前真实锁定的验证；未达标时显示原始成绩。';
  }catch(e){showError('aiNote',e)}
}

async function loadSimulation(){
  const name=document.getElementById('methodSelect').value;
  if(!name)return;
  const report=await get('/api/ai/simulations?method='+encodeURIComponent(name));
    document.getElementById('simRows').replaceChildren(...report.rows.slice(0,30).map(x=>{
    const tr=document.createElement('tr');tr.append(...[displayValue(x.period),x.phase,'单'+x.prediction,'单'+x.actual,x.hit?'命中':'未中'].map(y=>element('td',y)));return tr
  }));
}

async function authorize(id){
  if(!confirm('确定手动授权这个已验证方案给 Web 吗？'))return;
  const token=prompt('输入管理员授权口令');if(!token)return;
  try{const r=await fetch('/api/adopt/'+id,{method:'POST',headers:{'X-Admin-Token':token}});
      const data=await r.json();alert(data.ok?'授权成功':data.error);aiPage()}
  catch(e){alert('授权失败：'+e.message)}
}
const AI2_LABELS={numbers_shape:'号码形态',wave_mix:'红蓝绿波',odd_even:'单双与大小',domestic_wild:'家肖野肖',combined_profile:'综合结构'};
async function loadAi2(){
  try{
    const a=await get('/api/ai2'),s=a.status||{};
    document.getElementById('ai2Status').textContent=`阶段：${s.status||'等待历史审计'}；已训练 ${s.completedMethods||0}/${s.totalMethods||5} 种；已审计样本 ${s.sample||0} 期；第一方法 ${AI2_LABELS[s.selected?.[0]?.method]||'待定'}，第二方法 ${AI2_LABELS[s.selected?.[1]?.method]||'待定'}。`;
    document.getElementById('ai2Note').textContent=`AI练习2仅从已审计数据练习；第17组出现后、目标开奖前锁定，开奖后独立核对。最近心跳：${displayValue(a.heartbeat?.at)}。${a.error?.error?'最近错误：'+a.error.error:''}`;
    document.getElementById('ai2Models').replaceChildren(...a.models.map(m=>{
      const tr=element('tr','');
      const distribution=m.metrics?.validation?.predicted||{};
      const dist=Object.entries(distribution).filter(([,v])=>v).map(([k,v])=>'单'+k+':'+v).join(' · ')||'无';
      tr.append(...[AI2_LABELS[m.method]||m.method,pct(m.metrics?.validation?.accuracy),pct(m.metrics?.holdout?.accuracy),
        `${m.realHits}/${m.realValid} ${m.realRate==null?'（待新期）':'（'+pct(m.realRate)+'）'}`,dist].map(v=>element('td',v)));
      return tr;
    }));
    document.getElementById('ai2Predictions').replaceChildren(...a.predictions.map(p=>{
      const tr=element('tr','');tr.append(...[p.issue,AI2_LABELS[p.method]||p.method,'单'+p.prediction,p.actual==null?'待开奖':'单'+p.actual,
        p.actual==null?'已锁定':p.valid===true?(p.actual===p.prediction?'命中':'未中'):'迟到/无效',displayValue(p.lockedAt)].map(v=>element('td',v)));return tr;
    }));
  }catch(e){showError('ai2Note',e)}
}

// v2.0.31: independent evidence desk. The live ledger never uses a historical
// backtest's scores as if they were predictions locked before the draw.
function fateMetric(label,metric,detail){
  const card=element('article','','fate-metric');
  card.append(element('small',label),element('strong',pct(metric?.rate)),
    element('span',`${metric?.hits??0}/${detail} 期`));return card;
}
function fateMatchDetails(match){
  if(!match?.length)return '当前没有达到支持门槛的四期以上同步复现。';
  const evidence=(match.selectedEvidence||[]).map(x=>`单${x.candidate}：${x.length}期连续同步的${x.support}段里紧接出现${x.hits}次；来源 ${x.sources?.map(s=>s.issue).join('、')||'待核'}`).join('。');
  return `${match.length}期连续同步 · 最长匹配 ${match.support} 段。${evidence}。`;
}
let fateLiveBusy=false,fateLedgerBusy=false;
async function loadFateLive(){
  if(document.hidden||fateLiveBusy)return;fateLiveBusy=true;
  try{
    const a=await get('/api/replay/live'),f=a.forecast;
    const area=document.getElementById('fateLive'),detail=document.getElementById('fateLiveDetails');
    if(!f){area.textContent='当前无有效的下一期锁定预判；等待最新一期入库和目标区块出现前的锁定。';detail.textContent='不将开奖后生成的分析冒充提前预判。';return}
    area.replaceChildren(element('div',`${f.issue}期 · ${f.settledAt?'已开奖核对':'开奖前已锁定'} · 单${f.choices[0]} / 单${f.choices[1]}`,'fate-live-result'));
    detail.textContent=`锁定于 ${displayValue(f.lockedAt)} · ${f.settledAt?`实际单${f.actual??'待核'} · ${f.actual==null?'无效结果':f.firstHit?'第一候选命中':f.secondHit?'第二候选命中':'两码未中'}`:'目标结果尚未确认'}。${fateMatchDetails(f.match)}`;
    document.getElementById('fateMatch').textContent=fateMatchDetails(f.match);
    const hot=f.match?.hot||[],cold=f.match?.cold||[];
    document.getElementById('fateTrend').replaceChildren(
      element('div',`近期活跃：${hot.length?hot.map(n=>'单'+n).join('、'):'暂无可靠提示'}`,'fate-chip'),
      element('div',`近期偏冷：${cold.length?cold.map(n=>'单'+n).join('、'):'暂无可靠提示'}`,'fate-chip'),
      element('div',`单1 / 单6：${[1,6].map(k=>`单${k}历史紧接${f.match?.votes?.[String(k)]??0}次`).join(' · ')}（按当前最长匹配）`,'fate-chip'));
  }catch(e){document.getElementById('fateLive').textContent='实时预判读取失败：'+e.message}
  finally{fateLiveBusy=false}
}
async function loadFateLedger(){
  if(fateLedgerBusy)return;fateLedgerBusy=true;
  const status=document.getElementById('fateLedgerStatus');status.textContent='核对锁定时间与目标区块中…';
  try{
    const data=await get('/api/fate/ledger');
    status.textContent=`最近载入 ${data.loaded} 条锁定记录 · 可核实 ${data.all.verified} 条；只把目标区块出现前锁定的有效结果计入真实成绩。`;
    document.getElementById('fateMetrics').replaceChildren(
      fateMetric('样本内 · 第一候选',data.all.first,data.all.verified),
      fateMetric('样本内 · 第二候选',data.all.second,data.all.verified),
      fateMetric('样本内 · 两码任一',data.all.either,data.all.verified),
      fateMetric('最近50 · 两码任一',data.last50.either,data.last50.verified),
      fateMetric('最近200 · 两码任一',data.last200.either,data.last200.verified),
      (()=>{const box=element('article','','fate-metric');box.append(element('small','样本内 · 95%保守下界'),element('strong',pct(data.all.either.lower95)),element('span','样本少时不要只看表面命中率'));return box})());
    document.getElementById('fateStreaks').replaceChildren(...['first','second','either'].map((key,i)=>element('div',`${['第一候选','第二候选','两码任一'][i]} · 当前连续未中 ${data.streaks.current[key]} 期 · 已见最长 ${data.streaks.longest[key]} 期`,'fate-chip')));
    const labels={unsettled:'尚未结算',invalidResult:'无效结果',missingBlockTime:'缺目标区块时间',lateLock:'未能证明开奖前锁定',invalidChoices:'候选不完整',invalidSource:'前一期或区块映射不符'};
    document.getElementById('fateExcluded').textContent=Object.entries(data.excluded).map(([key,n])=>`${labels[key]} ${n}`).join(' · ');
    document.getElementById('fateLedgerRows').replaceChildren(...data.recent.map(row=>{
      const tr=element('tr','');
      for(const value of [`${row.issue} · 提前 ${row.leadSeconds}s`,`单${row.choices[0]} / 单${row.choices[1]}`,`单${row.actual}`,row.firstHit?'第一项命中':row.secondHit?'第二项命中':'未中',row.match.length?`${row.match.length}期同步 · ${row.match.support}段${row.match.backoff?`；次级${row.match.backoff.length}期单${row.match.backoff.candidate}`:''}`:'无四期复现'])tr.append(element('td',value));
      tr.dataset.hit=row.eitherHit?'yes':'no';return tr;
    }));
    document.getElementById('fateLedgerNote').textContent=data.note;
  }catch(e){status.textContent='真实账本读取失败：'+e.message}
  finally{fateLedgerBusy=false}
}
async function loadFateBacktest(){
  const button=document.getElementById('fateRun'),status=document.getElementById('fateBacktestStatus');
  button.disabled=true;status.textContent='逐期回放中；10000期可能需要数秒…';
  try{
    const data=await get('/api/playbook/replay?window='+encodeURIComponent(document.getElementById('fateWindow').value));
    const recent=data.recent200||{},n=recent.verified||0;
    status.textContent=`逐期核对 ${data.evaluated} 期 · 无效 ${data.invalid} · 缺口 ${data.missing}。以下均是历史回放，不是开奖前真实锁定成绩。`;
    document.getElementById('fateBacktestMetrics').replaceChildren(
      fateMetric('历史第一候选',data.first,data.evaluated),fateMetric('历史第二候选',data.second,data.evaluated),
      fateMetric('历史两码任一',data.either,data.evaluated),
      fateMetric('同期简单频数两码',{'rate':data.baseline.eitherRate,'hits':data.baseline.eitherHits},data.evaluated),
      fateMetric('最近200期回放',{'rate':recent.eitherRate,'hits':n&&recent.eitherRate!=null?Math.round(n*recent.eitherRate):0},n),
      fateMetric('最近200期频数',{'rate':recent.baselineEitherRate,'hits':n&&recent.baselineEitherRate!=null?Math.round(n*recent.baselineEitherRate):0},n));
    const p=data.preview,m=p?.match;
    document.getElementById('fateBacktestEvidence').textContent=p?`下一相邻期 ${p.issue} 的历史回放候选：单${p.predictions.join(' / 单')}。${fateMatchDetails(m)} 最近200期差值：${n&&recent.eitherRate!=null&&recent.baselineEitherRate!=null?((recent.eitherRate-recent.baselineEitherRate)*100).toFixed(1)+'个百分点':'样本不足'}。`:'当前历史不足以生成相邻期模拟候选。';
    if(!document.getElementById('fateLiveDetails').textContent.includes('期连续同步'))document.getElementById('fateMatch').textContent=fateMatchDetails(m);
  }catch(e){status.textContent='历史回放失败：'+e.message}
  finally{button.disabled=false}
}
function initFatePage(){
  document.getElementById('fateReload').onclick=loadFateLedger;
  document.getElementById('fateRun').onclick=loadFateBacktest;
  loadFateLive();loadFateLedger();
  setInterval(loadFateLive,3000);setInterval(()=>{if(!document.hidden)loadFateLedger()},30000);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden){loadFateLive();loadFateLedger()}});
}

// v2.0.59 worker heartbeat visibility + v2.0.58 manual tail homepage clone.
let manualTailCurrent=null,manualTailReportBusy=false,manualTailLiveBusy=false,manualHistoryBusy=false,manualResultClearTimer=null,manualLatestBlock=0,manualLatestIssue='',manualNextIssue='';
async function postJson(url,body){const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});let data={};try{data=await r.json()}catch(e){}if(!r.ok)throw Error(data.error||'操作失败');return data}
function recentAgeSeconds(stamp){const at=Date.parse(stamp||'');return Number.isFinite(at)?Math.max(0,(Date.now()-at)/1000):null}
async function loadManualTailBackfillStatus(){
  const box=document.getElementById('manualTailBackfillStatus'),toggle=document.getElementById('manualTailBackfillSwitch');
  if(!box||!toggle)return;
  try{
    const a=await get('/api/manual-tail?tail='+(manualTailCurrent??9)),b=a.backfill||{},audit=a.audit||{},live=a.liveSync||{},worker=a.worker||{},err=a.workerError||{},parent=a.parentWorker||{};
    toggle.checked=!!b.enabled;
    const direct=parent.direct||{},runtime=parent.runtime||{},startup=parent.startup||{},handoff=parent.handoff||{},release=parent.release||{};
    const directAge=recentAgeSeconds(direct.receivedAt||direct.reportedAt),runtimeAge=recentAgeSeconds(runtime.reportedAt),startupAge=recentAgeSeconds(startup.reportedAt),threadAge=recentAgeSeconds(worker.reportedAt);
    const directAlive=!!direct.status&&directAge!=null&&directAge<30;
    const parentRunning=(direct.status==='running'&&directAlive)||(runtime.status==='running'&&runtimeAge!=null&&runtimeAge<30);
    const parentStarting=!parentRunning&&((directAlive&&['booting','starting','degraded','error'].includes(direct.status))||(startup.status&&startupAge!=null&&startupAge<30));
    const threadAlive=['running','starting'].includes(worker.status)&&threadAge!=null&&threadAge<30;
    let parentText='主Worker未见有效心跳';
    if(directAlive){
      const age=Math.floor(directAge),ver=direct.version||runtime.version||release.version||startup.version||'版本未知';
      if(direct.status==='error') parentText=`主Worker进程已启动 · 数据库错误 · ${ver} · ${age}秒前${direct.databaseError?' · '+direct.databaseError:''}`;
      else if(direct.status==='degraded') parentText=`主Worker进程在线 · 数据库心跳异常 · ${ver} · ${age}秒前`;
      else if(parentRunning) parentText=`主Worker运行中 · ${ver} · ${age}秒前`;
      else {const waiting=direct.phase==='waiting-for-leader-lock'||startup.status==='waiting-for-leader-lock'||handoff.status==='waiting-for-previous-instance';parentText=`主Worker${waiting?'等待旧实例交接':'启动中'} · ${direct.phase||direct.databaseStatus||'启动'} · ${ver} · ${age}秒前`;}
    } else if(parentRunning)parentText=`主Worker运行中 · ${runtime.version||release.version||'版本未知'} · ${Math.floor(runtimeAge)}秒前`;
    else if(parentStarting){
      const waiting=startup.status==='waiting-for-leader-lock'||handoff.status==='waiting-for-previous-instance';
      parentText=`主Worker${waiting?'等待旧实例交接':'启动中'} · ${startup.version||release.version||'版本未知'} · ${Math.floor(startupAge)}秒前`;
    }
    let threadText='尾数线程未启动';
    if(threadAlive)threadText=`尾数线程${worker.status==='starting'?'启动中':'运行中'} · ${worker.phase||'工作中'} · ${Math.floor(threadAge)}秒前`;
    else if(parentStarting)threadText='尾数线程等待主Worker取得运行锁';
    else if(parentRunning)threadText=`尾数线程未见有效心跳${threadAge==null?'':` · ${Math.floor(threadAge)}秒前`}`;
    box.dataset.state=(b.status==='complete'&&audit.pass===true&&parentRunning&&threadAlive)?'ready':(err.error||!parentRunning||!threadAlive?'pending':b.enabled?'pending':'ready');
    const tails=audit.byTail?Object.entries(audit.byTail).map(([t,n])=>`${t}尾 ${n}`).join(' · '):'尚未完成总审计';
    const raw=`raw ${b.rawCursor??'—'}/${b.rawMax??'—'}${b.rawDone?' ✓':''}`;
    const legacy=`旧库 ${b.legacyCursor??'—'}/${b.legacyMax??'—'}${b.legacyDone?' ✓':''}`;
    const errorText=err.error?` · 错误：${err.error}`:'';
    box.textContent=`${parentText} · ${threadText} · 批量回填：${b.enabled?'开启':b.status==='complete'?'已完成':'暂停'} / ${b.status||'等待'} · 本批 raw ${b.lastRawBatch||0} + 旧库 ${b.lastLegacyBatch||0} · 已入独立库 ${b.stored??a.audit?.stored??a.total??0} 条 · ${raw} · ${legacy} · 新数据同步 ${live.status||'等待'} · 审计 ${audit.pass===true?'PASS':audit.pass===false?'未通过/未完成':'待执行'} · ${tails}${errorText}`;
  }catch(e){box.dataset.state='pending';box.textContent='手动尾数库状态读取失败：'+e.message}
}
function bindManualTailBackfillSwitch(){
  const toggle=document.getElementById('manualTailBackfillSwitch');if(!toggle||toggle.dataset.bound)return;
  toggle.dataset.bound='1';toggle.addEventListener('change',async()=>{
    toggle.disabled=true;
    try{await postJson('/api/manual-tail/backfill',{enabled:toggle.checked});await loadManualTailBackfillStatus()}
    catch(e){toggle.checked=!toggle.checked;const box=document.getElementById('manualTailBackfillStatus');if(box)box.textContent='切换失败：'+e.message}
    finally{toggle.disabled=false}
  });
}
const oldCheckCenter=checkCenter;
checkCenter=async function(){await oldCheckCenter();bindManualTailBackfillSwitch();await loadManualTailBackfillStatus();setInterval(()=>{if(!document.hidden)loadManualTailBackfillStatus()},5000)};

function manualPredictionCard(single,index,forecast,settled){
  const hit=settled&&forecast.actual===single;
  const item=element('article','','prediction-result-card'+(settled?(hit?' hit':' settled'):' pending'));
  item.dataset.single=String(single);
  const match=forecast.match||{},policy=String(match.selectionPolicy||''),adaptive=policy.includes('adaptive')||policy.includes('fallback');
  const mode=adaptive?'趋势 / 遗漏':(index===0?'历史复现':(match.secondCandidateMode==='adaptive'?'趋势补位':'历史复现'));
  const head=element('div','','prediction-result-head');
  head.append(element('span',index===0?'预判一':'预判二','prediction-result-title'),element('em',mode,'prediction-mode-badge'));
  const value=element('strong','单'+single,'prediction-result-value'),footer=element('div','','prediction-result-footer');
  if(settled)footer.append(element('span',hit?'✓ 命中':'未命中',hit?'prediction-hit-label':'prediction-miss-label'));
  else{
    const reasons=match.reasons?.[String(single)]||[];
    footer.append(element('span',reasons.length?reasons.slice(0,1).join(''):'等待下一条同尾结果核对','prediction-evidence'));
  }
  item.append(head,value,footer);return item;
}
function renderManualReplay(a){
  const state=document.getElementById('liveReplay'),cards=document.getElementById('liveReplayChoices'),stats=document.getElementById('liveReplayStats');if(!state||!cards||!stats)return;
  const n=a.stats?.verified||0;stats.textContent=n?`已核对 ${n} 期 · 第一项 ${pct(a.stats.firstRate)} · 第二项 ${pct(a.stats.secondRate)} · 任一项 ${pct(a.stats.eitherRate)}`:'真实同尾结果核对：暂无有效样本';
  const f=a.forecast,phase=a.phase||'waiting';
  if(manualResultClearTimer){clearTimeout(manualResultClearTimer);manualResultClearTimer=null;}

  // Manual-tail prediction data is independent from homepage prediction data,
  // but both obey the exact same issue clock and display gate.
  if(!clockSynced){
    cards.replaceChildren();state.hidden=false;state.classList.remove('analyzing');
    state.textContent='正在同步开奖时钟，请稍等…';return;
  }
  const gate=predictionDisplayGate(a.latest?.issue),cycle=gate.cycle;
  if(gate.delayed){
    cards.replaceChildren();state.hidden=false;state.classList.remove('analyzing');
    state.textContent='开奖结果延迟获取中，请稍等…';return;
  }

  if(gate.resultWindow){
    if(phase==='result'&&f&&f.targetIssue===cycle.current){
      state.hidden=true;state.classList.remove('analyzing');
      cards.replaceChildren(...f.choices.map((single,i)=>manualPredictionCard(single,i,f,true)));
    }else{
      cards.replaceChildren();state.hidden=false;state.classList.remove('analyzing');
      state.textContent='本期开奖结果已获取 · 正在核对上一期预判';
    }
    return;
  }

  if(phase==='forecast'&&f&&f.targetIssue===cycle.next){
    state.hidden=false;state.classList.remove('analyzing');state.textContent=`${a.tail}尾 · ${f.targetIssue}期两组预判已锁定`;
    cards.replaceChildren(...f.choices.map((single,i)=>manualPredictionCard(single,i,f,false)));return;
  }

  cards.replaceChildren();state.hidden=false;
  const runtime=a.predictionRuntime||{},workerError=a.workerError||{},collector=a.predictionCollector||{},heal=a.webSelfHeal||{},obs=a.observation||{};
  if(phase==='observing'||obs.accepted===false){
    state.classList.remove('analyzing');
    const seen=Number(obs.observed||0),need=Number(obs.required||4);
    if(obs.status==='blocked')state.textContent=`${a.tail}尾数据质量检查未通过 · 已确认 ${seen}/${need} 期 · 等待缺期补齐`;
    else if(obs.status==='waiting-source')state.textContent=`${a.tail}尾正在等待首条有效基准结果`;
    else state.textContent=`正在建立${a.tail}尾连续有效样本 · ${seen}/${need} 期 · 暂不接受乱序数据`;
  }
  else if(workerError.error){state.classList.remove('analyzing');state.textContent='预测Worker异常：'+workerError.error;}
  else if(collector.status==='error'&&collector.error){state.classList.remove('analyzing');state.textContent='预测Collector异常：'+collector.error;}
  else if(heal.status==='web-self-heal-error'){state.classList.remove('analyzing');state.textContent='预测自动修复失败：'+(heal.error||'未知错误');}
  else if(runtime.tail===a.tail&&runtime.status==='insufficient-evidence'){state.classList.remove('analyzing');state.textContent=`历史有效样本不足 · 当前 ${runtime.historyRows??a.validTotal??0} 期`;}
  else{state.classList.add('analyzing');state.textContent='正在生成新一期预判';}
}

function predictionIssueClockParts(epochMs){
  // Manual draw clock follows the same +3s issue boundary as the homepage.
  // clockOffset is -3, so 12:01:03 becomes the start of issue 12:01.
  const shifted=epochMs+(clockOffset*1000),parts={};
  new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(new Date(shifted)).forEach(p=>{if(p.type!=='literal')parts[p.type]=p.value});
  const issueNo=Number(parts.hour)*60+Number(parts.minute),yy=String(parts.year).slice(-2);
  const current=`${yy}${parts.month}${parts.day}${String(issueNo).padStart(4,'0')}`;
  const nextParts={};
  new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(new Date(shifted+60000)).forEach(p=>{if(p.type!=='literal')nextParts[p.type]=p.value});
  const nextNo=Number(nextParts.hour)*60+Number(nextParts.minute),next=`${String(nextParts.year).slice(-2)}${nextParts.month}${nextParts.day}${String(nextNo).padStart(4,'0')}`;
  const second=Number(parts.second||0),remaining=second===0?60:60-second;
  return {current,next,remaining};
}
function predictionDisplayGate(latestIssue,epochMs=Date.now()+clockDelta){
  const cycle=predictionIssueClockParts(epochMs),issue=String(latestIssue||'');
  return {cycle,delayed:!issue||issue!==cycle.current,
          resultWindow:cycle.remaining>45,forecastWindow:cycle.remaining<=45};
}
function manualIssueClockParts(epochMs){return predictionIssueClockParts(epochMs);}
function tickManualIssueClock(){
  if(!document.getElementById('manualRoundCountdown'))return;
  const now=Date.now()+clockDelta,p=manualIssueClockParts(now);
  const label=document.getElementById('manualNextIssueLabel');
  if(label)label.textContent=manualNextIssue?`距${manualNextIssue}期开奖`:`距下一期开奖`;
  const countdown=document.getElementById('manualRoundCountdown');if(countdown)countdown.textContent=`00:00:${String(p.remaining).padStart(2,'0')}`;
}
function renderManualLiveSnapshot(a){
  if(a.tail!=null)manualTailCurrent=Number(a.tail);
  const latest=a.latest,block=Number(latest?.block||0);
  // A slower full-report response must never overwrite a newer lightweight draw response.
  if(block&&manualLatestBlock&&block<manualLatestBlock)return false;
  const changed=block!==manualLatestBlock;
  if(block)manualLatestBlock=block;
  if(latest){
    manualLatestIssue=String(latest.issue||'');
    const period=document.getElementById('periodValue');if(period)period.textContent=latest.issue?`第${latest.issue}期开奖`:'第--------期开奖';
    document.getElementById('singleValue').textContent=latest.single??'--';
    document.getElementById('blockValue').textContent=latest.block??'--';
    document.getElementById('numberGrid').replaceChildren(...ballsWithSeparator(Array.isArray(latest.numbers)?latest.numbers:[],latest.issue||null));
  }
  manualNextIssue=String(a.nextIssue||manualNextIssue||'');
  const next=document.getElementById('manualTailNextBlock');if(next)next.textContent=a.nextBlock??'--';
  const badge=document.getElementById('drawSync'),fast=a.fastLive||{},fastAge=recentAgeSeconds(fast.reportedAt),fastAlive=fast.status==='synced'&&Number(fast.tail)===Number(a.tail)&&fastAge!=null&&fastAge<20;
  if(badge){badge.textContent=fastAlive?(fast.source==='proactive-exact-target'?'目标区块直取 · 已同步':'开奖结果实时同步'):'开奖数据优先监听';badge.dataset.state=fastAlive?'ready':'pending'}
  return changed;
}
function renderManualSnapshot(a){
  manualTailCurrent=a.tail;
  renderManualLiveSnapshot(a);
  document.querySelectorAll('.tail-switch').forEach(b=>b.classList.toggle('active',Number(b.dataset.tail)===a.tail));
  const picker=document.getElementById('manualTailPickerLabel');if(picker)picker.textContent=a.tail+'尾';
  const eyebrow=document.getElementById('manualTailEyebrow');if(eyebrow)eyebrow.textContent=`手动模式 · 当前 ${a.tail}尾`;
  const scope=document.getElementById('manualPredictionScope');if(scope)scope.textContent=`${a.tail}尾独立序列`;
  const hscope=document.getElementById('manualHistoryScope');if(hscope)hscope.textContent=`当前${a.tail}尾`;
  const ph=document.getElementById('manualPredictionHistoryLink');if(ph)ph.href=`/manual-tail/predictions?tail=${a.tail}`;
  const timing=document.getElementById('drawTiming');if(timing)timing.textContent=`${a.tail}尾历史 ${Number(a.total||0).toLocaleString()} 期 · 开奖数据优先 · 时间+3秒`;
  const memory=document.getElementById('homeMemoryStatus');if(memory){const obs=a.observation||{},seen=Number(obs.observed||0),need=Number(obs.required||4);memory.textContent=obs.accepted?`使用 ${Number(a.validTotal??a.total??0).toLocaleString()} 期${a.tail}尾历史 · 当前连续样本已通过 ${seen}/${need} · 只按所选尾复现`:`${a.tail}尾建模观察 ${seen}/${need} · 只接受连续+20区块有效结果 · 缺期/乱序不进入预测`;memory.dataset.state=obs.accepted?'ready':'pending'}
  const strip=document.getElementById('homeOmission');if(strip)strip.replaceChildren(...Array.from({length:8},(_,i)=>{const x=(a.omission||[]).find(v=>v.single===i)||{};const item=element('span','','home-omission-item');item.append(element('small','单'+i),element('b',x.gap==null?'—':String(x.gap)));return item}));
  const overdue=document.getElementById('todayOverdueSummary');if(overdue)overdue.replaceChildren(...[2,3,4,5].map(i=>{const x=(a.omission||[]).find(v=>v.single===i)||{};const item=element('div','','compact-overdue-item');item.append(element('small','单'+i),element('strong',`${x.hits??0}次`),element('span',`当前遗漏 ${x.gap??0}期`));return item}));
  renderManualReplay(a);
}
async function refreshManualTailLive(){
  if(manualTailLiveBusy||document.hidden||manualTailCurrent==null)return;manualTailLiveBusy=true;
  try{
    const r=await fetch('/api/manual-tail/live?tail='+manualTailCurrent,{cache:'no-store'});if(!r.ok)throw Error('实时开奖查询失败');
    const a=await r.json(),changed=renderManualLiveSnapshot(a);
    if(changed){refreshManualTailHistory();refreshManualTailSnapshot(false)}
  }catch(e){const badge=document.getElementById('drawSync');if(badge&&badge.dataset.state!=='ready'){badge.textContent='开奖数据优先监听中';badge.dataset.state='pending'}}
  finally{manualTailLiveBusy=false}
}
async function refreshManualTailSnapshot(forceHistory=false){
  if(manualTailReportBusy||document.hidden)return;manualTailReportBusy=true;
  try{
    const a=await get('/api/manual-tail?tail='+manualTailCurrent),before=manualLatestBlock;
    renderManualSnapshot(a);
    if((manualLatestBlock!==before)||forceHistory)refreshManualTailHistory();
  }catch(e){const badge=document.getElementById('drawSync');if(badge&&badge.dataset.state!=='ready'){badge.textContent='手动尾数库连接中';badge.dataset.state='pending'}}
  finally{manualTailReportBusy=false}
}
async function refreshManualTailHistory(){
  if(manualHistoryBusy||document.hidden)return;manualHistoryBusy=true;
  try{
    const a=await get(`/api/manual-tail/history?tail=${manualTailCurrent}&page=1`);
    homeRecentRows=(a.rows||[]).map(row=>({issue:row.issue||row.period||`区块 ${row.block}`,single:row.single,block:row.block,numbers:row.numbers}));homeRecentPage=1;renderHomeRecent();
  }catch(e){const box=document.getElementById('recent');if(box&&!box.children.length)box.textContent='同尾历史暂时无法读取'}
  finally{manualHistoryBusy=false}
}
async function selectManualTail(tail){
  try{
    await postJson('/api/manual-tail/select',{tail});manualTailCurrent=Number(tail);manualLatestBlock=0;manualLatestIssue='';manualNextIssue='';homeRecentPage=1;
    const picker=document.getElementById('manualTailPicker');if(picker)picker.open=false;
    await refreshManualTailLive();
    await refreshManualTailSnapshot(true);
  }catch(e){const badge=document.getElementById('drawSync');if(badge){badge.textContent='尾数切换失败：'+e.message;badge.dataset.state='pending'}}
}
async function initManualTailHome(){
  const wrap=document.getElementById('manualTailButtons');
  if(wrap)wrap.replaceChildren(...Array.from({length:10},(_,tail)=>{const b=element('button',tail+'尾','tail-switch');b.type='button';b.dataset.tail=tail;b.onclick=()=>selectManualTail(tail);return b}));
  document.getElementById('recentPrev')?.addEventListener('click',()=>changeHomeRecent(-1));
  document.getElementById('recentNext')?.addEventListener('click',()=>changeHomeRecent(1));
  // v2.0.11: restore the persisted backend selection and queue prediction immediately.  Opening or refreshing
  // this page must never overwrite the manually selected tail.
  manualLatestBlock=0;manualLatestIssue='';manualNextIssue='';
  try{
    const saved=await get('/api/manual-tail');
    manualTailCurrent=Number(saved.tail);
    renderManualSnapshot(saved);
  }catch(e){
    // Only use 9 as a local display fallback when the backend cannot be read;
    // do not POST it, so a temporary network failure cannot overwrite selection.
    manualTailCurrent=9;
  }
  tickManualIssueClock();
  await refreshManualTailLive();
  await refreshManualTailSnapshot(true);
  // Draw data uses a lightweight endpoint at 300ms; replay/omission/stats are
  // intentionally slower so they cannot compete with the live result path.
  setInterval(refreshManualTailLive,300);
  setInterval(()=>refreshManualTailSnapshot(false),1500);
  setInterval(()=>refreshManualTailHistory(),12000);
  setInterval(tickManualIssueClock,1000);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden){tickManualIssueClock();refreshManualTailLive();refreshManualTailSnapshot(true)}});
  window.addEventListener('pageshow',()=>{if(!document.hidden){tickManualIssueClock();refreshManualTailLive();refreshManualTailSnapshot(true)}});
}


// v2.0.19: keep the anti-overheat reminder independent from the old AI sprite.
// It is shared by the homepage and the manual-tail page.
function initSafetyReminder(){
  if(window.__god8SafetyReminderStarted)return;window.__god8SafetyReminderStarted=true;
  const toast=document.getElementById('safetyToast');if(!toast)return;
  const close=document.getElementById('safetyToastClose'),title=document.getElementById('safetyToastTitle'),hint=document.getElementById('safetyToastHint');
  const storageKey='god8-safety-overdue-ack-v1';let visible=[],timer=null,busy=false;
  function ack(){try{const v=JSON.parse(localStorage.getItem(storageKey));return Array.isArray(v)?v:[]}catch(e){return []}}
  function save(keys){try{localStorage.setItem(storageKey,JSON.stringify([...new Set([...ack(),...keys])].slice(-80)))}catch(e){}}
  function hide(manual){if(manual)save(visible.map(x=>x.key));visible=[];toast.hidden=true;if(timer){clearTimeout(timer);timer=null}}
  close.onclick=()=>hide(true);
  window.god8SafetyNotice=report=>{
    const events=spriteOverdueEvents(report);if(!events.length)return;
    const known=new Set([...ack(),...visible.map(x=>x.key)]),fresh=events.filter(x=>!known.has(x.key));if(!fresh.length)return;
    visible.push(...fresh);title.textContent=visible.map(x=>`单${x.single}遗漏${x.gap}期（阈值${x.threshold}）`).join('、')+' · 已超期';
    const auto=spriteToastAutoClose(visible);hint.textContent=auto?'单0/单7提醒将在12秒后自动收起':'请点右上角 × 手动关闭此提醒';
    toast.hidden=false;if(timer)clearTimeout(timer);
    if(auto){save(visible.map(x=>x.key));timer=setTimeout(()=>hide(false),12000)}
  };
  async function poll(){if(busy||document.hidden)return;busy=true;try{window.god8SafetyNotice(await get('/api/omission/detail'))}catch(e){}finally{busy=false}}
  poll();setInterval(poll,12000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)poll()});
}

function initChatWidget(){
  if(window.__god8ChatStarted)return;window.__god8ChatStarted=true;
  const $=id=>document.getElementById(id);
  const launcher=$('chatLauncher'),box=$('chatFloat');if(!launcher||!box)return;
  const auth=$('chatAuth'),room=$('chatRoom'),authMsg=$('chatAuthMessage'),userInput=$('chatUsername'),passInput=$('chatPassword');
  const messages=$('chatMessages'),input=$('chatInput'),composer=$('chatComposer'),sendBtn=$('chatSend'),mic=$('chatMic'),recording=$('chatRecording'),recordingTime=$('chatRecordingTime');
  const meLabel=$('chatMe'),headStatus=$('chatHeadStatus'),title=$('chatTitle'),unreadBadge=$('chatUnread'),soundBtn=$('chatSoundToggle'),jumpNew=$('chatJumpNew');
  const onlineCount=$('chatOnlineCount'),onlineDot=$('chatOnlineDot'),charCount=$('chatCharCount'),loginBtn=$('chatLogin'),registerBtn=$('chatRegister');
  const panel=$('chatConversationPanel'),conversationList=$('chatConversationList'),conversationName=$('chatConversationName'),conversationKind=$('chatConversationKind');
  const adminOpen=$('chatAdminOpen'),adminPanel=$('chatAdminPanel'),storageStats=$('chatStorageStats'),predictionBar=$('chatPredictionBar');
  const predictionSource=$('chatPredictionSource'),predictionCountdown=$('chatPredictionCountdown'),predictionText=$('chatPredictionText');
  const soundKey='god8-chat-sound-v1',lastUserKey='god8-chat-last-user-v1',dingKey='god8-chat-last-ding-v1',lastConversationKey='god8-chat-last-conversation-v1';
  const compactQuery=window.matchMedia?.('(max-width:640px), (pointer:coarse)');
  const crossTab=typeof BroadcastChannel!=='undefined'?new BroadcastChannel('god8-chat-sync-v3'):null;
  let me=null,conversations=[],currentCid=0,lastId=0,syncCursor=0,lastReadAck=0,loaded=false,unread=0,roomNew=0,audioContext=null,seenMessageIds=new Set();
  let socket=null,socketPing=null,reconnectTimer=null,pollTimer=null,conversationTimer=null,readTimer=null,pageLockY=0,pageLocked=false,soundEnabled=true,sendBusy=false;
  let recorder=null,recordStream=null,recordChunks=[],recordStarted=0,recordTimer=null,recordCancelled=false,recordStartX=0;
  try{soundEnabled=localStorage.getItem(soundKey)!=='off'}catch(e){}

  const compact=()=>!!compactQuery?.matches;
  const nearBottom=()=>messages.scrollHeight-messages.scrollTop-messages.clientHeight<90;
  const makeClientKey=()=>{try{return crypto.randomUUID().replaceAll('-','')}catch(e){return `${Date.now()}_${Math.random().toString(36).slice(2)}`}};
  const currentConversation=()=>conversations.find(x=>Number(x.id)===Number(currentCid))||null;
  const draftKey=()=>`god8-chat-draft-v3-${currentCid||'none'}`;
  function setConnection(state,text){box.dataset.connection=state||'';headStatus.textContent=text||'';onlineDot.classList.toggle('online',state==='online');onlineDot.classList.toggle('offline',state==='offline')}
  function updateOnline(value){const n=Math.max(0,Number(value)||0);onlineCount.textContent=n?String(n):'—'}
  function applySound(){soundBtn.textContent=soundEnabled?'🔔':'🔕';soundBtn.setAttribute('aria-pressed',String(soundEnabled));soundBtn.title=soundEnabled?'新消息声音已开启':'新消息声音已关闭'}
  function ensureAudio(){try{if(!audioContext){const A=window.AudioContext||window.webkitAudioContext;if(A)audioContext=new A()}if(audioContext?.state==='suspended')audioContext.resume()}catch(e){}}
  function tone(freq,start,duration,volume){if(!audioContext)return;const o=audioContext.createOscillator(),g=audioContext.createGain();o.type='sine';o.frequency.value=freq;g.gain.setValueAtTime(.0001,start);g.gain.exponentialRampToValueAtTime(volume,start+.015);g.gain.exponentialRampToValueAtTime(.0001,start+duration);o.connect(g);g.connect(audioContext.destination);o.start(start);o.stop(start+duration+.03)}
  function dingDong(){if(!soundEnabled||document.hidden)return;const now=Date.now();try{const last=Number(localStorage.getItem(dingKey)||0);if(now-last<1300)return;localStorage.setItem(dingKey,String(now))}catch(e){}ensureAudio();if(!audioContext||audioContext.state!=='running')return;const t=audioContext.currentTime+.01;tone(880,t,.14,.12);tone(659.25,t+.16,.22,.10)}
  function setUnread(v){unread=Math.max(0,Number(v)||0);unreadBadge.hidden=!unread;unreadBadge.textContent=unread>99?'99+':String(unread);launcher.classList.toggle('has-unread',unread>0)}
  function setRoomNew(v){roomNew=Math.max(0,Number(v)||0);jumpNew.hidden=!roomNew;jumpNew.textContent=roomNew?`↓ ${roomNew}条新消息`:'↓ 新消息'}
  function lockPage(){if(pageLocked)return;pageLockY=window.scrollY||0;document.body.style.top=`-${pageLockY}px`;document.body.classList.add('chat-page-locked');pageLocked=true}
  function unlockPage(){if(!pageLocked)return;document.body.classList.remove('chat-page-locked','chat-fullscreen-open');document.body.style.removeProperty('top');pageLocked=false;window.scrollTo(0,pageLockY)}
  function syncViewport(){if(box.hidden||box.dataset.mode==='fullscreen'){box.style.removeProperty('height');box.style.removeProperty('bottom');return}if(!compact())return;const vv=window.visualViewport;if(!vv)return;const inset=Math.max(0,window.innerHeight-(vv.offsetTop+vv.height));box.style.setProperty('height',`${Math.max(300,Math.min(560,vv.height-16))}px`,'important');box.style.setProperty('bottom',`${Math.max(8,inset+8)}px`,'important')}
  function openChat(value){if(value){lockPage();box.hidden=false;launcher.hidden=true;launcher.setAttribute('aria-expanded','true');ensureAudio();syncViewport();if(me&&!currentCid&&conversations.length)selectConversation(conversations[0].id);else if(me&&currentCid)loadMessages(true)}else{box.hidden=true;launcher.hidden=false;launcher.setAttribute('aria-expanded','false');box.dataset.mode='normal';predictionBar.hidden=true;unlockPage();box.style.removeProperty('height');box.style.removeProperty('bottom');panel.hidden=true;adminPanel.hidden=true}}
  function toggleFullscreen(){const full=box.dataset.mode!=='fullscreen';box.dataset.mode=full?'fullscreen':'normal';predictionBar.hidden=!full;document.body.classList.toggle('chat-fullscreen-open',full);$('chatFullscreen').textContent=full?'⤢':'⛶';$('chatFullscreen').setAttribute('aria-label',full?'退出全屏':'全屏聊天');syncViewport();if(full)syncPredictionTop()}
  function syncPredictionTop(){if(box.dataset.mode!=='fullscreen')return;const manual=$('manualRoundCountdown'),home=$('roundCountdown'),status=$('liveReplay'),choices=$('liveReplayChoices');if(manual){predictionSource.textContent=`手动${$('manualTailPickerLabel')?.textContent||''}`;predictionCountdown.textContent=manual.textContent||'--'}else{predictionSource.textContent='首页预测';predictionCountdown.textContent=home?.textContent?`${home.textContent}s`:'--'}const statusText=(status?.textContent||'').trim(),choiceText=(choices?.textContent||'').replace(/\s+/g,' ').trim();predictionText.textContent=/延迟获取|延迟|请稍等/.test(statusText)?statusText:(choiceText||statusText||'正在读取预测')}
  setInterval(syncPredictionTop,350);

  function formatTime(value){try{const d=new Date(value),now=new Date();const same=d.toLocaleDateString('zh-CN',{timeZone:'Asia/Shanghai'})===now.toLocaleDateString('zh-CN',{timeZone:'Asia/Shanghai'});return new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',...(same?{}:{month:'2-digit',day:'2-digit'}),hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(d)}catch(e){return ''}}
  function voiceNode(item){const wrap=element('div','','chat-voice'),play=element('button','▶'),progress=document.createElement('progress'),time=element('span',formatDuration(item.durationMs));progress.max=100;progress.value=0;const audio=new Audio(item.mediaUrl);audio.preload='metadata';play.onclick=()=>{ensureAudio();if(audio.paused){document.querySelectorAll('.chat-voice button.playing').forEach(b=>{if(b!==play)b.click()});audio.play().catch(()=>{});play.textContent='❚❚';play.classList.add('playing')}else{audio.pause();play.textContent='▶';play.classList.remove('playing')}};audio.ontimeupdate=()=>{if(audio.duration)progress.value=Math.min(100,audio.currentTime/audio.duration*100);time.textContent=formatDuration(audio.currentTime*1000)};audio.onended=()=>{play.textContent='▶';play.classList.remove('playing');progress.value=0;time.textContent=formatDuration(item.durationMs)};progress.onclick=e=>{if(audio.duration){const r=progress.getBoundingClientRect();audio.currentTime=Math.max(0,Math.min(audio.duration,(e.clientX-r.left)/r.width*audio.duration))}};wrap.append(play,progress,time);return wrap}
  function formatDuration(ms){const sec=Math.max(0,Math.round((Number(ms)||0)/1000));return `${Math.floor(sec/60)}:${String(sec%60).padStart(2,'0')}`}
  function messageNode(item){const mine=Number(item.userId)===Number(me?.id)||!!item.mine,row=element('div','',mine?'chat-message mine':'chat-message');row.dataset.messageId=String(item.id||'');const meta=element('div','','chat-message-meta');meta.append(element('strong',mine?'我':item.user),element('span',formatTime(item.at)));row.append(meta);if(item.kind==='voice'&&item.mediaUrl)row.append(voiceNode(item));else row.append(element('p',item.body||''));return row}
  function emptyThread(text='选择一个会话开始聊天'){messages.replaceChildren(element('div',text,'chat-empty'))}
  function appendItems(list,countIncoming=true){if(messages.querySelector('.chat-empty'))messages.replaceChildren();let incoming=0,added=0;for(const raw of list||[]){const item={...raw,mine:Number(raw.userId)===Number(me?.id)};const id=Number(item.id)||0;if(!id||seenMessageIds.has(id))continue;const node=messageNode(item);seenMessageIds.add(id);lastId=Math.max(lastId,id);let before=null;for(const child of messages.children){const existing=Number(child.dataset?.messageId||0);if(existing&&existing>id){before=child;break}}if(before)messages.insertBefore(node,before);else messages.append(node);added++;if(countIncoming&&loaded&&!item.mine)incoming++}return{incoming,added}}
  function scrollBottom(){requestAnimationFrame(()=>{messages.scrollTop=messages.scrollHeight;setRoomNew(0);scheduleRead()})}

  async function chatFetch(url,options={}){const ctl=new AbortController(),timeout=setTimeout(()=>ctl.abort(),12000);try{const r=await fetch(url,{cache:'no-store',credentials:'same-origin',...options,signal:ctl.signal});let data={};try{data=await r.json()}catch(e){}if(!r.ok)throw Error(data.error||'聊天连接失败');return data}catch(e){if(e.name==='AbortError')throw Error('聊天连接超时');throw e}finally{clearTimeout(timeout)}}
  const chatGet=url=>chatFetch(url),chatPost=(url,body)=>chatFetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body||{})});
  async function chatForm(url,form){return chatFetch(url,{method:'POST',body:form})}

  function updateComposer(){input.style.height='42px';input.style.height=Math.min(104,Math.max(42,input.scrollHeight))+'px';const n=input.value.length;charCount.textContent=`${n}/1000`;charCount.classList.toggle('warn',n>=850&&n<1000);charCount.classList.toggle('limit',n>=1000)}
  function restoreDraft(){try{input.value=localStorage.getItem(draftKey())||''}catch(e){}updateComposer()}
  function saveDraft(){try{if(input.value)localStorage.setItem(draftKey(),input.value);else localStorage.removeItem(draftKey())}catch(e){}}
  function renderConversations(){conversationList.replaceChildren();if(!conversations.length){conversationList.append(element('div','还没有会话','chat-empty'));return}for(const c of conversations){const btn=element('button','',`chat-conversation-item${Number(c.id)===Number(currentCid)?' active':''}`);btn.type='button';btn.dataset.id=c.id;btn.append(element('strong',`${c.kind==='group'?'👥':'👤'} ${c.name}`),element('small',c.preview||''));if(c.unread){const b=element('b',c.unread>99?'99+':String(c.unread));btn.append(b)}btn.onclick=()=>selectConversation(c.id);conversationList.append(btn)}const total=conversations.reduce((a,c)=>a+Number(c.unread||0),0);setUnread(total)}
  async function refreshConversations(selectDefault=false){if(!me)return;try{const data=await chatGet('/api/chat/conversations');conversations=data.conversations||[];updateOnline(data.onlineCount);renderConversations();if(selectDefault&&!currentCid&&conversations.length){let saved=0;try{saved=Number(localStorage.getItem(lastConversationKey)||0)}catch(e){};const target=conversations.find(c=>Number(c.id)===saved)||conversations[0];await selectConversation(target.id,false)}else if(currentCid&&!conversations.some(c=>Number(c.id)===Number(currentCid))){currentCid=0;emptyThread()}}catch(e){setConnection('offline',e.message)}}
  async function selectConversation(cid,closePanel=true){cid=Number(cid)||0;if(!cid)return;saveDraft();currentCid=cid;lastId=0;syncCursor=0;lastReadAck=0;loaded=false;seenMessageIds=new Set();setRoomNew(0);messages.replaceChildren();const c=currentConversation();conversationName.textContent=c?.name||'会话';conversationKind.textContent=c?.kind==='group'?'群聊':'单聊';title.textContent=c?.name||'聊天';try{localStorage.setItem(lastConversationKey,String(cid))}catch(e){}renderConversations();if(closePanel)panel.hidden=true;restoreDraft();await loadMessages(true);if(me?.admin)updateAdminGroupControls()}
  function scheduleRead(delay=180){if(box.hidden||!me||!currentCid||!lastId||!nearBottom()||lastReadAck>=lastId)return;clearTimeout(readTimer);readTimer=setTimeout(markRead,delay)}
  async function markRead(){if(!me||box.hidden||!currentCid||!lastId||!nearBottom()||lastReadAck>=lastId)return;const target=lastId;try{const data=await chatPost('/api/chat/read',{conversationId:currentCid,maxId:target});lastReadAck=Math.max(lastReadAck,target);setUnread(data.unreadCount||0);setRoomNew(0);updateOnline(data.onlineCount);refreshConversations(false)}catch(e){}}
  async function loadMessages(initial=false){if(!me||!currentCid||document.hidden||!navigator.onLine)return;const wasBottom=nearBottom(),cursor=syncCursor;try{const data=await chatGet(`/api/chat/messages?conversation=${currentCid}&limit=80${cursor?`&after=${cursor}`:''}`);const {incoming,added}=appendItems(data.messages||[],true);syncCursor=Math.max(syncCursor,Number(data.latestId||cursor)||0);updateOnline(data.onlineCount);setConnection('online',socket?.readyState===1?'实时连接':'已连接 · 自动同步');if(initial||!loaded)scrollBottom();else if(added&&wasBottom&&!box.hidden)scrollBottom();else if(incoming&&!box.hidden)setRoomNew(roomNew+incoming);if(loaded&&incoming)dingDong();loaded=true;while(messages.children.length>220)messages.firstElementChild?.remove();if(!box.hidden&&nearBottom())scheduleRead()}catch(e){if(String(e.message).includes('无权')){currentCid=0;syncCursor=0;seenMessageIds=new Set();emptyThread('会话已不可用');refreshConversations()}else setConnection('offline',navigator.onLine?'连接波动 · 正在自动重连':'网络已断开 · 等待恢复')}}

  function closeSocket(){if(reconnectTimer){clearTimeout(reconnectTimer);reconnectTimer=null}if(socketPing){clearInterval(socketPing);socketPing=null}if(socket){const ws=socket;socket=null;ws.onclose=null;ws.onerror=null;try{ws.close()}catch(e){}}}
  function connectSocket(){closeSocket();if(!me||document.hidden||!('WebSocket'in window))return;const proto=location.protocol==='https:'?'wss':'ws';let ws;try{ws=new WebSocket(`${proto}://${location.host}/ws/chat`);socket=ws}catch(e){return}ws.onopen=()=>{if(socket!==ws)return;setConnection('online','实时连接');socketPing=setInterval(()=>{try{if(socket===ws&&ws.readyState===1)ws.send(JSON.stringify({type:'ping'}))}catch(e){}},20000)};ws.onmessage=e=>{if(socket!==ws)return;let d={};try{d=JSON.parse(e.data||'{}')}catch(err){}if(d.type==='message'){const msg={...(d.message||{}),mine:Number(d.message?.userId)===Number(me?.id)};if(Number(d.conversationId)===Number(currentCid)){const wasBottom=nearBottom(),res=appendItems([msg],true);if(res.added){if(!box.hidden&&wasBottom)scrollBottom();else if(!msg.mine)setRoomNew(roomNew+1);if(!msg.mine)dingDong()}loadMessages(false)}else if(Number(msg.userId)!==Number(me?.id))dingDong();refreshConversations(false)}else if(d.type==='conversations'){refreshConversations(false)}else if(d.type==='cleared'){messages.replaceChildren();lastId=0;syncCursor=0;seenMessageIds=new Set();loaded=true;emptyThread('聊天记录已由管理号清除');refreshConversations(false)}};ws.onerror=()=>{if(socket===ws)setConnection('offline','实时连接波动 · 自动恢复')};ws.onclose=()=>{if(socket===ws)socket=null;if(socketPing){clearInterval(socketPing);socketPing=null}if(me&&!document.hidden){setConnection('offline','实时连接断开 · 使用同步模式');reconnectTimer=setTimeout(()=>{reconnectTimer=null;if(me&&!document.hidden&&!socket)connectSocket()},1800)}}}

  function showLoggedOut(message=''){closeSocket();me=null;conversations=[];currentCid=0;lastId=0;syncCursor=0;seenMessageIds=new Set();messages.replaceChildren();auth.hidden=false;room.hidden=true;adminPanel.hidden=true;panel.hidden=true;title.textContent='聊天';setConnection('', '登录后开始聊天');authMsg.textContent=message;passInput.value='';setUnread(0);updateOnline(0)}
  async function showLoggedIn(user,snapshot={}){me=user;auth.hidden=true;room.hidden=false;adminOpen.hidden=!user.admin;$('chatGroupTools').hidden=!user.admin;try{localStorage.setItem(lastUserKey,user.name)}catch(e){};conversations=snapshot.conversations||[];updateOnline(snapshot.onlineCount);setUnread(snapshot.unreadCount||0);renderConversations();setConnection('online','正在连接…');connectSocket();await refreshConversations(true)}
  async function refreshSession(){try{const data=await chatGet('/api/chat/session');if(data.loggedIn)await showLoggedIn(data.user,data);else{showLoggedOut();try{userInput.value=localStorage.getItem(lastUserKey)||''}catch(e){}}}catch(e){showLoggedOut('聊天服务暂时连接不上')}}
  async function authAction(path){if(loginBtn.disabled)return;authMsg.textContent='处理中…';loginBtn.disabled=registerBtn.disabled=true;try{const data=await chatPost(path,{username:userInput.value,password:passInput.value});await showLoggedIn(data.user,data);authMsg.textContent='';ensureAudio();crossTab?.postMessage({type:'login'})}catch(e){authMsg.textContent=e.message}finally{loginBtn.disabled=registerBtn.disabled=false}}

  loginBtn.onclick=()=>authAction('/api/chat/login');registerBtn.onclick=()=>authAction('/api/chat/register');passInput.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();authAction('/api/chat/login')}});
  $('chatLogout').onclick=async()=>{try{await chatPost('/api/chat/logout',{})}catch(e){}showLoggedOut('已退出聊天');crossTab?.postMessage({type:'logout'})};
  $('chatConversationToggle').onclick=()=>{panel.hidden=!panel.hidden;adminPanel.hidden=true};$('chatConversationClose').onclick=()=>panel.hidden=true;
  $('chatAddFriendForm').addEventListener('submit',async e=>{e.preventDefault();const v=$('chatFriendName').value.trim();if(!v)return;try{const d=await chatPost('/api/chat/friends',{username:v});$('chatFriendName').value='';await refreshConversations();await selectConversation(d.conversationId)}catch(err){setConnection('offline',err.message)}});
  $('chatCreateGroup').onclick=async()=>{const name=$('chatGroupName').value.trim(),members=$('chatGroupMembers').value.trim();if(!name)return;try{const d=await chatPost('/api/chat/groups',{name,members});$('chatGroupName').value='';$('chatGroupMembers').value='';await refreshConversations();await selectConversation(d.conversationId);if(d.missing?.length)setConnection('online',`群已创建，未找到：${d.missing.join('、')}`)}catch(e){setConnection('offline',e.message)}};

  input.addEventListener('input',()=>{saveDraft();updateComposer()});input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();composer.requestSubmit()}});
  composer.addEventListener('submit',async e=>{e.preventDefault();const body=input.value.trim();if(!body||sendBusy||!currentCid)return;sendBusy=true;sendBtn.disabled=true;sendBtn.textContent='发送中';const clientKey=makeClientKey();try{const data=await chatPost('/api/chat/messages',{conversationId:currentCid,body,clientKey});appendItems([{...data.message,mine:true}],false);if(input.value.trim()===body){input.value='';saveDraft();updateComposer()}scrollBottom();setConnection('online','已发送');crossTab?.postMessage({type:'poke'})}catch(err){setConnection('offline',err.message)}finally{sendBusy=false;sendBtn.disabled=false;sendBtn.textContent='发送';if(!compact())input.focus()}});

  async function startRecording(e){if(!currentCid||recorder||!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder){setConnection('offline','当前浏览器不支持语音录制');return}e.preventDefault();recordStartX=e.clientX||0;recordCancelled=false;recordChunks=[];try{mic.setPointerCapture?.(e.pointerId);recordStream=await navigator.mediaDevices.getUserMedia({audio:true});let opts={};if(MediaRecorder.isTypeSupported?.('audio/webm;codecs=opus'))opts={mimeType:'audio/webm;codecs=opus'};recorder=new MediaRecorder(recordStream,opts);recorder.ondataavailable=ev=>{if(ev.data?.size)recordChunks.push(ev.data)};recorder.onstop=finishRecording;recordStarted=Date.now();recording.hidden=false;mic.classList.add('recording');recordingTime.textContent='0:00';recordTimer=setInterval(()=>{recordingTime.textContent=formatDuration(Date.now()-recordStarted)},200);recorder.start(200)}catch(err){cleanupRecording();setConnection('offline','无法使用麦克风，请检查权限')}}
  function moveRecording(e){if(!recorder)return;if((e.clientX||0)<recordStartX-70){recordCancelled=true;recording.querySelector('strong').textContent='松开取消';mic.classList.add('cancel')}else{recordCancelled=false;recording.querySelector('strong').textContent='● 正在录音';mic.classList.remove('cancel')}}
  function stopRecording(e,cancel=false){if(!recorder)return;e?.preventDefault?.();recordCancelled=recordCancelled||cancel;if(recorder.state!=='inactive')recorder.stop()}
  function cleanupRecording(){clearInterval(recordTimer);recordTimer=null;recordStream?.getTracks?.().forEach(t=>t.stop());recordStream=null;recorder=null;recording.hidden=true;mic.classList.remove('recording','cancel');recording.querySelector('strong').textContent='● 正在录音'}
  async function finishRecording(){const duration=Date.now()-recordStarted,type=recorder?.mimeType||'audio/webm',blob=new Blob(recordChunks,{type});const cancel=recordCancelled||duration<450;cleanupRecording();if(cancel){setConnection('online',duration<450?'录音太短，未发送':'已取消录音');return}const form=new FormData();form.append('conversationId',String(currentCid));form.append('durationMs',String(duration));form.append('clientKey',makeClientKey());form.append('audio',blob,'voice.webm');try{setConnection('online','正在发送语音…');const d=await chatForm('/api/chat/voice',form);appendItems([{...d.message,mine:true}],false);scrollBottom();setConnection('online','语音已发送')}catch(e){setConnection('offline',e.message)}}
  mic.addEventListener('pointerdown',startRecording);mic.addEventListener('pointermove',moveRecording);mic.addEventListener('pointerup',e=>stopRecording(e));mic.addEventListener('pointercancel',e=>stopRecording(e,true));mic.addEventListener('contextmenu',e=>e.preventDefault());

  async function loadStorage(){if(!me?.admin)return;try{const d=await chatGet('/api/chat/admin/storage');const mb=(d.voiceBytes/1024/1024).toFixed(1);storageStats.innerHTML=`<span>消息<br><strong>${d.messages}</strong></span><span>语音<br><strong>${d.voices}</strong></span><span>语音空间<br><strong>${mb}MB</strong></span><span>用户/群<br><strong>${d.users}/${d.groups}</strong></span>`}catch(e){storageStats.textContent=e.message}}
  function updateAdminGroupControls(){const group=currentConversation()?.kind==='group';$('chatAddGroupMembers').disabled=!group;$('chatAddGroupMembersBtn').disabled=!group}
  adminOpen.onclick=()=>{adminPanel.hidden=!adminPanel.hidden;panel.hidden=true;if(!adminPanel.hidden){loadStorage();updateAdminGroupControls()}};$('chatAdminClose').onclick=()=>adminPanel.hidden=true;
  $('chatAddGroupMembersBtn').onclick=async()=>{const c=currentConversation(),members=$('chatAddGroupMembers').value.trim();if(!c||c.kind!=='group'||!members)return;try{const d=await chatPost(`/api/chat/groups/${c.id}/members`,{members});$('chatAddGroupMembers').value='';setConnection('online',d.missing?.length?`已添加，未找到：${d.missing.join('、')}`:'成员已加入群聊')}catch(e){setConnection('offline',e.message)}};
  $('chatClearAll').onclick=async()=>{if(!confirm('确定清除整个聊天系统的全部消息和语音吗？\n账号、好友和群聊会保留。'))return;if(!confirm('再次确认：数据库消息记录和语音文件都会物理删除，无法恢复。'))return;try{const d=await chatPost('/api/chat/admin/clear-all',{confirm:'CLEAR_ALL_CHAT'});messages.replaceChildren();lastId=0;syncCursor=0;seenMessageIds=new Set();emptyThread('聊天记录已全部清除');await refreshConversations();await loadStorage();setConnection('online',`已清除，删除语音文件 ${d.removedVoiceFiles} 个`)}catch(e){setConnection('offline',e.message)}};

  soundBtn.onclick=()=>{soundEnabled=!soundEnabled;try{localStorage.setItem(soundKey,soundEnabled?'on':'off')}catch(e){}applySound();if(soundEnabled){ensureAudio();dingDong()}};
  launcher.onclick=()=>openChat(true);$('chatMinimize').onclick=()=>openChat(false);$('chatFullscreen').onclick=toggleFullscreen;box.addEventListener('pointerdown',ensureAudio,{passive:true,once:true});jumpNew.onclick=scrollBottom;messages.addEventListener('scroll',()=>{if(nearBottom()){setRoomNew(0);scheduleRead(220)}},{passive:true});
  compactQuery?.addEventListener?.('change',syncViewport);window.visualViewport?.addEventListener('resize',syncViewport,{passive:true});window.visualViewport?.addEventListener('scroll',syncViewport,{passive:true});window.addEventListener('resize',syncViewport,{passive:true});
  window.addEventListener('online',()=>{setConnection('online','正在重新连接…');connectSocket();loadMessages(false)});window.addEventListener('offline',()=>setConnection('offline','网络已断开 · 等待恢复'));
  crossTab?.addEventListener('message',e=>{const m=e.data||{};if(m.type==='poke'){loadMessages(false);refreshConversations(false)}else if(m.type==='logout')showLoggedOut('已在其他页面退出聊天');else if(m.type==='login')refreshSession()});
  function schedulePolling(){clearTimeout(pollTimer);pollTimer=setTimeout(async()=>{if(me&&currentCid&&(!socket||socket.readyState!==1))await loadMessages(false);schedulePolling()},socket?.readyState===1?7000:1200)}
  function scheduleConversationPolling(){clearTimeout(conversationTimer);conversationTimer=setTimeout(async()=>{if(me)await refreshConversations(false);scheduleConversationPolling()},box.hidden?3500:5500)}
  applySound();setUnread(0);updateComposer();refreshSession().finally(()=>{schedulePolling();scheduleConversationPolling()});document.addEventListener('visibilitychange',()=>{if(!document.hidden){loadMessages(false);refreshConversations(false);if(me&&(!socket||socket.readyState>1))connectSocket()}});window.addEventListener('pagehide',()=>{unlockPage();closeSocket()});
}

function initManualPredictionHistory(){
  const list=document.getElementById('manualPredHistoryList');if(!list)return;
  const stats=document.getElementById('manualPredHistoryStats'),title=document.getElementById('manualPredHistoryTitle'),meta=document.getElementById('manualPredHistoryMeta');
  const params=new URLSearchParams(location.search);let tail=Number(params.get('tail'));if(!Number.isInteger(tail)||tail<0||tail>9)tail=null;
  const make=(tag,text,cls)=>{const el=document.createElement(tag);if(cls)el.className=cls;if(text!==undefined)el.textContent=text;return el};
  async function run(){
    try{
      const url='/api/manual-tail/predictions?limit=300'+(tail===null?'':`&tail=${tail}`),r=await fetch(url,{cache:'no-store'}),d=await r.json();if(!r.ok)throw Error(d.error||'读取失败');tail=d.tail;title.textContent=`${tail}尾 · 预判历史`;meta.textContent=`最近${d.items.length}期已核对记录`;
      const st=d.stats||{},rate=st.total?`${(Number(st.eitherRate||0)*100).toFixed(1)}%`:'—';stats.replaceChildren(
        stat('核对',st.total||0),stat('①命中',st.firstHits||0),stat('②命中',st.secondHits||0),stat('总命中率',rate));
      list.replaceChildren();if(!d.items.length){list.append(make('div','暂无已核对预判记录','chat-empty'));return}
      const frag=document.createDocumentFragment();for(const item of d.items){const row=make('div','',`manual-pred-history-row ${item.hit}`),issue=make('span',item.issue?item.issue.slice(-4):'----','issue');const a=make('span','','manual-pred-history-number'+(item.hit==='first'||item.hit==='both'?' hit':''));a.append(make('i','①'),make('b',String(item.predictionA)));const b=make('span','','manual-pred-history-number'+(item.hit==='second'||item.hit==='both'?' hit':''));b.append(make('i','②'),make('b',String(item.predictionB)));const labels={first:'①命中',second:'②命中',both:'①②命中',miss:'未中'};row.append(issue,a,b,make('span',labels[item.hit]||'未中',`manual-pred-history-result ${item.hit}`));frag.append(row)}list.append(frag)
    }catch(e){list.replaceChildren(make('div',e.message||'读取失败','chat-empty'))}
  }
  function stat(label,value){const el=make('div','', 'manual-pred-history-stat');el.append(make('span',label),make('strong',String(value)));return el}
  run();
}
