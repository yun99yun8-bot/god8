import os
import sys
import unittest
sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))

from tail_odds import analyze_tail


class TailOddsTests(unittest.TestCase):
    def test_tail_rates_and_omissions_are_descriptive(self):
        rows=[('2026-09-30:1300',3,86701013),
              ('2026-09-30:1301',4,86701033),
              ('2026-09-30:1302',3,86701053)]
        result=analyze_tail(rows,3)
        self.assertEqual(result['valid'],3)
        self.assertEqual(result['items'][3]['hits'],2)
        self.assertAlmostEqual(result['items'][3]['hitRate'],2/3)
        self.assertAlmostEqual(result['items'][3]['missRate'],1/3)
        self.assertEqual(result['items'][4]['gap'],1)
        self.assertIsNone(result['items'][4]['historicalGapReachRate'])

    def test_no_omission_join_across_tail_phase_or_void(self):
        rows=[('2026-09-30:1296',3,86700934),
              ('2026-09-30:1297',4,86700954),
              ('2026-09-30:1301',4,86701034),
              ('2026-09-30:1302',None,86701054)]
        report=analyze_tail(rows,4)
        self.assertEqual(report['invalid'],1)
        self.assertIsNone(report['items'][3]['gap'])
        self.assertEqual(report['items'][3]['completedRuns'],0)

    def test_wrong_tail_is_rejected(self):
        with self.assertRaises(ValueError):
            analyze_tail([('2026-09-30:1300',3,86701013)],2)


if __name__=='__main__':unittest.main()
