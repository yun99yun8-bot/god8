from datetime import datetime, timezone
from pathlib import Path

import live_replay
import manual_tail_center as mt

ROOT = Path(__file__).resolve().parents[1]


def test_shared_clock_boundary_and_45_reveal():
    # display offset is -3: wall second 03 is countdown 60, second 18 is countdown 45.
    at_60 = datetime(2026, 10, 3, 8, 0, 3, tzinfo=timezone.utc)
    at_45 = datetime(2026, 10, 3, 8, 0, 18, tzinfo=timezone.utc)
    assert live_replay.prediction_cycle(at_60)['remaining'] == 60
    assert live_replay.prediction_cycle(at_60)['forecastVisible'] is False
    assert live_replay.prediction_cycle(at_45)['remaining'] == 45
    assert live_replay.prediction_cycle(at_45)['forecastVisible'] is True


def test_manual_platform_calibration_is_unchanged():
    assert mt.manual_period_key(86775289, 9) == '2026-10-03:0695'
    assert mt.manual_period_key(86775309, 9) == '2026-10-03:0696'
    assert mt.manual_anchor_block(9) == 86775289


def test_delay_notice_and_two_independent_clock_gates_exist():
    js=(ROOT/'static'/'app.js').read_text(encoding='utf8')
    assert js.count("state.textContent='开奖结果延迟获取中，请稍等…'") >= 2
    assert 'predictionIssueClockParts' in js
    assert 'latestIssue!==cycle.current' in js
