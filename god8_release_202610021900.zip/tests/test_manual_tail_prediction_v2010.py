from pathlib import Path
import manual_tail_center as mt

ROOT = Path(__file__).resolve().parents[1]


def test_manual_fallback_returns_two_with_sufficient_history():
    rows=[]
    for i in range(180):
        rows.append((f'2026-10-02:{i:04d}', i % 8, None))
    preview=mt._manual_fallback_preview(rows)
    assert preview is not None
    assert len(preview['predictions']) == 2
    assert preview['predictions'][0] != preview['predictions'][1]
    assert preview['match']['selectionPolicy'] == 'manual-trend-omission-fallback'


def test_tail_selection_queues_prediction_runtime():
    source=(ROOT/'manual_tail_center.py').read_text()
    body=source[source.index('def select_tail'):source.index('def selected_tail')]
    assert "set_meta('manual_tail_prediction_request', request)" in body
    assert "set_meta('manual_tail_prediction_runtime', request)" in body


def test_worker_predicts_before_backfill_and_checks_each_second():
    source=(ROOT/'worker_ai.py').read_text()
    body=source[source.index('def manual_tail_worker'):source.index('def main')]
    assert body.index('prediction=prediction_step(tail)') < body.index('if backfill_enabled()')
    assert "time.sleep(1)" in body
    assert "tail-switch-priority" in body


def test_manual_page_surfaces_worker_and_queue_states():
    source=(ROOT/'static'/'app.js').read_text()
    assert '预测Worker异常' in source
    assert '预测任务已排队' in source
    assert "phase==='holding'" in source
