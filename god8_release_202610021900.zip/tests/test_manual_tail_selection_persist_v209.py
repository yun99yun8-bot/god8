from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_manual_page_never_forces_tail_nine_on_init():
    js = (ROOT / 'static/app.js').read_text(encoding='utf8')
    start = js.index('async function initManualTailHome()')
    end = js.index('}', start)
    # Use a wider slice because the function contains nested blocks.
    chunk = js[start:start+2200]
    assert "await get('/api/manual-tail')" in chunk
    assert "postJson('/api/manual-tail/select',{tail:9})" not in chunk
    assert 'manualTailCurrent=Number(saved.tail)' in chunk


def test_manual_nine_is_not_labeled_automatic_anymore():
    js = (ROOT / 'static/app.js').read_text(encoding='utf8')
    html = (ROOT / 'templates/manual_tail.html').read_text(encoding='utf8')
    assert '自动9尾' not in js
    assert '自动9尾' not in html
    assert '手动模式 · 当前 ${a.tail}尾' in js


def test_backend_selection_is_persistent_meta_state():
    source = (ROOT / 'manual_tail_center.py').read_text(encoding='utf8')
    assert "set_meta('manual_tail_selected', state)" in source
    assert "get_meta('manual_tail_selected')" in source
