import sys,os,unittest
sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))
from core import *
from audit import independent_target,independent_numbers
from collector_service import last_finished_index
class T(unittest.TestCase):
 def test_anchor(self):self.assertEqual(target_block('2026-09-24',481),86511906)
 def test_next(self):self.assertEqual(target_block('2026-09-24',482),86511926)
 def test_360_correction(self):
  i=ANCHOR_INDEX
  tails=[]
  for phase in range(-1,6):
   ds,p=from_index(i+phase*360);tails.append(target_block(ds,p)%10)
  self.assertEqual(tails,[8,6,4,2,0,8,6])
 def test_platform_exception_and_continued_360(self):
  self.assertEqual([target_block('2026-09-29',p) for p in range(989,995)],
                   [86666024,86666044,86666063,86666082,86666102,86666122])
  # The temporary -2 offset remains, but the old 1201 phase boundary survives.
  self.assertEqual([target_block('2026-09-29',p) for p in (1200,1201,1221,1224,1236)],
                   [86670242,86670260,86670660,86670720,86670960])
  self.assertEqual([target_block('2026-09-30',p) for p in (120,121)],
                   [86677440,86677458])
  at=pindex('2026-09-29',992)
  for n in (0,1,359,360,720):
   ds,p=from_index(at+n)
   self.assertEqual(target_block(ds,p),independent_target(ds,p))
  self.assertEqual(target_block(*from_index(at+360))-target_block(*from_index(at)),7198)
  self.assertEqual([target_block(*from_index(at+n))%10 for n in (0,208,209,359,360,569)],
                   [2,2,0,0,0,8])
 def test_sep30_confirmed_temporary_three_tail_and_next_zero_phase(self):
  observed={1295:86700914,1296:86700934,1297:86700954,
            1298:86700974,1299:86700994,1300:86701013,
            1301:86701033,1302:86701053,1303:86701073,
            1304:86701093,1305:86701113,1306:86701133}
  for period,block in observed.items():
   self.assertEqual(target_block('2026-09-30',period),block)
   self.assertEqual(independent_target('2026-09-30',period),block)
  self.assertEqual(target_block('2026-10-01',120)%10,3)
  # Every formal issue in the temporary interval must use a 3-tail target,
  # including rows rebuilt later for the History page.
  for idx in range(pindex('2026-09-30',1300),pindex('2026-10-01',120)+1):
   ds,p=from_index(idx);self.assertEqual(target_block(ds,p)%10,3,(ds,p))
  self.assertEqual(target_block('2026-10-01',121)%10,0)
  self.assertEqual(target_block('2026-10-01',481)%10,8)
 def test_independent_mapping(self):
  for d in (-10000,-721,-360,-1,0,1,359,360,361,9999):
   ds,p=from_index(ANCHOR_INDEX+d);self.assertEqual(target_block(ds,p),independent_target(ds,p))
 def test_numbers_example(self):
  # synthetic hash: reversed scan yields E4,B3,A2,C9,A9,B5,B1 -> 44,13,02,29,09,15,11
  pairs=['E4','B3','A2','C9','A9','B5','B1']
  rev=''.join(pairs);h=rev[::-1]
  self.assertEqual(calc_numbers(h),[44,13,2,29,9,15,11])
  self.assertEqual(independent_numbers(h),[44,13,2,29,9,15,11])
 def test_duplicate_and_00_discard(self):
  pairs=['A0','B1','B1','C2','D3','E4','A5','B6','C7']
  h=''.join(pairs)[::-1]
  self.assertEqual(calc_numbers(h),[11,22,33,44,5,16,27])
 def test_single(self):self.assertEqual(single_count([1,2,3,4,5,6,7]),4)
 def test_hash_without_seven_valid_numbers_remains_unlabeled(self):
  h='0'*64
  with self.assertRaisesRegex(ValueError,'7 valid'):calc_numbers(h)
  self.assertEqual(valid_result(h),(None,None))
 def test_historical_snapshot_never_includes_unfinished_round(self):
  for delta in (0,1,359,360,721):
   i=ANCHOR_INDEX+delta
   end=target_block(*from_index(i))
   self.assertEqual(last_finished_index(end),i)
   self.assertEqual(last_finished_index(end-1),i-1)
   self.assertEqual(last_finished_index(end+1),i)
if __name__=='__main__':unittest.main()
