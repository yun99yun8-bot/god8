"""Walk-forward adaptive historical prediction.

Every forecast uses only periods that were already known before the target issue.
Exact-sequence replay is never used with fewer than four synchronized periods.
Recent activity, hot/cold drift and omission hazard are auxiliary methods whose
weights are updated from their own already-settled predictions.
"""
from collections import Counter, defaultdict, deque
from math import ceil

from omission_research import issue
from streak_research import issue_index

REPLAY_LENGTHS = (8, 7, 6, 5, 4)
REPLAY_SUPPORT = {8: 3, 7: 3, 6: 4, 5: 5, 4: 6}
METHOD_LABELS = {
    'replay': '四期以上复现',
    'trend': '近期活跃趋势',
    'omission': '遗漏条件',
    'frequency': '长期频数',
}


def _chronological(rows):
    parsed = [(issue_index(key), key, value, numbers) for key, value, numbers in rows]
    parsed.sort(key=lambda row: row[0])
    return parsed


def _valid(value):
    return type(value) is int and 0 <= value <= 7


def _counter_prob(counter, total=None, alpha=0.5):
    total = total if total is not None else sum(counter.values())
    denom = total + alpha * 8
    if denom <= 0:
        return [1 / 8] * 8
    return [(counter[k] + alpha) / denom for k in range(8)]


def _normalize(values):
    clean = [max(0.0, float(v)) for v in values]
    total = sum(clean)
    return [v / total for v in clean] if total else [1 / 8] * 8


def _quantile(values, q):
    if not values:
        return None
    ordered = sorted(values)
    at = min(len(ordered) - 1, max(0, ceil(q * len(ordered)) - 1))
    return ordered[at]


def _replay_method(history, counters, sources, long_prob):
    levels = []
    for length in REPLAY_LENGTHS:
        if len(history) < length:
            continue
        sequence = tuple(history[-length:])
        votes = counters[length].get(sequence, Counter())
        support = sum(votes.values())
        minimum = REPLAY_SUPPORT[length]
        if support < minimum:
            continue
        # More synchronized periods get less shrinkage; short matches must have
        # more repeats before they can influence the forecast.
        prior_strength = max(5.0, 16.0 - length)
        probs = _normalize([(votes[k] + prior_strength * long_prob[k])
                            / (support + prior_strength) for k in range(8)])
        # Only an observed immediate successor can occupy a replay slot.
        ranked = sorted(range(8), key=lambda k: (-votes[k], -probs[k], k))
        levels.append((length, sequence, votes, support, ranked, probs))
    if levels:
        length, sequence, votes, support, ranked, probs = levels[0]
        # Keep the longest synchronized match as the first line of evidence,
        # but retain shorter (still >=4 issue) matches for a different second
        # successor. A hot overall label must not erase repeated 1/6 successors.
        primary = ranked[0]
        alternatives = []
        summary = []
        for depth, seq, counts, n, order, _ in levels:
            summary.append({'length': depth, 'support': n,
                            'votes': {str(k): counts[k] for k in range(8) if counts[k]}})
            if n < 12:
                continue
            for candidate in range(8):
                if candidate == primary or counts[candidate] < 4:
                    continue
                share = counts[candidate] / n
                lift = share / max(long_prob[candidate], 1e-9)
                if share >= 0.24 and lift >= 1.35:
                    alternatives.append((share * min(n, 30) / (min(n, 30) + 8),
                                         depth, counts[candidate], candidate, n, share))
        alternatives.sort(reverse=True)
        backoff = None
        if alternatives:
            _, depth, hits, candidate, n, share = alternatives[0]
            backoff = {'candidate': candidate, 'length': depth, 'hits': hits,
                       'support': n, 'share': round(share, 4),
                       'baseline': round(long_prob[candidate], 4),
                       'sources': sources[depth].get((tuple(history[-depth:]), candidate), [])[-3:]}
        successors = []
        # The longest exact context supplies the first candidate. A shorter
        # exact context (never fewer than four periods) may supply the second.
        # Auxiliary methods break ties among actual successors only.
        for depth, seq, counts, n, order, _ in levels:
            for candidate in range(8):
                if counts[candidate]:
                    baseline = max(long_prob[candidate], 1e-9)
                    successors.append({'candidate': candidate, 'length': depth,
                                       'hits': counts[candidate], 'support': n,
                                       'share': round(counts[candidate] / n, 4),
                                       'baseline': round(long_prob[candidate], 4),
                                       'lift': round((counts[candidate] / n) / baseline, 4),
                                       'sources': sources[depth].get((seq, candidate), [])[-3:]})
        return {
            'name': 'replay', 'scores': probs,
            'top': [k for k in ranked if votes[k]][:2], 'length': length,
            'sequence': list(sequence), 'support': support, 'minimumSupport': REPLAY_SUPPORT[length],
            'votes': {str(k): votes[k] for k in range(8) if votes[k]},
            'levels': summary, 'backoff': backoff, 'successors': successors,
            'sources': {str(k): (backoff['sources'] if backoff and backoff['candidate'] == k
                                  else sources[length].get((sequence, k), [])[-3:])
                        for k in set(ranked[:2] + ([backoff['candidate']] if backoff else []))},
            'detail': f'{length}期同步 · 历史复现{support}次',
        }
    return None


def _trend_method(recent, long_prob):
    if len(recent) < 20:
        return None
    windows = [20, 50, 100]
    weights = [0.55, 0.30, 0.15]
    weighted = [0.0] * 8
    lifts = [1.0] * 8
    for window, weight in zip(windows, weights):
        sample = list(recent)[-min(window, len(recent)):]
        counts = Counter(sample)
        size = len(sample)
        probs = _counter_prob(counts, size, alpha=0.75)
        for k in range(8):
            weighted[k] += weight * probs[k]
    for k in range(8):
        lifts[k] = weighted[k] / max(long_prob[k], 1e-9)
    # Trend follows meaningful drift but remains partially shrunk to the long-run
    # distribution so a tiny hot streak does not become a fixed 3/4 loop.
    probs = _normalize([0.72 * weighted[k] + 0.28 * long_prob[k] for k in range(8)])
    ranked = sorted(range(8), key=lambda k: (-probs[k], -lifts[k], k))
    hot = [k for k in ranked if lifts[k] >= 1.20][:3]
    cold = [k for k in sorted(range(8), key=lambda k: (lifts[k], k)) if lifts[k] <= 0.82][:3]
    return {
        'name': 'trend', 'scores': probs, 'top': ranked[:2],
        'hot': hot, 'cold': cold,
        'lifts': {str(k): round(lifts[k], 3) for k in range(8)},
        'detail': '最近20/50/100期活跃度对比长期分布',
    }


def _omission_method(gaps, completed_gaps, long_prob):
    scores = []
    info = {}
    enough = False
    for k in range(8):
        gap = int(gaps[k])
        historical = list(completed_gaps[k])
        eligible = [value for value in historical if value >= gap]
        hits = sum(value == gap for value in eligible)
        baseline = long_prob[k]
        support = len(eligible)
        hazard = (hits + 12 * baseline) / (support + 12)
        p90 = _quantile(historical, 0.90)
        ratio = hazard / max(baseline, 1e-9)
        # Only adjust omission meaningfully when there is enough comparable
        # historical evidence. For 3/4, an overdue state that historically did
        # not improve next-period hazard is automatically squeezed down.
        strength = min(1.0, support / 24.0)
        adjusted = baseline * (1.0 + strength * (ratio - 1.0))
        squeeze = False
        boost = False
        if p90 is not None and gap >= p90 and support >= 8:
            if k in (3, 4) and hazard <= baseline * 0.95:
                adjusted *= 0.72
                squeeze = True
            elif hazard >= baseline * 1.15:
                adjusted *= 1.16
                boost = True
        scores.append(max(1e-6, adjusted))
        info[str(k)] = {
            'gap': gap, 'support': support, 'nextRate': round(hazard, 4),
            'baseline': round(baseline, 4), 'p90': p90,
            'squeezed': squeeze, 'boosted': boost,
        }
        enough = enough or support >= 8
    if not enough:
        return None
    probs = _normalize(scores)
    ranked = sorted(range(8), key=lambda k: (-probs[k], k))
    return {
        'name': 'omission', 'scores': probs, 'top': ranked[:2], 'gaps': info,
        'detail': '当前遗漏与历史同等遗漏后的下一期表现',
    }


def _frequency_method(long_prob):
    ranked = sorted(range(8), key=lambda k: (-long_prob[k], k))
    return {
        'name': 'frequency', 'scores': list(long_prob), 'top': ranked[:2],
        'detail': '长期频数仅作低权重基线',
    }


def _method_weight(name, performance, miss_streak):
    outcomes = performance[name]
    n = len(outcomes)
    hits = sum(outcomes)
    # Bayesian shrinkage toward a neutral two-of-eight rate. This keeps a method
    # from taking over because of a handful of lucky results.
    posterior = (hits + 10 * 0.25) / (n + 10)
    weight = 0.70 + 1.35 * (posterior - 0.25)
    if name == 'frequency':
        weight *= 0.62
    if miss_streak[name] >= 3:
        weight *= max(0.58, 0.88 ** (miss_streak[name] - 2))
    return max(0.45, min(1.45, weight)), posterior


def _label_penalty(candidate, label_performance, label_miss_streak, recent_choices):
    """Softly down-weight a label using only already-settled forecasts."""
    penalty = 1.0
    if label_performance is not None:
        outcomes = list(label_performance.get(candidate, ()))
        if len(outcomes) >= 6:
            hits = sum(outcomes)
            # Shrink toward a neutral one-of-eight hit rate so small samples do
            # not overreact. This never looks at the target or future period.
            posterior = (hits + 8 * 0.125) / (len(outcomes) + 8)
            penalty *= max(0.74, min(1.08, 0.88 + posterior))
    if label_miss_streak is not None:
        misses = int(label_miss_streak.get(candidate, 0))
        if misses >= 2:
            penalty *= max(0.52, 0.86 ** (misses - 1))
    if recent_choices:
        last = list(recent_choices)[-6:]
        repeats = sum(candidate in pair for pair in last)
        if repeats >= 3:
            penalty *= max(0.68, 1.0 - 0.07 * (repeats - 2))
    return penalty


def _ensemble(methods, performance, miss_streak, label_performance=None,
              label_miss_streak=None, recent_choices=None):
    if not methods:
        return None
    combined = [0.0] * 8
    diagnostics = []
    for method in methods:
        weight, recent_rate = _method_weight(method['name'], performance, miss_streak)
        for k in range(8):
            combined[k] += weight * method['scores'][k]
        diagnostics.append({
            'name': method['name'], 'label': METHOD_LABELS[method['name']],
            'weight': round(weight, 3), 'recentRate': round(recent_rate, 4),
            'samples': len(performance[method['name']]), 'missStreak': miss_streak[method['name']],
            'top': method['top'], 'detail': method['detail'],
        })
    ranked = sorted(range(8), key=lambda k: (-combined[k], k))
    replay = next((m for m in methods if m['name'] == 'replay'), None)
    # Never turn a hot-frequency ranking into an alleged historical replay.
    if not replay:
        return None
    successors = replay['successors']
    if len({s['candidate'] for s in successors}) < 2:
        return None

    trend = next((m for m in methods if m['name'] == 'trend'), None)
    omission = next((m for m in methods if m['name'] == 'omission'), None)
    max_combined = max(combined) or 1.0

    # Only actual successors of a >=4-period synchronized context are eligible.
    # Unlike the old rule, raw successor count is no longer the first sort key.
    # Conditional lift, live trend/omission evidence and settled misses can
    # outweigh the long-run popularity of labels such as 3/4.
    scored = []
    for candidate in sorted({s['candidate'] for s in successors}):
        evidences = [s for s in successors if s['candidate'] == candidate]
        evidence_rows = []
        for ev in evidences:
            baseline = max(float(ev.get('baseline', 0.125)), 1e-9)
            lift = float(ev.get('lift', float(ev['share']) / baseline))
            replay_strength = (
                0.30 * (float(ev['length']) / max(REPLAY_LENGTHS)) +
                0.24 * min(1.5, float(ev['share']) / 0.30) +
                0.28 * min(1.7, lift / 1.55) +
                0.18 * min(1.4, float(ev['hits']) / 8.0)
            )
            evidence_rows.append((replay_strength, ev))
        evidence_rows.sort(key=lambda item: (-item[0], -item[1]['length'],
                                              -item[1]['hits']))
        replay_strength, best = evidence_rows[0]
        ensemble_strength = combined[candidate] / max_combined
        score = 0.64 * replay_strength + 0.36 * ensemble_strength

        # High baseline frequency by itself is not evidence of a replay edge.
        if float(best.get('lift', 1.0)) <= 1.08:
            score *= 0.72
        if trend and candidate in trend.get('hot', ()):
            score *= 1.08
        if trend and candidate in trend.get('cold', ()):
            score *= 0.94
        gap_info = (omission or {}).get('gaps', {}).get(str(candidate), {})
        if gap_info.get('boosted'):
            score *= 1.08
        if gap_info.get('squeezed'):
            score *= 0.72
        settled_penalty = _label_penalty(candidate, label_performance,
                                         label_miss_streak, recent_choices)
        score *= settled_penalty
        scored.append((score, candidate, best, settled_penalty))

    scored.sort(key=lambda item: (-item[0], -item[2]['length'],
                                  -float(item[2].get('lift', 1.0)),
                                  -item[2]['hits'], item[1]))
    if len(scored) < 2:
        return None
    first_row, second_row = scored[0], scored[1]
    first, second = first_row[1], second_row[1]
    choices = [first, second]
    chosen_evidence = [first_row[2], second_row[2]]
    selected_sources = {str(row[1]): row[2]['sources'] for row in (first_row, second_row)}
    # Keep the public policy identifier stable for old pages/APIs; the detailed
    # adaptive selector is exposed separately below.
    policy = 'observed-replay-successors'
    # Explain each selected label with the methods that actually placed it in
    # their own top two, rather than a generic "high probability" message.
    reasons = {}
    for choice in choices:
        items = []
        for method in methods:
            if choice in method['top']:
                items.append(METHOD_LABELS[method['name']])
        if replay and (replay.get('backoff') or {}).get('candidate') == choice:
            items.append('四期以上复现的次级紧接结果')
        reasons[str(choice)] = items
    match = {
        'length': replay['length'] if replay else 0,
        'sequence': replay['sequence'] if replay else [],
        'support': replay['support'] if replay else 0,
        'minimumSupport': replay['minimumSupport'] if replay else REPLAY_SUPPORT[4],
        'votes': replay['votes'] if replay else {},
        'levels': replay.get('levels', []) if replay else [],
        'backoff': replay.get('backoff') if replay else None,
        'selectionPolicy': policy,
        'selectionRevision': 'v2-lift-trend-omission-miss-aware',
        'selectedEvidence': chosen_evidence,
        'candidateScores': {str(row[1]): round(row[0], 6) for row in scored},
        'labelPenalties': {str(row[1]): round(row[3], 4) for row in scored},
        'sources': selected_sources,
        'methods': diagnostics,
        'reasons': reasons,
        'hot': trend.get('hot', []) if trend else [],
        'cold': trend.get('cold', []) if trend else [],
        'omission': omission.get('gaps', {}) if omission else {},
        'scores': {str(k): round(combined[k], 6) for k in set(ranked[:4] + choices)},
    }
    return choices, match


def simulate(rows, minimum_training=120, recent_limit=30):
    """Strict walk-forward backtest with adaptive method weights."""
    if minimum_training < 1:
        raise ValueError('minimum_training must be positive')
    indexed = _chronological(rows)
    counters = {length: defaultdict(Counter) for length in REPLAY_LENGTHS}
    sources = {length: defaultdict(list) for length in REPLAY_LENGTHS}
    overall = Counter()
    history = []
    recent = deque(maxlen=500)
    gaps = [0] * 8
    completed_gaps = [deque(maxlen=5000) for _ in range(8)]
    performance = {name: deque(maxlen=100) for name in METHOD_LABELS}
    miss_streak = {name: 0 for name in METHOD_LABELS}
    label_performance = {k: deque(maxlen=60) for k in range(8)}
    label_miss_streak = {k: 0 for k in range(8)}
    recent_choices = deque(maxlen=12)
    previous = None
    newest = None
    evaluated = skipped = missing = 0
    rank_hits = [0, 0]
    either_hits = 0
    baseline_hits = [0, 0]
    by_method = Counter()
    recent_rows = deque(maxlen=200)
    examples = []

    def methods_now():
        total = sum(overall.values())
        if total < minimum_training:
            return []
        long_prob = _counter_prob(overall, total, alpha=1.0)
        methods = []
        replay = _replay_method(history, counters, sources, long_prob)
        if replay:
            methods.append(replay)
        trend = _trend_method(recent, long_prob)
        if trend:
            methods.append(trend)
        omission = _omission_method(gaps, completed_gaps, long_prob)
        if omission:
            methods.append(omission)
        methods.append(_frequency_method(long_prob))
        return methods

    for at, key, actual, numbers in indexed:
        if previous is not None and at != previous + 1:
            history = []
            recent.clear()
            gaps = [0] * 8
            missing += max(0, at - previous - 1)
        previous = at
        if not _valid(actual):
            history = []
            recent.clear()
            gaps = [0] * 8
            skipped += 1
            continue

        methods = methods_now()
        selected = (_ensemble(methods, performance, miss_streak, label_performance,
                              label_miss_streak, recent_choices) if methods else None)
        if selected:
            choices, match = selected
            total = sum(overall.values())
            baseline = sorted(range(8), key=lambda k: (-overall[k], k))[:2]
            evaluated += 1
            first_hit = actual == choices[0]
            second_hit = actual == choices[1]
            either_hit = actual in choices
            rank_hits[0] += first_hit
            rank_hits[1] += second_hit
            either_hits += either_hit
            baseline_hits[0] += actual == baseline[0]
            baseline_hits[1] += actual in baseline
            recent_rows.append((first_hit, second_hit, either_hit,
                                actual == baseline[0], actual in baseline))
            active_names = []
            for method in methods:
                hit = actual in method['top']
                performance[method['name']].append(hit)
                miss_streak[method['name']] = 0 if hit else miss_streak[method['name']] + 1
                active_names.append(method['name'])
            for candidate in choices:
                hit = actual == candidate
                label_performance[candidate].append(hit)
                label_miss_streak[candidate] = 0 if hit else label_miss_streak[candidate] + 1
            recent_choices.append(tuple(choices))
            by_method['+'.join(active_names)] += 1
            record = {
                'issue': issue(at), 'predictions': choices, 'actual': actual,
                'numbers': numbers if isinstance(numbers, list) else None,
                'firstHit': first_hit, 'secondHit': second_hit, 'eitherHit': either_hit,
                'match': match,
            }
            examples.append(record)
            if len(examples) > recent_limit:
                examples.pop(0)

        # Register known successor only after the target has been scored.
        for length in REPLAY_LENGTHS:
            if len(history) >= length:
                context = tuple(history[-length:])
                counters[length][context][actual] += 1
                bucket = sources[length][(context, actual)]
                bucket.append({'issue': issue(at), 'single': actual,
                               'numbers': numbers if isinstance(numbers, list) else None})
                if len(bucket) > 3:
                    bucket.pop(0)
        overall[actual] += 1
        for k in range(8):
            if actual == k:
                completed_gaps[k].append(gaps[k])
                gaps[k] = 0
            else:
                gaps[k] += 1
        history.append(actual)
        if len(history) > max(REPLAY_LENGTHS):
            history.pop(0)
        recent.append(actual)
        newest = at

    preview = None
    methods = methods_now()
    selected = (_ensemble(methods, performance, miss_streak, label_performance,
                          label_miss_streak, recent_choices)
                if newest is not None and methods else None)
    if selected:
        choices, match = selected
        preview = {
            'issue': issue(newest + 1), 'predictions': choices, 'match': match,
            'note': '两码都必须是连续4期以上相同期序之后真实出现过的紧接结果；近期趋势与遗漏仅用于同证据候选的排序。证据不足时不生成预判。',
        }
    n = len(recent_rows)
    rates = [sum(row[i] for row in recent_rows) / n if n else None for i in range(5)]
    return {
        'stored': len(indexed), 'valid': sum(overall.values()), 'invalid': skipped,
        'missing': missing, 'evaluated': evaluated,
        'first': {'hits': rank_hits[0], 'rate': rank_hits[0] / evaluated if evaluated else None},
        'second': {'hits': rank_hits[1], 'rate': rank_hits[1] / evaluated if evaluated else None},
        'either': {'hits': either_hits, 'rate': either_hits / evaluated if evaluated else None},
        'baseline': {
            'firstHits': baseline_hits[0], 'firstRate': baseline_hits[0] / evaluated if evaluated else None,
            'eitherHits': baseline_hits[1], 'eitherRate': baseline_hits[1] / evaluated if evaluated else None,
        },
        'recent200': {
            'verified': n, 'firstRate': rates[0], 'secondRate': rates[1], 'eitherRate': rates[2],
            'baselineFirstRate': rates[3], 'baselineEitherRate': rates[4],
        },
        'methodCounts': dict(by_method), 'recent': list(reversed(examples)),
        'preview': preview, 'minimumTraining': minimum_training,
        'note': '严格逐期滚动。两码都来自连续4期以上同步历史的实际紧接结果；近期活跃、冷热和遗漏只在真实复现候选中排序，缺少两种结果则暂不预判。历史命中不保证未来。',
    }
