"""Persist a two-choice historical replay before the next target block exists."""
import json
from datetime import datetime, timezone

from core import DB, from_index, get_meta, pindex, target_block, runtime_config_revision, pool, set_meta
from history_simulation import simulate
from canonical_history import load as canonical_load, as_analysis as canonical_analysis

PREDICTION_LOCK_ID = 80086423
RESULT_HOLD_SECONDS = 10


def _runtime(status, **extra):
    payload={'status':status,'reportedAt':datetime.now(timezone.utc).isoformat(),**extra}
    try:
        set_meta('prediction_runtime',payload)
    except Exception:
        pass
    return payload


def target_for_latest(latest_key):
    ds, no = latest_key.split(':')
    next_ds, next_no = from_index(pindex(ds, int(no)) + 1)
    return f'{next_ds}:{next_no:04d}', target_block(next_ds, next_no)


def forecast_due(now, source_key, saved_at, next_block, head):
    """Allow locking whenever the source is known and the target block is future.

    The old wall-clock current/current-1 minute gate could suppress a valid
    pre-block forecast when calibration or formal period writing lagged the
    phone clock. Chain state is the anti-backdating authority.
    """
    elapsed = (now - saved_at).total_seconds()
    return elapsed >= RESULT_HOLD_SECONDS and head is not None and int(head) < int(next_block)


def advance(now=None):
    """One prediction tick. Return a diagnostic payload for watchdog callers."""
    now = now or datetime.now(timezone.utc)
    with DB() as conn:
        q = conn.cursor()
        q.execute('''UPDATE replay_forecasts f SET actual=p.single_count,settled_at=NOW()
                     FROM periods p WHERE f.period_key=p.period_key AND f.settled_at IS NULL''')
        q.close()

    latest_rows=canonical_load(limit=1,newest_first=True)
    if not latest_rows:
        return _runtime('waiting-latest-canonical')
    c=latest_rows[0]
    latest=(c[0],c[6],c[3],c[7],c[4])
    if latest[1] is None or not c[8]:
        return _runtime('waiting-valid-source',sourcePeriod=latest[0],canonical=bool(c[8]))

    target, next_block = target_for_latest(latest[0])
    # A stale pending row can survive a canonical-history correction or an
    # interrupted deploy. Because period_key is the primary key, such a row
    # blocks a fresh forecast even though the UI correctly refuses to show it
    # when source_period is no longer the newest canonical source.
    with DB() as conn:
        q=conn.cursor()
        q.execute("SELECT source_period,settled_at FROM replay_forecasts WHERE period_key=%s FOR UPDATE",(target,))
        existing=q.fetchone()
        if existing and existing[0] != latest[0] and existing[1] is None:
            q.execute('SELECT 1 FROM periods WHERE period_key=%s',(target,))
            formal_known=q.fetchone() is not None
            q.execute('SELECT 1 FROM raw_blocks WHERE block_number=%s',(next_block,))
            raw_known=q.fetchone() is not None
            if not formal_known and not raw_known:
                q.execute('DELETE FROM replay_forecasts WHERE period_key=%s AND settled_at IS NULL',(target,))
                existing=None
        q.close()
    if existing:
        return _runtime('locked',sourcePeriod=latest[0],targetPeriod=target,nextBlock=next_block,
                        storedSource=existing[0])

    elapsed=(now-latest[3]).total_seconds()
    if elapsed < RESULT_HOLD_SECONDS:
        return _runtime('holding-result',sourcePeriod=latest[0],targetPeriod=target,
                        holdSeconds=round(max(0,RESULT_HOLD_SECONDS-elapsed),1))

    head = (get_meta('chain_head') or {}).get('block')
    if not forecast_due(now, latest[0], latest[3], next_block, head):
        return _runtime('waiting-future-target',sourcePeriod=latest[0],targetPeriod=target,
                        nextBlock=next_block,head=head)

    canonical=canonical_load(limit=10000,newest_first=True)
    history=canonical_analysis(canonical)
    if not history or history[0][0] != latest[0]:
        return _runtime('waiting-history-sync',sourcePeriod=latest[0],
                        historyNewest=history[0][0] if history else None,rows=len(history))

    _runtime('simulating',sourcePeriod=latest[0],targetPeriod=target,
             nextBlock=next_block,head=head,historyRows=len(history),
             runtimeRevision=runtime_config_revision())
    preview = simulate(history)['preview']
    expected_issue=target[2:4]+target[5:7]+target[8:10]+target[11:]
    if not preview:
        return _runtime('no-preview',sourcePeriod=latest[0],targetPeriod=target,historyRows=len(history))
    if preview['issue'] != expected_issue:
        return _runtime('preview-period-mismatch',sourcePeriod=latest[0],targetPeriod=target,
                        expectedIssue=expected_issue,previewIssue=preview.get('issue'))

    # Recheck the target in the same transaction. Never backdate a prediction
    # against a target block/result that became known during the simulation.
    with DB() as conn:
        q = conn.cursor()
        q.execute('''INSERT INTO replay_forecasts(period_key,source_period,source_block,choices,match)
                     SELECT %s,%s,%s,%s::jsonb,%s::jsonb
                     WHERE NOT EXISTS(SELECT 1 FROM periods WHERE period_key=%s)
                       AND NOT EXISTS(SELECT 1 FROM raw_blocks WHERE block_number=%s)
                     ON CONFLICT(period_key) DO NOTHING''',
                  (target, latest[0], latest[2], json.dumps(preview['predictions']),
                   json.dumps(preview['match']), target, next_block))
        inserted=q.rowcount>0
        q.close()
    if inserted:
        return _runtime('locked',sourcePeriod=latest[0],targetPeriod=target,nextBlock=next_block,
                        head=head,choices=preview['predictions'],
                        policy=preview['match'].get('selectionPolicy'))
    return _runtime('target-became-known',sourcePeriod=latest[0],targetPeriod=target,
                    nextBlock=next_block,head=head)


def advance_guarded(now=None):
    """Run one tick under a short cross-service advisory lock.

    Collector and Worker both call this. Only one performs the 10k simulation
    at a time, while the other can take over on the next tick after an error or
    stall. The unique period key still guarantees a single stored forecast.
    """
    lease=pool().getconn()
    owned=False
    try:
        q=lease.cursor();q.execute('SELECT pg_try_advisory_lock(%s)',(PREDICTION_LOCK_ID,))
        owned=bool(q.fetchone()[0]);q.close();lease.commit()
        if not owned:
            return {'status':'busy-other-watchdog'}
        return advance(now)
    finally:
        if owned:
            try:
                q=lease.cursor();q.execute('SELECT pg_advisory_unlock(%s)',(PREDICTION_LOCK_ID,))
                q.close();lease.commit()
            except Exception:
                try: lease.rollback()
                except Exception: pass
        pool().putconn(lease)
