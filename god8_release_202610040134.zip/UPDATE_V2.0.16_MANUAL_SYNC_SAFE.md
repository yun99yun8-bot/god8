# v2.0.16 Manual Sync Safe

- Restores the original calibrated manual-tail block lane unchanged.
- 2026-10-02 issue 0337 keeps 9-tail block 86739339; 0-9 anchors remain 86739330..86739339.
- Manual page result issue now updates only together with the saved draw result.
- Countdown no longer overwrites the result issue before data arrives.
- Forecast responses expose targetIssue/targetBlock derived from sourceBlock+20, so predictions are visibly bound to the exact draw they settle against.
- No target_block() remapping is used in manual-tail mode.
