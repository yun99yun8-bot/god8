# God8 v2.0.28 · 呼叫挂断与 Android 接听修复

本次只修聊天语音通话交互，不修改开奖、区块、手动尾或预判核心。

## 修复

- “正在呼叫”阶段增加独立红色“挂断”按钮，点击立即结束本地呼叫 UI，并异步通知服务器取消来电。
- Android Chrome / WebView 接听不再复用“语音消息录音”权限检查，RTC 通话只要求 `getUserMedia`，不再依赖 `MediaRecorder`。
- Android 系统麦克风权限弹窗短暂让页面进入 hidden 时，不再被误判成“离开网页”并自动挂断。
- 接听流程改为：用户点击接听 → 在同一用户手势中申请麦克风 → 预加载 Agora SDK → 服务端确认接听 → 加入 RTC 频道。
- 增加 Android 粗指针按钮点击适配（touch-action / tap highlight / 更大点击区）。
- 真正刷新、关闭、切后台仍按原规则结束通话；仅系统权限弹窗被豁免。
- 挂断 UI 立即响应，不再等待网络请求完成后才退出“呼叫中”。

## 保持不变

`manual_tail_center.py`、`live_replay.py`、`platform_calibration.py`、`collector_service.py` 未改动。
