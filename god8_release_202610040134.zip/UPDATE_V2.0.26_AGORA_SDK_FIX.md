# v2.0.26 Agora SDK 加载修复

- Agora Web SDK 默认源改为 jsDelivr，并增加 unpkg 与 Agora 官方 CDN 三重回退。
- 移除动态 script 的 `crossOrigin=anonymous`，避免部分移动网络/CDN CORS 策略导致脚本被浏览器拒绝。
- 每个 SDK 源增加 12 秒超时和失败自动切换，失败脚本自动移除。
- SDK 下载成功但未创建 `window.AgoraRTC` 时继续尝试下一源。
- 不改动开奖、区块、预判核心文件。
