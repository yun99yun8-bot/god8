# v2.0.23 Web 502 启动修复

本修复仅处理 Web 启动安全：撤销 Gunicorn 对 gevent worker 的硬依赖，恢复 threaded worker。

- WebSocket 聊天保留：Flask-Sock 在依赖已安装时继续使用 WebSocket。
- 如果 flask-sock 暂不可用，聊天自动退回轮询；开奖、预测和页面仍可启动。
- 不修改 `manual_tail_center.py`、`live_replay.py`、区块映射、60 秒时钟、45 秒预判门或聊天数据库结构。
- `requirements.txt` 不再要求 gevent。

健康检查版本：`god8-v2.0.23-telegram-chat-502-hotfix`。
