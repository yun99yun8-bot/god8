"""Persist a two-choice historical replay before the next target block exists."""
import json
from datetime import datetime, timezone

from core import DB, from_index, get_meta, pindex, target_block, runtime_config_revision, pool, set_meta
from history_simulation import simulate
from canonical_history import load as canonical_load, as_analysis as canonical_analysis

PREDICTION_LOCK_ID = 80086423
RESULT_HOLD_SECONDS = 10  # compatibility only; presentation uses the shared 60s clock
RESULT_REVEAL_SECONDS = 15
DISPLAY_OFFSET_SECONDS = -3
PREDICTION_REVEAL_COUNTDOWN = 45
EARLY_REVEAL_BLOCKS = 8
MIN_LEAD_BLOCKS = 4
HEAD_MAX_AGE_SECONDS = 6



def prediction_cycle(now=None):
    """Shared 60-second platform clock used by both prediction systems."""
    now = now or datetime.now(timezone.utc)
    adjusted = int(now.timestamp()) + DISPLAY_OFFSET_SECONDS
    second = ((adjusted % 60) + 60) % 60
    remaining = 60 - second if second else 60
    return {'second': second, 'remaining': remaining,
            'forecastVisible': remaining <= PREDICTION_REVEAL_COUNTDOWN}


def prediction_window_open(now=None):
    return bool(prediction_cycle(now)['forecastVisible'])

def _runtime(status, **extra):
    payload={'status':status,'reportedAt':datetime.now(timezone.utc).isoformat(),**extra}
    try:
        set_meta('prediction_runtime',payload)
    except Exception:
        pass
    return payload


def target_for_latest(latest_key):
    ds, no = latest_key.split(':')
    next_ds, next_no = from_index(pindex(ds, int(no)) + 1)
    return f'{next_ds}:{next_no:04d}', target_block(next_ds, next_no)


def forecast_due(now, source_key, saved_at, next_block, head, head_seen_at=None):
    """Calculate immediately once the fresh result exists and target is still safe.

    The forecast is prepared early, but the API/UI reveal it only when the shared
    countdown reaches 45 seconds.
    """
    if head is None:
        return False
    if head_seen_at is not None:
        try:
            seen=datetime.fromisoformat(head_seen_at) if isinstance(head_seen_at,str) else head_seen_at
            age=(now-seen).total_seconds()
            if seen.tzinfo is None or age < -2 or age > HEAD_MAX_AGE_SECONDS:
                return False
        except (TypeError,ValueError,AttributeError):
            return False
    return int(next_block)-int(head) >= MIN_LEAD_BLOCKS

def pending_target_future(target, next_block, head, target_known=False,
                          head_seen_at=None, now=None):
    """A pending card is valid only before its target has reached the chain."""
    try:
        if target_known or head is None or int(head) >= int(next_block):
            return False
        if head_seen_at is not None:
            observed=datetime.fromisoformat(head_seen_at) if isinstance(head_seen_at,str) else head_seen_at
            age=((now or datetime.now(timezone.utc))-observed).total_seconds()
            return observed.tzinfo is not None and -2<=age<=HEAD_MAX_AGE_SECONDS
        return True
    except (TypeError, ValueError, AttributeError):
        return False


def advance(now=None):
    """One prediction tick. Return a diagnostic payload for watchdog callers."""
    now = now or datetime.now(timezone.utc)
    latest_rows=canonical_load(limit=1,newest_first=True)
    if not latest_rows:
        return _runtime('waiting-latest-canonical')
    c=latest_rows[0]
    latest=(c[0],c[6],c[3],c[7],c[4])
    if latest[1] is None or not c[8]:
        return _runtime('waiting-valid-source',sourcePeriod=latest[0],canonical=bool(c[8]))

    # The canonical raw target can become readable before its formal periods
    # row is written. Settle the saved forecast from that verified result so
    # both judged cards start their ten-second display at first detection.
    with DB() as conn:
        q=conn.cursor()
        q.execute('''UPDATE replay_forecasts SET actual=%s,
                       settled_at=COALESCE(settled_at,NOW())
                     WHERE period_key=%s AND (settled_at IS NULL OR actual IS DISTINCT FROM %s)''',
                  (latest[1],latest[0],latest[1]))
        q.execute('''UPDATE replay_forecasts f SET actual=p.single_count,settled_at=NOW()
                     FROM periods p WHERE f.period_key=p.period_key AND f.settled_at IS NULL''')
        q.close()

    target, next_block = target_for_latest(latest[0])
    # A stale pending row can survive a canonical-history correction or an
    # interrupted deploy. Because period_key is the primary key, such a row
    # blocks a fresh forecast even though the UI correctly refuses to show it
    # when source_period is no longer the newest canonical source.
    with DB() as conn:
        q=conn.cursor()
        q.execute("SELECT source_period,settled_at FROM replay_forecasts WHERE period_key=%s FOR UPDATE",(target,))
        existing=q.fetchone()
        if existing and existing[0] != latest[0] and existing[1] is None:
            q.execute('SELECT 1 FROM periods WHERE period_key=%s',(target,))
            formal_known=q.fetchone() is not None
            q.execute('SELECT 1 FROM raw_blocks WHERE block_number=%s',(next_block,))
            raw_known=q.fetchone() is not None
            if not formal_known and not raw_known:
                q.execute('DELETE FROM replay_forecasts WHERE period_key=%s AND settled_at IS NULL',(target,))
                existing=None
        q.close()
    if existing:
        chain=get_meta('chain_head') or {}
        if not chain.get('seenAt') or not pending_target_future(target,next_block,chain.get('block'),
                                     head_seen_at=chain.get('seenAt'),now=now):
            return _runtime('waiting-result',sourcePeriod=latest[0],targetPeriod=target,
                            nextBlock=next_block,head=chain.get('block'))
        return _runtime('locked',sourcePeriod=latest[0],targetPeriod=target,nextBlock=next_block,
                        storedSource=existing[0])

    # Prepare the next forecast immediately after the new actual result lands.
    # The judged cards remain visible until countdown 45 at presentation time.
    result_at=latest[3]
    chain=get_meta('chain_head') or {}
    head=chain.get('block')
    if not forecast_due(now, latest[0], result_at, next_block, head, chain.get('seenAt')):
        return _runtime('waiting-fresh-future-target',sourcePeriod=latest[0],targetPeriod=target,
                        nextBlock=next_block,head=head)

    # Include every retained formal period and the canonical correction window.
    # The old 10,000-row cap missed earlier exact successors after more data was saved.
    canonical=canonical_load(newest_first=True)
    history=canonical_analysis(canonical)
    if not history or history[0][0] != latest[0]:
        return _runtime('waiting-history-sync',sourcePeriod=latest[0],
                        historyNewest=history[0][0] if history else None,rows=len(history))

    _runtime('simulating',sourcePeriod=latest[0],targetPeriod=target,
             nextBlock=next_block,head=head,historyRows=len(history),
             runtimeRevision=runtime_config_revision())
    # Replay evidence uses the entire history; method weights only need the
    # latest 250 walk-forward observations, keeping the live calculation quick.
    preview = simulate(history,evaluation_window=250)['preview']
    expected_issue=target[2:4]+target[5:7]+target[8:10]+target[11:]
    if not preview:
        return _runtime('no-preview',sourcePeriod=latest[0],targetPeriod=target,historyRows=len(history))
    if preview['issue'] != expected_issue:
        return _runtime('preview-period-mismatch',sourcePeriod=latest[0],targetPeriod=target,
                        expectedIssue=expected_issue,previewIssue=preview.get('issue'))
    preview['match'].update({'historyRows':len(history),
                             'historyScope':'all-retained-canonical',
                             'methodEvaluationRows':250,
                             'predictionRevision':'v2.0.56-chain-deadline',
                             'chainHeadBeforeLock':head,
                             'leadBlocksBeforeLock':int(next_block)-int(head)})

    # Recheck the target in the same transaction. Never backdate a prediction
    # against a target block/result that became known during the simulation.
    with DB() as conn:
        q = conn.cursor()
        q.execute('''INSERT INTO replay_forecasts(period_key,source_period,source_block,choices,match)
                     SELECT %s,%s,%s,%s::jsonb,%s::jsonb
                     WHERE NOT EXISTS(SELECT 1 FROM periods WHERE period_key=%s)
                       AND NOT EXISTS(SELECT 1 FROM raw_blocks WHERE block_number=%s)
                       AND EXISTS(SELECT 1 FROM meta m WHERE m.k='chain_head'
                                  AND (m.v->>'block')::bigint <= %s
                                  AND (m.v->>'seenAt')::timestamptz >= NOW()-INTERVAL '6 seconds')
                     ON CONFLICT(period_key) DO NOTHING''',
                  (target, latest[0], latest[2], json.dumps(preview['predictions']),
                   json.dumps(preview['match']), target, next_block,
                   next_block-MIN_LEAD_BLOCKS))
        inserted=q.rowcount>0
        q.close()
    if inserted:
        return _runtime('locked',sourcePeriod=latest[0],targetPeriod=target,nextBlock=next_block,
                        head=head,choices=preview['predictions'],
                        policy=preview['match'].get('selectionPolicy'))
    return _runtime('target-became-known',sourcePeriod=latest[0],targetPeriod=target,
                    nextBlock=next_block,head=head)


def advance_guarded(now=None):
    """Run one tick under a short cross-service advisory lock.

    Collector and Worker both call this. Only one performs the 10k simulation
    at a time, while the other can take over on the next tick after an error or
    stall. The unique period key still guarantees a single stored forecast.
    """
    lease=pool().getconn()
    owned=False
    try:
        q=lease.cursor();q.execute('SELECT pg_try_advisory_lock(%s)',(PREDICTION_LOCK_ID,))
        owned=bool(q.fetchone()[0]);q.close();lease.commit()
        if not owned:
            return {'status':'busy-other-watchdog'}
        return advance(now)
    finally:
        if owned:
            try:
                q=lease.cursor();q.execute('SELECT pg_advisory_unlock(%s)',(PREDICTION_LOCK_ID,))
                q.close();lease.commit()
            except Exception:
                try: lease.rollback()
                except Exception: pass
        pool().putconn(lease)
