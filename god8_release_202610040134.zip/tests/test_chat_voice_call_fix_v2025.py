from pathlib import Path
import hashlib

ROOT=Path(__file__).resolve().parents[1]
def text(path): return (ROOT/path).read_text(encoding='utf-8')

def test_voice_hold_is_tactile_and_ios_mime_is_normalized():
    html=text('templates/_chat_widget.html'); js=text('static/app.js'); py=text('web.py'); css=text('static/app.css')
    assert 'chatVoiceHoldLabel' in html
    assert 'chat-voice-hold-dot' in html
    assert "localRecorder.start()" in js
    assert "recordPointerId" in js
    assert "navigator.vibrate" in js
    assert "split(';',1)[0].strip()" in py
    assert 'tactile WeChat-style voice hold' in css

def test_call_button_explains_missing_config_instead_of_silent_disable():
    js=text('static/app.js'); py=text('web.py'); html=text('templates/_chat_widget.html')
    assert "def _agora_config_status()" in py
    assert "'configReason':reason" in py
    assert "showCallNotice(callConfigReason" in js
    assert 'chatCallNoticeActions' in html
    assert 'chatCallNoticeClose' in html

def test_call_preflights_microphone_and_sdk_and_recovers_ios_audio():
    js=text('static/app.js')
    assert "if(!await primeMicrophone())" in js
    assert "await loadAgoraSdk(callSdkUrl)" in js
    assert "AgoraRTC.checkSystemRequirements" in js
    assert "AgoraRTC.onAutoplayFailed" in js
    assert "resumeAudioContext" in js
    assert "client.subscribe(user,'audio')" in js

def test_prediction_core_unchanged():
    expected={
        'manual_tail_center.py':'14794cfdb20e858e1cadb721975263f0f0f32f64576e2b4c288a6f7af2c9477b',
        'live_replay.py':'ba918e886b72145a56cd09bf2998144a481ca007c41b707f1df9dbdc79c68273',
        'platform_calibration.py':'afbe18ca64e7c48f35fc3b030c86cba6282dc4ab14814eb32bb769ae537679fe',
        'collector_service.py':'ff05429981f02ef2f0d3c632993077ba37e687b2bf2fc195b92ae05748d48886',
    }
    for name,digest in expected.items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest
