from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def test_private_chat_admin_and_groups_are_server_enforced():
    src=(ROOT/'web.py').read_text(encoding='utf8')
    assert "CHAT_ADMIN_NAME = '神一样的存在'" in src
    assert "CHAT_ADMIN_DEFAULT_PASSWORD = os.getenv('GOD8_CHAT_ADMIN_PASSWORD') or 'asd123'" in src
    assert 'ensure_default_admin_link(uid)' in src
    assert "只有管理号可以创建群聊" in src
    assert "只有管理号可以拉人进群" in src
    assert "kind IN ('direct','group')" in src


def test_realtime_voice_and_physical_clear_are_present():
    src=(ROOT/'web.py').read_text(encoding='utf8')
    req=(ROOT/'requirements.txt').read_text(encoding='utf8')
    gun=(ROOT/'gunicorn.conf.py').read_text(encoding='utf8')
    assert "@sock.route('/ws/chat')" in src
    assert "@app.post('/api/chat/voice')" in src
    assert "TRUNCATE TABLE chat_messages" in src
    assert "os.remove(path)" in src
    assert 'flask-sock' in req
    assert 'threads = 20' in gun
    assert "worker_class = 'gevent'" not in gun


def test_chat_ui_has_fullscreen_voice_admin_and_prediction_header():
    html=(ROOT/'templates'/'_chat_widget.html').read_text(encoding='utf8')
    js=(ROOT/'static'/'app.js').read_text(encoding='utf8')
    assert 'id="chatFullscreen"' in html
    assert 'id="chatPredictionBar"' in html
    assert 'id="chatVoiceMode"' in html
    assert 'id="chatVoiceHold"' in html
    assert 'id="chatCall"' in html
    assert 'id="chatClearAll"' in html
    assert 'MediaRecorder' in js
    assert 'new WebSocket' in js
    assert 'toggleFullscreen' in js
    assert 'syncPredictionTop' in js


def test_manual_prediction_history_is_compact_and_hit_position_specific():
    py=(ROOT/'web.py').read_text(encoding='utf8')
    html=(ROOT/'templates'/'manual_prediction_history.html').read_text(encoding='utf8')
    manual=(ROOT/'templates'/'manual_tail.html').read_text(encoding='utf8')
    js=(ROOT/'static'/'app.js').read_text(encoding='utf8')
    assert "@app.get('/api/manual-tail/predictions')" in py
    assert 'manualPredictionHistoryLink' in manual
    assert 'manualPredHistoryList' in html
    assert "first:'①命中'" in js
    assert "second:'②命中'" in js
    assert "miss:'未中'" in js


def test_prediction_core_files_untouched_by_chat_upgrade():
    # Regression anchor for the calibrated manual track and synchronized prediction clock.
    manual=(ROOT/'manual_tail_center.py').read_text(encoding='utf8')
    replay=(ROOT/'live_replay.py').read_text(encoding='utf8')
    assert '86775280' in manual
    assert 'manual-period-v5-platform-0695-sync' in manual
    assert 'PREDICTION_REVEAL_COUNTDOWN' in manual
    assert 'prediction_cycle' in replay
