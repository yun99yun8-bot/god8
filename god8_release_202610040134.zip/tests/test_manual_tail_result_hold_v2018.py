from datetime import datetime, timedelta, timezone
from pathlib import Path

import manual_tail_center as mt

ROOT = Path(__file__).resolve().parents[1]


class FakeQ:
    def __init__(self, judged=None, current=None):
        self.judged = judged
        self.current = current
        self.last = None
        self.calls = []

    def execute(self, sql, params=None):
        self.calls.append((sql, params))
        if 'actual IS NOT NULL AND settled_at IS NOT NULL' in sql:
            self.last = 'judged'
        else:
            self.last = 'current'

    def fetchone(self):
        return self.judged if self.last == 'judged' else self.current


def row(source, actual, settled_at):
    created = settled_at - timedelta(seconds=30)
    return (source, 2, 5, {'match': {}}, created, actual, settled_at)


def pending(source, created_at):
    return (source, 1, 6, {'match': {}}, created_at, None, None)


def test_result_window_uses_shared_countdown_until_45(monkeypatch):
    now = datetime(2026, 10, 3, 7, 30, 0, tzinfo=timezone.utc)
    monkeypatch.setattr(mt, '_prediction_cycle_remaining', lambda now=None: 55)
    latest = 86775289
    judged = row(latest - 20, 2, now - timedelta(seconds=20))
    q = FakeQ(judged=judged, current=pending(latest, now - timedelta(seconds=1)))
    phase, forecast = mt._forecast_view(q, 9, latest, now - timedelta(seconds=1), {'accepted': True})
    assert phase == 'result'
    assert forecast['targetBlock'] == latest
    assert forecast['targetIssue'] == '2610030695'
    assert forecast['actual'] == 2
    assert forecast['resultHoldSeconds'] == 10
    assert len(q.calls) == 1


def test_at_45_next_forecast_may_display(monkeypatch):
    now = datetime(2026, 10, 3, 7, 30, 0, tzinfo=timezone.utc)
    monkeypatch.setattr(mt, '_prediction_cycle_remaining', lambda now=None: 45)
    latest = 86775289
    q = FakeQ(judged=row(latest - 20, 2, now), current=pending(latest, now - timedelta(seconds=1)))
    phase, forecast = mt._forecast_view(q, 9, latest, now, {'accepted': True})
    assert phase == 'forecast'
    assert forecast['sourceBlock'] == latest
    assert forecast['targetBlock'] == latest + 20
    assert forecast['targetIssue'] == '2610030696'


def test_frontend_uses_clock_gate_and_delayed_result_guard():
    js = (ROOT / 'static' / 'app.js').read_text(encoding='utf8')
    assert js.count('开奖结果延迟获取中，请稍等…') >= 2
    assert js.count('gate.resultWindow') >= 2
    assert 'predictionDisplayGate(a.latest?.issue)' in js
    assert 'f.targetIssue===cycle.next' in js
    assert 'f.issue===cycle.next' in js
    assert 'manualResultClearTimer=setTimeout' not in js
