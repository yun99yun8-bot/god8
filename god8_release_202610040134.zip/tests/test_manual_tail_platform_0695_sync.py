import manual_tail_center as mt


def test_platform_0695_visible_history_matches_exactly():
    expected = {
        695: 86775289, 694: 86775269, 693: 86775249, 692: 86775229,
        691: 86775209, 690: 86775189, 689: 86775169, 688: 86775149,
        687: 86775129, 686: 86775109,
    }
    for issue, block in expected.items():
        key = mt.manual_period_key(block, 9)
        assert key == f"2026-10-03:{issue:04d}"
        assert mt._issue_no(key) == f"261003{issue:04d}"


def test_all_manual_tails_share_same_issue_lane():
    for tail in range(10):
        block = 86775280 + tail
        assert mt.manual_anchor_block(tail) == block
        assert mt.manual_period_key(block, tail) == "2026-10-03:0695"
        assert mt.manual_period_key(block + 20, tail) == "2026-10-03:0696"
