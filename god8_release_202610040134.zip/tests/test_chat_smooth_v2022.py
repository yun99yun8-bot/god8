from pathlib import Path
import hashlib

ROOT=Path(__file__).resolve().parents[1]

def text(path): return (ROOT/path).read_text(encoding='utf-8')

def test_chat_widget_has_stable_modern_controls():
    html=text('templates/_chat_widget.html')
    assert 'chatJumpNew' in html
    assert 'chatOnlineCount' in html
    assert '<textarea id="chatInput"' in html
    assert 'chatFullscreen' in html
    assert 'chatVoiceMode' in html
    assert 'chatVoiceHold' in html
    assert 'chatResize' not in html
    assert 'chatDrag' not in html


def test_chat_frontend_has_realtime_reconnect_and_fixed_page():
    js=text('static/app.js')
    assert "BroadcastChannel('god8-chat-sync-v4')" in js
    assert 'clientKey' in js
    assert "window.addEventListener('online'" in js
    assert "document.body.classList.add('chat-page-locked')" in js
    assert 'new WebSocket' in js
    assert 'MediaRecorder' in js


def test_chat_backend_has_private_conversations_voice_and_admin_clear():
    py=text('web.py')
    assert "PERMANENT_SESSION_LIFETIME=timedelta(days=30)" in py
    assert "SESSION_REFRESH_EACH_REQUEST=False" in py
    assert 'chat_conversations' in py
    assert 'chat_members' in py
    assert 'chat_friends' in py
    assert "@app.post('/api/chat/voice')" in py
    assert "TRUNCATE TABLE chat_messages" in py
    assert "APP_VERSION = 'god8-v2.0.25-voice-call-polish'" in py


def test_prediction_engines_are_untouched_by_chat_upgrade():
    expected={
        'manual_tail_center.py':'14794cfdb20e858e1cadb721975263f0f0f32f64576e2b4c288a6f7af2c9477b',
        'live_replay.py':'ba918e886b72145a56cd09bf2998144a481ca007c41b707f1df9dbdc79c68273',
    }
    for name,digest in expected.items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest
