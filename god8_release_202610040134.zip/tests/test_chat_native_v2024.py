from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def text(path): return (ROOT/path).read_text(encoding='utf-8')

def test_read_receipts_are_peer_read_driven():
    py=text('web.py'); js=text('static/app.js')
    assert "@app.post('/api/chat/read')" in py
    assert "'peerLastReadId':peer_read" in py
    assert "{'type':'read'" in py
    assert "receiptText(id)" in js
    assert "updateReceipts(d.maxId)" in js
    assert "lastReadAck>=lastId" in js

def test_wechat_style_voice_hold_release_and_slide_cancel():
    html=text('templates/_chat_widget.html'); js=text('static/app.js')
    assert 'id="chatVoiceHold"' in html
    assert '按住 说话' in html
    assert '上滑取消' in html
    assert "recordStartY-(e.clientY||recordStartY)" in js
    assert "pointerdown" in js and "pointerup" in js and "pointercancel" in js
    assert "audio/mp4" in js
    assert "getUserMedia" in js

def test_fullscreen_prediction_header_is_numbers_only():
    html=text('templates/_chat_widget.html'); js=text('static/app.js')
    assert 'chatPredictionSource' not in html
    assert 'chatPredictionText' not in html
    assert 'id="chatPredictionCountdown"' in html
    assert 'id="chatPredictionA"' in html
    assert 'id="chatPredictionB"' in html
    assert "querySelectorAll('[data-single]')" in js

def test_foreground_one_to_one_rtc_call_is_server_enforced():
    py=text('web.py'); js=text('static/app.js'); req=text('requirements.txt')
    assert "CREATE TABLE IF NOT EXISTS chat_calls" in py
    assert "@app.post('/api/chat/calls/start')" in py
    assert "@app.post('/api/chat/calls/accept')" in py
    assert "@app.post('/api/chat/calls/end')" in py
    assert "@app.get('/api/chat/calls/<call_key>/rtc')" in py
    assert "foreground_seen_at=NULL" in py
    assert "对方当前不在网页前台" in py
    assert "agora-token-builder" in req
    assert "AgoraRTC.createClient" in js
    assert "document.addEventListener('visibilitychange'" in js
    assert "backgroundHangup()" in js

def test_native_chat_visual_layer_present():
    css=text('static/app.css')
    for marker in ['native-chat polish','chat-call-overlay','chat-recording-overlay','chat-read-state','chat-pred-number']:
        assert marker in css
