from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def text(name):
    return (ROOT/name).read_text(encoding="utf-8")

def test_ios_voice_permission_is_separate_from_hold_gesture():
    js=text("static/app.js")
    css=text("static/app.css")
    base=text("templates/base.html")
    web=text("web.py")
    mode_line=next(line for line in js.splitlines() if "voiceMode.onclick=" in line)
    assert "primeMicrophone" not in mode_line
    assert "轻点启用麦克风" in js
    assert "if(!micPrimed)return" in js
    assert "e.pointerType!=='touch'" in js
    assert "MIC_PERMISSION_TIMEOUT" in js
    assert "window.addEventListener('blur'" in js
    assert "visibilitychange" in js and "stopRecording(null,true)" in js
    lock=css[css.index("body.chat-page-locked"):css.index("body.chat-page-locked")+180]
    assert "touch-action:none" not in lock
    assert "god8-v2.0.27-ios-voice-permission-fix" in web
    assert "2.0.27-ios-voice-permission-fix" in base
