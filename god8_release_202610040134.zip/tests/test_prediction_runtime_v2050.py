import os, sys, unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import live_replay

class PredictionRuntimeV2050Tests(unittest.TestCase):
    def test_full_canonical_history_and_method_evidence_are_saved(self):
        now=datetime.now(timezone.utc)
        source='2026-10-01:0100'
        target,block=live_replay.target_for_latest(source)
        canonical=(source,'2026-10-01',100,block-20,'a'*64,[1,2,3,4,5,6,7],4,
                   now-timedelta(seconds=25),True)
        connection=MagicMock()
        connection.__enter__.return_value=connection
        cursor=connection.cursor.return_value
        cursor.fetchone.side_effect=[None,None]
        cursor.rowcount=1
        full=[canonical]*12001
        issue='2610010101'
        preview={'issue':issue,'predictions':[1,6],
                 'match':{'selectionPolicy':'replay-anchor-plus-adaptive','methods':[{'name':'replay'}]}}
        with patch.object(live_replay,'DB',return_value=connection), \
             patch.object(live_replay,'canonical_load',side_effect=[[canonical],full]), \
             patch.object(live_replay,'get_meta',return_value={'block':block-5,'seenAt':now.isoformat()}), \
             patch.object(live_replay,'set_meta'), \
             patch.object(live_replay,'simulate',return_value={'preview':preview}) as simulation:
            result=live_replay.advance(now)
        self.assertEqual(result['status'],'locked')
        self.assertEqual(simulation.call_args.kwargs['evaluation_window'],250)
        self.assertEqual(len(simulation.call_args.args[0]),12001)
        self.assertEqual(preview['match']['historyRows'],12001)
        self.assertEqual(preview['match']['methods'][0]['name'],'replay')
        self.assertTrue(any('INSERT INTO replay_forecasts' in call.args[0]
                            for call in cursor.execute.call_args_list))

    def test_forecast_due_uses_chain_future_not_wall_clock_minute(self):
        now=datetime.now(timezone.utc)
        # Source may be older than the wall-clock minute; chain-future target is sufficient.
        self.assertTrue(live_replay.forecast_due(now,'2026-10-01:0100',now-timedelta(minutes=3),200,195))
        self.assertFalse(live_replay.forecast_due(now,'2026-10-01:0100',now-timedelta(minutes=3),200,200))


    def test_forecast_calculation_is_immediate_when_chain_lead_is_safe(self):
        now=datetime.now(timezone.utc)
        self.assertTrue(live_replay.forecast_due(now,'2026-10-01:0100',now-timedelta(seconds=1),200,190))
        self.assertTrue(live_replay.forecast_due(now,'2026-10-01:0100',now-timedelta(minutes=3),200,196))
        self.assertFalse(live_replay.forecast_due(now,'2026-10-01:0100',now,200,197))

    def test_forecast_requires_fresh_head_and_future_target(self):
        now=datetime.now(timezone.utc)
        saved=now-timedelta(seconds=1)
        self.assertTrue(live_replay.forecast_due(now,'late',saved,200,192,now.isoformat()))
        self.assertFalse(live_replay.forecast_due(now,'late',saved,200,197,now.isoformat()))
        self.assertFalse(live_replay.forecast_due(now,'late',saved,200,200,now.isoformat()))
        self.assertFalse(live_replay.forecast_due(now,'late',saved,200,192,
                                                  (now-timedelta(seconds=7)).isoformat()))
        self.assertFalse(live_replay.pending_target_future('late',200,200))
        self.assertFalse(live_replay.pending_target_future('late',200,198,True))

    def test_guarded_tick_skips_when_other_service_is_computing(self):
        lease=MagicMock();cur=MagicMock();lease.cursor.return_value=cur
        cur.fetchone.return_value=(False,)
        pool=MagicMock();pool.getconn.return_value=lease
        with patch.object(live_replay,'pool',return_value=pool), patch.object(live_replay,'advance') as advance:
            result=live_replay.advance_guarded()
        self.assertEqual(result['status'],'busy-other-watchdog')
        advance.assert_not_called()

    def test_guarded_tick_runs_and_unlocks(self):
        lease=MagicMock();cur=MagicMock();lease.cursor.return_value=cur
        cur.fetchone.return_value=(True,)
        pool=MagicMock();pool.getconn.return_value=lease
        with patch.object(live_replay,'pool',return_value=pool), patch.object(live_replay,'advance',return_value={'status':'locked'}) as advance:
            result=live_replay.advance_guarded()
        self.assertEqual(result['status'],'locked')
        advance.assert_called_once()
        sqls=[c.args[0] for c in cur.execute.call_args_list]
        self.assertTrue(any('pg_try_advisory_lock' in x for x in sqls))
        self.assertTrue(any('pg_advisory_unlock' in x for x in sqls))

if __name__=='__main__':unittest.main()
