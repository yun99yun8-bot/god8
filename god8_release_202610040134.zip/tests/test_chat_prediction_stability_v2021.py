from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_mobile_chat_is_pinned_and_does_not_trigger_ios_input_zoom():
    css = (ROOT / 'static' / 'app.css').read_text(encoding='utf8')
    js = (ROOT / 'static' / 'app.js').read_text(encoding='utf8')
    assert 'body.chat-page-locked{position:fixed' in css
    assert '.chat-composer textarea{display:block' in css
    assert 'font-size:16px!important' in css
    assert 'function lockPage()' in js and 'function unlockPage()' in js
    assert 'function syncViewport()' in js


def test_chat_send_is_realtime_with_polling_fallback():
    js = (ROOT / 'static' / 'app.js').read_text(encoding='utf8')
    assert 'new WebSocket' in js
    assert 'function connectSocket()' in js
    assert 'function schedulePolling()' in js
    assert "appendItems([{...data.message,mine:true}],false)" in js
    assert "credentials:'same-origin'" in js


def test_home_and_manual_use_same_clock_gate_but_independent_forecasts():
    js = (ROOT / 'static' / 'app.js').read_text(encoding='utf8')
    assert 'function predictionDisplayGate(' in js
    assert 'const gate=predictionDisplayGate(latest?.issue),cycle=gate.cycle;' in js
    assert 'const gate=predictionDisplayGate(a.latest?.issue),cycle=gate.cycle;' in js
    assert js.count("state.textContent='开奖结果延迟获取中，请稍等…'") >= 2
    assert "f&&f.settledAt&&f.issue===cycle.current" in js
    assert "f&&!f.settledAt&&f.issue===cycle.next" in js
    assert "phase==='result'&&f&&f.targetIssue===cycle.current" in js
    assert "phase==='forecast'&&f&&f.targetIssue===cycle.next" in js
    assert js.count('gate.resultWindow') >= 2


def test_clock_sync_failure_never_advances_prediction_ui():
    js = (ROOT / 'static' / 'app.js').read_text(encoding='utf8')
    assert 'clockSynced=false' in js
    assert js.count("state.textContent='正在同步开奖时钟，请稍等…'") >= 2
