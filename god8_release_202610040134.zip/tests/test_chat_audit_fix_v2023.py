from pathlib import Path
import hashlib

ROOT=Path(__file__).resolve().parents[1]

def test_websocket_and_poll_use_separate_sync_cursor():
    js=(ROOT/'static'/'app.js').read_text(encoding='utf8')
    assert 'syncCursor=0' in js
    assert 'seenMessageIds=new Set()' in js
    assert 'const wasBottom=nearBottom(),cursor=syncCursor' in js
    assert 'syncCursor=Math.max(syncCursor,Number(data.latestId||cursor)||0)' in js
    assert "loadMessages(false)}else if(Number(msg.userId)!==Number(me?.id))" in js

def test_intentional_socket_close_cannot_spawn_duplicate_reconnect():
    js=(ROOT/'static'/'app.js').read_text(encoding='utf8')
    assert 'ws.onclose=null;ws.onerror=null' in js
    assert 'reconnectTimer=setTimeout' in js
    assert 'if(me&&!document.hidden&&!socket)connectSocket()' in js

def test_prediction_core_still_unchanged():
    expected={
        'manual_tail_center.py':'14794cfdb20e858e1cadb721975263f0f0f32f64576e2b4c288a6f7af2c9477b',
        'live_replay.py':'ba918e886b72145a56cd09bf2998144a481ca007c41b707f1df9dbdc79c68273',
    }
    for name,digest in expected.items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest
