from pathlib import Path
import manual_tail_center as mt

ROOT=Path(__file__).resolve().parents[1]


def test_lightweight_manual_draw_report_exists():
    assert callable(mt.live_report)
    src=(ROOT/'manual_tail_center.py').read_text(encoding='utf8')
    body=src[src.index('def live_report'):src.index('def history')]
    assert 'FROM manual_tail_blocks' in body
    assert "'drawDataPriority': True" in body
    assert "'displayOffsetSeconds': -3" in body


def test_web_exposes_no_cache_manual_live_endpoint():
    src=(ROOT/'web.py').read_text(encoding='utf8')
    assert "@app.get('/api/manual-tail/live')" in src
    assert 'manual_tail_live_report' in src
    assert "Cache-Control']='no-store, no-cache, must-revalidate, max-age=0'" in src


def test_manual_clock_is_shifted_plus_three_seconds():
    js=(ROOT/'static'/'app.js').read_text(encoding='utf8')
    assert 'const shifted=epochMs+(clockOffset*1000)' in js
    assert '开奖数据优先 · 时间+3秒' in js


def test_manual_draw_has_lightweight_300ms_polling():
    js=(ROOT/'static'/'app.js').read_text(encoding='utf8')
    assert "fetch('/api/manual-tail/live?tail='+manualTailCurrent,{cache:'no-store'})" in js
    assert 'setInterval(refreshManualTailLive,300)' in js
    assert 'setInterval(()=>refreshManualTailSnapshot(false),1500)' in js
    assert 'block<manualLatestBlock' in js


def test_collector_probes_exact_upcoming_target_and_reserves_bandwidth():
    src=(ROOT/'collector_service.py').read_text(encoding='utf8')
    assert 'def manual_draw_needs_priority()' in src
    assert 'def manual_next_block(head, tail):' in src
    assert 'fetch_block(upcoming,timeout=2.0)' in src
    assert "'source':'proactive-exact-target'" in src
    assert 'if manual_draw_needs_priority():' in src


def test_fetch_block_supports_low_latency_timeout_override():
    src=(ROOT/'core.py').read_text(encoding='utf8')
    assert 'def fetch_block(n,timeout=8):' in src
    assert "getblockbynum',{'num':int(n)},timeout=timeout" in src
