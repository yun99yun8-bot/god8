from pathlib import Path
import hashlib

ROOT=Path(__file__).resolve().parents[1]
def text(path): return (ROOT/path).read_text(encoding='utf-8')

def test_outgoing_ringing_has_cancel_button():
    html=text('templates/_chat_widget.html'); js=text('static/app.js')
    assert 'id="chatCallOutgoingActions"' in html
    assert 'id="chatCallCancel"' in html
    assert "callOutgoingActions.hidden=mode!=='ringing'" in js
    assert "callCancel.onclick=()=>endCall('cancel',true)" in js
    assert "reason==='cancel'?'已取消呼叫'" in js

def test_android_accept_uses_rtc_permission_not_mediarecorder_gate():
    js=text('static/app.js')
    assert 'async function ensureCallMicrophonePermission()' in js
    block=js[js.index('async function ensureCallMicrophonePermission()'):js.index('async function loadAgoraSdk')]
    assert 'navigator.mediaDevices?.getUserMedia' in block
    assert 'MediaRecorder' not in block
    accept=next(line for line in js.splitlines() if 'callAccept.onclick=' in line)
    assert 'ensureCallMicrophonePermission' in accept
    assert 'primeMicrophone' not in accept

def test_permission_prompt_does_not_trigger_background_hangup():
    js=text('static/app.js')
    assert 'callPermissionInProgress' in js
    vis=next(line for line in js.splitlines() if "document.addEventListener('visibilitychange'" in line and 'callBackgroundTimer' in line)
    assert '!callPermissionInProgress' in vis
    assert '!callAccepting' in vis
    assert 'setTimeout' in vis

def test_call_hangup_ui_is_immediate_and_core_unchanged():
    js=text('static/app.js'); web=text('web.py'); base=text('templates/base.html')
    end=next(line for line in js.splitlines() if "async function endCall(reason='hangup'" in line)
    assert 'const request=' in end and 'await finishCallUi' in end and 'request.finally' in end
    assert "god8-v2.0.28-call-android-fix" in web
    assert "2.0.28-call-android-fix" in base
    expected={
        'manual_tail_center.py':'14794cfdb20e858e1cadb721975263f0f0f32f64576e2b4c288a6f7af2c9477b',
        'live_replay.py':'ba918e886b72145a56cd09bf2998144a481ca007c41b707f1df9dbdc79c68273',
        'platform_calibration.py':'afbe18ca64e7c48f35fc3b030c86cba6282dc4ab14814eb32bb769ae537679fe',
        'collector_service.py':'ff05429981f02ef2f0d3c632993077ba37e687b2bf2fc195b92ae05748d48886',
    }
    for name,digest in expected.items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest
