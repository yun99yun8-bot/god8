from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def test_web_has_nonblocking_manual_prediction_self_heal():
    src=(ROOT/'web.py').read_text(encoding='utf8')
    assert 'def schedule_manual_tail_heal' in src
    assert 'manual_tail_prediction_step' in src
    assert "payload.get('phase')=='waiting'" in src
    assert "threading.Thread(target=_manual_tail_heal_task" in src
    assert 'now-last < 2.0' in src

def test_manual_page_surfaces_each_prediction_channel():
    js=(ROOT/'static'/'app.js').read_text(encoding='utf8')
    assert '预测Collector异常' in js
    assert '预测自动修复失败' in js
    assert '预测未锁定 · 正在自动检查复现引擎' in js

def test_version_cache_bust_and_service_markers():
    assert '2.0.14-manual-clean-tail' in (ROOT/'templates'/'base.html').read_text(encoding='utf8')
    assert 'god8-v2.0.14-manual-clean-tail' in (ROOT/'collector_service.py').read_text(encoding='utf8')
    assert 'god8-v2.0.14-manual-clean-tail' in (ROOT/'worker_ai.py').read_text(encoding='utf8')
