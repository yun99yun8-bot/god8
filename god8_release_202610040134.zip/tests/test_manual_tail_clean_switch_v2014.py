from pathlib import Path
import inspect
import manual_tail_center as mt

ROOT = Path(__file__).resolve().parents[1]


def test_switch_starts_four_issue_clean_observation_window():
    assert mt.MANUAL_OBSERVATION_REQUIRED == 4
    src = inspect.getsource(mt.select_tail)
    assert "observationStartBlock" in src
    assert "observationRequired" in src
    assert "status': 'observing-tail'" in src


def test_observation_rejects_gap_or_invalid_selected_tail_data():
    src = inspect.getsource(mt._observation_status)
    assert "block != expected" in src
    assert "'missing-target'" in src
    assert "'invalid-result'" in src
    assert "expected += MANUAL_PERIOD_STEP" in src
    assert "observed >= required and blocked is None" in src


def test_manual_engine_does_not_force_generic_fallback_when_replay_engine_has_no_output():
    src = inspect.getsource(mt._engine_preview)
    assert "_manual_fallback_preview(rows)" not in src
    assert "fallbackUsed': False" in src
    assert "selected-tail-only-all-history" in src


def test_predictions_wait_for_clean_selected_tail_sequence():
    src = inspect.getsource(mt.prediction_step)
    assert "observation = _observation_status" in src
    assert "not observation.get('accepted')" in src
    assert "'status': 'observing-tail'" in src
    assert "'selectedTail': tail" in src


def test_settlement_never_jumps_over_missing_issue():
    src = inspect.getsource(mt.settle_predictions)
    assert src.count('p.source_block+20') >= 4
    assert 'm.block_number>p.source_block' not in src
    assert 'r.block_number>p.source_block' not in src


def test_manual_page_explains_clean_tail_observation():
    js = (ROOT/'static'/'app.js').read_text(encoding='utf8')
    html = (ROOT/'templates'/'manual_tail.html').read_text(encoding='utf8')
    assert '正在建立${a.tail}尾连续有效样本' in js
    assert '暂不接受乱序数据' in js
    assert '缺期/乱序不进入预测' in js
    assert '切换后先观察至少4期连续同尾结果' in html
