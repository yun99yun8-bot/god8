# v2.0.23 502 hotfix: keep Web startup independent of optional gevent.
# Flask-Sock/simple-websocket supports Gunicorn's threaded worker, so chat can
# still use WebSocket after flask-sock is installed. If it is unavailable,
# web.py falls back to polling instead of taking the whole site down.
workers = 1
threads = 20
timeout = 60
keepalive = 5
