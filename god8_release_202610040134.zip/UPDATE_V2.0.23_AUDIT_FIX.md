# God8 v2.0.23 · 中断后复检补强

- 对照 v2.0.22 全量文件，确认开奖、手动尾数、预测核心、采集与校准文件未被聊天升级覆盖。
- 修复 WebSocket 新消息与轮询补偿同时返回时的消息竞态：实时消息与 HTTP 同步游标分离，使用消息 ID 集合去重并按 ID 插入，避免极端网络时序下中间消息被跳过显示。
- 修复主动关闭旧 WebSocket 时可能触发旧 onclose 再次安排重连的问题，避免重复连接与重连抖动。
- 管理员清空聊天后同步重置聊天游标与去重状态。
- 未修改 manual_tail_center.py、live_replay.py、platform_calibration.py、collector_service.py、monitor_collector.py。
