"""One collector service: fixed 10,000-round history plus uninterrupted live capture."""
import json
import threading
import time
from datetime import datetime, timezone
from urllib.error import HTTPError

from core import (DB, TRAIN_N, fetch_block, fetch_block_range, fetch_latest, from_index,
                  get_meta, init_db, pindex, period_key, save_block,
                  save_blocks_batch, save_period, set_meta, target_block, pool, runtime_config_revision)
from god8_flow import first_complete_index
from monitor_collector import HEAD_UPDATED, run_forever
import monitor_collector as monitor
from audit_service import queued_repairs
from live_replay import advance_guarded as advance_replay
from lab_live import advance as advance_lab
from platform_calibration import reconcile_forever, reconcile_priority_bootstrap
from pattern_memory import analyze as analyze_pattern_memory
from canonical_history import load as canonical_load, as_pairs as canonical_pairs
from manual_tail_center import (MANUAL_PERIOD_STEP, manual_anchor_block,
                                prediction_step as manual_prediction_step,
                                selected_tail as manual_selected_tail,
                                settle_predictions as manual_settle_predictions)


def last_finished_index(head):
    index = first_complete_index(head + 1) - 1
    while target_block(*from_index(index)) > head:
        index -= 1
    return index


def seed_window():
    """Freeze round identities before either live or historic writes can begin."""
    saved = get_meta('historical_capture') or {}
    if 'firstBlock' in saved:
        return saved
    head = fetch_latest()['number']
    end_index = last_finished_index(head)
    start_index = end_index - TRAIN_N + 1
    first_block = target_block(*from_index(start_index)) - 19
    last_block = target_block(*from_index(end_index))
    planned = {'firstIndex':start_index, 'lastIndex':end_index,
               'firstBlock':first_block, 'lastBlock':last_block,
               'nextBlock':first_block, 'status':'collecting',
               'capturedAt':datetime.now(timezone.utc).isoformat()}
    origin = {'index':start_index,
              'period':period_key(*from_index(start_index)),
              'source':'frozen-10000-history-window', 'noBackwardFetch':True,
              'recordedAt':planned['capturedAt']}
    with DB() as c:
        q = c.cursor()
        q.execute('SELECT pg_advisory_xact_lock(%s)', (80086422,))
        q.execute('''INSERT INTO meta(k,v) VALUES('god8_origin',%s::jsonb)
                     ON CONFLICT(k) DO NOTHING''', (json.dumps(origin),))
        q.execute('''INSERT INTO meta(k,v) VALUES('historical_capture',%s::jsonb)
                     ON CONFLICT(k) DO NOTHING''', (json.dumps(planned),))
        q.execute("SELECT v FROM meta WHERE k='historical_capture'")
        result = q.fetchone()[0]
        q.close()
    if (result['firstIndex'] != start_index and
            (get_meta('god8_origin') or {}).get('index') != result['firstIndex']):
        raise RuntimeError('history window and origin disagree')
    set_meta('chain_head', {'block':head, 'seenAt':planned['capturedAt'],
                            'source':'collector-bootstrap'})
    return result


def queue_missing(start, end):
    with DB() as c:
        q = c.cursor()
        q.execute('''INSERT INTO repair_queue(block_number,last_error)
                     SELECT n,'historical range missing' FROM generate_series(%s,%s) n
                     WHERE NOT EXISTS (SELECT 1 FROM raw_blocks WHERE block_number=n)
                     ON CONFLICT DO NOTHING''', (start,end))
        q.close()


def counted(start, end):
    with DB() as c:
        q = c.cursor()
        q.execute('SELECT COUNT(*) FROM raw_blocks WHERE block_number BETWEEN %s AND %s',
                  (start,end))
        count = q.fetchone()[0]
        q.close()
    return count


def live_needs_priority(monitor_stats, chain_head):
    """Pause historical network work while the live head is behind or retrying."""
    if monitor_stats.get('status') == 'retrying':
        return True
    seen = chain_head.get('seenAt')
    if not seen:
        return True
    try:
        return (datetime.now(timezone.utc) - datetime.fromisoformat(seen)).total_seconds() > 8
    except (TypeError, ValueError):
        return True


def backfill_forever():
    while True:
        window = get_meta('historical_capture') or {}
        if window.get('status') == 'raw-complete':
            return
        start, end = window['firstBlock'], window['lastBlock']
        cursor = max(start, min(end+1, int(window['nextBlock'])))
        try:
            if cursor <= end:
                # Range requests amortize HTTP and DB cost. Never advance over
                # missing heights without putting them into the repair queue.
                monitor=get_meta('monitor_stats',{}) or {}
                if manual_draw_needs_priority():
                    # Selected manual draw has network priority in the last ~9s.
                    time.sleep(.5)
                    continue
                if live_needs_priority(monitor, get_meta('chain_head') or {}):
                    # Give the live head priority when the shared node quota is exhausted.
                    time.sleep(3)
                    continue
                last = min(end, cursor + 99)
                found = fetch_block_range(cursor,last)
                save_blocks_batch(found.values())
                if len(found) != last - cursor + 1:
                    queue_missing(cursor,last)
                cursor = last + 1
                progress = counted(start,end) if (cursor-start)%1000<100 or cursor>end else window.get('rawBlocks',0)
                set_meta('historical_capture', {**{k:v for k,v in window.items() if k!='error'}, 'nextBlock':cursor,
                    'rawBlocks':progress, 'status':'collecting',
                    'updatedAt':datetime.now(timezone.utc).isoformat()})
            else:
                count = counted(start,end)
                if count == end - start + 1:
                    set_meta('historical_capture', {**{k:v for k,v in window.items() if k!='error'},'nextBlock':end+1,
                        'rawBlocks':count,'status':'raw-complete',
                        'updatedAt':datetime.now(timezone.utc).isoformat()})
                    return
                queue_missing(start,end)
                set_meta('historical_capture', {**window,'rawBlocks':count,
                    'status':'repairing-gaps',
                    'updatedAt':datetime.now(timezone.utc).isoformat()})
                time.sleep(2)
        except Exception as exc:
            set_meta('historical_capture', {**window,'nextBlock':cursor,
                'status':'retrying','error':str(exc)[:300],
                'updatedAt':datetime.now(timezone.utc).isoformat()})
            time.sleep(3)


def build_live_period(ds,no):
    """Use already captured blocks first; request only if the 20-group row is incomplete."""
    tb=target_block(ds,no)
    ok,missing=save_period(ds,no,'collector-live')
    source='cached-blocks'
    if not ok and missing:
        batch=fetch_block_range(tb-19,tb)
        save_blocks_batch(batch.values())
        ok,missing=save_period(ds,no,'collector-live')
        source='range-repair'
    if not ok:
        if missing:queue_missing(tb-19,tb)
        return False
    with DB() as c:
        q=c.cursor()
        q.execute('SELECT block_time FROM raw_blocks WHERE block_number=%s',(tb,))
        stamp=q.fetchone()
        q.close()
    now=datetime.now(timezone.utc)
    latency=round(max(0,(now-stamp[0]).total_seconds()),3) if stamp and stamp[0] else None
    set_meta('collector_live_latency',{'period':period_key(ds,no),
        'targetBlock':tb,'source':source,'blockToSavedSeconds':latency,
        'savedAt':now.isoformat()})
    return True


def capture_target_first(ds,no):
    """Publish a skipped target hash before repairing the other 19 group blocks."""
    tb=target_block(ds,no)
    with DB() as c:
        q=c.cursor()
        q.execute('SELECT 1 FROM raw_blocks WHERE block_number=%s',(tb,))
        present=q.fetchone() is not None
        q.close()
    if present:return False
    save_block(fetch_block(tb))
    return True


def fast_target_forever():
    """Publish the newest draw target without waiting for group repair/backfill."""
    last_target=None
    fallback_head=None
    last_fallback=0
    last_head=None
    last_progress=time.monotonic()
    next_probe=0
    retry_delay=.5
    while True:
        try:
            now=time.monotonic()
            if fallback_head is None or now-last_fallback>=2:
                fallback_head=(get_meta('chain_head') or {}).get('block')
                last_fallback=now
            head=max((h for h in (monitor.HEAD_NUMBER,fallback_head) if h is not None),default=None)
            if head is not None and (last_head is None or head>last_head):
                last_head=head
                last_progress=now
            # A paused/throttled Monitor can leave the browser one issue behind.
            # Probe independently, but at most once every 10 seconds while its
            # head is stale. Never infer a result from the clock alone.
            if now-last_progress>=9 and now>=next_probe:
                next_probe=now+10
                try:
                    observed=fetch_latest()
                    if head is None or observed['number']>head:
                        head=observed['number']
                        save_block(observed)
                        last_head=head
                        last_progress=now
                        set_meta('chain_head',{'block':head,'seenAt':datetime.now(timezone.utc).isoformat(),
                                               'source':'target-fallback'})
                        fallback_head=head
                except HTTPError as exc:
                    if exc.code in (403,429):
                        try: wait=float(exc.headers.get('Retry-After',''))
                        except (TypeError,ValueError): wait=15
                        next_probe=now+max(10,min(120,wait))
                    raise
            if head is not None:
                ds,no=from_index(last_finished_index(head))
                tb=target_block(ds,no)
                if tb!=last_target:
                    capture_target_first(ds,no)
                    set_meta('fast_target_latest',{'period':period_key(ds,no),'targetBlock':tb,
                        'seenAt':datetime.now(timezone.utc).isoformat()})
                    last_target=tb
                    retry_delay=.5
        except Exception as exc:
            set_meta('fast_target_error',{'error':str(exc)[:300],
                'at':datetime.now(timezone.utc).isoformat()})
            retry_delay=min(8.,max(1.2,retry_delay*2))
        time.sleep(retry_delay)



def manual_due_block(head, tail):
    """Newest fixed-tail one-minute target that is already due at ``head``."""
    head = int(head); tail = int(tail)
    anchor = manual_anchor_block(tail)
    if head < anchor:
        return None
    return anchor + ((head - anchor) // MANUAL_PERIOD_STEP) * MANUAL_PERIOD_STEP


def manual_next_block(head, tail):
    """Next selected-tail target after the observed head."""
    head = int(head); tail = int(tail)
    anchor = manual_anchor_block(tail)
    if head < anchor:
        return anchor
    return anchor + (((head - anchor) // MANUAL_PERIOD_STEP) + 1) * MANUAL_PERIOD_STEP


def manual_draw_needs_priority():
    """Reserve public-node bandwidth around the selected manual draw target."""
    head=max((h for h in (monitor.HEAD_NUMBER,(get_meta('chain_head') or {}).get('block')) if h is not None),default=None)
    if head is None:
        return False
    target=manual_next_block(head,manual_selected_tail())
    return 0 < int(target)-int(head) <= 3


def manual_tail_fast_forever():
    """Prioritize the selected manual draw over background network work.

    The current due target is repaired immediately.  During the final three
    chain blocks before the next selected-tail target, probe that exact height
    directly instead of waiting for ``getnowblock``/Monitor to announce it.
    This removes one polling hop from the manual draw path while keeping the
    official 360-tail collector unchanged.
    """
    last_identity = None
    last_probe_at = 0.0
    while True:
        wait_timeout = .25
        try:
            head = max((h for h in (monitor.HEAD_NUMBER,
                       (get_meta('chain_head') or {}).get('block')) if h is not None), default=None)
            tail = manual_selected_tail()
            due = manual_due_block(head, tail) if head is not None else None
            if due is not None:
                with DB() as c:
                    q=c.cursor(); q.execute('SELECT 1 FROM raw_blocks WHERE block_number=%s',(due,))
                    present=q.fetchone() is not None; q.close()
                fetched=False
                if not present:
                    save_block(fetch_block(due))
                    fetched=True
                identity=(tail,due)
                if identity != last_identity or fetched:
                    set_meta('manual_tail_fast_live', {
                        'status':'synced','tail':tail,'targetBlock':due,'chainHead':int(head),
                        'source':'exact-target-fetch' if fetched else 'live-cache',
                        'reportedAt':datetime.now(timezone.utc).isoformat()})
                    last_identity=identity

            # Speed-priority burst: when the selected target is at most three
            # blocks away, query that exact height every ~250ms.  Some public
            # nodes expose getblockbynum slightly before getnowblock advances.
            if head is not None:
                upcoming=manual_next_block(head,tail)
                distance=int(upcoming)-int(head)
                now=time.monotonic()
                if 0 < distance <= 3:
                    wait_timeout = .12
                if 0 < distance <= 3 and now-last_probe_at >= .25:
                    last_probe_at=now
                    try:
                        block=fetch_block(upcoming,timeout=2.0)
                    except RuntimeError as exc:
                        if 'unavailable' not in str(exc):
                            raise
                    else:
                        save_block(block)
                        if monitor.HEAD_NUMBER is None or int(upcoming)>int(monitor.HEAD_NUMBER):
                            monitor.HEAD_NUMBER=int(upcoming)
                        set_meta('chain_head',{'block':int(upcoming),
                            'seenAt':datetime.now(timezone.utc).isoformat(),
                            'source':'manual-exact-target-priority'})
                        HEAD_UPDATED.set()
                        set_meta('manual_tail_fast_live',{
                            'status':'synced','tail':tail,'targetBlock':int(upcoming),
                            'chainHead':int(upcoming),'source':'proactive-exact-target',
                            'reportedAt':datetime.now(timezone.utc).isoformat()})
                        last_identity=(tail,int(upcoming))
        except HTTPError as exc:
            set_meta('manual_tail_fast_live',{'status':'retrying','tail':manual_selected_tail(),
                'httpStatus':getattr(exc,'code',None),'error':str(exc)[:300],
                'reportedAt':datetime.now(timezone.utc).isoformat()})
            if getattr(exc,'code',None) in (403,429):
                time.sleep(1.5)
        except Exception as exc:
            set_meta('manual_tail_fast_live',{'status':'retrying','tail':manual_selected_tail(),
                'error':str(exc)[:300],'reportedAt':datetime.now(timezone.utc).isoformat()})
        HEAD_UPDATED.wait(timeout=wait_timeout)
        HEAD_UPDATED.clear()


def manual_prediction_forever():
    """Collector-side forecast safety net using the full replay-first engine.

    The AI Worker may run the same step. ``prediction_step`` owns a DB advisory
    lock so both services cannot calculate/write the same tail at once.
    """
    while True:
        try:
            tail=manual_selected_tail()
            settled=manual_settle_predictions()
            result=manual_prediction_step(tail)
            if result.get('status') != 'busy':
                set_meta('manual_tail_prediction_runtime',{**result,
                    'producer':'collector-safety-net','settledPredictions':settled,
                    'reportedAt':datetime.now(timezone.utc).isoformat()})
            set_meta('manual_tail_prediction_collector',{
                'status':result.get('status'),'tail':tail,'sourceBlock':result.get('sourceBlock'),
                'reportedAt':datetime.now(timezone.utc).isoformat()})
        except Exception as exc:
            set_meta('manual_tail_prediction_collector',{
                'status':'error','tail':manual_selected_tail(),'error':str(exc)[:500],
                'reportedAt':datetime.now(timezone.utc).isoformat()})
        time.sleep(.75)

def live_periods_forever():
    window = get_meta('historical_capture') or {}
    cursor = max(window['lastIndex'],
                 int((get_meta('collector_live_cursor') or {}).get('index',window['lastIndex'])))
    fallback_head=None
    last_fallback=0
    while True:
        try:
            now=time.monotonic()
            if now-last_fallback>=2 or fallback_head is None:
                fallback_head=(get_meta('chain_head') or {}).get('block')
                last_fallback=now
            head=max((h for h in (monitor.HEAD_NUMBER,fallback_head) if h is not None),default=None)
            if head is not None:
                index = cursor + 1
                ds, no = from_index(index)
                tb = target_block(ds,no)
                if tb <= head:
                    if build_live_period(ds,no):
                        cursor = index
                        set_meta('collector_live_cursor',{'index':cursor,
                             'period':period_key(ds,no), 'targetBlock':tb,
                             'updatedAt':datetime.now(timezone.utc).isoformat()})
        except Exception as exc:
            set_meta('collector_live_error', {'error':str(exc)[:300],
                'at':datetime.now(timezone.utc).isoformat()})
        HEAD_UPDATED.wait(timeout=.4)
        HEAD_UPDATED.clear()


def repairs_forever():
    while True:
        try:
            if manual_draw_needs_priority():
                time.sleep(1)
                continue
            if live_needs_priority(get_meta('monitor_stats') or {}, get_meta('chain_head') or {}):
                time.sleep(4)
                continue
            window = get_meta('historical_capture') or {}
            queued_repairs(2, window.get('firstBlock',0))
            with DB() as c:
                q=c.cursor()
                q.execute('SELECT COUNT(*) FROM repair_queue')
                missing=q.fetchone()[0]
                q.close()
            set_meta('audit_stats',{'status':'repairing',
                'queuedMissingBlocks':missing,
                'reportedAt':datetime.now(timezone.utc).isoformat()})
        except Exception as exc:
            set_meta('audit_repair_error',{'error':str(exc)[:300]})
        time.sleep(4)


def replay_forever():
    while True:
        try:
            advance_replay()
        except Exception as exc:
            set_meta('replay_error', {'error':str(exc)[:300],
                                     'at':datetime.now(timezone.utc).isoformat()})
        try:
            advance_lab()
        except Exception as exc:
            set_meta('lab_error', {'error':str(exc)[:300],
                                  'at':datetime.now(timezone.utc).isoformat()})
        time.sleep(2)


def pattern_memory_forever():
    """Record each canonical saved target and refresh after a tail-data revision."""
    last_identity=None
    while True:
        try:
            head=max((h for h in (monitor.HEAD_NUMBER,
                      (get_meta('chain_head') or {}).get('block')) if h is not None),default=None)
            if head is not None:
                ds,no=from_index(last_finished_index(head))
                key=period_key(ds,no)
                tb=target_block(ds,no)
                with DB() as c:
                    q=c.cursor()
                    q.execute('SELECT single_count FROM raw_blocks WHERE block_number=%s',(tb,))
                    raw=q.fetchone()
                    q.close()
                revision=(get_meta('canonical_data_revision') or {}).get('updatedAt')
                identity=(key,tb,raw[0] if raw else None,revision)
                if raw and identity!=last_identity:
                    if raw[0] is not None:
                        canonical=canonical_load(limit=60000,newest_first=True)
                        current_index=pindex(ds,no)
                        history=[(r[0],r[6]) for r in reversed(canonical)
                                 if pindex(r[1],r[2])<current_index]
                        report=analyze_pattern_memory(history+[(key,raw[0])])
                        with DB() as c:
                            q=c.cursor()
                            q.execute('''INSERT INTO pattern_memories(period_key,single_count,report)
                                VALUES(%s,%s,%s::jsonb) ON CONFLICT(period_key) DO UPDATE
                                SET single_count=EXCLUDED.single_count,report=EXCLUDED.report,
                                    recorded_at=NOW()''',(key,raw[0],json.dumps(report)))
                            q.execute('''INSERT INTO meta(k,v,updated_at) VALUES('pattern_memory_live',%s::jsonb,NOW())
                                ON CONFLICT(k) DO UPDATE SET v=EXCLUDED.v,updated_at=NOW()''',(json.dumps(report),))
                            q.close()
                    last_identity=identity
        except Exception as exc:
            set_meta('pattern_memory_error',{'error':str(exc)[:300],
                    'at':datetime.now(timezone.utc).isoformat()})
        time.sleep(.8)


def _acquire_collector_leader():
    """Keep the new Render instance alive until the old collector releases its lock.

    This turns automatic deployments into a clean hand-off instead of two writers
    overlapping for a few seconds. The same lock existed in older releases, so the
    the prediction-watchdog deployment is protected too.
    """
    lease=pool().getconn()
    while True:
        q=lease.cursor();q.execute('SELECT pg_try_advisory_lock(%s)',(monitor.LOCK_ID,))
        owned=bool(q.fetchone()[0]);q.close();lease.commit()
        if owned:
            return lease
        try:
            set_meta('collector_handoff',{'status':'waiting-for-previous-instance',
                     'reportedAt':datetime.now(timezone.utc).isoformat()})
        except Exception:
            pass
        time.sleep(1)

def main():
    init_db()
    leader_lease=_acquire_collector_leader()
    try:
        set_meta('collector_release',{'version':'god8-v2.0.16-manual-sync-safe',
                 'runtimeRevision':runtime_config_revision(),
                 'startedAt':datetime.now(timezone.utc).isoformat()})
        set_meta('collector_handoff',{'status':'leader','reportedAt':datetime.now(timezone.utc).isoformat()})
        while True:
            try:
                seed_window()
                break
            except Exception as exc:
                set_meta('collector_boot_error',{'error':str(exc)[:300]})
                time.sleep(5)
        try:
            reconcile_priority_bootstrap()
        except Exception as exc:
            set_meta('platform_calibration_bootstrap',{'status':'retrying',
                     'error':str(exc)[:300],'updatedAt':datetime.now(timezone.utc).isoformat()})
        for target in (fast_target_forever,manual_tail_fast_forever,manual_prediction_forever,backfill_forever,live_periods_forever,repairs_forever,replay_forever,pattern_memory_forever,reconcile_forever):
            threading.Thread(target=target,name=target.__name__,daemon=True).start()
        # The process-level leader lock is already held, so Monitor must not
        # acquire the same advisory lock a second time on another DB session.
        run_forever(already_locked=True)
    finally:
        try:
            q=leader_lease.cursor();q.execute('SELECT pg_advisory_unlock(%s)',(monitor.LOCK_ID,));q.close();leader_lease.commit()
        finally:
            pool().putconn(leader_lease)


if __name__ == '__main__':
    main()
