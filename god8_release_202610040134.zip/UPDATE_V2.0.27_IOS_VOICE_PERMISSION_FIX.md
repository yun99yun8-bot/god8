# God8 v2.0.27 - iOS 语音授权卡死修复

- 首次进入语音模式不再立刻弹麦克风权限，先切换到“轻点启用麦克风”状态。
- 麦克风授权与按住录音手势彻底分离，避免 iOS Safari 权限弹窗吞掉 pointerup 后页面停在录音/锁定状态。
- 授权返回后强制恢复录音遮罩、按压状态、按钮状态和移动端 viewport。
- 录音 pointer capture 改为只在非 touch 指针启用，降低 iOS Safari 手势锁死风险。
- 增加授权超时、blur、visibilitychange、pointercancel 兜底清理。
- 不修改开奖、手动尾、区块映射、预判核心。
