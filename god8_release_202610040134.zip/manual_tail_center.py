"""Independent 0-9 block-tail center.

The manual center deliberately never calls or mutates ``target_block``.  It is a
second homepage fed by a selected block-number tail.  History backfill uses
persistent source cursors so it can stop/resume without rescanning the oldest
rows on every batch.  Live predictions use the same walk-forward replay/trend/
omission engine as the normal homepage; only the input history is different.
"""
import json
from datetime import datetime, timezone

from core import DB, from_index, get_meta, pindex, set_meta, valid_result
from history_simulation import simulate

RESULT_HOLD_SECONDS = 10  # compatibility only; presentation uses shared countdown
ANALYSIS_SECONDS = 15
DISPLAY_OFFSET_SECONDS = -3
PREDICTION_REVEAL_COUNTDOWN = 45
MANUAL_CALIBRATION_DATE = '2026-10-03'
MANUAL_CALIBRATION_PERIOD = 695
# Platform screenshot calibration (2026-10-03 11:35 Beijing):
# issue 2610030695 -> block 86775289 for 9-tail. The visible history confirms
# 0694=86775269, 0693=86775249 ... i.e. one selected-tail target every +20 blocks.
# Other manually selected tails share the same issue decade/lane:
# 0-tail=86775280 ... 9-tail=86775289.
MANUAL_CALIBRATION_DECADE = 86775280
MANUAL_CALIBRATION_INDEX = pindex(MANUAL_CALIBRATION_DATE, MANUAL_CALIBRATION_PERIOD)
MANUAL_PERIOD_STEP = 20
MANUAL_ENGINE_VERSION = 'manual-period-v5-platform-0695-sync'
MANUAL_OBSERVATION_REQUIRED = 4

# v2.0.7 manual-period fix.  The archive still stores every captured raw block,
# but the manual page is a one-minute lottery view: exactly one selected-tail
# target per issue, spaced 20 blocks apart.  This is independent from the
# official 360-period tail clock.
def manual_anchor_block(tail):
    tail = int(tail)
    if not 0 <= tail <= 9:
        raise ValueError('tail must be 0..9')
    # Calibrated from the platform reference at 2026-10-03 issue 0695.
    # Every later/earlier issue is +/-20, so the selected tail stays fixed.
    return MANUAL_CALIBRATION_DECADE + tail


def manual_period_index(block_number, tail):
    delta = int(block_number) - manual_anchor_block(tail)
    if delta % MANUAL_PERIOD_STEP:
        return None
    return MANUAL_CALIBRATION_INDEX + (delta // MANUAL_PERIOD_STEP)


def manual_period_key(block_number, tail):
    idx = manual_period_index(block_number, tail)
    if idx is None:
        return None
    ds, no = from_index(idx)
    return f'{ds}:{no:04d}'


def _issue_no(period_key):
    if not period_key:
        return None
    ds, no = period_key.split(':', 1)
    return ds[2:4] + ds[5:7] + ds[8:10] + f'{int(no):04d}'


def _source_cte():
    return '''WITH manual_union AS (
        SELECT block_number,tail,block_hash,block_time,numbers,single_count,source,copied_at
        FROM manual_tail_blocks WHERE tail=%s
        UNION ALL
        SELECT r.block_number,MOD(r.block_number,10)::smallint,r.block_hash,r.block_time,
               r.numbers,r.single_count,'raw-fallback'::text,r.fetched_at
        FROM raw_blocks r
        WHERE MOD(r.block_number,10)=%s
          AND NOT EXISTS (SELECT 1 FROM manual_tail_blocks m WHERE m.block_number=r.block_number)
    ), manual_source AS (
        SELECT * FROM manual_union
        WHERE MOD(block_number - %s, 20)=0
    ) '''


def _source_params(tail):
    tail = int(tail)
    return (tail, tail, manual_anchor_block(tail))


def _now():
    return datetime.now(timezone.utc)


def _prediction_cycle_remaining(now=None):
    now = now or _now()
    adjusted = int(now.timestamp()) + DISPLAY_OFFSET_SECONDS
    second = ((adjusted % 60) + 60) % 60
    return 60 - second if second else 60


def _iso(value):
    return value.isoformat() if value else None


def _legacy_exists(cursor):
    cursor.execute("SELECT to_regclass('public.historical_raw_blocks')")
    return bool(cursor.fetchone()[0])


def _insert_rows(cursor, rows):
    if not rows:
        return 0
    from psycopg2.extras import execute_values
    execute_values(cursor, '''INSERT INTO manual_tail_blocks
        (block_number,tail,block_hash,block_time,numbers,single_count,source)
        VALUES %s ON CONFLICT(block_number) DO UPDATE SET
          tail=EXCLUDED.tail, block_hash=EXCLUDED.block_hash,
          block_time=COALESCE(EXCLUDED.block_time,manual_tail_blocks.block_time),
          numbers=COALESCE(EXCLUDED.numbers,manual_tail_blocks.numbers),
          single_count=COALESCE(EXCLUDED.single_count,manual_tail_blocks.single_count),
          source=CASE WHEN manual_tail_blocks.source='raw' THEN manual_tail_blocks.source ELSE EXCLUDED.source END''',
        rows, template='(%s,%s,%s,%s,%s::jsonb,%s,%s)', page_size=500)
    return len(rows)


def live_sync_step(limit=500):
    """Copy only new raw blocks after the live cursor.

    The first call anchors at the current raw head, so bulk historical work is
    controlled only by the explicit backfill switch.
    """
    state = get_meta('manual_tail_live_sync') or {}
    cursor_value = state.get('cursor')
    copied = 0
    with DB() as conn:
        q = conn.cursor()
        if cursor_value is None:
            q.execute('SELECT MAX(block_number) FROM raw_blocks')
            cursor_value = int(q.fetchone()[0] or 0)
            q.close()
            payload = {'cursor': cursor_value, 'status': 'anchored', 'copied': 0,
                       'reportedAt': _now().isoformat()}
            set_meta('manual_tail_live_sync', payload)
            return 0
        q.execute('''SELECT block_number,block_hash,block_time,numbers,single_count
                     FROM raw_blocks WHERE block_number>%s
                     ORDER BY block_number LIMIT %s''', (int(cursor_value), int(limit)))
        found = q.fetchall()
        if found:
            prepared = [(int(n), int(n) % 10, h, t,
                         json.dumps(nums) if nums is not None else None, s, 'raw')
                        for n, h, t, nums, s in found]
            copied = _insert_rows(q, prepared)
            cursor_value = max(int(r[0]) for r in found)
        q.close()
    set_meta('manual_tail_live_sync', {'cursor': int(cursor_value), 'status': 'live',
        'copied': copied, 'reportedAt': _now().isoformat()})
    return copied


def backfill_enabled():
    return bool((get_meta('manual_tail_backfill') or {}).get('enabled'))


def set_backfill_enabled(enabled):
    previous = get_meta('manual_tail_backfill') or {}
    enabled = bool(enabled)
    state = {**previous, 'enabled': enabled,
             'status': 'running' if enabled else ('complete' if previous.get('status') == 'complete' else 'paused'),
             'changedAt': _now().isoformat()}
    if enabled:
        # Preserve cursors so pause/resume continues from the exact source point.
        # A completed job may be re-opened to scan only rows newer than its cursors.
        state['rawDone'] = False
        state['legacyDone'] = False
        state['error'] = None
        state['completedAt'] = None
        state['auditCompleteAt'] = None
    set_meta('manual_tail_backfill', state)
    return state


def _source_min(cursor, table):
    cursor.execute(f'SELECT MIN(block_number) FROM {table}')
    value = cursor.fetchone()[0]
    return int(value) if value is not None else None


def _source_max(cursor, table):
    cursor.execute(f'SELECT MAX(block_number) FROM {table}')
    value = cursor.fetchone()[0]
    return int(value) if value is not None else None


def _raw_batch(q, cursor_value, limit):
    if cursor_value is None:
        first = _source_min(q, 'raw_blocks')
        cursor_value = (first - 1) if first is not None else 0
    q.execute('''SELECT block_number,block_hash,block_time,numbers,single_count
                 FROM raw_blocks WHERE block_number>%s
                 ORDER BY block_number LIMIT %s''', (int(cursor_value), int(limit)))
    rows = q.fetchall()
    prepared = [(int(n), int(n) % 10, h, t,
                 json.dumps(nums) if nums is not None else None, s, 'raw')
                for n, h, t, nums, s in rows]
    _insert_rows(q, prepared)
    if rows:
        cursor_value = int(rows[-1][0])
    max_value = _source_max(q, 'raw_blocks')
    done = max_value is None or int(cursor_value) >= max_value
    return rows, int(cursor_value), done, max_value


def _legacy_batch(q, cursor_value, limit):
    if not _legacy_exists(q):
        return [], int(cursor_value or 0), True, None
    if cursor_value is None:
        first = _source_min(q, 'historical_raw_blocks')
        cursor_value = (first - 1) if first is not None else 0
    q.execute('''SELECT block_number,block_hash
                 FROM historical_raw_blocks WHERE block_number>%s
                 ORDER BY block_number LIMIT %s''', (int(cursor_value), int(limit)))
    rows = q.fetchall()
    prepared = []
    for n, block_hash in rows:
        nums, single = valid_result(block_hash)
        prepared.append((int(n), int(n) % 10, block_hash, None,
                         json.dumps(nums) if nums is not None else None, single, 'legacy'))
    _insert_rows(q, prepared)
    if rows:
        cursor_value = int(rows[-1][0])
    max_value = _source_max(q, 'historical_raw_blocks')
    done = max_value is None or int(cursor_value) >= max_value
    return rows, int(cursor_value), done, max_value


def backfill_step(limit=2500):
    """Advance both historical sources with persistent cursors.

    Raw and legacy stores each receive part of every batch so a very large raw
    table cannot starve the legacy source. No network/API request is made.
    """
    state = get_meta('manual_tail_backfill') or {}
    if not state.get('enabled'):
        return {'status': state.get('status', 'paused'), 'processed': 0}

    each = max(1, int(limit) // 2)
    raw_rows = legacy_rows = []
    with DB() as conn:
        q = conn.cursor()
        raw_rows, raw_cursor, raw_done, raw_max = _raw_batch(q, state.get('rawCursor'), each)
        legacy_rows, legacy_cursor, legacy_done, legacy_max = _legacy_batch(q, state.get('legacyCursor'), each)
        q.execute('SELECT COUNT(*) FROM manual_tail_blocks')
        stored = int(q.fetchone()[0] or 0)
        q.close()

    processed = len(raw_rows) + len(legacy_rows)
    next_state = {**state,
        'enabled': True,
        'status': 'running',
        'rawCursor': raw_cursor,
        'legacyCursor': legacy_cursor,
        'rawMax': raw_max,
        'legacyMax': legacy_max,
        'rawDone': raw_done,
        'legacyDone': legacy_done,
        'lastRawBatch': len(raw_rows),
        'lastLegacyBatch': len(legacy_rows),
        'lastBatch': processed,
        'processed': int(state.get('processed', 0)) + processed,
        'stored': stored,
        'reportedAt': _now().isoformat(),
        'error': None,
    }

    if raw_done and legacy_done:
        next_state.update({'enabled': False, 'status': 'complete',
                           'completedAt': _now().isoformat()})
        set_meta('manual_tail_backfill', next_state)
        audit = audit_snapshot()
        next_state.update({'auditCompleteAt': _now().isoformat(),
                           'auditPass': bool(audit.get('pass'))})
        set_meta('manual_tail_backfill', next_state)
    else:
        set_meta('manual_tail_backfill', next_state)
    return {'status': next_state['status'], 'processed': processed,
            'raw': len(raw_rows), 'legacy': len(legacy_rows), 'stored': stored,
            'rawCursor': raw_cursor, 'legacyCursor': legacy_cursor}


def audit_snapshot():
    """Audit the historical snapshot captured by the backfill cursors.

    New raw blocks can arrive while the audit is running. They are intentionally
    excluded above the captured rawMax because live_sync_step owns that moving
    edge. This prevents an endless false "missing 1" race at completion.
    """
    state = get_meta('manual_tail_backfill') or {}
    raw_limit = state.get('rawMax')
    legacy_limit = state.get('legacyMax')
    with DB() as conn:
        q = conn.cursor()
        q.execute('SELECT COUNT(*) FROM manual_tail_blocks')
        stored = int(q.fetchone()[0] or 0)
        if raw_limit is None:
            raw_limit = _source_max(q, 'raw_blocks')
        q.execute('SELECT COUNT(*) FROM raw_blocks WHERE block_number<=%s', (int(raw_limit or 0),))
        raw = int(q.fetchone()[0] or 0)
        q.execute('''SELECT COUNT(*) FROM raw_blocks r
                     WHERE r.block_number<=%s AND NOT EXISTS
                     (SELECT 1 FROM manual_tail_blocks m WHERE m.block_number=r.block_number)''',
                  (int(raw_limit or 0),))
        missing_raw = int(q.fetchone()[0] or 0)
        q.execute('''SELECT COUNT(*) FROM manual_tail_blocks m JOIN raw_blocks r USING(block_number)
                     WHERE r.block_number<=%s AND
                     (m.block_hash<>r.block_hash OR m.tail<>MOD(m.block_number,10))''',
                  (int(raw_limit or 0),))
        mismatches = int(q.fetchone()[0] or 0)
        legacy_missing = 0
        if _legacy_exists(q):
            if legacy_limit is None:
                legacy_limit = _source_max(q, 'historical_raw_blocks')
            q.execute('''SELECT COUNT(*) FROM historical_raw_blocks h
                         WHERE h.block_number<=%s AND NOT EXISTS
                         (SELECT 1 FROM manual_tail_blocks m WHERE m.block_number=h.block_number)''',
                      (int(legacy_limit or 0),))
            legacy_missing = int(q.fetchone()[0] or 0)
        q.execute('''SELECT tail,COUNT(*) FROM manual_tail_blocks GROUP BY tail ORDER BY tail''')
        by_tail = {str(int(t)): int(n) for t, n in q.fetchall()}
        q.close()
    report = {'stored': stored, 'rawBlocks': raw, 'rawThrough': raw_limit,
              'legacyThrough': legacy_limit, 'missingRaw': missing_raw,
              'missingLegacy': legacy_missing, 'mismatches': mismatches,
              'byTail': by_tail,
              'pass': missing_raw == 0 and legacy_missing == 0 and mismatches == 0,
              'reportedAt': _now().isoformat()}
    set_meta('manual_tail_audit', report)
    return report


def settle_predictions():
    """Settle forecasts only with the exact next scheduled issue of the same tail.

    A missing +20 target is never skipped. This keeps incomplete/backfilled data
    from silently redefining a forecast against a later result.
    """
    with DB() as conn:
        q = conn.cursor()
        q.execute("""UPDATE manual_tail_predictions p
                     SET actual=(SELECT x.single_count FROM (
                           SELECT m.block_number,m.single_count FROM manual_tail_blocks m
                           WHERE m.tail=p.tail AND m.block_number=p.source_block+20
                             AND MOD(m.block_number-(86775280+p.tail),20)=0
                           UNION ALL
                           SELECT r.block_number,r.single_count FROM raw_blocks r
                           WHERE MOD(r.block_number,10)=p.tail AND r.block_number=p.source_block+20
                             AND MOD(r.block_number-(86775280+p.tail),20)=0
                             AND NOT EXISTS (SELECT 1 FROM manual_tail_blocks m2 WHERE m2.block_number=r.block_number)
                         ) x WHERE x.single_count BETWEEN 0 AND 7
                         ORDER BY x.block_number LIMIT 1),
                         settled_at=COALESCE(p.settled_at,NOW())
                     WHERE p.actual IS NULL
                       AND p.evidence->>'engineVersion'=%s
                       AND MOD(p.source_block-(86775280+p.tail),20)=0
                       AND EXISTS (SELECT 1 FROM (
                           SELECT m.block_number,m.single_count FROM manual_tail_blocks m
                           WHERE m.tail=p.tail AND m.block_number=p.source_block+20
                             AND MOD(m.block_number-(86775280+p.tail),20)=0
                           UNION ALL
                           SELECT r.block_number,r.single_count FROM raw_blocks r
                           WHERE MOD(r.block_number,10)=p.tail AND r.block_number=p.source_block+20
                             AND MOD(r.block_number-(86775280+p.tail),20)=0
                             AND NOT EXISTS (SELECT 1 FROM manual_tail_blocks m2 WHERE m2.block_number=r.block_number)
                         ) y WHERE y.single_count BETWEEN 0 AND 7)""", (MANUAL_ENGINE_VERSION,))
        changed = q.rowcount
        q.close()
    return changed


def _latest_valid_source_block(tail):
    """Return the newest valid scheduled block for one fixed manual tail."""
    tail = int(tail)
    with DB() as conn:
        q = conn.cursor()
        q.execute(_source_cte() + '''SELECT block_number FROM manual_source
                     ORDER BY block_number DESC LIMIT 1''', _source_params(tail))
        row = q.fetchone()
        q.close()
    return int(row[0]) if row else None


def _selection_state(tail=None, initialize=False):
    """Read the persisted manual-tail selection/observation session.

    v2.0.14 deliberately starts a clean observation window for a legacy
    selection that predates the clean-sequence fields. This prevents an old
    cache or a mixed/incomplete sequence from being treated as a fresh model
    context immediately after deployment.
    """
    state = get_meta('manual_tail_selected') or {}
    try:
        current = int(state.get('tail', 9))
    except (TypeError, ValueError):
        current = 9
    if not 0 <= current <= 9:
        current = 9
    if tail is not None and int(tail) != current:
        return state
    if initialize and state.get('observationStartBlock') is None:
        latest = _latest_valid_source_block(current)
        now = _now().isoformat()
        state = {**state, 'tail': current, 'mode': 'manual-independent',
                 'changedAt': state.get('changedAt') or now,
                 'observationStartedAt': now,
                 'observationStartBlock': latest,
                 'observationRequired': MANUAL_OBSERVATION_REQUIRED,
                 'dataPolicy': 'selected-tail-only-contiguous-valid',
                 'note': 'fixed +20 block cadence; prediction accepts only clean selected-tail sequence'}
        set_meta('manual_tail_selected', state)
    return state


def select_tail(tail):
    tail = int(tail)
    if not 0 <= tail <= 9:
        raise ValueError('tail must be 0..9')
    previous = get_meta('manual_tail_selected') or {}
    try:
        previous_tail = int(previous.get('tail'))
    except (TypeError, ValueError):
        previous_tail = None
    # Clicking the already-active tail must not reset a nearly-complete
    # observation window. A real tail change always starts a fresh clean
    # sequence after the latest already-known result for the newly selected lane.
    if previous_tail == tail and previous.get('observationStartBlock') is not None:
        state = {**previous, 'tail': tail, 'mode': 'manual-independent'}
    else:
        latest = _latest_valid_source_block(tail)
        now = _now().isoformat()
        state = {'tail': tail, 'mode': 'manual-independent', 'changedAt': now,
                 'observationStartedAt': now, 'observationStartBlock': latest,
                 'observationRequired': MANUAL_OBSERVATION_REQUIRED,
                 'dataPolicy': 'selected-tail-only-contiguous-valid',
                 'note': 'fixed +20 block cadence; prediction accepts only clean selected-tail sequence'}
    set_meta('manual_tail_selected', state)
    request = {'tail': tail, 'status': 'observing-tail',
               'observed': 0, 'required': int(state.get('observationRequired') or MANUAL_OBSERVATION_REQUIRED),
               'requestedAt': state.get('changedAt') or _now().isoformat(),
               'observationStartBlock': state.get('observationStartBlock')}
    set_meta('manual_tail_prediction_request', request)
    set_meta('manual_tail_prediction_runtime', request)
    return state


def selected_tail():
    try:
        value = int((get_meta('manual_tail_selected') or {}).get('tail', 9))
        return value if 0 <= value <= 9 else 9
    except (TypeError, ValueError):
        return 9


def _observation_status(q, tail, latest_block=None):
    """Validate the post-switch live sequence before predictions are accepted.

    Only consecutive scheduled blocks (+20 each), for the currently selected
    tail and with a valid single 0..7, count. A missing/invalid target stops the
    accepted run; later rows do not bridge across the gap. This is intentionally
    conservative so a partial backfill or wrong-lane row can never redefine the
    live prediction context.
    """
    tail = int(tail)
    state = _selection_state(tail, initialize=(tail == selected_tail()))
    required = max(4, int(state.get('observationRequired') or MANUAL_OBSERVATION_REQUIRED))
    start = state.get('observationStartBlock')
    if tail != selected_tail():
        return {'status': 'passive', 'tail': tail, 'accepted': True,
                'observed': required, 'required': required}
    if start is None:
        return {'status': 'waiting-source', 'tail': tail, 'accepted': False,
                'observed': 0, 'required': required, 'startBlock': None,
                'reason': '当前尾数还没有有效基准结果'}
    start = int(start)
    q.execute(_source_cte() + '''SELECT block_number,single_count FROM manual_source
                 WHERE block_number>%s ORDER BY block_number''', _source_params(tail) + (start,))
    rows = q.fetchall()
    expected = start + MANUAL_PERIOD_STEP
    observed = 0
    last_clean = start
    blocked = None
    for block, single in rows:
        block = int(block)
        if latest_block is not None and block > int(latest_block):
            break
        if block != expected:
            blocked = {'type': 'missing-target', 'expectedBlock': expected, 'nextSeenBlock': block}
            break
        if single is None or not 0 <= int(single) <= 7:
            blocked = {'type': 'invalid-result', 'expectedBlock': expected}
            break
        observed += 1
        last_clean = block
        expected += MANUAL_PERIOD_STEP
    accepted = (observed >= required and blocked is None and
                (latest_block is None or last_clean == int(latest_block)))
    if accepted:
        status = 'ready'
        reason = '已建立连续同尾有效样本'
    elif blocked:
        status = 'blocked'
        reason = '检测到缺期或无效数据，等待补齐后重新确认连续序列'
    else:
        status = 'observing'
        reason = '切尾后正在建立连续同尾样本'
    return {'status': status, 'tail': tail, 'accepted': accepted,
            'observed': observed, 'required': required, 'startBlock': start,
            'lastCleanBlock': last_clean, 'nextExpectedBlock': expected,
            'blocked': blocked, 'reason': reason,
            'startedAt': state.get('observationStartedAt') or state.get('changedAt'),
            'dataPolicy': 'selected-tail-only-contiguous-valid'}

def _synthetic_rows(q, tail):
    q.execute(_source_cte() + '''SELECT block_number,single_count,numbers FROM manual_source
                 ORDER BY block_number''', _source_params(tail))
    data = q.fetchall()
    rows = []
    for block, single, numbers in data:
        key = manual_period_key(block, tail)
        if key is not None:
            rows.append((key, single, numbers))
    return rows


def _manual_fallback_preview(rows):
    """Always provide two distinct manual-tail choices once history is sufficient.

    The shared simulator remains the primary engine.  This manual-only fallback
    is used when the latest context has no replay/trend/omission ensemble output
    even though the selected tail already has a substantial valid history.  It
    uses only rows that existed before the target: long-run frequency, recent
    20/50 activity and the current omission gap.
    """
    values = [int(single) for _, single, _ in rows if single is not None and 0 <= int(single) <= 7]
    if len(values) < 120:
        return None

    total = len(values)
    overall = [values.count(k) / total for k in range(8)]
    recent20 = values[-min(20, total):]
    recent50 = values[-min(50, total):]

    def rates(sample):
        size = max(1, len(sample))
        return [sample.count(k) / size for k in range(8)]

    rate20, rate50 = rates(recent20), rates(recent50)
    gaps = []
    for candidate in range(8):
        gap = 0
        for value in reversed(values):
            if value == candidate:
                break
            gap += 1
        gaps.append(gap)
    gap_scale = max(1, max(gaps))

    scored = []
    for candidate in range(8):
        # Keep the fallback deliberately conservative: recent activity leads,
        # long-run history anchors it, and omission is only a modest tiebreaker.
        score = (0.30 * overall[candidate] +
                 0.25 * rate20[candidate] +
                 0.35 * rate50[candidate] +
                 0.10 * min(1.0, gaps[candidate] / gap_scale))
        scored.append((score, candidate))
    scored.sort(key=lambda item: (-item[0], item[1]))
    choices = [scored[0][1], scored[1][1]]
    reasons = {str(candidate): ['近期趋势', '当前遗漏', '长期频数基线'] for candidate in choices}
    match = {
        'length': 0, 'sequence': [], 'support': 0, 'minimumSupport': 0,
        'votes': {}, 'levels': [], 'backoff': None,
        'selectionPolicy': 'manual-trend-omission-fallback',
        'selectionRevision': 'v2.0.12-replay-sync-self-heal',
        'secondCandidateMode': 'adaptive',
        'selectedEvidence': [
            {'candidate': candidate, 'fallback': True, 'score': round(score, 6),
             'gap': gaps[candidate], 'recent20Rate': round(rate20[candidate], 4),
             'recent50Rate': round(rate50[candidate], 4),
             'baseline': round(overall[candidate], 4)}
            for score, candidate in scored[:2]
        ],
        'candidateScores': {str(candidate): round(score, 6) for score, candidate in scored},
        'sources': {str(candidate): [] for candidate in choices},
        'methods': [], 'reasons': reasons,
        'hot': sorted(range(8), key=lambda k: (-rate20[k], k))[:3],
        'cold': sorted(range(8), key=lambda k: (rate20[k], k))[:3],
        'omission': {str(k): {'gap': gaps[k]} for k in range(8)},
    }
    return {
        'predictions': choices, 'match': match,
        'note': '当前没有可用的精确复现输出，手动尾数使用近期趋势、遗漏与长期频数生成两组补位。',
    }


def _engine_preview(q, tail):
    rows = _synthetic_rows(q, tail)
    if not rows:
        return None, {'historyRows': 0, 'engine': 'history_simulation'}
    result = simulate(rows, evaluation_window=250)
    preview = result.get('preview')
    meta = {'historyRows': len(rows), 'validRows': result.get('valid', 0),
            'evaluated': result.get('evaluated', 0), 'missingRows': result.get('missing', 0),
            'engine': 'history_simulation',
            'historyScope': 'selected-tail-only-all-history', 'engineVersion': MANUAL_ENGINE_VERSION,
            'methodEvaluationRows': 250, 'fallbackUsed': False,
            'dataPolicy': 'selected-tail-only-contiguous-valid'}
    return preview, meta


def prediction_step(tail=None):
    """Prepare the next selected-tail forecast immediately after a fresh result.

    Display remains independent and reveals the prepared forecast only at the
    shared countdown-45 boundary.
    """
    settle_predictions()
    tail = selected_tail() if tail is None else int(tail)
    if not 0 <= tail <= 9:
        raise ValueError('tail must be 0..9')
    now = _now()
    with DB() as conn:
        q = conn.cursor()
        q.execute(_source_cte() + '''SELECT block_number,single_count,COALESCE(copied_at,block_time)
                     FROM manual_source
                     ORDER BY block_number DESC LIMIT 1''', _source_params(tail))
        latest = q.fetchone()
        if not latest or latest[1] is None or not 0 <= int(latest[1]) <= 7:
            q.close()
            return {'status': 'waiting-valid-source', 'tail': tail}
        source_block, latest_single, result_at = int(latest[0]), int(latest[1]), latest[2]
        observation = _observation_status(q, tail, source_block)
        if not observation.get('accepted'):
            q.close()
            return {**observation, 'status': 'observing-tail', 'tail': tail, 'sourceBlock': source_block}
        # Collector and Worker may both service the manual forecast. Use one
        # short transaction-scoped lock per tail so only one process performs
        # the full-history replay simulation for the same cycle.
        q.execute('SELECT pg_try_advisory_xact_lock(%s)', (81086430 + tail,))
        if not bool(q.fetchone()[0]):
            q.close()
            return {'status': 'busy', 'tail': tail, 'sourceBlock': source_block}
        q.execute('''SELECT prediction_a,prediction_b,evidence,created_at,actual,settled_at
                     FROM manual_tail_predictions WHERE tail=%s AND source_block=%s
                       AND evidence->>'engineVersion'='manual-period-v5-platform-0695-sync' ''',
                  (tail, source_block))
        existing = q.fetchone()
        if existing:
            q.close()
            return {'status': 'locked', 'tail': tail, 'sourceBlock': source_block,
                    'choices': [int(existing[0]), int(existing[1])]}

        # Compute immediately after the fresh selected-tail result lands.
        # The UI keeps the judged result visible until countdown 45.
        preview, meta = _engine_preview(q, tail)
        if not preview or len(preview.get('predictions') or []) < 2:
            q.close()
            return {'status': 'insufficient-evidence', 'tail': tail, 'sourceBlock': source_block,
                    **meta}
        choices = [int(x) for x in preview['predictions'][:2]]
        evidence = {'match': preview.get('match') or {}, 'note': preview.get('note'), 'engineVersion': MANUAL_ENGINE_VERSION, 'selectedTail': tail, 'observation': observation, **meta}
        q.execute('''INSERT INTO manual_tail_predictions
                     (tail,source_block,prediction_a,prediction_b,evidence)
                     VALUES(%s,%s,%s,%s,%s::jsonb)
                     ON CONFLICT(tail,source_block) DO UPDATE SET
                       prediction_a=EXCLUDED.prediction_a,
                       prediction_b=EXCLUDED.prediction_b,
                       evidence=EXCLUDED.evidence,
                       actual=NULL,created_at=NOW(),settled_at=NULL
                     WHERE COALESCE(manual_tail_predictions.evidence->>'engineVersion','')<>'manual-period-v5-platform-0695-sync' ''',
                  (tail, source_block, choices[0], choices[1], json.dumps(evidence)))
        q.close()
    return {'status': 'locked', 'tail': tail, 'sourceBlock': source_block,
            'choices': choices, **meta}


def _forecast_view(q, tail, latest_block, latest_seen_at, observation=None):
    """Return manual prediction phase on the shared 60-second clock.

    Countdown 60..46 shows the just-settled result. Countdown 45..01 shows only
    the next forecast sourced from that exact latest result.
    """
    observation = observation or _observation_status(q, tail, latest_block)
    if not observation.get('accepted'):
        return 'observing', None

    remaining = _prediction_cycle_remaining()
    if remaining > PREDICTION_REVEAL_COUNTDOWN:
        judged_source = int(latest_block) - MANUAL_PERIOD_STEP
        q.execute('''SELECT source_block,prediction_a,prediction_b,evidence,created_at,actual,settled_at
                     FROM manual_tail_predictions WHERE tail=%s AND source_block=%s
                       AND actual IS NOT NULL AND settled_at IS NOT NULL
                       AND evidence->>'engineVersion'='manual-period-v5-platform-0695-sync' ''',
                  (tail, judged_source))
        judged = q.fetchone()
        if judged:
            evidence = judged[3] or {}
            target_block = int(judged[0]) + MANUAL_PERIOD_STEP
            target_key = manual_period_key(target_block, tail)
            return 'result', {'sourceBlock': int(judged[0]), 'targetBlock': target_block,
                'targetPeriod': target_key, 'targetIssue': _issue_no(target_key),
                'choices': [int(judged[1]), int(judged[2])], 'match': evidence.get('match') or {},
                'evidence': evidence, 'lockedAt': _iso(judged[4]), 'actual': int(judged[5]),
                'settledAt': _iso(judged[6]),
                'resultHoldSeconds': max(0, remaining - PREDICTION_REVEAL_COUNTDOWN)}
        return 'holding', None

    q.execute('''SELECT source_block,prediction_a,prediction_b,evidence,created_at,actual,settled_at
                 FROM manual_tail_predictions WHERE tail=%s AND source_block=%s
                   AND evidence->>'engineVersion'='manual-period-v5-platform-0695-sync' ''',
              (tail, latest_block))
    current = q.fetchone()
    if current and current[5] is None:
        evidence = current[3] or {}
        target_block = int(current[0]) + MANUAL_PERIOD_STEP
        target_key = manual_period_key(target_block, tail)
        return 'forecast', {'sourceBlock': int(current[0]), 'targetBlock': target_block,
            'targetPeriod': target_key, 'targetIssue': _issue_no(target_key),
            'choices': [int(current[1]), int(current[2])], 'match': evidence.get('match') or {},
            'evidence': evidence, 'lockedAt': _iso(current[4]), 'actual': None, 'settledAt': None}

    runtime = get_meta('manual_tail_prediction_runtime') or {}
    if runtime.get('tail') == tail:
        status = runtime.get('status')
        source_matches = runtime.get('sourceBlock') in (None, latest_block)
        if status in ('waiting-valid-source', 'insufficient-evidence', 'busy', 'observing-tail') and source_matches:
            return 'waiting', None
    return 'analyzing', None


def report(tail=None):
    tail = selected_tail() if tail is None else int(tail)
    if not 0 <= tail <= 9:
        raise ValueError('tail must be 0..9')
    with DB() as conn:
        q = conn.cursor()
        q.execute(_source_cte() + '''SELECT COUNT(*),MIN(block_number),MAX(block_number)
                       FROM manual_source''', _source_params(tail))
        total, first, last = q.fetchone(); total = int(total or 0)
        q.execute(_source_cte() + '''
                     , valid_source AS (
                         SELECT single_count,ROW_NUMBER() OVER(ORDER BY block_number) AS rn
                         FROM manual_source WHERE single_count BETWEEN 0 AND 7
                     ), valid_summary AS (
                         SELECT COUNT(*)::bigint AS total FROM valid_source
                     ), valid_by_single AS (
                         SELECT single_count,COUNT(*)::bigint AS hits,MAX(rn)::bigint AS last_rn
                         FROM valid_source GROUP BY single_count
                     )
                     SELECT g.single,COALESCE(v.hits,0),
                            s.total-COALESCE(v.last_rn,0),s.total
                     FROM generate_series(0,7) AS g(single)
                     CROSS JOIN valid_summary s
                     LEFT JOIN valid_by_single v ON v.single_count=g.single
                     ORDER BY g.single''', _source_params(tail))
        stat_rows = q.fetchall()
        valid_total = int(stat_rows[0][3] or 0) if stat_rows else 0
        dist = {int(single): int(hits or 0) for single, hits, _, _ in stat_rows}
        omissions = [{'single': int(single), 'gap': int(gap or 0) if valid_total else None,
                      'hits': int(hits or 0),
                      'rate': (int(hits or 0) / valid_total if valid_total else None)}
                     for single, hits, gap, _ in stat_rows]
        q.execute(_source_cte() + '''SELECT block_number,single_count,numbers,COALESCE(copied_at,block_time)
                     FROM manual_source
                     ORDER BY block_number DESC LIMIT 1''', _source_params(tail))
        latest = q.fetchone()
        latest_single = int(latest[1]) if latest and latest[1] is not None else None
        q.execute('''SELECT COUNT(*),
                            COUNT(*) FILTER (WHERE actual=prediction_a),
                            COUNT(*) FILTER (WHERE actual=prediction_b),
                            COUNT(*) FILTER (WHERE actual IN (prediction_a,prediction_b))
                     FROM manual_tail_predictions WHERE tail=%s AND actual IS NOT NULL
                       AND evidence->>'engineVersion'='manual-period-v5-platform-0695-sync'
                       AND MOD(source_block-(86775280+tail),20)=0''', (tail,))
        verified, first_hits, second_hits, either_hits = [int(v or 0) for v in q.fetchone()]
        observation = (_observation_status(q, tail, int(latest[0])) if latest
                       else {'status':'waiting-source','tail':tail,'accepted':False,'observed':0,
                             'required':MANUAL_OBSERVATION_REQUIRED,'reason':'当前尾数还没有有效基准结果'})
        phase, forecast = (_forecast_view(q, tail, int(latest[0]), latest[3], observation)
                           if latest else ('waiting', None))
        q.close()

    chain = get_meta('chain_head') or {}
    head = chain.get('block')
    head = int(head) if head is not None else None
    # Keep issue/block/prediction on one truth source. Once an actual selected-tail
    # result exists, the next target is exactly that result +20. Chain head is only
    # a bootstrap fallback before the first valid result is present.
    next_block = int(latest[0]) + MANUAL_PERIOD_STEP if latest else None
    if next_block is None and head is not None:
        anchor = manual_anchor_block(tail)
        next_block = anchor if head < anchor else anchor + (((head - anchor) // MANUAL_PERIOD_STEP) + 1) * MANUAL_PERIOD_STEP
    latest_payload = None
    if latest:
        latest_key = manual_period_key(int(latest[0]), tail)
        latest_payload = {'period': latest_key,
                          'issue': _issue_no(latest_key),
                          'block': int(latest[0]), 'single': latest_single,
                          'numbers': latest[2], 'observedAt': _iso(latest[3])}
    return {'tail': tail, 'selected': tail == selected_tail(), 'total': total, 'validTotal': valid_total,
            'firstBlock': int(first) if first is not None else None,
            'lastBlock': int(last) if last is not None else None,
            'latest': latest_payload,
            'nextBlock': next_block,
            'nextPeriod': manual_period_key(next_block, tail) if next_block is not None else None,
            'nextIssue': _issue_no(manual_period_key(next_block, tail)) if next_block is not None else None,
            'chainHead': head,
            'distribution': [{'single': s, 'hits': dist.get(s, 0),
                              'rate': (dist.get(s, 0) / valid_total if valid_total else None)} for s in range(8)],
            'omission': omissions, 'phase': phase, 'forecast': forecast, 'observation': observation,
            'stats': {'verified': verified,
                      'firstRate': first_hits / verified if verified else None,
                      'secondRate': second_hits / verified if verified else None,
                      'eitherRate': either_hits / verified if verified else None},
            'backfill': get_meta('manual_tail_backfill') or {'enabled': False, 'status': 'paused'},
            'audit': get_meta('manual_tail_audit') or {},
            'liveSync': get_meta('manual_tail_live_sync') or {},
            'fastLive': get_meta('manual_tail_fast_live') or {},
            'predictionCollector': get_meta('manual_tail_prediction_collector') or {},
            'worker': get_meta('manual_tail_worker') or {},
            'workerError': get_meta('manual_tail_worker_error') or {},
            'parentWorker': {
                'runtime': get_meta('god8_worker_heartbeat') or {},
                'startup': get_meta('god8_worker_startup_heartbeat') or {},
                'handoff': get_meta('god8_worker_handoff') or {},
                'release': get_meta('god8_worker_release') or {},
            },
            'predictionRuntime': get_meta('manual_tail_prediction_runtime') or {},
            'systemIndependent': True, 'clockSynchronized': True, 'clockIndependent': False, 'periodStepBlocks': MANUAL_PERIOD_STEP,
            'anchorBlock': manual_anchor_block(tail),
            'engine': 'selected-tail-clean-sequence-replay-first', 'engineVersion': MANUAL_ENGINE_VERSION,
            'readSource': 'manual-tail-plus-raw-fallback'}


def live_report(tail=None):
    """Lightweight selected-tail draw snapshot for sub-second polling.

    Fresh collector writes land in ``manual_tail_blocks`` in the same database
    transaction as ``raw_blocks``. Reading that table directly keeps the draw
    path independent from heavier omission/replay/statistics queries.
    """
    tail = selected_tail() if tail is None else int(tail)
    if not 0 <= tail <= 9:
        raise ValueError('tail must be 0..9')
    anchor = manual_anchor_block(tail)
    latest = None
    with DB() as conn:
        q = conn.cursor()
        q.execute("""SELECT block_number,single_count,numbers,COALESCE(copied_at,block_time),source
                     FROM manual_tail_blocks
                     WHERE tail=%s AND MOD(block_number-%s,20)=0
                     ORDER BY block_number DESC LIMIT 1""", (tail, anchor))
        latest = q.fetchone()
        if latest is None:
            q.execute("""SELECT block_number,single_count,numbers,block_time,'raw-fallback'
                         FROM raw_blocks
                         WHERE MOD(block_number,10)=%s AND MOD(block_number-%s,20)=0
                         ORDER BY block_number DESC LIMIT 1""", (tail, anchor))
            latest = q.fetchone()
        q.close()
    chain = get_meta('chain_head') or {}
    head = chain.get('block')
    head = int(head) if head is not None else None
    # Live card follows the latest actual draw. Do not let chain-head movement
    # advance the displayed issue before that exact selected-tail result arrives.
    next_block = int(latest[0]) + MANUAL_PERIOD_STEP if latest else None
    if next_block is None and head is not None:
        next_block = anchor if head < anchor else anchor + (((head-anchor)//MANUAL_PERIOD_STEP)+1)*MANUAL_PERIOD_STEP
    latest_payload = None
    if latest:
        key = manual_period_key(int(latest[0]), tail)
        latest_payload = {'period': key, 'issue': _issue_no(key), 'block': int(latest[0]),
                          'single': int(latest[1]) if latest[1] is not None else None,
                          'numbers': latest[2], 'observedAt': _iso(latest[3]), 'source': latest[4]}
    return {'tail': tail, 'selected': tail == selected_tail(), 'latest': latest_payload,
            'nextBlock': next_block,
            'nextPeriod': manual_period_key(next_block, tail) if next_block is not None else None,
            'nextIssue': _issue_no(manual_period_key(next_block, tail)) if next_block is not None else None,
            'chainHead': head,
            'fastLive': get_meta('manual_tail_fast_live') or {},
            'serverEpochMs': int(_now().timestamp()*1000),
            'displayOffsetSeconds': -3,
            'drawDataPriority': True, 'readSource': 'manual-tail-fast-live'}


def history(tail, page=1, page_size=100):
    tail = int(tail); page = max(1, int(page)); page_size = max(1, min(100, int(page_size)))
    with DB() as conn:
        q = conn.cursor()
        q.execute(_source_cte() + 'SELECT COUNT(*) FROM manual_source', _source_params(tail))
        total = int(q.fetchone()[0] or 0)
        pages = max(1, (total + page_size - 1) // page_size); page = min(page, pages)
        q.execute(_source_cte() + '''SELECT block_number,single_count,numbers,block_time,source
                     FROM manual_source ORDER BY block_number DESC
                     LIMIT %s OFFSET %s''', _source_params(tail) + (page_size, (page - 1) * page_size))
        data = q.fetchall(); q.close()
    result_rows = []
    for n, single, nums, block_time, src in data:
        key = manual_period_key(int(n), tail)
        result_rows.append({'period': key, 'issue': _issue_no(key), 'block': int(n),
                            'single': single, 'numbers': nums,
                            'blockTime': block_time.isoformat() if block_time else None, 'source': src})
    return {'tail': tail, 'page': page, 'pages': pages, 'total': total, 'pageSize': page_size,
            'periodStepBlocks': MANUAL_PERIOD_STEP, 'anchorBlock': manual_anchor_block(tail),
            'rows': result_rows}
