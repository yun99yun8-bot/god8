import os
import sys
import unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from core import from_index, pindex
from history_simulation import simulate
from live_replay import forecast_due, target_for_latest
from research_lab import analyze
from omission_extras import daily_overdue, overdue_page, chase_comparison, recommend_recent


def draws(labels, day='2026-09-28'):
    start=pindex(day, 1)
    return [(f'{ds}:{no:04d}', label, [1,2,3,4,5,6,7] if label is not None else None)
            for i,label in enumerate(labels) for ds,no in [from_index(start+i)]]


class HistoricalReplayTests(unittest.TestCase):
    def test_walk_forward_does_not_read_target_or_future(self):
        prefix=[3,4,3,4,3,4,6,3,4,3,4,6]
        before=simulate(draws(prefix),minimum_training=1)
        after=simulate(draws(prefix+[7]),minimum_training=1)
        self.assertEqual(after['recent'][0]['predictions'],before['preview']['predictions'])
        self.assertEqual(after['recent'][0]['match'],before['preview']['match'])
        for row in after['recent']:
            for examples in row['match']['sources'].values():
                self.assertTrue(all(x['issue']<row['issue'] for x in examples))

    def test_gap_or_invalid_cannot_create_fake_sequence(self):
        data=draws([3,4,3,4,None,3,4,7])
        original=simulate(data,minimum_training=1)
        self.assertEqual(original['invalid'],1)
        last=original['recent'][0]
        self.assertEqual(last['match']['length'],0)
        data=draws([3,4,3,4,3,4,7])
        data.pop(4)
        result=simulate(data,minimum_training=1)
        self.assertEqual(result['stored'],6)
        self.assertEqual(result['recent'][0]['match']['length'],0)

    def test_empty_and_small_samples_have_no_false_percent(self):
        self.assertEqual(simulate([],minimum_training=2)['either']['rate'],None)
        self.assertEqual(simulate(draws([3,4]),minimum_training=2)['evaluated'],0)

    def test_two_historical_matches_do_not_become_strong_sequence(self):
        labels=[3,4,3,4,3,4,3,4,3,4,6]
        report=simulate(draws(labels),minimum_training=1)
        self.assertEqual(report['preview']['match']['length'],0)
        self.assertEqual(report['recent200']['verified'],report['evaluated'])
        self.assertIsNotNone(report['recent200']['baselineEitherRate'])


class DailyOverdueTests(unittest.TestCase):
    def test_one_episode_on_crossing_then_reset_and_new_episode(self):
        # 单3阈值7：先遗漏8期，再出现一次，再遗漏8期。
        data=draws([3]+[4]*8+[3]+[5]*8)
        subset=[(key,value) for key,value,_ in data]
        report=daily_overdue(subset)
        item=report['items'][3]
        self.assertEqual(item['count'],2)
        self.assertTrue(item['events'][0]['active'])
        self.assertEqual(item['events'][0]['peakGap'],8)
        self.assertEqual(item['events'][1]['endedBy'],'2026-09-28:0010')
        page=overdue_page(subset,3,1,1)
        self.assertEqual((page['totalPages'],len(page['events'])),(2,1))

    def test_invalids_are_neither_hits_nor_extra_omissions(self):
        data=draws([3]+[4]*7+[None,4])
        report=daily_overdue([(k,v) for k,v,_ in data])
        self.assertEqual(report['items'][3]['count'],1)
        self.assertEqual(report['items'][3]['currentGap'],8)

    def test_recommendation_never_claims_certain_chase(self):
        report=chase_comparison([(k,v) for k,v,_ in draws([3,4,5]*20)])
        self.assertEqual(len(report['items']),8)
        self.assertIn('暂不追',report['items'][0]['status'])

    def test_recent200_is_exact_window_and_returns_two_evidenced_labels(self):
        data=draws([0]+[3,4]*100)
        result=recommend_recent([(k,v) for k,v,_ in data])
        self.assertEqual((result['firstIssue'],result['valid']),('2026-09-28:0002',200))
        self.assertEqual([x['single'] for x in result['candidates']],[4,3])
        self.assertEqual(result['items'][0]['hits'],0)
        self.assertFalse(result['items'][0]['eligible'])
        self.assertTrue(all(x['overdueCount']==0 for x in result['candidates']))

    def test_recent_screen_counts_episode_once_and_rejects_incomplete(self):
        data=draws([3]+[4]*8+[3]+[5]*8+[3])
        pairs=[(k,v) for k,v,_ in data]
        report=recommend_recent(pairs,window=len(pairs),min_occurrences=2)
        self.assertEqual(report['items'][3]['overdueCount'],2)
        self.assertEqual(report['items'][3]['currentGap'],0)
        short=recommend_recent(pairs,window=200,min_occurrences=2)
        self.assertFalse(short['complete'])
        self.assertEqual(short['candidates'],[])

    def test_recent_screen_stops_for_gap_invalid_and_mapping(self):
        continuous=[(k,v) for k,v,_ in draws([3,4]*100)]
        gap=continuous[:50]+continuous[51:]+[(draws([3],day='2026-09-29')[0][0],3)]
        self.assertFalse(recommend_recent(gap)['complete'])
        self.assertGreater(recommend_recent(gap)['missing'],0)
        invalid=continuous.copy();invalid[50]=(invalid[50][0],None)
        self.assertEqual(recommend_recent(invalid)['status'],'含无效开奖')
        self.assertEqual(recommend_recent(invalid)['candidates'],[])
        blocked=recommend_recent(continuous,mapping_valid=False)
        self.assertEqual(blocked['status'],'校准未完成')
        self.assertEqual(blocked['candidates'],[])
        stale=recommend_recent(continuous,latest_age=3)
        self.assertEqual(stale['status'],'最近开奖延迟，等待同步')
        self.assertEqual(stale['candidates'],[])

    def test_web_endpoint_and_home_show_recent200_independently(self):
        from web import app, APP_VERSION
        records=[(key,value) for key,value,_ in draws([3,4]*100)]
        with patch('web.rows',return_value=list(reversed(records))) as query, patch('web.datetime') as clock:
            clock.now.return_value=datetime(2026,9,28,3,20,tzinfo=timezone(timedelta(hours=8)))
            response=app.test_client().get('/api/omission/recommend200')
        self.assertEqual(response.status_code,200)
        self.assertIn('LIMIT 200',query.call_args.args[0])
        self.assertEqual(len(response.get_json()['candidates']),2)
        self.assertIn('omissionRows',app.test_client().get('/statistics').get_data(as_text=True))
        self.assertIn('checkRecent200',app.test_client().get('/checks').get_data(as_text=True))
        self.assertIn('v2.0.24',APP_VERSION)

    def test_web_screen_blocks_wrong_target_block(self):
        from web import app
        records=[(key,value,1) for key,value,_ in draws([3,4]*100)]
        with patch('web.rows',return_value=list(reversed(records))):
            report=app.test_client().get('/api/omission/recommend200').get_json()
        self.assertEqual(report['status'],'校准未完成')
        self.assertEqual(report['candidates'],[])

    def test_adaptive_research_uses_only_prior_outcomes(self):
        labels=[3,4,3,4,5,3,4,3,4,5]*25
        prefix=analyze(draws(labels),minimum_training=5)
        extended=analyze(draws(labels+[6]),minimum_training=5)
        next_row=extended['recent'][0]
        self.assertEqual(next_row['predictions'],prefix['preview']['predictions'])
        self.assertEqual(next_row['aiPrediction'],prefix['preview']['aiPrediction'])
        self.assertEqual(next_row['aiMethod'],prefix['preview']['aiMethod'])
        self.assertEqual(next_row['methods'],prefix['preview']['methodPredictions'])
        self.assertGreater(len(prefix['methods']),2)

    def test_replay_has_its_own_page(self):
        from web import app
        client=app.test_client()
        self.assertIn('replayWindow',client.get('/replay').get_data(as_text=True))
        self.assertNotIn('replayWindow',client.get('/playbook').get_data(as_text=True))
        self.assertIn('liveReplayChoices',client.get('/').get_data(as_text=True))

    def test_live_replay_locks_immediately_after_previous_result_and_before_next_block(self):
        now=datetime(2026,9,28,10,28,28,tzinfo=timezone.utc)  # Beijing 18:28
        next_issue,next_block=target_for_latest('2026-09-28:1108')
        self.assertEqual(next_issue,'2026-09-28:1109')
        self.assertTrue(forecast_due(now,'2026-09-28:1108',now-timedelta(seconds=1),next_block,next_block-1))
        self.assertTrue(forecast_due(now,'2026-09-28:1108',now,next_block,next_block-1))
        self.assertTrue(forecast_due(now,'2026-09-28:1108',now-timedelta(seconds=20),next_block,next_block-1))
        self.assertFalse(forecast_due(now,'2026-09-28:1108',now-timedelta(seconds=20),next_block,next_block))
        self.assertFalse(forecast_due(now,'2026-09-28:1108',now-timedelta(seconds=20),next_block,None))
        self.assertFalse(forecast_due(now,'2026-09-28:1108',now+timedelta(seconds=1),next_block,next_block-1))
        self.assertFalse(forecast_due(now,'2026-09-27:1108',now-timedelta(seconds=20),next_block,next_block-1))
        self.assertEqual(target_for_latest('2026-09-28:1440')[0],'2026-09-29:0001')

    def test_live_replay_api_keeps_two_fixed_choices_when_result_arrives(self):
        from web import app
        now=datetime.now(timezone.utc)
        answers=[ [('2026-09-28:1109',4,now)],
                  [('2026-09-28:1109','2026-09-28:1108',[3,4],{'length':2},now-timedelta(seconds=40),4,now)],
                  [(10,3,2,5)] ]
        with patch('web.rows',side_effect=answers):
            result=app.test_client().get('/api/replay/live').get_json()
        self.assertEqual(result['forecast']['choices'],[3,4])
        self.assertFalse(result['forecast']['firstHit'])
        self.assertTrue(result['forecast']['secondHit'])
        self.assertEqual(result['stats']['eitherRate'],.5)

    def test_home_keeps_settled_forecast_for_ten_seconds_before_next(self):
        from web import app
        now=datetime.now(timezone.utc)
        old=('2026-09-29:0992','2026-09-29:0991',[3,4],{},
             now-timedelta(seconds=50),4,now-timedelta(seconds=2))
        new=('2026-09-29:0993','2026-09-29:0992',[1,6],{},
             now-timedelta(seconds=1),None,None)
        for age,expected in ((3,'2609290992'),(11,'2609290993')):
            answers=[[('2026-09-29:0992',4,now-timedelta(seconds=age))],
                     [new,old],[(10,3,2,5)]]
            with self.subTest(age=age),patch('web.rows',side_effect=answers):
                result=app.test_client().get('/api/replay/live').get_json()
                self.assertEqual(result['forecast']['issue'],expected)
                self.assertEqual(result['forecast']['choices'],[3,4] if age==3 else [1,6])
                self.assertEqual(result['resultHoldSeconds']>0,age==3)


if __name__=='__main__':unittest.main()
