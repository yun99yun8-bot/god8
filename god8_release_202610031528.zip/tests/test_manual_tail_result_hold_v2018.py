from datetime import datetime, timedelta, timezone
from pathlib import Path

import manual_tail_center as mt

ROOT = Path(__file__).resolve().parents[1]


class FakeQ:
    def __init__(self, judged=None, current=None):
        self.judged = judged
        self.current = current
        self.last = None
        self.calls = []

    def execute(self, sql, params=None):
        self.calls.append((sql, params))
        if 'actual IS NOT NULL AND settled_at IS NOT NULL' in sql:
            self.last = 'judged'
        else:
            self.last = 'current'

    def fetchone(self):
        return self.judged if self.last == 'judged' else self.current


def row(source, actual, settled_at):
    created = settled_at - timedelta(seconds=30)
    return (source, 2, 5, {'match': {}}, created, actual, settled_at)


def pending(source, created_at):
    return (source, 1, 6, {'match': {}}, created_at, None, None)


def test_exact_current_issue_result_has_priority_for_full_ten_seconds(monkeypatch):
    now = datetime(2026, 10, 3, 7, 30, 0, tzinfo=timezone.utc)
    monkeypatch.setattr(mt, '_now', lambda: now)
    latest = 86775289
    judged = row(latest - 20, 2, now - timedelta(seconds=5))
    # Even if the next prediction already exists, current issue result wins.
    q = FakeQ(judged=judged, current=pending(latest, now - timedelta(seconds=1)))
    phase, forecast = mt._forecast_view(q, 9, latest, now - timedelta(seconds=1),
                                        {'accepted': True})
    assert phase == 'result'
    assert forecast['targetBlock'] == latest
    assert forecast['targetIssue'] == '2610030695'
    assert forecast['actual'] == 2
    assert 4.9 <= forecast['resultHoldSeconds'] <= 5.1
    assert len(q.calls) == 1  # next forecast must not be consulted during hold


def test_after_ten_seconds_current_issue_cards_are_removed_for_analysis(monkeypatch):
    now = datetime(2026, 10, 3, 7, 30, 0, tzinfo=timezone.utc)
    monkeypatch.setattr(mt, '_now', lambda: now)
    latest = 86775289
    judged = row(latest - 20, 2, now - timedelta(seconds=11))
    q = FakeQ(judged=judged, current=pending(latest, now - timedelta(seconds=1)))
    phase, forecast = mt._forecast_view(q, 9, latest, now - timedelta(seconds=1),
                                        {'accepted': True})
    assert phase == 'analyzing'
    assert forecast is None
    assert len(q.calls) == 1  # pending next issue cannot appear during 10-20s analysis


def test_after_twenty_seconds_next_issue_forecast_may_display(monkeypatch):
    now = datetime(2026, 10, 3, 7, 30, 0, tzinfo=timezone.utc)
    monkeypatch.setattr(mt, '_now', lambda: now)
    latest = 86775289
    judged = row(latest - 20, 2, now - timedelta(seconds=21))
    q = FakeQ(judged=judged, current=pending(latest, now - timedelta(seconds=1)))
    phase, forecast = mt._forecast_view(q, 9, latest, now - timedelta(seconds=1),
                                        {'accepted': True})
    assert phase == 'forecast'
    assert forecast['sourceBlock'] == latest
    assert forecast['targetBlock'] == latest + 20
    assert forecast['targetIssue'] == '2610030696'


def test_frontend_clears_result_cards_at_hold_expiry_and_does_not_show_hold_notice():
    js = (ROOT / 'static' / 'app.js').read_text(encoding='utf8')
    assert 'manualResultClearTimer=setTimeout' in js
    assert "state.hidden=true;state.classList.remove('analyzing')" in js
    assert "state.textContent='正在分析中'" in js
    assert '开奖结果已核对 · 保留10秒' not in js
    assert "setInterval(()=>refreshManualTailSnapshot(false),1500);" in js
