import json
import os
import shutil
import subprocess
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))


@unittest.skipUnless(shutil.which('node'), 'Node.js unavailable')
class SpriteModeTests(unittest.TestCase):
    def test_switch_persists_across_refresh_and_controls_home(self):
        code=r'''
const fs=require('fs'),vm=require('vm');
const source=fs.readFileSync('static/app.js','utf8').split('const CHASE_KEY=')[0];
const values=new Map();const storage={getItem:k=>values.get(k)??null,setItem:(k,v)=>values.set(k,v)};
function session(){const nodes={homeReplayIdle:{hidden:false},homeReplayActive:{hidden:true},
liveReplayChoices:{replaceChildren(){this.cleared=(this.cleared||0)+1}},liveReplay:{textContent:''}};
const sandbox={localStorage:storage,document:{cookie:'',getElementById:id=>nodes[id]}};
vm.runInNewContext(source+'\nthis.api={read:readSpritePredictionMode,apply:applySpritePredictionMode,enabled:()=>spritePredictEnabled};',sandbox);
sandbox.api.apply(sandbox.api.read());return {sandbox,nodes}}
let first=session();first.sandbox.api.apply(true,true);
let refreshed=session();let started=[refreshed.sandbox.api.enabled(),refreshed.nodes.homeReplayIdle.hidden,refreshed.nodes.homeReplayActive.hidden];
refreshed.sandbox.api.apply(false,true);
let stopped=session();
process.stdout.write(JSON.stringify({started,stopped:[stopped.sandbox.api.enabled(),stopped.nodes.homeReplayIdle.hidden,stopped.nodes.homeReplayActive.hidden],stored:values.get('god8-sprite-predict-switch-v1')}));
'''
        output=subprocess.check_output(['node','-e',code],cwd=ROOT,text=True)
        self.assertEqual(json.loads(output),{'started':[True,True,False],
                                            'stopped':[False,False,True],'stored':'off'})

    def test_old_replay_response_cannot_restore_cards_after_stop(self):
        code=r'''
const fs=require('fs'),vm=require('vm');
const source=fs.readFileSync('static/app.js','utf8').split('syncClock().then(tickClock)')[0];
const nodes={homeReplayIdle:{hidden:false},homeReplayActive:{hidden:true},
liveReplayChoices:{replaceChildren(){this.count=(this.count||0)+1}},
liveReplay:{textContent:''},liveReplayStats:{textContent:''}};
let resolve,queries=0;const pending=new Promise(r=>resolve=r);
const sandbox={document:{hidden:false,getElementById:id=>nodes[id]},
  fetch:()=>{queries++;return pending},window:{},localStorage:{setItem(){}}};
vm.runInNewContext(source+'\nthis.api={apply:applySpritePredictionMode,refresh:refreshLiveReplay};',sandbox);
(async()=>{sandbox.api.apply(true);const old=sandbox.api.refresh();sandbox.api.apply(false);
resolve({ok:true,json:async()=>({forecast:{choices:[1,6]},stats:{verified:1}})});await old;
process.stdout.write(JSON.stringify({queries,hidden:nodes.homeReplayActive.hidden,clear:nodes.liveReplayChoices.count,contents:nodes.liveReplay.textContent}));})();
'''
        output=subprocess.check_output(['node','-e',code],cwd=ROOT,text=True)
        self.assertEqual(json.loads(output),{'queries':1,'hidden':True,'clear':1,'contents':'正在核对历史记录'})

    def test_home_prediction_is_covered_until_start_and_cleared_on_stop(self):
        code = r'''
const fs=require('fs'),vm=require('vm');
const source=fs.readFileSync('static/app.js','utf8').split('syncClock().then(tickClock)')[0];
const nodes={homeReplayIdle:{hidden:false},homeReplayActive:{hidden:true},
 liveReplayChoices:{replaceChildren(){this.cleared=(this.cleared||0)+1}},liveReplay:{textContent:''}};
const sandbox={document:{getElementById:id=>nodes[id]},window:{}};
vm.runInNewContext(source+'\nthis.toggle=setHomePredictionMode;',sandbox);
sandbox.toggle(true);const started=[nodes.homeReplayIdle.hidden,nodes.homeReplayActive.hidden];
sandbox.toggle(false);const stopped=[nodes.homeReplayIdle.hidden,nodes.homeReplayActive.hidden,nodes.liveReplayChoices.cleared];
process.stdout.write(JSON.stringify({started,stopped}));
'''
        output=subprocess.check_output(['node','-e',code],cwd=ROOT,text=True)
        self.assertEqual(json.loads(output),{'started':[True,False],'stopped':[False,True,1]})

    def test_high_frequency_alert_is_manual_close(self):
        with open(os.path.join(ROOT,'static/app.js'),encoding='utf8') as source:
            script=source.read()
        forecast=script.split('function showForecastToast(){',1)[1].split('const eventKey=',1)[0]
        self.assertIn('spriteForecastToastClose',forecast)
        self.assertNotIn('setTimeout(',forecast)

    def test_stop_removes_forecast_but_keeps_observed_practice(self):
        code = r'''
const fs=require('fs'),vm=require('vm');
const source=fs.readFileSync('static/app.js','utf8').split('syncClock().then(tickClock)')[0];
const sandbox={};vm.runInNewContext(source+'\nthis.view=spriteMemoryView;',sandbox);
const report={status:'replay',highFrequency:true,notice:'历史相似片段提示单1/单6高发期',
  practice:{highFrequencyEpisodes:27,preceded07InFour:5},
  replay:{length:4,matchedPositions:4,samples:12,highFrequencyCases:7}};
const views=[sandbox.view(report,false),sandbox.view(report,true),sandbox.view(report,false)];
process.stdout.write(JSON.stringify(views));
'''
        output = subprocess.check_output(['node', '-e', code], cwd=ROOT, text=True)
        idle, started, stopped = json.loads(output)
        self.assertEqual(idle, stopped)
        self.assertEqual(idle['reason'], '')
        self.assertIn('27 段', idle['message'])
        self.assertNotIn('高发期', idle['message'])
        self.assertNotIn('7/12', idle['message'])
        self.assertIn('7/12', started['message'])
        self.assertIn('高发期', started['reason'])

    def test_template_cache_buster_advances_with_release(self):
        with open(os.path.join(ROOT, 'templates/base.html'), encoding='utf8') as source:
            html = source.read()
        self.assertIn('/static/app.js?v=2.0.33', html)
        self.assertIn('/static/app.css?v=2.0.33', html)


if __name__ == '__main__':
    unittest.main()
