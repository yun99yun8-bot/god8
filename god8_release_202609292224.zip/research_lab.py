"""Walk-forward comparison of independent sequence and frequency methods.

The adaptive selector uses only predictions already scored before the target row.
It is a deterministic statistical model, not an external language-model service.
"""
from collections import Counter, defaultdict, deque

from history_simulation import _chronological, _valid
from omission_research import issue

METHODS = ('seq4', 'seq3', 'seq2', 'transition', 'recent30', 'recent100', 'frequency')
LABELS = {'seq4':'四期序列复现', 'seq3':'三期序列复现',
          'seq2':'两期序列复现', 'transition':'上一期条件转移',
          'recent30':'近30期分布', 'recent100':'近100期分布',
          'frequency':'已知全期频数'}


def _rank(counts):
    return sorted(range(8), key=lambda k: (-counts[k], k))


def analyze(rows, minimum_training=100, recent_limit=25):
    patterns = {k: defaultdict(Counter) for k in (1, 2, 3, 4)}
    long_counts, recent, sequence = Counter(), deque(maxlen=100), []
    performance = {name: deque(maxlen=200) for name in METHODS}
    total = Counter()
    method_totals = Counter()
    method_hits = Counter()
    examples = deque(maxlen=recent_limit)
    switches = deque(maxlen=12)
    previous_method = None
    previous = newest = None
    ready = 0

    def proposal():
        candidates = {}
        for length in (4, 3, 2, 1):
            if len(sequence) < length:
                continue
            key = tuple(sequence[-length:])
            found = patterns[length].get(key, Counter())
            if sum(found.values()) >= max(8, length * 3):
                name = 'transition' if length == 1 else f'seq{length}'
                candidates[name] = (found, sum(found.values()))
        if len(recent) >= 30:
            candidates['recent30'] = (Counter(list(recent)[-30:]), 30)
        if len(recent) >= 100:
            candidates['recent100'] = (Counter(recent), 100)
        if long_counts:
            candidates['frequency'] = (long_counts, sum(long_counts.values()))
        return candidates

    def choose():
        available = proposal()
        if not available:
            return None
        # Laplace smoothing and a fixed uniform prior prevent short lucky streaks
        # from immediately replacing a method with a longer track record.
        weights = {}
        for name in available:
            values = performance[name]
            weights[name] = (sum(values) + 2) / (len(values) + 16)
        selected = max(available, key=lambda name: (weights[name], len(performance[name]), -METHODS.index(name)))
        votes = Counter()
        prior_total=sum(long_counts.values())
        for name, (counts, support) in available.items():
            for single in range(8):
                prior=long_counts[single]/prior_total if prior_total else 1/8
                votes[single] += weights[name] * (counts[single]+16*prior)/(support+16)
        picks = sorted(range(8), key=lambda k: (-votes[k], -long_counts[k], k))[:2]
        return {'predictions':picks, 'aiPrediction':_rank(available[selected][0])[0],
                'aiMethod':selected,'methodPredictions':{name:_rank(item[0])[0] for name,item in available.items()},
                'methodSupport':{name:item[1] for name,item in available.items()},
                'weights':{name:round(weights[name],4) for name in available}}

    for at,key,actual,numbers in _chronological(rows):
        if previous is not None and at != previous+1:
            sequence = []
        previous = at
        if not _valid(actual):
            sequence = []
            continue
        choice = choose() if ready >= minimum_training and sequence else None
        if choice:
            first,second = choice['predictions']
            if previous_method and previous_method != choice['aiMethod']:
                switches.append({'issue':issue(at),'from':previous_method,
                                 'to':choice['aiMethod']})
            previous_method = choice['aiMethod']
            total['evaluated'] += 1
            total['first'] += actual == first
            total['second'] += actual == second
            total['either'] += actual in (first,second)
            total['ai'] += actual == choice['aiPrediction']
            for name,guess in choice['methodPredictions'].items():
                success = int(guess == actual)
                performance[name].append(success)
                method_totals[name] += 1
                method_hits[name] += success
            examples.append({'issue':issue(at),'predictions':[first,second],
                             'aiPrediction':choice['aiPrediction'], 'aiMethod':choice['aiMethod'],
                             'actual':actual,'firstHit':first==actual,'secondHit':second==actual,
                             'aiHit':choice['aiPrediction']==actual,
                             'methods':choice['methodPredictions']})
        # Register this result after every prediction has been scored.
        for length in (1,2,3,4):
            if len(sequence)>=length:
                patterns[length][tuple(sequence[-length:])][actual] += 1
        long_counts[actual] += 1
        recent.append(actual)
        sequence = (sequence + [actual])[-4:]
        ready += 1
        newest = at
    preview = choose() if newest is not None and ready>=minimum_training and sequence else None
    insight = None
    if preview:
        selected = preview['aiMethod']
        recent_hits = performance[selected]
        insight = {'selectedMethod':selected,'name':LABELS[selected],
                   'recentVerified':len(recent_hits),'recentHits':sum(recent_hits),
                   'recentRate':sum(recent_hits)/len(recent_hits) if recent_hits else None,
                   'selectionWeight':preview['weights'][selected],
                   'switches':list(reversed(switches)),
                   'reason':'采用此前逐期历史核对中的近200次记录，经平滑后比较当前可用方法；每一期重新评估。'}
        preview = {'issue':issue(newest+1), **preview}
    n = total['evaluated']
    return {'stored':len(rows), 'valid':ready, 'evaluated':n,
            'first':{'hits':total['first'],'rate':total['first']/n if n else None},
            'second':{'hits':total['second'],'rate':total['second']/n if n else None},
            'either':{'hits':total['either'],'rate':total['either']/n if n else None},
            'ai':{'hits':total['ai'],'rate':total['ai']/n if n else None},
            'methods':[{'key':name,'name':LABELS[name],'evaluated':method_totals[name],
                        'hits':method_hits[name], 'rate':method_hits[name]/method_totals[name]
                        if method_totals[name] else None} for name in METHODS],
            'preview':preview, 'insight':insight,'recent':list(reversed(examples)),
            'note':'滚动复盘只使用目标期以前的数据；序列至少复现8–12次，并与总体分布平滑；自动换法按此前200次可验证成绩调整。历史命中率不代表下一期概率，也不保证命中。'}
