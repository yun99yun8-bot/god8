import inspect
from pathlib import Path

import manual_tail_center as mt
from core import ANCHOR_INDEX

ROOT = Path(__file__).resolve().parents[1]


def test_all_tails_use_one_issue_every_twenty_blocks():
    for tail in range(10):
        anchor = mt.manual_anchor_block(tail)
        assert anchor % 10 == tail
        assert mt.manual_period_index(anchor, tail) == ANCHOR_INDEX
        assert mt.manual_period_index(anchor + 20, tail) == ANCHOR_INDEX + 1
        assert mt.manual_period_index(anchor + 10, tail) is None
        assert mt.manual_period_key(anchor, tail) == '2026-09-24:0481'


def test_manual_source_filters_second_same_tail_block_out():
    cte = mt._source_cte()
    assert 'MOD(block_number - %s, 20)=0' in cte
    for tail in range(10):
        anchor = mt.manual_anchor_block(tail)
        assert (anchor - anchor) % 20 == 0
        assert (anchor + 10 - anchor) % 20 == 10
        assert (anchor + 20 - anchor) % 20 == 0


def test_omission_is_based_on_valid_issue_sequence_not_raw_tail_blocks():
    source = inspect.getsource(mt.report)
    assert 'ROW_NUMBER() OVER(ORDER BY block_number)' in source
    assert 'single_count BETWEEN 0 AND 7' in source
    assert 's.total-COALESCE(v.last_rn,0)' in source
    # Formula example: [1,2,1,3] => current gaps 1:1, 2:2, 3:0, unseen:4.
    seq = [1, 2, 1, 3]
    total = len(seq)
    last = {s: max((i for i, x in enumerate(seq, 1) if x == s), default=0) for s in range(8)}
    gaps = {s: total - last[s] for s in range(8)}
    assert gaps[1] == 1
    assert gaps[2] == 2
    assert gaps[3] == 0
    assert gaps[0] == 4


def test_prediction_settlement_uses_twenty_block_schedule():
    source = inspect.getsource(mt.settle_predictions)
    assert 'MOD(m.block_number-(86511900+p.tail),20)=0' in source
    assert 'MOD(r.block_number-(86511900+p.tail),20)=0' in source
    assert 'MOD(p.source_block-(86511900+p.tail),20)=0' in source


def test_manual_history_returns_real_issue_numbers():
    source = inspect.getsource(mt.history)
    assert "'issue': _issue_no(key)" in source
    js = (ROOT / 'static/app.js').read_text(encoding='utf8')
    assert 'row.issue||row.period' in js
    html = (ROOT / 'templates/manual_tail.html').read_text(encoding='utf8')
    assert '最近100期同尾结果' in html


def test_old_ten_block_predictions_are_not_reused():
    source = inspect.getsource(mt.prediction_step) + inspect.getsource(mt._forecast_view) + inspect.getsource(mt.settle_predictions)
    assert "engineVersion'='manual-period-v2'" in source
    assert "COALESCE(manual_tail_predictions.evidence->>'engineVersion','')<>'manual-period-v2'" in inspect.getsource(mt.prediction_step)
