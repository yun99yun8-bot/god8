"""The live result must reuse stored chain data and repair genuine gaps."""
import os
import sys
import unittest
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import collector_service as collector


class LivePeriodTest(unittest.TestCase):
    def run_period(self, saved_results):
        stamp = datetime.now(timezone.utc)
        connection = MagicMock()
        connection.__enter__.return_value = connection
        connection.cursor.return_value.fetchone.return_value = (stamp,)
        with patch.object(collector, 'save_period', side_effect=saved_results) as save, \
             patch.object(collector, 'fetch_block_range', return_value={1: {'number': 1}}) as fetch, \
             patch.object(collector, 'save_blocks_batch') as batch, \
             patch.object(collector, 'set_meta') as meta, \
             patch.object(collector, 'DB', return_value=connection):
            result = collector.build_live_period('2026-09-27', 10)
        return result, save, fetch, batch, meta

    def test_complete_cached_period_avoids_remote_range(self):
        result, save, fetch, batch, meta = self.run_period([(True, [])])
        self.assertTrue(result)
        self.assertEqual(save.call_count, 1)
        fetch.assert_not_called()
        batch.assert_not_called()
        self.assertEqual(meta.call_args.args[1]['source'], 'cached-blocks')

    def test_missing_block_repairs_then_saves(self):
        result, save, fetch, batch, meta = self.run_period([(False, [42]), (True, [])])
        self.assertTrue(result)
        self.assertEqual(save.call_count, 2)
        self.assertEqual(fetch.call_count, 1)
        batch.assert_called_once()
        self.assertEqual(meta.call_args.args[1]['source'], 'range-repair')

    def test_live_api_never_promotes_unlabeled_result(self):
        from web import app
        connection = MagicMock()
        connection.__enter__.return_value = connection
        connection.cursor.return_value.fetchone.side_effect = [
            ('2026-09-27:0011', None, 86500020, None, datetime.now(timezone.utc)),
            ('2026-09-27:0010', 3, 86500000, [1, 2, 3, 4, 5, 6, 7], datetime.now(timezone.utc)),
            None]
        with patch('web.DB', return_value=connection), patch('web.get_meta', return_value={}):
            response = app.test_client().get('/api/live')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()['latest']['issue'], '2609270010')
        self.assertIsNone(response.get_json()['newest']['single'])
        self.assertEqual(response.headers['Cache-Control'], 'no-store, max-age=0')

    def test_target_hash_is_visible_before_twenty_groups_finish(self):
        from web import app
        stamp=datetime.now(timezone.utc)
        connection=MagicMock()
        connection.__enter__.return_value=connection
        connection.cursor.return_value.fetchone.side_effect=[
            ('2026-09-29:0990',3,86666044,[1,2,3,4,5,6,7],stamp),
            ('2026-09-29:0990',3,86666044,[1,2,3,4,5,6,7],stamp),
            ([1,3,5,7,9,11,12],6,stamp,stamp)]
        with patch('web.DB',return_value=connection), \
             patch('web.get_meta',side_effect=lambda k,default=None: {'block':86666063} if k=='chain_head' else {}):
            live=app.test_client().get('/api/live').get_json()
        self.assertEqual(live['latest']['issue'],'2609290991')
        self.assertEqual(live['latest']['block'],86666063)
        self.assertTrue(live['latest']['provisional'])
        self.assertEqual(live['nextTargetBlock'],86666082)

    def test_existing_pending_period_promotes_its_raw_target_immediately(self):
        from web import app
        from core import target_block
        block=target_block('2026-09-29',991)
        stamp=datetime.now(timezone.utc)
        connection=MagicMock()
        connection.__enter__.return_value=connection
        connection.cursor.return_value.fetchone.side_effect=[
            ('2026-09-29:0991',None,block,None,stamp),
            ('2026-09-29:0990',3,block-20,[1,2,3,4,5,6,7],stamp),
            ([1,3,5,7,9,11,12],6,stamp,stamp)]
        with patch('web.DB',return_value=connection), \
             patch('web.get_meta',side_effect=lambda k,default=None: {'block':block} if k=='chain_head' else {}):
            live=app.test_client().get('/api/live').get_json()
        self.assertEqual(live['latest']['issue'],'2609290991')
        self.assertEqual(live['latest']['single'],6)
        self.assertTrue(live['latest']['provisional'])

    def test_skipped_target_is_saved_before_group_repair(self):
        connection=MagicMock()
        connection.__enter__.return_value=connection
        connection.cursor.return_value.fetchone.return_value=None
        block={'number':42,'hash':'a'*64,'timestamp':0}
        with patch.object(collector,'DB',return_value=connection), \
             patch.object(collector,'target_block',return_value=42), \
             patch.object(collector,'fetch_block',return_value=block) as fetch, \
             patch.object(collector,'save_block') as save:
            self.assertTrue(collector.capture_target_first('2026-09-29',991))
        fetch.assert_called_once_with(42)
        save.assert_called_once_with(block)

    def test_clock_uses_three_second_display_offset(self):
        from web import app
        clock=app.test_client().get('/api/clock').get_json()
        self.assertEqual(clock['displayOffsetSeconds'],-3)


if __name__ == '__main__':
    unittest.main()
