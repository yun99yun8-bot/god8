# God8 v2.0.44 完整部署包

版本：`god8-v2.0.44-home-canonical-history`

本版修复首页历史记录仍读取旧2尾数据的问题。首页最近100期逐期按规范 target_block() 读取真实 raw_blocks：当前原2尾阶段临时使用3尾，2026-10-01 第0121期起恢复0尾。历史上原本3尾的数据不做批量重写。

同时把静态 app.js/app.css 缓存版本更新为 v2.0.44，避免手机继续使用旧前端。

部署后 `/health` 的 `version` 与 `collectorVersion` 应显示 `god8-v2.0.44-home-canonical-history`。
