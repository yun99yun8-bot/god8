import json
from datetime import datetime, timezone
from core import *

def independent_target(ds,p):
 # Independent expression: 20-block advance with a 2-block correction per crossed 360 boundary.
 delta=pindex(ds,p)-ANCHOR_INDEX
 baseline=ANCHOR_BLOCK + 20*delta - 2*(delta//360)
 date_key=(ds,int(p))
 if date_key>=('2026-09-29',992):
  return baseline-2
 if date_key==('2026-09-29',991):return baseline-1
 return baseline

def independent_numbers(h):
 rev=str(h).upper()[::-1]; L=[];D=[]
 for ch in rev:
  if ch in 'ABCDE': L.append(ch)
  if '0'<=ch<='9': D.append(ch)
 out=[]
 for a,b in zip(L,D):
  x={'A':0,'B':1,'C':2,'D':3,'E':4}[a]*10+int(b)
  if 1<=x<=49 and x not in out: out.append(x)
  if len(out)==7: break
 if len(out)!=7: raise ValueError('7-number failure')
 return out

def run_audit(training_only=True,start_index=None,end_index=None):
 if (start_index is None)!=(end_index is None):raise ValueError('audit boundaries must be paired')
 bounds=None
 if start_index is not None:
  a,b=from_index(start_index),from_index(end_index)
  bounds=(f'{a[0]}:{a[1]:04d}',f'{b[0]}:{b[1]:04d}')
 with DB() as c:
  q=c.cursor(); q.execute("INSERT INTO audit_runs DEFAULT VALUES RETURNING id"); rid=q.fetchone()[0]
  where='WHERE period_key BETWEEN %s AND %s ' if bounds else ('WHERE training_set=TRUE ' if training_only else '')
  q.execute("SELECT period_key,period_date::text,period_no,target_block,block_hash,numbers,single_count FROM periods "+where+"ORDER BY period_date,period_no",bounds or ())
  rows=q.fetchall();q.close()
 errors=[]; checked=0; checked_groups=0; void_periods=0; mapping_mismatch=hash_mismatch=number_mismatch=single_mismatch=group_mismatch=0
 seen=set()
 total=len(rows)
 set_meta('god8_audit_progress',{'status':'running','checked':0,'total':total,
          'stageRange':bounds,'runId':rid,'updatedAt':datetime.now(timezone.utc).isoformat()})
 # A stage contains about 200,000 raw blocks. Query them in 100-period chunks
 # to bound memory and avoid 20,000 individual database round trips.
 for offset in range(0,total,100):
  batch=rows[offset:offset+100]
  first=min(independent_target(r[1],r[2])-19 for r in batch)
  last=max(independent_target(r[1],r[2]) for r in batch)
  keys=[r[0] for r in batch]
  with DB() as c:
   q=c.cursor()
   q.execute('SELECT block_number,block_hash FROM raw_blocks WHERE block_number BETWEEN %s AND %s ORDER BY block_number',(first,last))
   source=dict(q.fetchall())
   q.execute('SELECT period_key,group_no,block_number,block_hash FROM groups WHERE period_key=ANY(%s) ORDER BY period_key,group_no',(keys,))
   saved_groups={key:[] for key in keys}
   for period,group_no,number,block_hash in q.fetchall():
    saved_groups[period].append((group_no,number,block_hash))
   q.close()
  for key,ds,p,tb,h,nums,sc in batch:
   try:
    nums=nums if isinstance(nums,list) else json.loads(nums) if nums is not None else None; exp=independent_target(ds,p); e=[]
    if key in seen: e.append('duplicate period')
    seen.add(key)
    if tb!=exp: mapping_mismatch+=1; e.append(f'target {tb}!={exp}')
    # The one-off 0991 transition ends in 3; all subsequent rounds resume
    # the 360-phase even-tail cycle at the platform-confirmed offset.
    if tb%10 not in TAIL_CYCLE and key!='2026-09-29:0991': e.append('tail outside 86420')
    # Recompute from persisted raw hash, independently of periods/groups; this is
    # internal consistency, not proof that a third-party platform used this block.
    src=[(number,source[number]) for number in range(exp-19,exp+1) if number in source]
    checked_groups += len(src)
    if len(src)!=20 or any(int(src[i][0])!=exp-19+i for i in range(min(len(src),20))):
     group_mismatch+=1; e.append(f'historical source groups invalid n={len(src)}')
    else:
     source_hash=src[-1][1]
     try: rec=independent_numbers(source_hash)
     except ValueError: rec=None; void_periods+=1
     if h!=source_hash: hash_mismatch+=1; e.append('hash mismatch vs persisted raw source')
     if nums!=rec: number_mismatch+=1; e.append('numbers mismatch')
     if sc!=(sum(x%2 for x in rec) if rec is not None else None): single_mismatch+=1; e.append('single mismatch')
     gs=saved_groups[key]
     if len(gs)!=20 or any(int(gs[i][0])!=i+1 or int(gs[i][1])!=int(src[i][0]) or gs[i][2]!=src[i][1] for i in range(min(len(gs),20))):
      group_mismatch+=1; e.append('stored groups mismatch historical source')
    if e: errors.append({'period':key,'errors':e})
    checked+=1
   except Exception as ex: errors.append({'period':key,'errors':[str(ex)]})
  set_meta('god8_audit_progress',{'status':'running','checked':offset+len(batch),
           'total':total,'errorsSoFar':len(errors),'stageRange':bounds,
           'runId':rid,'updatedAt':datetime.now(timezone.utc).isoformat()})
 passed=(checked==TRAIN_N and not errors) if training_only or bounds else not errors
 fp,n=training_fingerprint() if training_only and not bounds else ('',0)
 report={'checkedPeriods':checked,'expectedPeriods':TRAIN_N if training_only or bounds else checked,'checkedGroups':checked_groups,'voidPeriods':void_periods,'validLabeledPeriods':checked-void_periods,
         'errors':len(errors),'mappingMismatches':mapping_mismatch,'hashMismatches':hash_mismatch,
         'numberMismatches':number_mismatch,'singleMismatches':single_mismatch,'groupMismatches':group_mismatch,
         'examples':errors[:50],'fingerprint':fp,'fingerprintCount':n,
         'highStandard360':'20 blocks/period, -2 each original 360-period boundary; persistent -2 platform offset from 2026-09-29:0992 without resetting phase; 0991 is a one-off actual result','pass':passed,'aiTrainingAllowed':passed,
         'stageRange':bounds,
         'limitation':'Internal hash/period consistency only; platform alignment needs confirmed external anchor checks.'}
 with DB() as c:
  q=c.cursor();q.execute('UPDATE audit_runs SET finished_at=NOW(),checked=%s,errors=%s,report=%s::jsonb,pass=%s WHERE id=%s',(checked,len(errors),json.dumps(report),passed,rid))
  if bounds:q.execute('UPDATE periods SET audit_ok=%s WHERE period_key BETWEEN %s AND %s',(passed,*bounds))
  elif training_only:q.execute('UPDATE periods SET audit_ok=%s WHERE training_set=TRUE',(passed,))
  q.close()
 set_meta('audit',report)
 set_meta('god8_audit_progress',{'status':'passed' if passed else 'failed',
          'checked':checked,'total':total,'errors':len(errors),'stageRange':bounds,
          'runId':rid,'updatedAt':datetime.now(timezone.utc).isoformat()})
 return report
