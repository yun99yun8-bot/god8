"""The live result must reuse stored chain data and repair genuine gaps."""
import os
import sys
import unittest
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import collector_service as collector
import live_replay


class LivePeriodTest(unittest.TestCase):
    def test_absent_replay_candidate_is_not_recomputed_every_two_seconds(self):
        key='2026-09-30:0581'
        target=live_replay.target_for_latest(key)[1]
        source=(key,3,collector.target_block('2026-09-30',581),datetime.now(timezone.utc),'a'*64)
        connection=MagicMock()
        connection.__enter__.return_value=connection
        connection.cursor.return_value.fetchone.side_effect=[source,None,source,None]
        connection.cursor.return_value.fetchall.return_value=[(key,3,[])]
        previous=live_replay._last_attempted_source
        live_replay._last_attempted_source=None
        try:
            with patch.object(live_replay,'DB',return_value=connection), \
                 patch.object(live_replay,'get_meta',return_value={'block':target-1}), \
                 patch.object(live_replay,'forecast_due',return_value=True), \
                 patch.object(live_replay,'simulate',return_value={'preview':None}) as simulate:
                live_replay.advance()
                live_replay.advance()
            simulate.assert_called_once()
        finally:
            live_replay._last_attempted_source=previous

    def run_period(self, saved_results):
        stamp = datetime.now(timezone.utc)
        connection = MagicMock()
        connection.__enter__.return_value = connection
        connection.cursor.return_value.fetchone.return_value = (stamp,)
        with patch.object(collector, 'save_period', side_effect=saved_results) as save, \
             patch.object(collector, 'fetch_block_range', return_value={1: {'number': 1}}) as fetch, \
             patch.object(collector, 'save_blocks_batch') as batch, \
             patch.object(collector, 'set_meta') as meta, \
             patch.object(collector, 'DB', return_value=connection):
            result = collector.build_live_period('2026-09-27', 10)
        return result, save, fetch, batch, meta

    def test_complete_cached_period_avoids_remote_range(self):
        result, save, fetch, batch, meta = self.run_period([(True, [])])
        self.assertTrue(result)
        self.assertEqual(save.call_count, 1)
        fetch.assert_not_called()
        batch.assert_not_called()
        self.assertEqual(meta.call_args.args[1]['source'], 'cached-blocks')

    def test_missing_block_repairs_then_saves(self):
        result, save, fetch, batch, meta = self.run_period([(False, [42]), (True, [])])
        self.assertTrue(result)
        self.assertEqual(save.call_count, 2)
        self.assertEqual(fetch.call_count, 1)
        batch.assert_called_once()
        self.assertEqual(meta.call_args.args[1]['source'], 'range-repair')

    def test_live_api_never_promotes_unlabeled_result(self):
        from web import app
        connection = MagicMock()
        connection.__enter__.return_value = connection
        connection.cursor.return_value.fetchone.side_effect = [
            ('2026-09-27:0011', None, 86500020, None, datetime.now(timezone.utc)),
            ('2026-09-27:0010', 3, 86500000, [1, 2, 3, 4, 5, 6, 7], datetime.now(timezone.utc)),
            None]
        with patch('web.DB', return_value=connection), patch('web.get_meta', return_value={}):
            response = app.test_client().get('/api/live')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()['latest']['issue'], '2609270010')
        self.assertIsNone(response.get_json()['newest']['single'])
        self.assertEqual(response.headers['Cache-Control'], 'no-store, max-age=0')

    def test_target_hash_is_visible_before_twenty_groups_finish(self):
        from web import app
        stamp=datetime.now(timezone.utc)
        connection=MagicMock()
        connection.__enter__.return_value=connection
        connection.cursor.return_value.fetchone.side_effect=[
            ('2026-09-29:0990',3,86666044,[1,2,3,4,5,6,7],stamp),
            ('2026-09-29:0990',3,86666044,[1,2,3,4,5,6,7],stamp),
            ([1,3,5,7,9,11,12],6,stamp,stamp)]
        with patch('web.DB',return_value=connection), \
             patch('web.get_meta',side_effect=lambda k,default=None: {'block':86666063} if k=='chain_head' else {}):
            live=app.test_client().get('/api/live').get_json()
        self.assertEqual(live['latest']['issue'],'2609290991')
        self.assertEqual(live['latest']['block'],86666063)
        self.assertTrue(live['latest']['provisional'])
        self.assertEqual(live['nextTargetBlock'],86666082)

    def test_existing_pending_period_promotes_its_raw_target_immediately(self):
        from web import app
        from core import target_block
        block=target_block('2026-09-29',991)
        stamp=datetime.now(timezone.utc)
        connection=MagicMock()
        connection.__enter__.return_value=connection
        connection.cursor.return_value.fetchone.side_effect=[
            ('2026-09-29:0991',None,block,None,stamp),
            ('2026-09-29:0990',3,block-20,[1,2,3,4,5,6,7],stamp),
            ([1,3,5,7,9,11,12],6,stamp,stamp)]
        with patch('web.DB',return_value=connection), \
             patch('web.get_meta',side_effect=lambda k,default=None: {'block':block} if k=='chain_head' else {}):
            live=app.test_client().get('/api/live').get_json()
        self.assertEqual(live['latest']['issue'],'2609290991')
        self.assertEqual(live['latest']['single'],6)
        self.assertTrue(live['latest']['provisional'])

    def test_skipped_target_is_saved_before_group_repair(self):
        connection=MagicMock()
        connection.__enter__.return_value=connection
        connection.cursor.return_value.fetchone.return_value=None
        block={'number':42,'hash':'a'*64,'timestamp':0}
        with patch.object(collector,'DB',return_value=connection), \
             patch.object(collector,'target_block',return_value=42), \
             patch.object(collector,'fetch_block',return_value=block) as fetch, \
             patch.object(collector,'save_block') as save:
            self.assertTrue(collector.capture_target_first('2026-09-29',991))
        fetch.assert_called_once_with(42)
        save.assert_called_once_with(block)

    def test_stale_monitor_triggers_independent_verified_head_probe(self):
        latest={'number':120,'hash':'a'*64,'timestamp':0}
        sleeps=iter((None,StopIteration()))
        def stop_after_second(_):
            result=next(sleeps)
            if isinstance(result,Exception):raise result
        with patch.object(collector.monitor,'HEAD_NUMBER',None), \
             patch.object(collector,'get_meta',return_value={'block':100}), \
             patch.object(collector.time,'monotonic',side_effect=[0,0,10]), \
             patch.object(collector.time,'sleep',side_effect=stop_after_second), \
             patch.object(collector,'last_finished_index',return_value=1), \
             patch.object(collector,'from_index',return_value=('2026-09-29',991)), \
             patch.object(collector,'target_block',return_value=120), \
             patch.object(collector,'capture_target_first') as capture, \
             patch.object(collector,'fetch_latest',return_value=latest) as fetch, \
             patch.object(collector,'save_block') as save, \
             patch.object(collector,'set_meta') as meta:
            with self.assertRaises(StopIteration):collector.fast_target_forever()
        fetch.assert_called_once()
        save.assert_called_once_with(latest)
        self.assertEqual(capture.call_count,1)
        self.assertTrue(any(call.args[0]=='chain_head' and call.args[1]['source']=='target-fallback'
                            for call in meta.call_args_list))

    def test_fast_target_marker_exposes_verified_raw_result_with_stale_chain(self):
        from web import app
        from core import target_block
        target=target_block('2026-09-29',991)
        stamp=datetime.now(timezone.utc)
        connection=MagicMock()
        connection.__enter__.return_value=connection
        connection.cursor.return_value.fetchone.side_effect=[
            ('2026-09-29:0990',3,target-19,[1,2,3,4,5,6,7],stamp),
            ('2026-09-29:0990',3,target-19,[1,2,3,4,5,6,7],stamp),
            ([1,3,5,7,9,11,12],6,stamp,stamp)]
        def meta(key,default=None):
            return {'chain_head':{'block':target-1,'seenAt':stamp.isoformat()},
                    'fast_target_latest':{'period':'2026-09-29:0991','targetBlock':target,
                                          'seenAt':stamp.isoformat()}}.get(key,{})
        with patch('web.DB',return_value=connection),patch('web.get_meta',side_effect=meta):
            data=app.test_client().get('/api/live').get_json()
        self.assertEqual(data['latest']['period'],'2026-09-29:0991')
        self.assertEqual(data['latest']['single'],6)
        self.assertEqual(data['head'],target)

    def test_clock_uses_three_second_display_offset(self):
        from web import app
        clock=app.test_client().get('/api/clock').get_json()
        self.assertEqual(clock['displayOffsetSeconds'],-3)


if __name__ == '__main__':
    unittest.main()
