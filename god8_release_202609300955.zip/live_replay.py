"""Persist a two-choice historical replay before the next target block exists."""
import json
from datetime import datetime, timezone

from core import CN, DB, from_index, get_meta, pindex, target_block
from history_simulation import simulate

# The strict replay rule can legitimately return no two-choice forecast. Keep
# that decision for this source draw; otherwise the collector replays 10,000
# rows on every two-second tick and starves its live block capture thread.
_last_attempted_source = None


def target_for_latest(latest_key):
    ds, no = latest_key.split(':')
    next_ds, next_no = from_index(pindex(ds, int(no)) + 1)
    return f'{next_ds}:{next_no:04d}', target_block(next_ds, next_no)


def forecast_due(now, source_key, saved_at, next_block, head):
    """Lock the next round as soon as its source result is stored, before its block."""
    ds, no = source_key.split(':')
    at = pindex(ds, int(no))
    local = now.astimezone(CN)
    current = pindex(local.date().isoformat(), local.hour * 60 + local.minute)
    elapsed = (now - saved_at).total_seconds()
    return (elapsed >= 0 and at in (current, current - 1)
            and head is not None and int(head) < next_block)


def advance(now=None):
    """Collector tick: settle saved predictions and create one only while the block is future."""
    global _last_attempted_source
    now = now or datetime.now(timezone.utc)
    with DB() as conn:
        q = conn.cursor()
        q.execute('''UPDATE replay_forecasts f SET actual=p.single_count,settled_at=NOW()
                     FROM periods p WHERE f.period_key=p.period_key AND f.settled_at IS NULL''')
        q.execute('''SELECT period_key,single_count,target_block,created_at,block_hash FROM periods
                     ORDER BY period_date DESC,period_no DESC LIMIT 1''')
        latest = q.fetchone()
        if not latest or latest[1] is None:
            q.close()
            return
        source_ds,source_no=latest[0].split(':')
        if int(latest[2]) != target_block(source_ds,int(source_no)):
            q.close()
            return  # Wait for platform_calibration to rebuild this source row.
        target, next_block = target_for_latest(latest[0])
        source_identity=(latest[0],latest[1],latest[2],latest[4])
        q.execute('SELECT 1 FROM replay_forecasts WHERE period_key=%s', (target,))
        exists = q.fetchone() is not None
        q.close()
    if exists or source_identity==_last_attempted_source:
        return
    head = (get_meta('chain_head') or {}).get('block')
    if not forecast_due(now, latest[0], latest[3], next_block, head):
        return
    with DB() as conn:
        q = conn.cursor()
        q.execute('''SELECT period_key,single_count,numbers FROM periods
                     ORDER BY period_date DESC,period_no DESC LIMIT 10000''')
        history = q.fetchall()
        q.close()
    if not history or history[0][0] != latest[0]:
        return
    preview = simulate(history)['preview']
    if not preview or preview['issue'] != target[2:4]+target[5:7]+target[8:10]+target[11:]:
        _last_attempted_source=source_identity
        return
    # Recheck the target in the same transaction. A collector may have saved it
    # during the simulation; never backdate a prediction against a known result.
    with DB() as conn:
        q = conn.cursor()
        q.execute('''INSERT INTO replay_forecasts(period_key,source_period,source_block,choices,match)
                     SELECT %s,%s,%s,%s::jsonb,%s::jsonb
                     WHERE NOT EXISTS(SELECT 1 FROM periods WHERE period_key=%s)
                       AND NOT EXISTS(SELECT 1 FROM raw_blocks WHERE block_number=%s)
                     ON CONFLICT(period_key) DO NOTHING''',
                  (target, latest[0], latest[2], json.dumps(preview['predictions']),
                   json.dumps(preview['match']), target, next_block))
        q.close()
    _last_attempted_source=source_identity
