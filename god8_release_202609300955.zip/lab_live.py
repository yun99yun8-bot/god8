"""Record adaptive single-choice research independently from homepage replay."""
import json
from datetime import datetime, timezone

from core import DB, get_meta
from live_replay import forecast_due, target_for_latest
from research_lab import analyze


def advance(now=None):
    now=now or datetime.now(timezone.utc)
    with DB() as conn:
        q=conn.cursor()
        q.execute('''UPDATE lab_forecasts f SET actual=p.single_count,settled_at=NOW()
                     FROM periods p WHERE f.period_key=p.period_key AND f.settled_at IS NULL''')
        q.execute('''SELECT period_key,single_count,target_block,created_at FROM periods
                     ORDER BY period_date DESC,period_no DESC LIMIT 1''')
        latest=q.fetchone()
        if not latest or latest[1] is None:
            q.close()
            return
        target,next_block=target_for_latest(latest[0])
        q.execute('SELECT 1 FROM lab_forecasts WHERE period_key=%s',(target,))
        already=q.fetchone() is not None
        q.close()
    if already or not forecast_due(now,latest[0],latest[3],next_block,
                                   (get_meta('chain_head') or {}).get('block')):
        return
    with DB() as conn:
        q=conn.cursor()
        q.execute('''SELECT period_key,single_count,numbers FROM periods
                     ORDER BY period_date DESC,period_no DESC LIMIT 10000''')
        history=q.fetchall()
        q.close()
    if not history or history[0][0]!=latest[0]:
        return
    preview=analyze(history)['preview']
    if not preview or preview['issue'] != target[2:4]+target[5:7]+target[8:10]+target[11:]:
        return
    with DB() as conn:
        q=conn.cursor()
        q.execute('''INSERT INTO lab_forecasts(period_key,source_period,choices,ai_prediction,ai_method,weights)
                     SELECT %s,%s,%s::jsonb,%s,%s,%s::jsonb
                     WHERE NOT EXISTS(SELECT 1 FROM periods WHERE period_key=%s)
                       AND NOT EXISTS(SELECT 1 FROM raw_blocks WHERE block_number=%s)
                     ON CONFLICT(period_key) DO NOTHING''',
                  (target,latest[0],json.dumps(preview['predictions']),
                   preview['aiPrediction'],preview['aiMethod'],json.dumps(preview['weights']),
                   target,next_block))
        q.close()
