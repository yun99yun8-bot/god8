# God8 v2.0.12 两码连错统计完整部署包

本包是完整工程。上一个「手机更新包」只有 14 个增量文件，直接用它替换仓库会缺少运行模块、`render.yaml` 和 `requirements.txt`，导致构建或网页接口报错。这个压缩包的根目录直接放着这两个配置文件和所有 Python 入口文件，`templates/`、`static/` 目录也已补齐。

## iPhone 更新现有部署

1. 在「文件」中解压。打开解压后的目录，确认直接看见 `render.yaml`、`requirements.txt`、`web.py`、`collector_service.py`、`worker_ai.py`，以及 `templates` 和 `static` 两个文件夹。
2. 在 GitHub 仓库 `yun99yun8-bot/god8` 的**根目录**上传解压后的文件和两个文件夹内的内容，覆盖同名旧文件。GitHub 网页不能上传 zip 后自动解压。不要只上传 14 个增量文件，也不要多套一层目录。
3. 提交后，在 Render 观察 `god8-web`、`god8-collector`、`god8-worker-ai` 三项部署。保留现有 `god8-db`，不要重建数据库；蓝图若提示新建同名资源，先核对现有 Blueprint 的连接，不要重复创建收费资源。
4. 查看 `https://god8-web.onrender.com/health`。应返回 `databaseConnected: true` 和版本 `god8-v2.0.12-replay-streaks`。新的独立地址 `/chase` 查看两码连续错误及十把额度成本；原有首页、导航和采集逻辑沿用 V2.0.10。

三项服务的启动文件分别是：Web `web.py`、采集 `collector_service.py`、回填和分段审计 `worker_ai.py`。Render 由 `render.yaml` 启动，Web 使用 `gunicorn.conf.py`。数据库连接来自已有 `DATABASE_URL`；若旧服务是手动建立的，务必核对三项服务连接的是同一个原数据库。

本包包含本地测试目录 `tests/`，不影响部署。离线复核：安装 `requirements.txt` 后执行 `python -m unittest discover -s tests`。本地测试只能证明代码及模拟接口通过；无法读取你的 Render 部署日志或在线数据库。若 `/health` 依然异常，需提供**该次部署的 Deploy logs 中第一条 Traceback**和服务名称，才能定位与本次缺文件无关的线上故障；不要贴数据库连接串或 API 密钥。

V2.0.10 修正上一版“上一期开奖入库后还等 20 秒”的锁定门槛。现在采集服务发现上一期有效结果后就运行两码复刻、存入目标期记录；首页每 2 秒读取锁定结果，显示锁定的北京时间。首页不会在下一期结果出来后才生成预测，已开奖但此前没有锁定的期保持空记录。

V2.0.12 新增独立只读两码连错页面。无需新表，也不调整首页原有两码预判。计算口径、十把翻倍公式及独立网址详见 `UPDATE_V2.0.12.md`。
