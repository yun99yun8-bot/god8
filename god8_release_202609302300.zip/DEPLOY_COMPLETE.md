# God8 v2.0.40 完整部署包

本 ZIP 是完整工程，不是增量补丁。根目录直接包含 `render.yaml`、`requirements.txt`、`web.py`、`collector_service.py`、`worker_ai.py`，以及 `templates/`、`static/`、`tests/` 等目录。

## 本版重点

- 修复“数据库已有很多区块，但查询 3 尾/其他尾数没有历史”的兼容问题。
- “更多玩法 → 区块尾数”同时读取 `raw_blocks` 与旧版 `historical_raw_blocks`，按区块号自动去重。
- 旧表只有区块哈希也可以直接计算七个号码与单0–单7；查看时会分批迁移进 `raw_blocks`，不需要重新抓链上数据。
- 尾数统计取最近最多 10000 个同尾原始区块；历史记录每页 100 个并可翻页。
- 9月30日第1300期起的临时3尾规则保留，到原2尾阶段结束；10月1日第0121期恢复0尾，原360期节奏不改。
- Web 与采集服务版本均为 `god8-v2.0.40-tail-history-bridge`。

## iPhone 更新

1. 在“文件”App 中解压本 ZIP。
2. 打开解压后的目录，确认第一层就能看到 `render.yaml`、`web.py`、`collector_service.py`、`templates`、`static`，不要多套一层目录。
3. 上传到 GitHub 仓库根目录并覆盖同名文件。GitHub 网页不会自动解压 ZIP，所以要上传解压后的文件。
4. Render 的 `god8-web`、`god8-collector`、`god8-worker-ai` 使用同一个现有 `god8-db`，不要新建数据库。
5. 部署后查看 `/health`：`version` 与 `collectorVersion` 都应为 `god8-v2.0.40-tail-history-bridge`。
6. 打开“更多玩法”，输入 3 查询。第一次可能显示从旧库读取/迁移的数量；再次查询时这些记录会逐步落入新原始区块表。

完整变更见 `UPDATE_V2.0.40.md`。
