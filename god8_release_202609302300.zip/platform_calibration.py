"""Reconcile already stored period rows against a confirmed platform mapping.

Never invent a result: re-materialize from the immutable raw block hashes.
The cursor is only a progress hint; every pass checks stored target blocks again.
"""
import time
from datetime import datetime, timezone

from core import (DB, fetch_block_range, pindex, save_blocks_batch,
                  save_period, set_meta, target_block)

START_INDEX=pindex('2026-09-29',991)


def mismatches(limit=25):
    with DB() as conn:
        q=conn.cursor()
        q.execute('''SELECT period_date::text,period_no,target_block,training_set
                     FROM periods WHERE period_date>=%s
                     ORDER BY period_date,period_no''',('2026-09-29',))
        found=[]
        for ds,no,tb,training in q.fetchall():
            if pindex(ds,no)>=START_INDEX and tb!=target_block(ds,no):
                found.append((ds,no,training))
                if len(found)>=limit:break
        q.close()
    return found


def reconcile_one(ds,no,training):
    target=target_block(ds,no)
    with DB() as conn:
        q=conn.cursor()
        q.execute('''SELECT block_number FROM raw_blocks
                     WHERE block_number BETWEEN %s AND %s''',(target-19,target))
        have={r[0] for r in q.fetchall()}
        q.close()
    if len(have)!=20:
        fetched=fetch_block_range(target-19,target)
        save_blocks_batch(fetched.values())
    ok,missing=save_period(ds,no,'platform-calibrated',training)
    if not ok:
        raise RuntimeError(f'confirmed block range incomplete: {missing[:5]}')
    key=f'{ds}:{no:04d}'
    with DB() as conn:
        q=conn.cursor()
        q.execute('UPDATE periods SET audit_ok=FALSE WHERE period_key=%s',(key,))
        # Forecast choices/lock times remain immutable; correct only the
        # observed result used by all historical hit-rate displays.
        for table in ('replay_forecasts','lab_forecasts','ai_predictions'):
            q.execute(f'''UPDATE {table} f SET actual=p.single_count
                          FROM periods p WHERE f.period_key=p.period_key
                          AND p.period_key=%s AND f.actual IS DISTINCT FROM p.single_count''',(key,))
        q.close()
    return {'period':key,'targetBlock':target}


def reconcile_once():
    changed=[]
    for ds,no,training in mismatches():
        changed.append(reconcile_one(ds,no,training))
    if changed:
        set_meta('platform_calibration',{'status':'corrected',
                 'confirmed':{'2026-09-29:0991':86666063,
                              '2026-09-29:0992':86666082,
                              '2026-09-30:1299':86700994,
                              '2026-09-30:1300':86701013,
                              '2026-09-30:1306':86701133},
                 'inferredBoundary':{'2026-09-29:1201':86670260,
                                     '2026-10-01:0121':target_block('2026-10-01',121)},
                 'batch':changed,'updatedAt':datetime.now(timezone.utc).isoformat()})
    return changed


def reconcile_forever():
    while True:
        try:
            changed=reconcile_once()
            time.sleep(.5 if len(changed)==25 else 30)
        except Exception as exc:
            set_meta('platform_calibration',{'status':'retrying','error':str(exc)[:300],
                     'updatedAt':datetime.now(timezone.utc).isoformat()})
            time.sleep(5)
