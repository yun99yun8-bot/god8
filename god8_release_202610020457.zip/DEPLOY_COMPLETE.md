# God8 v2.0.58 完整部署包

版本：`god8-v2.0.58-manual-home-backfill-fix`

本包在 v2.0.57 基础上修复手动尾数中心和历史回填。正式首页360规则未修改。

Render 仍使用三服务 + PostgreSQL：
- `god8-web`
- `god8-collector`
- `god8-worker-ai`（`python worker_ai.py`）
- `god8-db`

详细变更见 `UPDATE_V2.0.58.md`。
