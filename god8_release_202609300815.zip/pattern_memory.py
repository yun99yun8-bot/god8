"""Evidence-only replay memory; never treats a historical match as a guarantee."""
from streak_research import issue_index

WINDOW = 10


def _valid_segment(rows):
    segment = []
    last = None
    for key, single in rows:
        try:
            index = issue_index(key)
        except (ValueError, TypeError):
            index = None
        if index is None or not isinstance(single, int) or not 0 <= single <= 7:
            segment = []
            last = None
            continue
        if last is not None and index != last + 1:
            segment = []
        segment.append((key, single))
        last = index
    return segment


def _practice(rows):
    """Describe observed high-frequency runs; never use them as future labels."""
    values = []
    indexes = []
    for key, single in rows:
        try:
            index = issue_index(key)
        except (ValueError, TypeError):
            index = None
        values.append(single)
        indexes.append(index)
    episodes = preceded = 0
    active = False
    examples = []
    for end in range(WINDOW - 1, len(rows)):
        start = end - WINDOW + 1
        valid = (indexes[start] is not None and indexes[end] == indexes[start] + WINDOW - 1
                 and all(isinstance(x, int) and 0 <= x <= 7 for x in values[start:end + 1]))
        high = valid and sum(x in (1, 6) for x in values[start:end + 1]) >= 4
        if high and not active:
            episodes += 1
            before = start - 4
            has_07 = (before >= 0 and indexes[before] is not None
                      and indexes[start] == indexes[before] + 4
                      and any(x in (0, 7) for x in values[before:start]))
            preceded += bool(has_07)
            examples.append({'period': rows[end][0], 'preceded07': bool(has_07)})
            examples = examples[-5:]
        active = high
    return {'highFrequencyEpisodes': episodes, 'preceded07InFour': preceded,
            'definition': '连续10期中单1/单6合计至少4次；重叠窗口合并为一段',
            'examples': examples}


def analyze(rows):
    """Analyze ordered, retained results through the current draw only.

    Replay outcomes use *older* endpoints with a complete ten-issue future;
    the current suffix is never included in either support or outcome.
    """
    rows = list(rows)
    current = _valid_segment(rows)
    result = {'period': rows[-1][0] if rows else None, 'status': 'waiting',
              'window': WINDOW, 'recent16': None, 'replay': None,
              'highFrequency': False, 'notice': '等待连续有效开奖记录',
              'practice': _practice(rows)}
    if len(current) < 4:
        return result
    recent = [single for _, single in current[-WINDOW:]]
    recent_hits = sum(x in (1, 6) for x in recent)
    if len(recent) == WINDOW:
        result['recent16'] = {'hits': recent_hits, 'total': WINDOW,
                              'first': current[-WINDOW][0], 'last': current[-1][0]}
    if len(recent) == WINDOW and recent_hits >= 4:
        result.update(status='active', highFrequency=True,
                      notice=f'单1/单6近期活跃：最近10期出现{recent_hits}次（已发生）')
    # The replay search is triggered by the just-arrived valid 0/7 result.
    if recent[-1] not in (0, 7):
        return result
    values = [single for _, single in rows]
    indexes = []
    for key, _ in rows:
        try:
            indexes.append(issue_index(key))
        except (ValueError, TypeError):
            indexes.append(None)
    for length, required in ((6, 6), (5, 5), (4, 4), (6, 5)):
        if len(current) < length:
            continue
        pattern = tuple(x for _, x in current[-length:])
        matched = []
        # Disjoint ten-period forward windows prevent heavily overlapping
        # historical episodes from masquerading as independent samples.
        last_end = -WINDOW - 1
        for end in range(length - 1, len(rows) - WINDOW):
            if end <= last_end + WINDOW or values[end] != pattern[-1]:
                continue
            start = end - length + 1
            if sum(a == b for a, b in zip(values[start:end + 1], pattern)) < required:
                continue
            if indexes[start] is None or indexes[end + WINDOW] != indexes[start] + length + WINDOW - 1:
                continue
            if any(not isinstance(x, int) or not 0 <= x <= 7 for x in values[start:end + WINDOW + 1]):
                continue
            following = values[end + 1:end + WINDOW + 1]
            matched.append({'period': rows[end][0], 'hits16': sum(x in (1, 6) for x in following)})
            last_end = end
        if matched:
            high = sum(x['hits16'] >= 4 for x in matched)
            result['replay'] = {'trigger': '单0' if recent[-1] == 0 else '单7',
                                'pattern': list(pattern), 'length': length,
                                'matchedPositions': required,
                                'samples': len(matched), 'highFrequencyCases': high,
                                'rate': round(high / len(matched), 4),
                                'examples': matched[-5:]}
            minimum = 12 if required == length else 20
            if len(matched) >= minimum and high / len(matched) >= .35:
                result.update(status='replay', highFrequency=True,
                              notice=f'历史{required}/{length}位相似片段提示单1/单6高发期：{high}/{len(matched)}段后续10期至少出现4次；仅供观察')
            elif not result['highFrequency']:
                result.update(status='observing', notice=f'单0/单7复现已检索：相似{len(matched)}段，证据不足，不提示高发')
            break
    if not result['replay'] and not result['highFrequency']:
        result.update(status='observing', notice='单0/单7已检索留存历史，暂无连续4期相同且可核对的片段')
    return result
