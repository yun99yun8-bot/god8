"""Reconcile already stored period rows against a confirmed platform mapping.

Never invent a result: re-materialize from the immutable raw block hashes.
The cursor is only a progress hint; every pass checks stored target blocks again.
"""
import time
from datetime import datetime, timezone

from core import (DB, fetch_block_range, from_index, get_meta, pindex, save_blocks_batch,
                  save_period, set_meta, target_block)

START_INDEX=pindex('2026-09-29',991)
TEMP_3_START=pindex('2026-09-30',1300)
TEMP_3_END=pindex('2026-10-01',46)
RESUME_2_START=pindex('2026-10-01',47)
NEXT_ZERO_START=pindex('2026-10-01',121)
TRANSITION_REPAIR_END=pindex('2026-10-01',1440)


def mismatches(limit=25):
    """Return newest formal rows needing canonical transition repair.

    During the Sep30/Oct1 tail transition, verify not only the target height but
    also the saved hash, seven numbers and single-count against raw_blocks. This
    prevents a corrected target from keeping an older result payload.
    """
    with DB() as conn:
        q=conn.cursor()
        q.execute('''SELECT period_date::text,period_no,target_block,block_hash,numbers,single_count,training_set
                     FROM periods WHERE period_date>=%s
                     ORDER BY period_date DESC,period_no DESC''',('2026-09-29',))
        stored=q.fetchall()
        transition=[]
        targets=[]
        for ds,no,tb,bh,nums,sc,training in stored:
            idx=pindex(ds,no); exp=target_block(ds,no)
            if idx>=START_INDEX and int(tb)!=int(exp):
                transition.append((ds,no,training,exp,bh,nums,sc,True))
                targets.append(exp)
            elif TEMP_3_START<=idx<=TRANSITION_REPAIR_END:
                transition.append((ds,no,training,exp,bh,nums,sc,False))
                targets.append(exp)
        raw={}
        if targets:
            q.execute('''SELECT block_number,block_hash,numbers,single_count FROM raw_blocks
                         WHERE block_number=ANY(%s)''',(list(set(targets)),))
            raw={int(n):(h,nums,sc) for n,h,nums,sc in q.fetchall()}
        q.close()
    found=[]
    for ds,no,training,exp,bh,nums,sc,target_bad in transition:
        mismatch=target_bad
        rr=raw.get(int(exp))
        if not mismatch and rr is None:
            mismatch=True
        elif not mismatch:
            r_hash,r_nums,r_sc=rr
            mismatch=(bh!=r_hash or nums!=r_nums or sc!=r_sc)
        if mismatch:
            found.append((ds,no,training))
            if len(found)>=limit:
                break
    return found


def _reuse_legacy_blocks(start,end,missing):
    """Reuse hashes already captured by older releases before network fetching."""
    if not missing:
        return 0
    with DB() as conn:
        q=conn.cursor()
        q.execute("SELECT to_regclass('public.historical_raw_blocks')")
        legacy=q.fetchone()[0]
        if legacy:
            q.execute('''SELECT block_number,block_hash FROM historical_raw_blocks
                         WHERE block_number BETWEEN %s AND %s''',(start,end))
            blocks=[{'number':int(n),'hash':h,'timestamp':None}
                    for n,h in q.fetchall() if int(n) in missing]
        else:
            blocks=[]
        # A previous period may also have retained the immutable hash even when
        # raw_blocks was pruned or never materialized during a rule correction.
        q.execute('''SELECT block_number,block_hash FROM groups
                     WHERE block_number BETWEEN %s AND %s''',(start,end))
        by_number={b['number']:b for b in blocks}
        for n,h in q.fetchall():
            if int(n) in missing:
                by_number[int(n)]={'number':int(n),'hash':h,'timestamp':None}
        q.close()
    return save_blocks_batch(by_number.values()) if by_number else 0


def _missing_transition_periods(limit=25):
    """Find completed transition-window issues absent from formal history.

    The scan begins at the first temporary 3-tail issue and continues through
    Oct 1, covering the real 0047 return to 2-tail and the normal 0121 move to
    0-tail. A restart therefore cannot preserve holes around either boundary.
    """
    head=(get_meta('chain_head') or {}).get('block')
    fast=(get_meta('fast_target_latest') or {}).get('targetBlock')
    head=max((int(x) for x in (head,fast) if x is not None),default=None)
    if head is None:
        return []
    candidates=[]
    capture=get_meta('historical_capture') or {}
    train_first=capture.get('firstIndex');train_last=capture.get('lastIndex')
    for idx in range(TEMP_3_START,TRANSITION_REPAIR_END+1):
        ds,no=from_index(idx)
        if target_block(ds,no)>head:
            break
        training=(train_first is not None and train_last is not None and
                  int(train_first)<=idx<=int(train_last))
        candidates.append((f'{ds}:{no:04d}',ds,no,training))
    if not candidates:
        return []
    keys=[x[0] for x in candidates]
    with DB() as conn:
        q=conn.cursor();q.execute('SELECT period_key FROM periods WHERE period_key=ANY(%s)',(keys,))
        existing={r[0] for r in q.fetchall()};q.close()
    return [(ds,no,training) for key,ds,no,training in candidates if key not in existing][:limit]


def reconcile_one(ds,no,training):
    target=target_block(ds,no)
    start=target-19
    with DB() as conn:
        q=conn.cursor()
        q.execute('''SELECT block_number FROM raw_blocks
                     WHERE block_number BETWEEN %s AND %s''',(start,target))
        have={int(r[0]) for r in q.fetchall()}
        q.close()
    missing=set(range(start,target+1))-have
    if missing:
        _reuse_legacy_blocks(start,target,missing)
        with DB() as conn:
            q=conn.cursor();q.execute('''SELECT block_number FROM raw_blocks
                         WHERE block_number BETWEEN %s AND %s''',(start,target))
            have={int(r[0]) for r in q.fetchall()};q.close()
        missing=set(range(start,target+1))-have
    if missing:
        fetched=fetch_block_range(start,target)
        save_blocks_batch(fetched.values())
    ok,missing=save_period(ds,no,'platform-calibrated',training)
    if not ok:
        raise RuntimeError(f'confirmed block range incomplete: {missing[:5]}')
    key=f'{ds}:{no:04d}'
    with DB() as conn:
        q=conn.cursor()
        q.execute('UPDATE periods SET audit_ok=FALSE WHERE period_key=%s',(key,))
        # Forecast choices/lock times remain immutable; correct only the
        # observed result used by all historical hit-rate displays.
        for table in ('replay_forecasts','lab_forecasts','ai_predictions'):
            q.execute(f'''UPDATE {table} f SET actual=p.single_count
                          FROM periods p WHERE f.period_key=p.period_key
                          AND p.period_key=%s AND f.actual IS DISTINCT FROM p.single_count''',(key,))
        q.close()
    return {'period':key,'targetBlock':target}



def _invalidate_future_views(changed):
    """Discard only not-yet-settled derived views after canonical history changes.

    Settled historical forecasts remain immutable. Future forecasts are regenerated
    from the corrected 3-tail/2-tail/0-tail formal history on the next collector tick.
    """
    if not changed:
        return
    now=datetime.now(timezone.utc).isoformat()
    with DB() as conn:
        q=conn.cursor()
        q.execute("""DELETE FROM replay_forecasts f
                     WHERE f.settled_at IS NULL
                       AND NOT EXISTS (SELECT 1 FROM periods p WHERE p.period_key=f.period_key)""")
        replay_deleted=q.rowcount
        q.execute("""DELETE FROM lab_forecasts f
                     WHERE f.settled_at IS NULL
                       AND NOT EXISTS (SELECT 1 FROM periods p WHERE p.period_key=f.period_key)""")
        lab_deleted=q.rowcount
        q.close()
    set_meta('canonical_data_revision',{
        'updatedAt':now,
        'changedPeriods':[item['period'] for item in changed],
        'latestChanged':changed[0]['period'] if changed else None,
        'pendingReplayInvalidated':replay_deleted,
        'pendingLabInvalidated':lab_deleted,
        'reason':'platform-tail-reconciliation'
    })


def reconcile_priority_bootstrap(max_batches=20):
    """Repair newest canonical rows before replay/pattern workers are allowed to start."""
    batches=0
    changed_total=0
    while batches < max_batches:
        changed=reconcile_once()
        batches += 1
        changed_total += len(changed)
        if not changed or len(changed) < 25:
            break
    set_meta('platform_calibration_bootstrap',{
        'status':'ready',
        'batches':batches,
        'changed':changed_total,
        'updatedAt':datetime.now(timezone.utc).isoformat()
    })
    return changed_total

def reconcile_once():
    changed=[]
    pending=mismatches(limit=25)
    if len(pending)<25:
        known={(ds,no) for ds,no,_ in pending}
        for item in _missing_transition_periods(limit=25-len(pending)):
            if (item[0],item[1]) not in known:
                pending.append(item)
    for ds,no,training in pending:
        changed.append(reconcile_one(ds,no,training))
    if changed:
        _invalidate_future_views(changed)
        set_meta('platform_calibration',{'status':'corrected',
                 'confirmed':{'2026-09-29:0991':86666063,
                              '2026-09-29:0992':86666082,
                              '2026-09-30:1299':86700994,
                              '2026-09-30:1300':86701013,
                              '2026-09-30:1306':86701133,
                              '2026-10-01:0046':86704733,
                              '2026-10-01:0047':86704752},
                 'confirmedBoundary':{'temporary3Start':'2026-09-30:1300',
                                      'temporary3Last':'2026-10-01:0046',
                                      'resume2Start':'2026-10-01:0047'},
                 'inferredBoundary':{'2026-09-29:1201':86670260,
                                     '2026-10-01:0121':target_block('2026-10-01',121)},
                 'batch':changed,'updatedAt':datetime.now(timezone.utc).isoformat()})
    set_meta('platform_tail_transition',{
        'temporary3Start':{'period':'2026-09-30:1300','targetBlock':86701013,'tail':3},
        'temporary3Last':{'period':'2026-10-01:0046','targetBlock':86704733,'tail':3},
        'resume2Start':{'period':'2026-10-01:0047','targetBlock':86704752,'tail':2},
        'nextNormalPhase':{'period':'2026-10-01:0121','targetBlock':target_block('2026-10-01',121),'tail':0},
        'source':'platform-confirmed-transition',
        'updatedAt':datetime.now(timezone.utc).isoformat()
    })
    return changed


def reconcile_forever():
    while True:
        try:
            changed=reconcile_once()
            time.sleep(.5 if len(changed)==25 else 30)
        except Exception as exc:
            set_meta('platform_calibration',{'status':'retrying','error':str(exc)[:300],
                     'updatedAt':datetime.now(timezone.utc).isoformat()})
            time.sleep(5)
