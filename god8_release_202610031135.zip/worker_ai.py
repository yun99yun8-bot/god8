"""God8 worker: forward backfill and independent stage audit."""
import os
import json
import socket
import threading
import time
from datetime import datetime, timezone
from urllib.request import Request, urlopen

from audit_service import verify_forever
from backfill_worker import forward_forever
from core import init_db, pool, set_meta
from live_replay import advance_guarded as advance_replay
from manual_tail_center import live_sync_step, backfill_step, backfill_enabled, settle_predictions, prediction_step, selected_tail

WORKER_VERSION = 'god8-v2.0.17-manual-platform-0695-sync'



# v2.0.7: process-level heartbeat is independent of PostgreSQL.  The Worker
# reports directly to the Web service over Render's private network before
# init_db() runs, so database/bootstrap failures are still visible.
_process_lock = threading.Lock()
_process_state = {
    'status': 'booting',
    'phase': 'process-imported',
    'databaseStatus': 'not-started',
    'version': WORKER_VERSION,
    'pid': os.getpid(),
    'host': socket.gethostname(),
    'reportedAt': datetime.now(timezone.utc).isoformat(),
}


def update_process_state(status=None, phase=None, **extra):
    with _process_lock:
        if status is not None:
            _process_state['status'] = status
        if phase is not None:
            _process_state['phase'] = phase
        _process_state.update(extra)
        _process_state['version'] = WORKER_VERSION
        _process_state['reportedAt'] = datetime.now(timezone.utc).isoformat()
        return dict(_process_state)


def _direct_heartbeat_target():
    host = (os.getenv('GOD8_WEB_HOST') or '').strip()
    port = (os.getenv('GOD8_WEB_PORT') or '').strip()
    token = (os.getenv('GOD8_INTERNAL_HEARTBEAT_TOKEN') or '').strip()
    if not host or not port or not token:
        return None, token
    return f'http://{host}:{port}/api/internal/worker-heartbeat', token


def post_direct_heartbeat():
    url, token = _direct_heartbeat_target()
    if not url:
        return {'ok': False, 'reason': 'direct-heartbeat-not-configured'}
    with _process_lock:
        payload = dict(_process_state)
    payload['reportedAt'] = datetime.now(timezone.utc).isoformat()
    body = json.dumps(payload, separators=(',', ':')).encode()
    req = Request(url, data=body, method='POST', headers={
        'Content-Type': 'application/json',
        'X-God8-Heartbeat-Token': token,
        'User-Agent': 'god8-worker-heartbeat/2.0.7',
    })
    try:
        with urlopen(req, timeout=2) as response:
            return {'ok': 200 <= int(response.status) < 300, 'status': int(response.status)}
    except Exception as exc:
        # This path intentionally never touches PostgreSQL.  Keep the error in
        # local process state so a later successful direct report exposes it.
        update_process_state(directHeartbeatError=str(exc)[:300])
        return {'ok': False, 'reason': str(exc)[:300]}


def direct_heartbeat_forever():
    while True:
        post_direct_heartbeat()
        time.sleep(5)


def publish_worker_meta(key, status, **extra):
    payload={'status':status,'version':WORKER_VERSION,
             'reportedAt':datetime.now(timezone.utc).isoformat(), **extra}
    set_meta(key,payload)
    return payload


def supervised_forward():
    while True:
        try:
            forward_forever()
        except Exception as exc:
            try:
                set_meta('god8_forward_worker_error',{'error':str(exc)[:400],
                    'at':datetime.now(timezone.utc).isoformat()})
            except Exception:
                pass
            time.sleep(5)



def prediction_watchdog():
    """Redundant pre-block forecast scheduler shared with Collector."""
    while True:
        try:
            result=advance_replay() or {}
            if result.get('status') != 'busy-other-watchdog':
                set_meta('prediction_worker_watchdog',{'status':result.get('status','ok'),
                    'reportedAt':datetime.now(timezone.utc).isoformat()})
        except Exception as exc:
            try:
                set_meta('prediction_worker_error',{'error':str(exc)[:400],
                    'at':datetime.now(timezone.utc).isoformat()})
            except Exception:
                pass
        time.sleep(2)


def publish_manual_tail(status='running', phase='idle', **extra):
    payload={'status':status,'phase':phase,'version':WORKER_VERSION,
             'reportedAt':datetime.now(timezone.utc).isoformat(), **extra}
    set_meta('manual_tail_worker',payload)
    return payload


def manual_tail_worker():
    """Live 0-9 sync, selected-tail forecasts, then resumable backfill.

    v2.0.11 keeps live prediction priority over historical backfill.  A tail
    switch is noticed between backfill chunks, and prediction runtime is saved
    before any potentially expensive backfill work begins.
    """
    try:
        publish_manual_tail('starting','thread-start')
    except Exception:
        pass
    while True:
        began=datetime.now(timezone.utc)
        try:
            tail=selected_tail()
            publish_manual_tail('running','cycle-start',tail=tail)

            publish_manual_tail('running','live-sync',tail=tail)
            live_copied=live_sync_step(500)
            publish_manual_tail('running','settle',tail=tail,liveCopied=live_copied)
            settled=settle_predictions()

            # Prediction comes before backfill.  Switching tails therefore does
            # not wait for several historical batches before the new tail gets
            # its first forecast attempt.
            publish_manual_tail('running','prediction',tail=tail,
                liveCopied=live_copied,settledPredictions=settled)
            prediction=prediction_step(tail)
            if prediction.get('status') != 'busy':
                set_meta('manual_tail_prediction_runtime',{**prediction,
                    'producer':'worker-ai',
                    'reportedAt':datetime.now(timezone.utc).isoformat()})
            set_meta('manual_tail_prediction_request',{
                'tail':tail,'status':'handled','predictionStatus':prediction.get('status'),
                'handledAt':datetime.now(timezone.utc).isoformat()})

            result={'status':'paused','processed':0,'raw':0,'legacy':0}
            if backfill_enabled():
                raw_total=legacy_total=processed_total=0
                last_result=result
                for chunk in range(5):
                    # If the user changes tail while historical work is running,
                    # stop the batch train and let the next cycle serve that tail.
                    current_tail=selected_tail()
                    if current_tail != tail:
                        publish_manual_tail('running','tail-switch-priority',tail=current_tail,
                            previousTail=tail,backfillChunk=chunk+1)
                        break
                    publish_manual_tail('running','backfill',tail=tail,
                        backfillChunk=chunk+1,backfillChunks=5,
                        processedThisCycle=processed_total,liveCopied=live_copied,
                        settledPredictions=settled,predictionStatus=prediction.get('status'))
                    last_result=backfill_step(500)
                    raw_total += int(last_result.get('raw',0) or 0)
                    legacy_total += int(last_result.get('legacy',0) or 0)
                    processed_total += int(last_result.get('processed',0) or 0)
                    if last_result.get('status') == 'complete':
                        break
                result={**last_result,'raw':raw_total,'legacy':legacy_total,
                        'processed':processed_total}

            heartbeat={'status':'running','phase':'sleep','version':WORKER_VERSION,'tail':tail,
                'backfillStatus':result.get('status'),
                'lastBatch':result.get('processed',0),
                'lastRawBatch':result.get('raw',0),
                'lastLegacyBatch':result.get('legacy',0),
                'liveCopied':live_copied,'settledPredictions':settled,
                'predictionStatus':prediction.get('status'),
                'cycleSeconds':round((datetime.now(timezone.utc)-began).total_seconds(),3),
                'reportedAt':datetime.now(timezone.utc).isoformat()}
            set_meta('manual_tail_worker',heartbeat)
            set_meta('manual_tail_worker_error',{})
        except Exception as exc:
            error={'error':str(exc)[:500],'type':type(exc).__name__,
                   'at':datetime.now(timezone.utc).isoformat()}
            try:
                set_meta('manual_tail_worker_error',error)
                publish_manual_tail('error','exception',**error)
            except Exception:
                pass
        time.sleep(1)

def main():
    # Start the database-independent channel before touching DATABASE_URL,
    # psycopg2, schema creation, or the advisory lock.
    update_process_state('starting', 'process-started', databaseStatus='not-started', directHeartbeatError=None)
    threading.Thread(target=direct_heartbeat_forever, name='worker-direct-heartbeat', daemon=True).start()
    post_direct_heartbeat()

    try:
        update_process_state('starting', 'database-initializing', databaseStatus='initializing')
        post_direct_heartbeat()
        init_db()
        update_process_state('starting', 'database-ready', databaseStatus='ready', databaseError=None)
        post_direct_heartbeat()
    except Exception as exc:
        update_process_state('error', 'database-init-error', databaseStatus='error',
                             databaseError=str(exc)[:500], errorType=type(exc).__name__)
        post_direct_heartbeat()
        # Give the direct channel a final chance to publish before Render
        # restarts the failed process.
        time.sleep(1)
        raise

    try:
        publish_worker_meta('god8_worker_startup_heartbeat','starting',phase='database-ready')
        publish_worker_meta('god8_worker_release','starting')
    except Exception as exc:
        update_process_state('degraded', 'database-heartbeat-write-error',
                             databaseHeartbeatError=str(exc)[:500])
        post_direct_heartbeat()

    try:
        lease=pool().getconn()
    except Exception as exc:
        update_process_state('error', 'database-pool-error', databaseStatus='error',
                             databaseError=str(exc)[:500], errorType=type(exc).__name__)
        post_direct_heartbeat()
        time.sleep(1)
        raise

    owns_lock=False
    try:
        while True:
            update_process_state('starting', 'waiting-for-leader-lock', databaseStatus='ready')
            post_direct_heartbeat()
            try:
                publish_worker_meta('god8_worker_startup_heartbeat','waiting-for-leader-lock',phase='handoff')
            except Exception as exc:
                update_process_state(databaseHeartbeatError=str(exc)[:500])
            q=lease.cursor()
            q.execute('SELECT pg_try_advisory_lock(%s)',(80086420,))
            leader=bool(q.fetchone()[0])
            q.close();lease.commit()
            if leader:
                owns_lock=True
                break
            try:
                publish_worker_meta('god8_worker_handoff','waiting-for-previous-instance')
            except Exception as exc:
                update_process_state(databaseHeartbeatError=str(exc)[:500])
            time.sleep(1)

        update_process_state('starting', 'leader-acquired', databaseStatus='ready')
        post_direct_heartbeat()
        publish_worker_meta('god8_worker_startup_heartbeat','leader-acquired',phase='starting-threads')
        publish_worker_meta('god8_worker_handoff','leader')
        publish_worker_meta('god8_worker_release','running')
        threading.Thread(target=supervised_forward,name='god8-forward',daemon=True).start()
        threading.Thread(target=verify_forever,name='god8-stage-audit',daemon=True).start()
        threading.Thread(target=prediction_watchdog,name='prediction-watchdog',daemon=True).start()
        threading.Thread(target=manual_tail_worker,name='manual-tail-center',daemon=True).start()

        update_process_state('running', 'worker-running', databaseStatus='ready', duties='backfill-audit-prediction-watchdog-manual-tail')
        post_direct_heartbeat()
        while True:
            update_process_state('running', 'worker-running', databaseStatus='ready')
            try:
                publish_worker_meta('god8_worker_heartbeat','running',
                    duties='backfill-audit-prediction-watchdog-manual-tail',ai='disabled')
                update_process_state(databaseHeartbeatStatus='ok', databaseHeartbeatError=None)
            except Exception as exc:
                update_process_state('degraded', 'database-heartbeat-write-error',
                                     databaseHeartbeatStatus='error', databaseHeartbeatError=str(exc)[:500])
            post_direct_heartbeat()
            time.sleep(5)
    except Exception as exc:
        update_process_state('error', 'runtime-error', runtimeError=str(exc)[:500],
                             errorType=type(exc).__name__)
        post_direct_heartbeat()
        try:
            publish_worker_meta('god8_worker_startup_heartbeat','error',
                error=str(exc)[:500],errorType=type(exc).__name__)
        except Exception:
            pass
        raise
    finally:
        if owns_lock:
            try:
                q=lease.cursor()
                q.execute('SELECT pg_advisory_unlock(%s)',(80086420,))
                q.close();lease.commit()
            except Exception:
                pass
        pool().putconn(lease)


if __name__=='__main__':main()
