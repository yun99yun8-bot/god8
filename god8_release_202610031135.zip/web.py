"""Monitor dashboard; only manual adoption endpoint may mutate model state."""
import re, os, hmac, threading, time
from datetime import datetime, timedelta, timezone
from flask import Flask, jsonify, render_template, request
from ai_research import METHODS, REVISION, wilson
from core import (CN, DB, from_index, get_meta, pindex, target_block, runtime_config,
                  runtime_config_revision, set_runtime_config, DEFAULT_RUNTIME_CONFIG, add_runtime_tail_override,
                  fetch_latest, fetch_block)
from god8_flow import first_complete_index
from omission_research import current_snapshot, retained_stats, run_page
from streak_research import issue_index
from streak_research import report as streak_report
from pattern_research import pattern_report
from pattern_memory import practice_view
from historical_playbook import summarize
from history_simulation import simulate
from live_replay import (advance_guarded as advance_replay, RESULT_HOLD_SECONDS,
                         RESULT_REVEAL_SECONDS, pending_target_future)
from fate_dashboard import summarize_ledger
from research_lab import analyze, LABELS
from replay_streaks import summarize as replay_streak_summary
from omission_extras import daily_overdue, overdue_page, chase_comparison, recommend_recent
from tail_odds import analyze_blocks
from tail_history import tail_rows, tail_total, materialize_legacy, period_map
from canonical_history import load as canonical_load, as_pairs as canonical_pairs, as_analysis as canonical_analysis, quality as canonical_quality
from manual_tail_center import (report as manual_tail_report, live_report as manual_tail_live_report, history as manual_tail_history,
    select_tail as manual_tail_select, selected_tail as manual_tail_selected,
    set_backfill_enabled as manual_tail_set_backfill, prediction_step as manual_tail_prediction_step)

app = Flask(__name__)
APP_VERSION = 'god8-v2.0.17-manual-platform-0695-sync'

# Web self-heal must never block /api/replay/live.  Keep at most one local
# background kick active; Collector/Worker still remain the primary watchdogs.
_replay_heal_lock = threading.Lock()
_replay_heal_running = False
_replay_heal_last = {'status':'idle'}


# v2.0.7: direct Worker process heartbeat.  This lives in Web memory and is
# intentionally independent of PostgreSQL so Worker bootstrap/database errors
# remain visible even before Worker can write the meta table.
_direct_worker_lock = threading.Lock()
_direct_worker_heartbeat = {}


def direct_worker_heartbeat():
    with _direct_worker_lock:
        return dict(_direct_worker_heartbeat)


@app.post('/api/internal/worker-heartbeat')
def internal_worker_heartbeat():
    expected=(os.getenv('GOD8_INTERNAL_HEARTBEAT_TOKEN') or '').encode()
    supplied=(request.headers.get('X-God8-Heartbeat-Token') or '').encode()
    if not expected:
        return jsonify({'ok':False,'error':'heartbeat secret not configured'}),503
    if not hmac.compare_digest(expected,supplied):
        return jsonify({'ok':False,'error':'unauthorized'}),403
    body=request.get_json(silent=True) or {}
    allowed=('status','phase','databaseStatus','version','pid','host','reportedAt',
             'databaseError','databaseHeartbeatStatus','databaseHeartbeatError',
             'directHeartbeatError','runtimeError','errorType','duties')
    clean={k:body.get(k) for k in allowed if k in body}
    clean['receivedAt']=datetime.now(timezone.utc).isoformat()
    with _direct_worker_lock:
        _direct_worker_heartbeat.clear(); _direct_worker_heartbeat.update(clean)
    return jsonify({'ok':True,'receivedAt':clean['receivedAt']})

def _replay_heal_task():
    global _replay_heal_running, _replay_heal_last
    try:
        result = advance_replay() or {}
        _replay_heal_last = dict(result) if isinstance(result, dict) else {'status':'finished'}
    except Exception as exc:
        _replay_heal_last = {'status':'web-self-heal-error','error':str(exc)[:300]}
    finally:
        with _replay_heal_lock:
            _replay_heal_running = False

def schedule_replay_heal():
    global _replay_heal_running, _replay_heal_last
    with _replay_heal_lock:
        if _replay_heal_running:
            return {'status':'already-running'}
        _replay_heal_running = True
        _replay_heal_last = {'status':'scheduled'}
        threading.Thread(target=_replay_heal_task, name='god8-replay-self-heal', daemon=True).start()
        return {'status':'scheduled'}


# v2.0.12: manual-tail web self-heal.  Collector/Worker remain the primary
# producers, but the manual page must not stay in a permanent waiting state if
# either background service is on an older deploy, waiting for handoff, or has
# temporarily stopped.  The web process only kicks the already-existing
# replay-first prediction_step after the 20-second display cadence has expired.
_manual_tail_heal_lock = threading.Lock()
_manual_tail_heal_running = set()
_manual_tail_heal_last = {}
_manual_tail_heal_last_started = {}


def _manual_tail_heal_task(tail, source_block):
    key=(int(tail),int(source_block))
    try:
        result=manual_tail_prediction_step(int(tail)) or {}
        payload=dict(result) if isinstance(result,dict) else {'status':'finished'}
        payload.update({'tail':int(tail),'sourceBlock':int(source_block),
                        'producer':'web-self-heal','reportedAt':datetime.now(timezone.utc).isoformat()})
        _manual_tail_heal_last[key]=payload
    except Exception as exc:
        _manual_tail_heal_last[key]={'status':'web-self-heal-error','tail':int(tail),
            'sourceBlock':int(source_block),'error':str(exc)[:500],
            'reportedAt':datetime.now(timezone.utc).isoformat()}
    finally:
        with _manual_tail_heal_lock:
            _manual_tail_heal_running.discard(key)


def schedule_manual_tail_heal(tail, source_block):
    key=(int(tail),int(source_block))
    now=time.monotonic()
    with _manual_tail_heal_lock:
        if key in _manual_tail_heal_running:
            return {'status':'already-running','tail':key[0],'sourceBlock':key[1]}
        # Do not start the full-history engine on every 700ms browser poll.
        # A failed/busy attempt may retry after two seconds; a locked result will
        # be visible in the next /api/manual-tail response and stop scheduling.
        last=float(_manual_tail_heal_last_started.get(key,0) or 0)
        if now-last < 2.0:
            previous=dict(_manual_tail_heal_last.get(key) or {})
            return previous or {'status':'cooldown','tail':key[0],'sourceBlock':key[1]}
        _manual_tail_heal_last_started[key]=now
        _manual_tail_heal_running.add(key)
        _manual_tail_heal_last[key]={'status':'scheduled','tail':key[0],'sourceBlock':key[1],
            'producer':'web-self-heal','reportedAt':datetime.now(timezone.utc).isoformat()}
        threading.Thread(target=_manual_tail_heal_task,args=key,
            name=f'god8-manual-tail-heal-{key[0]}',daemon=True).start()
        return dict(_manual_tail_heal_last[key])


@app.after_request
def prevent_api_cache(response):
    if request.path.startswith('/api/'):
        response.headers['Cache-Control']='no-store, max-age=0'
    return response


def rows(sql, args=()):
    with DB() as c:
        q = c.cursor()
        q.execute(sql, args)
        result = q.fetchall()
        q.close()
    return result


def canonical_period_row(row):
    """True only when a stored formal row matches today's canonical tail mapping."""
    try:
        ds,no=row[0].split(':',1)
        return int(row[2]) == target_block(ds,int(no))
    except (TypeError,ValueError,IndexError,AttributeError):
        return False

def newest_canonical(limit=200):
    candidates=rows('''SELECT period_key,single_count,target_block,numbers,created_at
                       FROM periods ORDER BY period_date DESC,period_no DESC LIMIT %s''',(limit,))
    return next((r for r in candidates if canonical_period_row(r)),None)


def canonical_recent_rows(limit=100):
    """Build the newest visible history from the canonical target block itself.

    The homepage must not depend on a stale pre-calibration row in ``periods``.
    For every issue we recompute its current canonical target and prefer the
    immutable raw block stored at that exact height. A matching formal period is
    only a fallback while raw history is being compacted. This makes the temporary
    3-tail replacement visible immediately without rewriting older genuine
    3-tail phases.
    """
    limit=max(1,min(int(limit),500))
    latest_idx=None
    fast=get_meta('fast_target_latest',{}) or {}
    try:
        key=fast.get('period')
        if key:
            ds,no=key.split(':',1)
            idx=pindex(ds,int(no))
            if int(fast.get('targetBlock'))==target_block(ds,int(no)):
                latest_idx=idx
    except (TypeError,ValueError,AttributeError):
        pass
    chain=(get_meta('chain_head',{}) or {}).get('block')
    if chain is not None:
        try:
            idx=first_complete_index(int(chain)+1)-1
            while target_block(*from_index(idx))>int(chain):
                idx-=1
            latest_idx=max(latest_idx,idx) if latest_idx is not None else idx
        except (TypeError,ValueError):
            pass
    saved=newest_canonical(max(200,limit*3))
    if saved:
        try:
            ds,no=saved[0].split(':',1)
            idx=pindex(ds,int(no))
            latest_idx=max(latest_idx,idx) if latest_idx is not None else idx
        except (TypeError,ValueError,AttributeError):
            pass
    if latest_idx is None:
        return []

    # Over-read so an invalid hash or a temporarily missing block does not make
    # the homepage short. 500 candidates is enough for the 100-row home view.
    indices=list(range(latest_idx,max(-1,latest_idx-max(limit*4,160)),-1))
    specs=[]
    for idx in indices:
        ds,no=from_index(idx); specs.append((idx,f'{ds}:{no:04d}',target_block(ds,no)))
    targets=[x[2] for x in specs]; keys=[x[1] for x in specs]
    raw_rows=rows('''SELECT block_number,numbers,single_count FROM raw_blocks
                     WHERE block_number=ANY(%s)''',(targets,))
    raw={int(r[0]):r for r in raw_rows}
    formal_rows=rows('''SELECT period_key,single_count,target_block,numbers FROM periods
                        WHERE period_key=ANY(%s)''',(keys,))
    formal={r[0]:r for r in formal_rows}
    out=[]
    for _,key,tb in specs:
        r=raw.get(int(tb))
        if r is not None:
            out.append((key,r[2],tb,r[1]))
        else:
            p=formal.get(key)
            if p is not None and int(p[2])==int(tb):
                out.append((p[0],p[1],p[2],p[3]))
        if len(out)>=limit:
            break
    return out


@app.get('/')
def home():
    return render_template('home.html')


@app.get('/runtime-config')
def runtime_config_page():
    return render_template('runtime_config.html')


def _admin_ok():
    expected=os.getenv('ADMIN_TOKEN','')
    supplied=request.headers.get('X-Admin-Token','')
    if not supplied and request.is_json:
        supplied=str((request.get_json(silent=True) or {}).get('token',''))
    return bool(expected and supplied and hmac.compare_digest(expected,supplied))


# v2.0.8: passive block-race timing lab. It never calls a betting/platform API;
# it only timestamps the first time this Web service can obtain a future TRON block.
_block_race_lock = threading.Lock()
_block_race_generation = 0
_block_race_state = {
    'active': False, 'status': 'idle', 'targetBlock': None, 'armedMs': None,
    'latestHead': None, 'distance': None, 'polls': 0, 'errors': 0,
    'lastRequestMs': None, 'headSeenMs': None, 'firstSeenMs': None,
    'chainMs': None, 'blockId': None, 'captureSource': None, 'error': None,
}


def _race_now_ms():
    return time.time_ns() // 1_000_000


def _race_beijing(ms):
    if ms is None:
        return None
    try:
        dt=datetime.fromtimestamp(int(ms)/1000, timezone.utc).astimezone(CN)
        return dt.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    except (TypeError,ValueError,OverflowError):
        return None


def _race_ensure_table():
    with DB() as c:
        q=c.cursor()
        q.execute('''CREATE TABLE IF NOT EXISTS block_race_tests(
            target_block BIGINT PRIMARY KEY,
            armed_ms BIGINT NOT NULL,
            chain_ms BIGINT,
            head_seen_ms BIGINT,
            first_seen_ms BIGINT,
            block_id TEXT,
            capture_source TEXT,
            request_ms INT,
            polls INT DEFAULT 0,
            errors INT DEFAULT 0,
            platform_close_ms BIGINT,
            platform_open_ms BIGINT,
            note TEXT,
            updated_at TIMESTAMPTZ DEFAULT NOW()
        )''')
        q.close()


def _race_save_capture(snapshot):
    _race_ensure_table()
    with DB() as c:
        q=c.cursor()
        q.execute('''INSERT INTO block_race_tests(
            target_block,armed_ms,chain_ms,head_seen_ms,first_seen_ms,block_id,
            capture_source,request_ms,polls,errors,updated_at)
          VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NOW())
          ON CONFLICT(target_block) DO UPDATE SET
            armed_ms=EXCLUDED.armed_ms,chain_ms=EXCLUDED.chain_ms,
            head_seen_ms=EXCLUDED.head_seen_ms,first_seen_ms=EXCLUDED.first_seen_ms,
            block_id=EXCLUDED.block_id,capture_source=EXCLUDED.capture_source,
            request_ms=EXCLUDED.request_ms,polls=EXCLUDED.polls,errors=EXCLUDED.errors,
            updated_at=NOW()''',(
            snapshot.get('targetBlock'),snapshot.get('armedMs'),snapshot.get('chainMs'),
            snapshot.get('headSeenMs'),snapshot.get('firstSeenMs'),snapshot.get('blockId'),
            snapshot.get('captureSource'),snapshot.get('lastRequestMs'),snapshot.get('polls',0),
            snapshot.get('errors',0)))
        q.close()


def _race_record(row):
    if not row:
        return None
    keys=('targetBlock','armedMs','chainMs','headSeenMs','firstSeenMs','blockId',
          'captureSource','requestMs','polls','errors','platformCloseMs','platformOpenMs','note')
    out=dict(zip(keys,row[:len(keys)]))
    for k in ('armedMs','chainMs','headSeenMs','firstSeenMs','platformCloseMs','platformOpenMs'):
        out[k.replace('Ms','Beijing')]=_race_beijing(out.get(k))
    chain=out.get('chainMs'); seen=out.get('firstSeenMs')
    close=out.get('platformCloseMs'); opened=out.get('platformOpenMs')
    out['chainToUsMs']=(seen-chain) if seen is not None and chain is not None else None
    out['closeToChainMs']=(chain-close) if chain is not None and close is not None else None
    out['closeToUsMs']=(seen-close) if seen is not None and close is not None else None
    out['usVsPlatformMs']=(opened-seen) if opened is not None and seen is not None else None
    return out


def _race_history(limit=10):
    try:
        _race_ensure_table()
        with DB() as c:
            q=c.cursor()
            q.execute('''SELECT target_block,armed_ms,chain_ms,head_seen_ms,first_seen_ms,block_id,
                     capture_source,request_ms,polls,errors,platform_close_ms,platform_open_ms,note
                     FROM block_race_tests ORDER BY updated_at DESC LIMIT %s''',(int(limit),))
            rs=q.fetchall(); q.close()
        return [_race_record(r) for r in rs]
    except Exception:
        return []


def _race_worker(target, generation, armed_ms):
    polls=0; errors=0; head_seen=None
    while True:
        with _block_race_lock:
            if generation != _block_race_generation or not _block_race_state.get('active'):
                return
        try:
            req0=_race_now_ms()
            latest=fetch_latest()
            req1=_race_now_ms()
            polls+=1
            head=int(latest['number']); distance=int(target)-head
            with _block_race_lock:
                if generation != _block_race_generation:
                    return
                _block_race_state.update(latestHead=head,distance=distance,polls=polls,errors=errors,
                    lastRequestMs=max(0,req1-req0),error=None,status='watching')
            captured=None; source=None; request_ms=max(0,req1-req0); captured_ms=None
            if head == target:
                head_seen=req1
                captured=latest; source='getnowblock'; captured_ms=req1
            elif head > target:
                head_seen=req1
                b0=_race_now_ms(); captured=fetch_block(target); b1=_race_now_ms()
                source='getblockbynum'; captured_ms=b1; request_ms=max(0,b1-b0)
            if captured is not None:
                snapshot={
                    'active':False,'status':'captured','targetBlock':int(target),'armedMs':int(armed_ms),
                    'latestHead':head,'distance':head-int(target),'polls':polls,'errors':errors,
                    'lastRequestMs':request_ms,'headSeenMs':head_seen,'firstSeenMs':captured_ms,
                    'chainMs':int(captured.get('timestamp')) if captured.get('timestamp') is not None else None,
                    'blockId':captured.get('hash'),'captureSource':source,'error':None,
                }
                with _block_race_lock:
                    if generation != _block_race_generation:
                        return
                    _block_race_state.update(snapshot)
                try:
                    _race_save_capture(snapshot)
                except Exception as exc:
                    with _block_race_lock:
                        _block_race_state['error']='保存测速记录失败：'+str(exc)[:180]
                return
            if distance > 10:
                delay=1.0
            elif distance > 3:
                delay=0.45
            elif distance > 1:
                delay=0.18
            else:
                delay=0.10
            time.sleep(delay)
        except Exception as exc:
            errors+=1
            with _block_race_lock:
                if generation != _block_race_generation:
                    return
                _block_race_state.update(errors=errors,error=str(exc)[:240],status='retrying')
            time.sleep(0.35 if errors < 4 else 0.8)


def _race_parse_platform_time(value, reference_ms):
    raw=str(value or '').strip()
    if not raw:
        return None
    formats=('%Y-%m-%d %H:%M:%S.%f','%Y-%m-%d %H:%M:%S','%H:%M:%S.%f','%H:%M:%S')
    parsed=None; used=None
    for fmt in formats:
        try:
            parsed=datetime.strptime(raw,fmt); used=fmt; break
        except ValueError:
            continue
    if parsed is None:
        raise ValueError('时间格式请用 HH:MM:SS、HH:MM:SS.000 或 YYYY-MM-DD HH:MM:SS.000')
    ref=datetime.fromtimestamp(int(reference_ms)/1000,timezone.utc).astimezone(CN)
    if used.startswith('%H'):
        candidates=[]
        for shift in (-1,0,1):
            day=(ref+timedelta(days=shift)).date()
            candidates.append(datetime.combine(day,parsed.time(),tzinfo=CN))
        parsed=min(candidates,key=lambda d:abs(d.timestamp()*1000-int(reference_ms)))
    else:
        parsed=parsed.replace(tzinfo=CN)
    return int(round(parsed.timestamp()*1000))


@app.get('/block-race')
def block_race_page():
    return render_template('block_race.html', version=APP_VERSION)


@app.get('/api/block-race/state')
def block_race_state_api():
    with _block_race_lock:
        state=dict(_block_race_state)
    for k in ('armedMs','chainMs','headSeenMs','firstSeenMs'):
        state[k.replace('Ms','Beijing')]=_race_beijing(state.get(k))
    if state.get('chainMs') is not None and state.get('firstSeenMs') is not None:
        state['chainToUsMs']=state['firstSeenMs']-state['chainMs']
    else:
        state['chainToUsMs']=None
    return jsonify({'ok':True,'version':APP_VERSION,'state':state,'history':_race_history(10)})


@app.post('/api/block-race/start')
def block_race_start_api():
    global _block_race_generation, _block_race_state
    if not _admin_ok():
        return jsonify({'ok':False,'error':'管理员口令不正确'}),403
    body=request.get_json(silent=True) or {}
    try:
        target=int(body.get('targetBlock'))
        if target <= 0: raise ValueError()
    except (TypeError,ValueError):
        return jsonify({'ok':False,'error':'请输入正确的目标区块号'}),400
    with _block_race_lock:
        if _block_race_state.get('active'):
            return jsonify({'ok':False,'error':'已有目标正在监听，请先停止'}),409
    try:
        pre0=_race_now_ms(); latest=fetch_latest(); pre1=_race_now_ms()
        head=int(latest['number'])
    except Exception as exc:
        return jsonify({'ok':False,'error':'TRON 链头查询失败：'+str(exc)[:200]}),502
    if target <= head:
        return jsonify({'ok':False,'error':f'目标区块 {target} 已产生（当前链头 {head}），请提前输入未来区块，避免测速失真。'}),400
    armed=_race_now_ms()
    with _block_race_lock:
        _block_race_generation+=1; generation=_block_race_generation
        _block_race_state={
            'active':True,'status':'watching','targetBlock':target,'armedMs':armed,
            'latestHead':head,'distance':target-head,'polls':0,'errors':0,
            'lastRequestMs':max(0,pre1-pre0),'headSeenMs':None,'firstSeenMs':None,
            'chainMs':None,'blockId':None,'captureSource':None,'error':None,
        }
    threading.Thread(target=_race_worker,args=(target,generation,armed),
                     name=f'block-race-{target}',daemon=True).start()
    return jsonify({'ok':True,'targetBlock':target,'currentHead':head,'armedBeijing':_race_beijing(armed)})


@app.post('/api/block-race/stop')
def block_race_stop_api():
    global _block_race_generation
    if not _admin_ok():
        return jsonify({'ok':False,'error':'管理员口令不正确'}),403
    with _block_race_lock:
        _block_race_generation+=1
        _block_race_state['active']=False
        _block_race_state['status']='stopped'
    return jsonify({'ok':True})


@app.post('/api/block-race/platform')
def block_race_platform_api():
    if not _admin_ok():
        return jsonify({'ok':False,'error':'管理员口令不正确'}),403
    body=request.get_json(silent=True) or {}
    try:
        target=int(body.get('targetBlock'))
    except (TypeError,ValueError):
        return jsonify({'ok':False,'error':'目标区块错误'}),400
    _race_ensure_table()
    with DB() as c:
        q=c.cursor();q.execute('''SELECT target_block,armed_ms,chain_ms,head_seen_ms,first_seen_ms,block_id,
            capture_source,request_ms,polls,errors,platform_close_ms,platform_open_ms,note
            FROM block_race_tests WHERE target_block=%s''',(target,)); row=q.fetchone();q.close()
    record=_race_record(row)
    if not record or record.get('firstSeenMs') is None:
        return jsonify({'ok':False,'error':'该目标还没有我方首次获取记录'}),404
    ref=record.get('chainMs') or record.get('firstSeenMs')
    try:
        close_ms=_race_parse_platform_time(body.get('platformClose'),ref) if body.get('platformClose') else None
        open_ms=_race_parse_platform_time(body.get('platformOpen'),record.get('firstSeenMs')) if body.get('platformOpen') else None
    except ValueError as exc:
        return jsonify({'ok':False,'error':str(exc)}),400
    note=str(body.get('note') or '')[:300]
    with DB() as c:
        q=c.cursor();q.execute('''UPDATE block_race_tests SET platform_close_ms=%s,platform_open_ms=%s,note=%s,updated_at=NOW()
                                  WHERE target_block=%s''',(close_ms,open_ms,note,target));q.close()
    updated=next((r for r in _race_history(20) if int(r['targetBlock'])==target),None)
    return jsonify({'ok':True,'record':updated})


@app.get('/api/runtime-config')
def runtime_config_data():
    cfg=runtime_config(force=True)
    return jsonify({'version':APP_VERSION,'revision':runtime_config_revision(),
                    'config':cfg,'reloadSeconds':cfg.get('reloadSeconds',2),
                    'collector':get_meta('collector_release',{}),
                    'calibration':get_meta('platform_calibration',{}),
                    'note':'配置保存在数据库；各服务自动刷新，不需要手动重启。'})


@app.post('/api/runtime-config')
def runtime_config_update():
    if not _admin_ok():
        return jsonify({'ok':False,'error':'ADMIN_TOKEN 不正确'}),403
    body=request.get_json(silent=True) or {}
    candidate=body.get('config',body)
    if not isinstance(candidate,dict):
        return jsonify({'ok':False,'error':'config 必须是 JSON 对象'}),400
    try:
        saved=set_runtime_config(candidate)
    except Exception as exc:
        return jsonify({'ok':False,'error':str(exc)[:300]}),400
    return jsonify({'ok':True,'revision':saved['revision'],'config':saved,
                    'effectiveWithinSeconds':saved.get('reloadSeconds',2),
                    'note':'规则已写入数据库。当前已锁定预测不追改；后续计算自动使用新配置。'})


@app.post('/api/runtime-config/tail-override')
def runtime_tail_override():
    if not _admin_ok():
        return jsonify({'ok':False,'error':'ADMIN_TOKEN 不正确'}),403
    body=request.get_json(silent=True) or {}
    try:
        start_ds,start_no=parse_issue(str(body.get('startIssue','')))
        end_raw=str(body.get('endIssue','') or '').strip()
        if end_raw:
            end_ds,end_no=parse_issue(end_raw); end_period=f'{end_ds}:{end_no:04d}'
        else:
            end_period=None
        tail=int(body.get('tail'))
        if not 0<=tail<=9: raise ValueError('尾数须为0至9')
        saved=add_runtime_tail_override(f'{start_ds}:{start_no:04d}',end_period,tail,
                                        label=str(body.get('label') or 'manual-hot-tail'))
    except Exception as exc:
        return jsonify({'ok':False,'error':str(exc)[:300]}),400
    return jsonify({'ok':True,'revision':saved['revision'],'config':saved,
                    'effectiveWithinSeconds':saved.get('reloadSeconds',2),
                    'note':'尾数覆盖已写入数据库，无需重启。'})


@app.post('/api/runtime-config/reset')
def runtime_config_reset():
    if not _admin_ok():
        return jsonify({'ok':False,'error':'ADMIN_TOKEN 不正确'}),403
    saved=set_runtime_config(DEFAULT_RUNTIME_CONFIG)
    return jsonify({'ok':True,'revision':saved['revision'],'config':saved})


@app.get('/playbook')
def playbook():
    return render_template('playbook.html')



@app.get('/manual-tail')
def manual_tail_page():
    return render_template('manual_tail.html')


@app.get('/api/manual-tail')
def manual_tail_data():
    raw=request.args.get('tail')
    try:
        tail=manual_tail_selected() if raw in (None,'') else int(raw)
        if tail<0 or tail>9: raise ValueError()
        payload=manual_tail_report(tail)
        payload.setdefault('parentWorker',{})['direct']=direct_worker_heartbeat()
        latest=payload.get('latest') or {}
        source_block=latest.get('block')
        # Only the actively selected tail gets an automatic web kick.  This
        # preserves the independence of passive history browsing for other tails.
        if (payload.get('phase')=='waiting' and source_block is not None
                and int(tail)==int(manual_tail_selected())):
            payload['webSelfHeal']=schedule_manual_tail_heal(tail,source_block)
        elif source_block is not None:
            key=(int(tail),int(source_block))
            payload['webSelfHeal']=dict(_manual_tail_heal_last.get(key) or {'status':'idle'})
        else:
            payload['webSelfHeal']={'status':'waiting-source'}
        return jsonify(payload)
    except ValueError:
        return jsonify({'error':'尾数必须是0至9'}),400


@app.get('/api/manual-tail/live')
def manual_tail_live_data():
    raw=request.args.get('tail')
    try:
        tail=manual_tail_selected() if raw in (None,'') else int(raw)
        if tail<0 or tail>9: raise ValueError()
        response=jsonify(manual_tail_live_report(tail))
        response.headers['Cache-Control']='no-store, no-cache, must-revalidate, max-age=0'
        return response
    except ValueError:
        return jsonify({'error':'尾数必须是0至9'}),400


@app.get('/api/manual-tail/history')
def manual_tail_history_data():
    try:
        tail=int(request.args.get('tail',manual_tail_selected()))
        page=int(request.args.get('page','1'))
        if tail<0 or tail>9 or page<1: raise ValueError()
        return jsonify(manual_tail_history(tail,page,100))
    except ValueError:
        return jsonify({'error':'尾数或页码无效'}),400


@app.post('/api/manual-tail/select')
def manual_tail_select_data():
    body=request.get_json(silent=True) or {}
    try:
        return jsonify({'ok':True,'selection':manual_tail_select(int(body.get('tail')))})
    except (TypeError,ValueError):
        return jsonify({'ok':False,'error':'尾数必须是0至9'}),400


@app.post('/api/manual-tail/backfill')
def manual_tail_backfill_control():
    body=request.get_json(silent=True) or {}
    enabled=bool(body.get('enabled'))
    state=manual_tail_set_backfill(enabled)
    return jsonify({'ok':True,'backfill':state})

@app.get('/replay')
def replay_page():
    return render_template('replay.html')


@app.get('/fate')
def fate_page():
    return render_template('fate.html')


@app.get('/api/fate/ledger')
def fate_ledger():
    forecasts=rows('''SELECT period_key,source_period,choices,match,locked_at,
                             actual,settled_at,source_block
                      FROM replay_forecasts ORDER BY period_key DESC LIMIT 1000''')
    targets={}
    for period,source,*_ in forecasts:
        for key in (period,source):
            if key and key not in targets:
                ds,no=key.split(':',1);targets[key]=target_block(ds,int(no))
    block_numbers=list(set(targets.values()))
    block_times={}
    if block_numbers:
        block_times={int(n):t for n,t in rows('''SELECT block_number,block_time FROM raw_blocks
                                                WHERE block_number=ANY(%s)''',(block_numbers,))}
    data=[]
    for period,source,choices,match,locked,actual,settled,source_block in forecasts:
        target=targets.get(period);source_target=targets.get(source)
        data.append((period,source,choices,match,locked,actual,settled,
                     block_times.get(target),source_block,target,source_target))
    result=summarize_ledger(data)
    result['canonicalSource']='target_block+raw_blocks'
    return jsonify(result)


@app.get('/chase')
def chase_page():
    return render_template('chase.html')


@app.get('/api/chase/replay-streaks')
def chase_replay_streaks():
    history=rows('''SELECT period_key,choices,actual,locked_at,settled_at
                    FROM replay_forecasts WHERE settled_at IS NOT NULL
                    ORDER BY period_key DESC LIMIT 10000''')
    return jsonify(replay_streak_summary(history))


@app.get('/history')
def history():
    return render_template('history.html')


@app.get('/statistics')
def statistics():
    return render_template('statistics.html')


@app.get('/api/statistics/research')
def statistics_research():
    canonical=canonical_load(limit=10001,newest_first=True)
    historical=canonical_pairs(canonical)
    historical.reverse()
    return jsonify({'sample':len(historical), 'streaks':streak_report(historical),
                    'patterns':pattern_report(historical),'canonical':canonical_quality(canonical)})


@app.get('/api/playbook')
def playbook_data():
    try:
        window=int(request.args.get('window','1000'))
        if window not in (30,100,500,1000,10000):raise ValueError('期数无效')
        mode=request.args.get('mode','special')
        kind=request.args.get('kind','wave')
        value=request.args.get('value','红波')
        filters={name:request.args.get(name,'') for name in ('wave','parity','size')}
        # Validate before hitting the database (also refuse empty combinations).
        summarize([],mode,kind,value,**filters)
    except ValueError as exc:
        return jsonify({'error':str(exc)}),400
    canonical=canonical_load(limit=window,newest_first=True)
    history_rows=[(r[0],r[5],r[6]) for r in canonical]
    result=summarize(history_rows,mode,kind,value,**filters)
    result['canonical']=canonical_quality(canonical)
    return jsonify(result)


@app.get('/api/playbook/block-tail')
def playbook_block_tail():
    raw_tail=request.args.get('tail','')
    if not re.fullmatch(r'[0-9]',raw_tail):
        return jsonify({'error':'请输入0至9的区块尾数'}),400
    tail=int(raw_tail)
    combined=tail_rows(tail,10000)
    chronological=[(r['block'],r['single']) for r in reversed(combined)]
    report=analyze_blocks(chronological,tail)
    report['totalBlocks']=tail_total(tail)
    legacy_in_sample=sum(not r['materialized'] for r in combined)
    imported,import_error=materialize_legacy(combined,1000)
    report['legacyBridge']={'legacyOnlyInSample':legacy_in_sample,
                            'materializedNow':imported,
                            'error':import_error}
    report['collectorVersion']=(get_meta('collector_release') or {}).get('version')
    report['webVersion']=APP_VERSION
    now=datetime.now(CN)
    current_no=now.hour*60+now.minute
    current_day=now.date() if current_no else now.date()-timedelta(days=1)
    if not current_no:current_no=1440
    current_block=target_block(current_day.isoformat(),current_no)
    report['currentMapping']={'issue':issue_no(f'{current_day.isoformat()}:{current_no:04d}'),
                              'targetBlock':current_block,'tail':current_block%10}
    return jsonify(report)


@app.get('/api/playbook/block-tail/history')
def playbook_block_tail_history():
    raw_tail=request.args.get('tail','')
    raw_page=request.args.get('page','1')
    if not re.fullmatch(r'[0-9]',raw_tail) or len(raw_page)>4 or not re.fullmatch(r'[1-9][0-9]*',raw_page):
        return jsonify({'error':'请输入0至9的区块尾数及有效页码'}),400
    tail=int(raw_tail)
    requested=int(raw_page)
    total=tail_total(tail)
    pages=max(1,(total+99)//100)
    page=min(requested,pages)
    data=tail_rows(tail,100,(page-1)*100)
    mapping=period_map(r['block'] for r in data)
    imported,import_error=materialize_legacy(data,100)
    records=[]
    for row in data:
        key=mapping.get(row['block'])
        records.append({'period':key,
                        'issue':issue_no(key) if key else None,
                        'block':row['block'],'single':row['single'],'numbers':row['numbers'],
                        'legacySource':not row['materialized']})
    return jsonify({'tail':tail,'page':page,'pageSize':100,'pages':pages,
                    'total':total,'rows':records,
                    'legacyBridge':{'materializedNow':imported,'error':import_error}})


@app.get('/api/playbook/replay')
def playbook_replay():
    try:
        window=int(request.args.get('window','10000'))
        if window not in (500,1000,2500,10000):raise ValueError()
    except ValueError:
        return jsonify({'error':'复盘范围须为500、1000、2500或10000期'}),400
    canonical=canonical_load(limit=window,newest_first=True)
    data=canonical_analysis(canonical)
    result=simulate(data);result['canonical']=canonical_quality(canonical)
    return jsonify(result)


@app.get('/api/replay/lab')
def lab_backtest():
    try:
        window=int(request.args.get('window','10000'))
        if window not in (500,1000,2500,10000):raise ValueError()
    except ValueError:
        return jsonify({'error':'复盘范围须为500、1000、2500或10000期'}),400
    canonical=canonical_load(limit=window,newest_first=True)
    data=canonical_analysis(canonical)
    result=analyze(data);result['canonical']=canonical_quality(canonical)
    return jsonify(result)


@app.get('/api/replay/lab/live')
def lab_live():
    latest_canonical=canonical_load(limit=1,newest_first=True)
    latest=[(latest_canonical[0][0],)] if latest_canonical and latest_canonical[0][8] else []
    saved=rows('''SELECT period_key,source_period,choices,ai_prediction,ai_method,
                        weights,locked_at,actual,settled_at
                 FROM lab_forecasts ORDER BY locked_at DESC LIMIT 1''')
    counts=rows('''SELECT COUNT(*),
                      COUNT(*) FILTER (WHERE actual=(choices->>0)::int),
                      COUNT(*) FILTER (WHERE actual=(choices->>1)::int),
                      COUNT(*) FILTER (WHERE actual IN ((choices->>0)::int,(choices->>1)::int)),
                      COUNT(*) FILTER (WHERE actual=ai_prediction)
                 FROM lab_forecasts WHERE settled_at IS NOT NULL AND actual BETWEEN 0 AND 7''')[0]
    forecast=None
    if latest and saved:
        period,source,choices,guess,method,weights,locked,actual,settled=saved[0]
        if latest[0][0] in (period,source):
            forecast={'issue':issue_no(period),'choices':choices,'aiPrediction':guess,
                      'method':method,'methodName':LABELS.get(method,method),
                      'weights':weights,'lockedAt':locked.isoformat(),
                      'actual':actual,'settledAt':settled.isoformat() if settled else None}
    n,first,second,either,ai=counts
    return jsonify({'forecast':forecast,'verified':n,
                    'first':{'hits':first,'rate':first/n if n else None},
                    'second':{'hits':second,'rate':second/n if n else None},
                    'either':{'hits':either,'rate':either/n if n else None},
                    'ai':{'hits':ai,'rate':ai/n if n else None}})


@app.get('/api/replay/live')
def replay_live():
    """Read the current forecast and self-heal a missing pending forecast."""
    self_heal=None

    def snapshot():
        latest_rows=canonical_load(limit=1,newest_first=True)
        canonical_latest=latest_rows[0] if latest_rows and latest_rows[0][8] else None
        current=[(canonical_latest[0],canonical_latest[6],canonical_latest[7])] if canonical_latest else []
        saved=rows("""SELECT period_key,source_period,choices,match,locked_at,actual,settled_at
                    FROM replay_forecasts ORDER BY locked_at DESC LIMIT 4""")
        latest=current[0] if current else None
        selected=None;hold_seconds=0;phase=None;target_head=None;selected_block=None
        if latest:
            # Exact result-hold contract: once the forecast for the latest
            # period is settled, keep those judged cards visible for 10 full
            # seconds from settled_at. Do not replace them with a text notice.
            settled_row=next((r for r in saved if r[0]==latest[0] and r[6] is not None),None)
            if settled_row:
                age=(datetime.now(timezone.utc)-settled_row[6]).total_seconds()
                if 0<=age<RESULT_HOLD_SECONDS:
                    selected=settled_row
                    hold_seconds=max(0,RESULT_HOLD_SECONDS-age)
                    phase='result'
                elif RESULT_HOLD_SECONDS<=age<RESULT_REVEAL_SECONDS:
                    phase='analyzing'
            elif latest[2] is not None:
                age=(datetime.now(timezone.utc)-latest[2]).total_seconds()
                if RESULT_HOLD_SECONDS<=age<RESULT_REVEAL_SECONDS:
                    phase='analyzing'
            if selected is None:
                pending=next((r for r in saved if r[1]==latest[0] and r[6] is None),None)
                if pending:
                    try:
                        ds,no=pending[0].split(':')
                        selected_block=target_block(ds,int(no))
                        chain=(get_meta('chain_head') or {})
                        target_head=chain.get('block')
                        known=bool(rows('''SELECT 1 FROM raw_blocks WHERE block_number=%s LIMIT 1''',
                                        (selected_block,)))
                        if chain.get('seenAt') and pending_target_future(
                                pending[0],selected_block,target_head,known,
                                chain.get('seenAt')):
                            # The normal 20s hold applies unless the collector
                            # deliberately locked early to beat a close target.
                            age=(datetime.now(timezone.utc)-(settled_row[6] if settled_row else latest[2])).total_seconds()
                            if age>=RESULT_REVEAL_SECONDS or (age>=RESULT_HOLD_SECONDS and
                                    selected_block-int(target_head)<=8):
                                selected=pending
                                phase='predicted'
                        else:
                            phase='waiting-result'
                    except (TypeError,ValueError,AttributeError):
                        phase='waiting-result'
        return latest,selected,hold_seconds,phase,target_head,selected_block

    latest,selected,hold_seconds,phase,target_head,selected_block=snapshot()
    # Third watchdog, but never inside the request itself.  A 10k simulation
    # can take seconds; running it inline used to leave the browser's first
    # /api/replay/live request pending and suppress every later poll.  Schedule
    # one daemon kick and return the current snapshot immediately.
    if latest and selected is None:
        self_heal=schedule_replay_heal()
    else:
        self_heal=dict(_replay_heal_last)

    counts=rows("""SELECT COUNT(*),
                       COUNT(*) FILTER (WHERE actual=(choices->>0)::int),
                       COUNT(*) FILTER (WHERE actual=(choices->>1)::int),
                       COUNT(*) FILTER (WHERE actual IN ((choices->>0)::int,(choices->>1)::int))
                    FROM replay_forecasts WHERE settled_at IS NOT NULL AND actual BETWEEN 0 AND 7""")[0]
    forecast=None
    if selected:
        period,source,choices,match,locked,actual,settled=selected
        if latest and latest[0] in (source,period):
            forecast={'period':period,'issue':issue_no(period),'sourcePeriod':source,
                      'choices':choices,'match':match,'lockedAt':locked.isoformat(),
                      'targetBlock':selected_block if not settled else None,
                      'actual':actual,'settledAt':settled.isoformat() if settled else None,
                      'firstHit':actual==choices[0] if settled and actual is not None else None,
                      'secondHit':actual==choices[1] if settled and actual is not None else None}
    n,first,second,either=counts
    return jsonify({'forecast':forecast,'resultHoldSeconds':round(hold_seconds,1),
                    'phase':phase or ('predicted' if forecast else 'waiting'),
                    'latest':{'period':latest[0],'single':latest[1],'savedAt':latest[2].isoformat()} if latest else None,
                    'runtime':get_meta('prediction_runtime',{}),
                    'webSelfHeal':self_heal,
                    'workerWatchdog':get_meta('prediction_worker_watchdog',{}),
                    'predictionError':get_meta('replay_error',{}) or get_meta('prediction_worker_error',{}),
                    'stats':{'verified':n,'firstHits':first,'secondHits':second,
                             'eitherHits':either,'firstRate':first/n if n else None,
                             'secondRate':second/n if n else None,
                             'eitherRate':either/n if n else None}})

@app.get('/api/omission/chase')
def omission_chase():
    canonical=canonical_load()
    data=canonical_pairs(canonical)
    result=chase_comparison(data);result['canonical']=canonical_quality(canonical)
    return jsonify(result)


@app.get('/api/omission/recommend200')
def omission_recommend200():
    canonical=canonical_load(limit=200,newest_first=True)
    data=[(r[0],r[6],r[3]) for r in canonical]
    mapping_valid=all(r[8] and r[6] is not None for r in canonical)
    now=datetime.now(CN)
    current=pindex(now.date().isoformat(),now.hour*60+now.minute)
    latest_age=current-issue_index(data[0][0]) if data else None
    result=recommend_recent(data,mapping_valid=mapping_valid,latest_age=latest_age)
    result['canonical']=canonical_quality(canonical)
    return jsonify(result)


NAMES = ('god8-collector', 'god8-worker-ai', 'god8-web', 'god8-db')


def ai_alive(heartbeat):
    stamped = heartbeat.get('reportedAt')
    if not stamped:
        return False
    try:
        return (datetime.now(timezone.utc)-datetime.fromisoformat(stamped)).total_seconds()<60
    except ValueError:
        return False


@app.get('/services')
@app.get('/services/<role>')
def services(role=None):
    if role and role not in ('monitor', 'worker', 'audit', 'db', 'ai'):
        return 'Unknown service', 404
    return render_template('services.html', role=role or 'all')


@app.get('/checks')
def checks():
    """Human-readable index of existing status reports and read-only checks."""
    return render_template('checks.html')


@app.get('/api/services')
def service_data():
    counts = rows('''SELECT (SELECT COUNT(*) FROM raw_blocks),
                            (SELECT COUNT(*) FROM periods),
                            (SELECT COUNT(*) FROM groups),
                            (SELECT COUNT(*) FROM repair_queue),
                            (SELECT COUNT(*) FROM ai_simulations),
                            (SELECT COUNT(*) FROM ai_models),
                            pg_database_size(current_database()),
                            (SELECT COUNT(*) FROM manual_tail_blocks),
                            (SELECT COUNT(*) FROM manual_tail_predictions)''')[0]
    heartbeat = get_meta('ai_heartbeat', {}) or {}
    ai = get_meta('ai_status', {}) or {}
    if not ai_alive(heartbeat):
        ai = {'status':'not-started-or-offline', 'lastSavedStatus':ai.get('status')}
    history=get_meta('history_progress',{}) or {}
    history.update({'forward':get_meta('god8_forward',{}),
                    'origin':get_meta('god8_origin',{}),
                    'aiStage':get_meta('god8_ai_stage',{}),
                    'historicalCapture':get_meta('historical_capture',{}),
                    'recovery':get_meta('god8_forward_recovery',{}),
                    'live':get_meta('collector_live_cursor',{})})
    return jsonify({'names': NAMES, 'aiName': 'god8-worker-ai',
        'workerDirectHeartbeat':direct_worker_heartbeat(),
        'workerHeartbeat':get_meta('god8_worker_heartbeat',{}),
        'workerStartupHeartbeat':get_meta('god8_worker_startup_heartbeat',{}),
        'workerHandoff':get_meta('god8_worker_handoff',{}),
        'workerRelease':get_meta('god8_worker_release',{}),
        'monitor': get_meta('monitor_stats', {}),
        'liveLatency':get_meta('collector_live_latency',{}),
        'platformCalibration':get_meta('platform_calibration',{}),
        'platformCalibrationBootstrap':get_meta('platform_calibration_bootstrap',{}),
        'canonicalRevision':get_meta('canonical_data_revision',{}),
        'worker': history,
        'audit': {'repair': get_meta('audit_stats', {}),
                  'verification': get_meta('audit', {}),
                  'progress': get_meta('god8_audit_progress', {}),
                  'error': get_meta('audit_error', {}),
                  'failover': get_meta('audit_failover', {})},
        'db': dict(zip(('blocks','periods','groups','queuedRepairs','simulations','models','sizeBytes','manualTailBlocks','manualTailPredictions'),counts)) |
              {'retention':get_meta('god8_retention',{}),
               'manualTailBackfill':get_meta('manual_tail_backfill',{}),
               'manualTailAudit':get_meta('manual_tail_audit',{}),
               'manualTailLive':get_meta('manual_tail_live_sync',{}),
               'manualTailWorker':get_meta('manual_tail_worker',{}),
               'manualTailWorkerError':get_meta('manual_tail_worker_error',{})},
        'ai': {'status': {'status':'disabled'}, 'gate': get_meta('ai_gate', {}),
               'shadow': get_meta('ai_shadow', {}),
               'regime': get_meta('ai_streak_report', {}),
               'heartbeat': get_meta('ai_heartbeat', {}),
               'lock': get_meta('ai_lock_status', {}),
               'stageComparison':get_meta('god8_stage_comparison',{})},
        'predictionRuntime':get_meta('prediction_runtime',{}),
        'predictionWorker':get_meta('prediction_worker_watchdog',{}),
        'predictionError':get_meta('replay_error',{}) or get_meta('prediction_worker_error',{}),
        'runtimeConfig': {'revision':runtime_config_revision(),
                          'reloadSeconds':runtime_config().get('reloadSeconds',2),
                          'repairRequest':get_meta('runtime_repair_request',{})},
        'chain': get_meta('chain_head', {})})


@app.get('/ai-lab')
def ai_page():
    return render_template('statistics.html')


@app.get('/ai-lab-2')
def ai2_page():
    return render_template('statistics.html')


@app.get('/api/ai2')
def ai2_data():
    status=get_meta('ai2_status',{}) or {}
    models=rows('''SELECT m.id,m.method,m.stage_no,m.metrics,
                  COUNT(p.id) FILTER (WHERE p.valid=TRUE),
                  COUNT(p.id) FILTER (WHERE p.valid=TRUE AND p.prediction=p.actual)
                  FROM ai2_models m LEFT JOIN ai2_predictions p ON p.model_id=m.id
                  GROUP BY m.id ORDER BY m.id DESC LIMIT 50''')
    predictions=rows('''SELECT p.period_key,m.method,p.prediction,p.actual,p.valid,p.locked_at
                         FROM ai2_predictions p JOIN ai2_models m ON m.id=p.model_id
                         ORDER BY p.locked_at DESC LIMIT 50''')
    return jsonify({'status':status,'heartbeat':get_meta('ai2_heartbeat',{}),
                    'error':get_meta('ai2_error',{}),
                    'models':[{'id':r[0],'method':r[1],'stage':r[2],'metrics':r[3],
                               'realValid':r[4],'realHits':r[5],
                               'realRate':r[5]/r[4] if r[4] else None} for r in models],
                    'predictions':[{'issue':issue_no(r[0]),'method':r[1],
                                    'prediction':r[2],'actual':r[3],
                                    'valid':r[4],'lockedAt':r[5].isoformat()} for r in predictions]})


@app.get('/api/models')
def models():
    data = rows('''SELECT m.id,m.method,m.metrics,m.tier,m.adopted,m.artifact,
               COUNT(a.id) FILTER (WHERE a.valid=TRUE),
               COUNT(a.id) FILTER (WHERE a.valid=TRUE AND a.actual=a.prediction),
               COUNT(a.id) FILTER (WHERE a.valid=FALSE),
               COUNT(a.id) FILTER (WHERE a.actual IS NULL)
               FROM ai_models m LEFT JOIN ai_predictions a ON a.model_id=m.id
               GROUP BY m.id ORDER BY m.id DESC LIMIT 100''')
    result = []
    for mid,method,metrics,tier,adopted,artifact,n,hits,late,pending in data:
        result.append({'id':mid,'method':method,'metrics':metrics,'tier':tier,
            'adopted':adopted,'future':{'valid':n,'hits':hits,
            'late':late,'pending':pending,
            'rate':hits/n if n else 0,'wilsonLower95':wilson(hits,n),
            'eligible':(artifact or {}).get('revision')==REVISION and n>=300 and wilson(hits,n)>=.8 and
                       metrics.get('holdout',{}).get('wilsonLower95',0)>=.8}})
    return jsonify(result)


@app.get('/api/ai/simulations')
def simulations():
    method = request.args.get('method','')
    if method not in METHODS:
        return jsonify({'error':'请选择有效的练习方法'}),400
    try:
        page = max(1,min(1000,int(request.args.get('page','1'))))
    except ValueError:
        return jsonify({'error':'页码无效'}),400
    fp = (get_meta('ai_status') or {}).get('trainsetFingerprint','')
    train_id = (get_meta('ai_status') or {}).get('trainsetId','')
    result = rows('''SELECT period_key,phase,prediction,actual FROM ai_simulations
                     WHERE trainset_id=%s AND method=%s
                     ORDER BY period_key DESC LIMIT 100 OFFSET %s''',
                  (train_id,method,100*(page-1))) if fp else []
    return jsonify({'method':method,'page':page,'rows':[
        {'period':r[0],'phase':r[1],'prediction':r[2],'actual':r[3],
         'hit':r[2]==r[3]} for r in result]})


@app.get('/api/ai/switches')
def switches():
    data = rows('''SELECT occurred_at,from_model_id,to_model_id,reason
                   FROM ai_switches ORDER BY id DESC LIMIT 20''')
    return jsonify([{'at':r[0].isoformat(),'fromId':r[1],
                    'toId':r[2],'reason':r[3]} for r in data])


@app.get('/api/ai/streaks')
def streaks():
    canonical=canonical_load(limit=10001,newest_first=True)
    data=canonical_pairs(canonical);data.reverse()
    result=streak_report(data);result['canonical']=canonical_quality(canonical)
    result['source']='canonical-live-history'
    return jsonify(result)


@app.get('/api/ai/patterns')
def patterns():
    canonical=canonical_load(limit=10001,newest_first=True)
    data=canonical_pairs(canonical);data.reverse()
    result=pattern_report(data);result['canonical']=canonical_quality(canonical)
    result['source']='canonical-live-history'
    return jsonify(result)


@app.get('/api/ai/diagnostic')
def ai_diagnostic():
    """Expose actual learning cadence and pre-result evidence, without creating predictions."""
    status=get_meta('ai_status',{}) or {}
    stage=get_meta('god8_ai_stage',{}) or {}
    forward=get_meta('god8_forward',{}) or {}
    heartbeat=get_meta('ai_heartbeat',{}) or {}
    lock=get_meta('ai_lock_status',{}) or {}
    completed=max(0,int(forward.get('completedSinceOrigin') or 0))
    processed=int(stage.get('processed',-1))
    next_target=(processed+2)*10000
    selected=[x for x in status.get('selectedTopTwo',[]) if isinstance(x,dict) and x.get('id')]
    ids=[x['id'] for x in selected]
    evidence=rows('''SELECT model_id,
                     COUNT(*) FILTER (WHERE actual IS NULL),
                     COUNT(*) FILTER (WHERE actual IS NOT NULL AND valid=TRUE),
                     COUNT(*) FILTER (WHERE actual IS NOT NULL AND valid=TRUE AND prediction=actual),
                     COUNT(*) FILTER (WHERE actual IS NOT NULL AND valid=FALSE)
                     FROM ai_predictions WHERE model_id=ANY(%s) GROUP BY model_id''',(ids,)) if ids else []
    by_id={r[0]:r[1:] for r in evidence}
    candidates=[]
    for chosen in selected:
        pending,valid,hits,late=by_id.get(chosen['id'],(0,0,0,0))
        candidates.append({'id':chosen['id'],'method':chosen.get('method'),
                           'pending':pending,'valid':valid,'hits':hits,'late':late,
                           'rate':hits/valid if valid else None})
    if not ai_alive(heartbeat): explanation='Worker/AI 心跳未更新；先检查服务运行状态。'
    elif status.get('status')=='simulating': explanation='正在运行一轮历史方法比较，查看已完成的方法数。'
    elif processed<0: explanation='首段10,000期还未完成审计与训练。'
    elif completed<next_target: explanation='现有审计历史已比较全部候选方法；下一轮新数据评估须等新一段10,000期通过审计，开奖前影子验证在持续进行。'
    else: explanation='新一段期数已够；等待阶段审计或下一轮训练启动。'
    return jsonify({'explanation':explanation,'workerAlive':ai_alive(heartbeat),
                    'status':status.get('status'),'revision':status.get('revision'),
                    'completedSinceOrigin':completed,'lastTrainedStage':processed,
                    'nextStageAt':next_target,'roundsUntilNextStage':max(0,next_target-completed),
                    'methodsFinished':status.get('finishedMethods',0),
                    'methodsTotal':status.get('totalMethods',0),'candidates':candidates,
                    'lock':lock,'heartbeat':heartbeat,
                    'note':'有效样本仅统计开奖前锁定并被数据库验证的预测；运行两天不等于完成新训练阶段。'})


@app.post('/api/adopt/<int:model_id>')
def adopt(model_id):
    return jsonify({'ok':False,'error':'AI练习已停用，不能授权旧模型'}),410


@app.get('/api/status')
def status():
    return jsonify({'history': get_meta('history_progress', {}),
                    'audit': get_meta('audit', {}),
                    'trainset': get_meta('god8_trainset', {}),
                    'origin':get_meta('god8_origin',{}),
                    'retention':get_meta('god8_retention',{}),
                    'chain': get_meta('chain_head', {}),
                    'platformCalibration':get_meta('platform_calibration',{}),
        'platformCalibrationBootstrap':get_meta('platform_calibration_bootstrap',{}),
        'canonicalRevision':get_meta('canonical_data_revision',{}),
                    'gate': get_meta('ai_gate', {}),
                    'ai':get_meta('ai_status',{}),
                    'ai2':get_meta('ai2_status',{}),
                    'runtimeConfig':{'revision':runtime_config_revision(),
                                     'reloadSeconds':runtime_config().get('reloadSeconds',2)}})


@app.get('/api/recent')
def recent():
    data = canonical_recent_rows(30)
    return jsonify([{'period': x[0], 'issue': issue_no(x[0]), 'single': x[1], 'block': x[2],
                     'numbers': x[3]} for x in data])


@app.get('/api/pattern-memory/live')
def pattern_memory_live():
    report=get_meta('pattern_memory_live', {}) or {}
    if request.args.get('predict') != '1':
        report=practice_view(report)
    return jsonify(report)


@app.get('/api/live')
def live_snapshot():
    """Show a saved target hash immediately, before the 20-group audit finishes."""
    canonical_now=canonical_load(limit=4,newest_first=True)
    newest_row=canonical_now[0] if canonical_now else None
    latest_row=next((r for r in canonical_now if r[6] is not None and r[8]),None)
    newest=(newest_row[0],newest_row[6],newest_row[3],newest_row[5],newest_row[7]) if newest_row else None
    latest=(latest_row[0],latest_row[6],latest_row[3],latest_row[5],latest_row[7]) if latest_row else None
    chain=get_meta('chain_head',{}) or {}
    head=chain.get('block')
    fast=get_meta('fast_target_latest',{}) or {}
    fast_idx=None
    try:
        fast_key=fast.get('period')
        fast_idx=pindex(fast_key[:10],int(fast_key[11:]))
        if target_block(fast_key[:10],int(fast_key[11:]))!=int(fast.get('targetBlock')):
            fast_idx=None
    except (ValueError,TypeError,AttributeError):
        fast_idx=None
    if fast_idx is not None:
        head=max((n for n in (head,int(fast['targetBlock'])) if n is not None),default=None)
    raw_candidate=None
    idx=None
    if head is not None:
        idx=first_complete_index(int(head)+1)-1
        while target_block(*from_index(idx))>int(head):
            idx-=1
    if newest:
        newest_idx=pindex(newest[0][:10],int(newest[0][11:]))
        # A provisional/invalid period row can precede its target block's raw
        # capture. Check that SAME period too, instead of skipping to the next.
        idx=max(idx,newest_idx) if idx is not None else newest_idx
    if fast_idx is not None:
        idx=max(idx,fast_idx) if idx is not None else fast_idx
    if idx is not None:
        ds,no=from_index(idx)
        tb=target_block(ds,no)
        with DB() as c:
            q=c.cursor()
            q.execute('''SELECT numbers,single_count,fetched_at,block_time
                         FROM raw_blocks WHERE block_number=%s''',(tb,))
            raw=q.fetchone()
            q.close()
        if raw:
            raw_candidate=(f'{ds}:{no:04d}',raw[1],tb,raw[0],raw[2])
    def draw(row,provisional=False):
        return ({'period':row[0],'issue':issue_no(row[0]),'single':row[1],
                 'block':row[2],'numbers':row[3],
                 'provisional':provisional,
                 'savedAt':row[4].isoformat() if row[4] else None}) if row else None
    latency=get_meta('collector_live_latency',{}) or {}
    monitor=get_meta('monitor_stats',{}) or {}
    if raw_candidate:
        if raw_candidate[1] is not None:
            latest=raw_candidate
        newest=raw_candidate
        # Distinguish chain capture from the slower 20-group materialization.
        if raw[3] and raw[2]:
            latency={'period':raw_candidate[0], 'targetBlock':raw_candidate[2],
                     'source':'target-block-before-group-audit',
                     'blockToSavedSeconds':round(max(0,(raw[2]-raw[3]).total_seconds()),3)}
    next_period=None; next_target=None
    if newest:
        ds,no=from_index(pindex(newest[0][:10],int(newest[0][11:]))+1)
        next_period=f'{ds}:{no:04d}';next_target=target_block(ds,no)
    return jsonify({'latest':draw(latest,latest is raw_candidate),'newest':draw(newest,newest is raw_candidate),
                    'nextPeriod':next_period,'nextTargetBlock':next_target,
                    'head':head,'headSeenAt':fast.get('seenAt') if fast_idx is not None and
                        int(fast['targetBlock'])>int(chain.get('block') or 0) else chain.get('seenAt'),
                    'latency':latency,
                    'monitor':{'status':monitor.get('status'),
                               'pollIntervalSeconds':monitor.get('pollIntervalSeconds'),
                               'recentFailures':monitor.get('recentFailures'),
                               'lastError':monitor.get('lastError') if monitor.get('status')=='retrying' else None},
                    'serverEpochMs':int(datetime.now(timezone.utc).timestamp()*1000)})


def issue_no(period):
    ds,no = period.split(':',1)
    return ds[2:4]+ds[5:7]+ds[8:10]+f'{int(no):04d}'


def parse_issue(value):
    if not re.fullmatch(r'\d{10}',value):
        raise ValueError('请输入十位期号，如 2609270409')
    ds=f'20{value[:2]}-{value[2:4]}-{value[4:6]}'
    datetime.strptime(ds,'%Y-%m-%d')
    no=int(value[6:])
    if not 1<=no<=1440:
        raise ValueError('期数须为0001至1440')
    return ds,no


@app.get('/api/clock')
def clock():
    return jsonify({'serverEpochMs':int(datetime.now(timezone.utc).timestamp()*1000),
                    'zone':'Asia/Shanghai','displayOffsetSeconds':-3})


@app.get('/api/official-prediction')
def official_prediction():
    return jsonify({'active':False,'reason':'AI练习已停用'})


@app.get('/api/history')
def history_data():
    try:
        page = max(1, int(request.args.get('page', '1')))
        requested=request.args.get('count','30')
        selected=None if requested=='all' else int(requested)
        if selected is not None and not 1<=selected<=60000:
            raise ValueError()
    except ValueError:
        return jsonify({'error': '期数须在1至60000之间，或选择全部'}), 400
    page=min(page,2000)
    count=rows('SELECT COUNT(*) FROM periods')[0][0]
    page_size=min(100,selected or 100)
    wanted_end=page*page_size
    # Every page now uses the same canonical overlay.  Page 1 still benefits
    # from chain-head discovery when formal materialization lags, while older
    # pages never expose a stale transition payload.
    if page==1:
        selected_rows=canonical_recent_rows(page_size)
        source='canonical-target-blocks'
        quality={'rows':len(selected_rows),'canonical':len(selected_rows),
                 'pendingCanonical':0,'invalid':sum(r[1] is None for r in selected_rows),
                 'source':'canonical-target-blocks'}
    else:
        canonical=canonical_load(limit=wanted_end,newest_first=True)
        selected_rows=[(r[0],r[6],r[3],r[5]) for r in canonical[(page-1)*page_size:wanted_end]]
        source='canonical-history-overlay'
        quality=canonical_quality(canonical)
    available=min(selected,count) if selected is not None else count
    return jsonify({'page':page,'pageSize':page_size,'total':available,
                    'stored':count,'selected':requested,'canonicalOnly':True,
                    'source':source,'canonical':quality,
                    'calibration':get_meta('platform_calibration_bootstrap',{}),
                    'rows':[{'period':r[0],'issue':issue_no(r[0]),'single':r[1],
                             'block':r[2],'numbers':r[3]} for r in selected_rows]})

@app.get('/api/history/search')
def history_search():
    try:
        ds,no=parse_issue(request.args.get('issue','').strip())
    except ValueError as exc:
        return jsonify({'error':str(exc)}),400
    center=pindex(ds,no)
    indices=range(center-10,center+11)
    keys=[f'{day}:{period:04d}' for day,period in map(from_index,indices)]
    # Load this small date span through the same canonical overlay used by
    # omissions/statistics so search cannot expose an older wrong-tail payload.
    all_rows=[]
    days=sorted(set(key[:10] for key in keys))
    for day in days: all_rows.extend(canonical_load(day=day))
    found={r[0]:r for r in all_rows if r[0] in set(keys)}
    if keys[10] not in found:
        return jsonify({'error':'数据库中没有这个期号','issue':issue_no(keys[10])}),404
    return jsonify({'center':issue_no(keys[10]),'canonical':canonical_quality(list(found.values())), 'rows':[
        {'period':key,'issue':issue_no(key),'single':found[key][6] if key in found else None,
         'block':found[key][3] if key in found else None,
         'numbers':found[key][5] if key in found else None,
         'missing':key not in found or not found[key][8],'center':i==10} for i,key in enumerate(keys)]})


@app.get('/api/omission/detail')
def omission_detail():
    today=datetime.now(CN).date().isoformat()
    canonical=canonical_load(day=today)
    data=[(r[0],r[1],r[2],r[6]) for r in canonical]
    report=daily_omission_stats(data,today)
    report['canonical']=canonical_quality(canonical)
    overdue=daily_overdue([(key,label) for key,_,_,label in data])
    for item, extra in zip(report['items'], overdue['items']):
        item['overdueCount']=extra['count']
        item['overdueLatest']=extra['events'][0] if extra['events'] else None
    report['overdueTotal']=overdue['total']
    return jsonify(report)


@app.get('/api/omission/today/overdue')
def omission_today_overdue():
    try:
        single=int(request.args.get('single',''))
        page=int(request.args.get('page','1'))
        if single not in range(8) or page not in range(1,101):raise ValueError()
    except ValueError:
        return jsonify({'error':'单几须为0–7，页码须为1–100'}),400
    today=datetime.now(CN).date().isoformat()
    canonical=canonical_load(day=today)
    data=canonical_pairs(canonical)
    result=overdue_page(data,single,page);result['canonical']=canonical_quality(canonical)
    return jsonify(result)


@app.get('/api/omission/retained')
def retained_omission():
    canonical=canonical_load()
    data=canonical_pairs(canonical)
    result=retained_stats(data);result['canonical']=canonical_quality(canonical)
    return jsonify(result)


@app.get('/api/omission/retained/run')
def retained_omission_run():
    try:
        label=int(request.args.get('single',''))
        page=int(request.args.get('page','1'))
        if label not in range(8) or page not in range(1,601):raise ValueError()
    except ValueError:
        return jsonify({'error':'单几须为0–7，页码须为1–600'}),400
    canonical=canonical_load()
    data=canonical_pairs(canonical)
    result=run_page(data,label,page);result['canonical']=canonical_quality(canonical)
    return jsonify(result)


def daily_omission_stats(data,day):
    """Today's omission over stored valid results only; holes/invalid rows are metadata."""
    thresholds=(200,30,10,7,7,10,30,200)
    valid=[];invalid=0;missing=0;previous=None
    for key,ds,no,label in data:
        index=int(no)
        if previous is not None and index>previous+1: missing+=index-previous-1
        previous=index
        if label is None or not 0<=int(label)<=7:
            invalid+=1;continue
        valid.append((key,index,int(label)))
    counts=[0]*8;last_pos=[None]*8;last_issue=[None]*8;longest=[None]*8
    for pos,(key,index,label) in enumerate(valid):
        if last_pos[label] is not None:
            length=pos-last_pos[label]-1
            start_pos=last_pos[label]+1;end_pos=pos-1
            run={'length':length,
                 'startNo':valid[start_pos][1] if length else index,
                 'endNo':valid[end_pos][1] if length else index-1,
                 'endedBy':issue_no(key),'active':False,'exact':True}
            if longest[label] is None or length>longest[label]['length']:longest[label]=run
        counts[label]+=1;last_pos[label]=pos;last_issue[label]=issue_no(key)
    n=len(valid);newest=int(data[-1][2]) if data else 0
    items=[]
    for label in range(8):
        gap=n if last_pos[label] is None else n-1-last_pos[label]
        exact=last_pos[label] is not None
        if gap:
            start_no=(valid[last_pos[label]+1][1] if exact and last_pos[label]+1<n else
                      valid[0][1] if valid else newest)
            active={'length':gap,'startNo':start_no,'endNo':newest,
                    'endedBy':None,'active':True,'exact':exact}
            if longest[label] is None or gap>longest[label]['length']:longest[label]=active
        level=('超期' if gap>thresholds[label] else
               '接近' if gap>=thresholds[label]*.8 else '正常')
        items.append({'single':label,'count':counts[label],'gap':gap,'lowerBound':gap,
                      'exact':exact,'lastIssue':last_issue[label],'longest':longest[label],
                      'threshold':thresholds[label],'level':level})
    return {'day':day,'sample':len(data),'valid':n,'complete':n>0,
            'sourceComplete':missing==0 and invalid==0,'missing':missing,'invalid':invalid,
            'items':items,
            'note':'按当天规范化目标区块的有效开奖记录计算；缺失期和无效结果仅单独报告，不会重置遗漏。'}


@app.get('/api/omission/run')
def omission_run():
    try:
        label=int(request.args.get('single',''))
        if label not in range(8): raise ValueError()
    except ValueError:
        return jsonify({'error':'单几须为0–7'}),400
    day=datetime.now(CN).date().isoformat()
    canonical=canonical_load(day=day)
    data=[(r[0],r[1],r[2],r[6]) for r in canonical]
    report=daily_omission_stats(data,day)
    selected=report['items'][label]['longest']
    if selected is None:
        return jsonify({'day':day,'single':label,'length':0,'rows':[],'counts':[0]*8,
                        'canonical':canonical_quality(canonical)})
    lower,upper=selected['startNo'],selected['endNo']
    by_no={int(r[2]):r for r in data}
    sequence=[];counts=[0]*8
    for no in range(lower,upper+1):
        row=by_no.get(no)
        value=row[3] if row else None
        if value is not None and 0<=int(value)<=7:
            counts[int(value)]+=1
        sequence.append({'issue':issue_no(f'{day}:{no:04d}'),
                         'single':value,'missing':row is None or value is None})
    return jsonify({'day':day,'single':label,'length':selected['length'],
                    'startIssue':sequence[0]['issue'] if sequence else None,
                    'endIssue':sequence[-1]['issue'] if sequence else None,
                    'endedBy':selected['endedBy'],'active':selected['active'],
                    'complete':selected.get('exact',True),'counts':counts,'rows':sequence,
                    'canonical':canonical_quality(canonical)})


@app.get('/api/omission')
def omission():
    canonical=canonical_load()
    data=canonical_pairs(canonical)
    result=current_snapshot(data);result['canonical']=canonical_quality(canonical)
    return jsonify(result)


@app.get('/health')
def health():
    try:
        with DB() as connection:
            cursor=connection.cursor()
            cursor.execute("SELECT to_regclass('public.periods') IS NOT NULL")
            initialized=bool(cursor.fetchone()[0])
            cursor.close()
        if not initialized:
            return jsonify({'ok':False,'version':APP_VERSION,'aiEnabled':False,
                            'reason':'database connected but periods table not initialized'}),503
        return jsonify({'ok':True,'version':APP_VERSION,'aiEnabled':False,'databaseConnected':True,
                        'collectorVersion':(get_meta('collector_release') or {}).get('version'),
                        'runtimeRevision':runtime_config_revision(),
                        'role':'god8-web'})
    except Exception as exc:
        return jsonify({'ok':False,'version':APP_VERSION,'aiEnabled':False,'databaseConnected':False,
                        'reason':type(exc).__name__}),503
