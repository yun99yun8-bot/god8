"""Independent 0-9 block-tail center.

The manual center deliberately never calls or mutates ``target_block``.  It is a
second homepage fed by a selected block-number tail.  History backfill uses
persistent source cursors so it can stop/resume without rescanning the oldest
rows on every batch.  Live predictions use the same walk-forward replay/trend/
omission engine as the normal homepage; only the input history is different.
"""
import json
from datetime import datetime, timezone

from core import DB, from_index, get_meta, pindex, set_meta, valid_result
from history_simulation import simulate

RESULT_HOLD_SECONDS = 10
ANALYSIS_SECONDS = 20
SYNTHETIC_BASE = pindex('2020-01-01', 1)

# v2.0.61 unified read source.  The independent table remains the canonical
# manual-tail archive, but any raw row not copied there yet is visible
# immediately.  This removes the old all-or-nothing dependency on Worker
# backfill while preserving legacy-only rows already materialized in the
# independent table.
def _source_cte():
    return '''WITH manual_source AS (
        SELECT block_number,tail,block_hash,block_time,numbers,single_count,source,copied_at
        FROM manual_tail_blocks WHERE tail=%s
        UNION ALL
        SELECT r.block_number,MOD(r.block_number,10)::smallint,r.block_hash,r.block_time,
               r.numbers,r.single_count,'raw-fallback'::text,r.fetched_at
        FROM raw_blocks r
        WHERE MOD(r.block_number,10)=%s
          AND NOT EXISTS (SELECT 1 FROM manual_tail_blocks m WHERE m.block_number=r.block_number)
    ) '''


def _source_params(tail):
    return (int(tail), int(tail))


def _now():
    return datetime.now(timezone.utc)


def _iso(value):
    return value.isoformat() if value else None


def _legacy_exists(cursor):
    cursor.execute("SELECT to_regclass('public.historical_raw_blocks')")
    return bool(cursor.fetchone()[0])


def _insert_rows(cursor, rows):
    if not rows:
        return 0
    from psycopg2.extras import execute_values
    execute_values(cursor, '''INSERT INTO manual_tail_blocks
        (block_number,tail,block_hash,block_time,numbers,single_count,source)
        VALUES %s ON CONFLICT(block_number) DO UPDATE SET
          tail=EXCLUDED.tail, block_hash=EXCLUDED.block_hash,
          block_time=COALESCE(EXCLUDED.block_time,manual_tail_blocks.block_time),
          numbers=COALESCE(EXCLUDED.numbers,manual_tail_blocks.numbers),
          single_count=COALESCE(EXCLUDED.single_count,manual_tail_blocks.single_count),
          source=CASE WHEN manual_tail_blocks.source='raw' THEN manual_tail_blocks.source ELSE EXCLUDED.source END''',
        rows, template='(%s,%s,%s,%s,%s::jsonb,%s,%s)', page_size=500)
    return len(rows)


def live_sync_step(limit=500):
    """Copy only new raw blocks after the live cursor.

    The first call anchors at the current raw head, so bulk historical work is
    controlled only by the explicit backfill switch.
    """
    state = get_meta('manual_tail_live_sync') or {}
    cursor_value = state.get('cursor')
    copied = 0
    with DB() as conn:
        q = conn.cursor()
        if cursor_value is None:
            q.execute('SELECT MAX(block_number) FROM raw_blocks')
            cursor_value = int(q.fetchone()[0] or 0)
            q.close()
            payload = {'cursor': cursor_value, 'status': 'anchored', 'copied': 0,
                       'reportedAt': _now().isoformat()}
            set_meta('manual_tail_live_sync', payload)
            return 0
        q.execute('''SELECT block_number,block_hash,block_time,numbers,single_count
                     FROM raw_blocks WHERE block_number>%s
                     ORDER BY block_number LIMIT %s''', (int(cursor_value), int(limit)))
        found = q.fetchall()
        if found:
            prepared = [(int(n), int(n) % 10, h, t,
                         json.dumps(nums) if nums is not None else None, s, 'raw')
                        for n, h, t, nums, s in found]
            copied = _insert_rows(q, prepared)
            cursor_value = max(int(r[0]) for r in found)
        q.close()
    set_meta('manual_tail_live_sync', {'cursor': int(cursor_value), 'status': 'live',
        'copied': copied, 'reportedAt': _now().isoformat()})
    return copied


def backfill_enabled():
    return bool((get_meta('manual_tail_backfill') or {}).get('enabled'))


def set_backfill_enabled(enabled):
    previous = get_meta('manual_tail_backfill') or {}
    enabled = bool(enabled)
    state = {**previous, 'enabled': enabled,
             'status': 'running' if enabled else ('complete' if previous.get('status') == 'complete' else 'paused'),
             'changedAt': _now().isoformat()}
    if enabled:
        # Preserve cursors so pause/resume continues from the exact source point.
        # A completed job may be re-opened to scan only rows newer than its cursors.
        state['rawDone'] = False
        state['legacyDone'] = False
        state['error'] = None
        state['completedAt'] = None
        state['auditCompleteAt'] = None
    set_meta('manual_tail_backfill', state)
    return state


def _source_min(cursor, table):
    cursor.execute(f'SELECT MIN(block_number) FROM {table}')
    value = cursor.fetchone()[0]
    return int(value) if value is not None else None


def _source_max(cursor, table):
    cursor.execute(f'SELECT MAX(block_number) FROM {table}')
    value = cursor.fetchone()[0]
    return int(value) if value is not None else None


def _raw_batch(q, cursor_value, limit):
    if cursor_value is None:
        first = _source_min(q, 'raw_blocks')
        cursor_value = (first - 1) if first is not None else 0
    q.execute('''SELECT block_number,block_hash,block_time,numbers,single_count
                 FROM raw_blocks WHERE block_number>%s
                 ORDER BY block_number LIMIT %s''', (int(cursor_value), int(limit)))
    rows = q.fetchall()
    prepared = [(int(n), int(n) % 10, h, t,
                 json.dumps(nums) if nums is not None else None, s, 'raw')
                for n, h, t, nums, s in rows]
    _insert_rows(q, prepared)
    if rows:
        cursor_value = int(rows[-1][0])
    max_value = _source_max(q, 'raw_blocks')
    done = max_value is None or int(cursor_value) >= max_value
    return rows, int(cursor_value), done, max_value


def _legacy_batch(q, cursor_value, limit):
    if not _legacy_exists(q):
        return [], int(cursor_value or 0), True, None
    if cursor_value is None:
        first = _source_min(q, 'historical_raw_blocks')
        cursor_value = (first - 1) if first is not None else 0
    q.execute('''SELECT block_number,block_hash
                 FROM historical_raw_blocks WHERE block_number>%s
                 ORDER BY block_number LIMIT %s''', (int(cursor_value), int(limit)))
    rows = q.fetchall()
    prepared = []
    for n, block_hash in rows:
        nums, single = valid_result(block_hash)
        prepared.append((int(n), int(n) % 10, block_hash, None,
                         json.dumps(nums) if nums is not None else None, single, 'legacy'))
    _insert_rows(q, prepared)
    if rows:
        cursor_value = int(rows[-1][0])
    max_value = _source_max(q, 'historical_raw_blocks')
    done = max_value is None or int(cursor_value) >= max_value
    return rows, int(cursor_value), done, max_value


def backfill_step(limit=2500):
    """Advance both historical sources with persistent cursors.

    Raw and legacy stores each receive part of every batch so a very large raw
    table cannot starve the legacy source. No network/API request is made.
    """
    state = get_meta('manual_tail_backfill') or {}
    if not state.get('enabled'):
        return {'status': state.get('status', 'paused'), 'processed': 0}

    each = max(1, int(limit) // 2)
    raw_rows = legacy_rows = []
    with DB() as conn:
        q = conn.cursor()
        raw_rows, raw_cursor, raw_done, raw_max = _raw_batch(q, state.get('rawCursor'), each)
        legacy_rows, legacy_cursor, legacy_done, legacy_max = _legacy_batch(q, state.get('legacyCursor'), each)
        q.execute('SELECT COUNT(*) FROM manual_tail_blocks')
        stored = int(q.fetchone()[0] or 0)
        q.close()

    processed = len(raw_rows) + len(legacy_rows)
    next_state = {**state,
        'enabled': True,
        'status': 'running',
        'rawCursor': raw_cursor,
        'legacyCursor': legacy_cursor,
        'rawMax': raw_max,
        'legacyMax': legacy_max,
        'rawDone': raw_done,
        'legacyDone': legacy_done,
        'lastRawBatch': len(raw_rows),
        'lastLegacyBatch': len(legacy_rows),
        'lastBatch': processed,
        'processed': int(state.get('processed', 0)) + processed,
        'stored': stored,
        'reportedAt': _now().isoformat(),
        'error': None,
    }

    if raw_done and legacy_done:
        next_state.update({'enabled': False, 'status': 'complete',
                           'completedAt': _now().isoformat()})
        set_meta('manual_tail_backfill', next_state)
        audit = audit_snapshot()
        next_state.update({'auditCompleteAt': _now().isoformat(),
                           'auditPass': bool(audit.get('pass'))})
        set_meta('manual_tail_backfill', next_state)
    else:
        set_meta('manual_tail_backfill', next_state)
    return {'status': next_state['status'], 'processed': processed,
            'raw': len(raw_rows), 'legacy': len(legacy_rows), 'stored': stored,
            'rawCursor': raw_cursor, 'legacyCursor': legacy_cursor}


def audit_snapshot():
    """Audit the historical snapshot captured by the backfill cursors.

    New raw blocks can arrive while the audit is running. They are intentionally
    excluded above the captured rawMax because live_sync_step owns that moving
    edge. This prevents an endless false "missing 1" race at completion.
    """
    state = get_meta('manual_tail_backfill') or {}
    raw_limit = state.get('rawMax')
    legacy_limit = state.get('legacyMax')
    with DB() as conn:
        q = conn.cursor()
        q.execute('SELECT COUNT(*) FROM manual_tail_blocks')
        stored = int(q.fetchone()[0] or 0)
        if raw_limit is None:
            raw_limit = _source_max(q, 'raw_blocks')
        q.execute('SELECT COUNT(*) FROM raw_blocks WHERE block_number<=%s', (int(raw_limit or 0),))
        raw = int(q.fetchone()[0] or 0)
        q.execute('''SELECT COUNT(*) FROM raw_blocks r
                     WHERE r.block_number<=%s AND NOT EXISTS
                     (SELECT 1 FROM manual_tail_blocks m WHERE m.block_number=r.block_number)''',
                  (int(raw_limit or 0),))
        missing_raw = int(q.fetchone()[0] or 0)
        q.execute('''SELECT COUNT(*) FROM manual_tail_blocks m JOIN raw_blocks r USING(block_number)
                     WHERE r.block_number<=%s AND
                     (m.block_hash<>r.block_hash OR m.tail<>MOD(m.block_number,10))''',
                  (int(raw_limit or 0),))
        mismatches = int(q.fetchone()[0] or 0)
        legacy_missing = 0
        if _legacy_exists(q):
            if legacy_limit is None:
                legacy_limit = _source_max(q, 'historical_raw_blocks')
            q.execute('''SELECT COUNT(*) FROM historical_raw_blocks h
                         WHERE h.block_number<=%s AND NOT EXISTS
                         (SELECT 1 FROM manual_tail_blocks m WHERE m.block_number=h.block_number)''',
                      (int(legacy_limit or 0),))
            legacy_missing = int(q.fetchone()[0] or 0)
        q.execute('''SELECT tail,COUNT(*) FROM manual_tail_blocks GROUP BY tail ORDER BY tail''')
        by_tail = {str(int(t)): int(n) for t, n in q.fetchall()}
        q.close()
    report = {'stored': stored, 'rawBlocks': raw, 'rawThrough': raw_limit,
              'legacyThrough': legacy_limit, 'missingRaw': missing_raw,
              'missingLegacy': legacy_missing, 'mismatches': mismatches,
              'byTail': by_tail,
              'pass': missing_raw == 0 and legacy_missing == 0 and mismatches == 0,
              'reportedAt': _now().isoformat()}
    set_meta('manual_tail_audit', report)
    return report


def settle_predictions():
    """Settle each saved forecast with the next valid row of the same tail."""
    with DB() as conn:
        q = conn.cursor()
        q.execute('''UPDATE manual_tail_predictions p
                     SET actual=(SELECT x.single_count FROM (
                           SELECT m.block_number,m.single_count FROM manual_tail_blocks m
                           WHERE m.tail=p.tail AND m.block_number>p.source_block
                           UNION ALL
                           SELECT r.block_number,r.single_count FROM raw_blocks r
                           WHERE MOD(r.block_number,10)=p.tail AND r.block_number>p.source_block
                             AND NOT EXISTS (SELECT 1 FROM manual_tail_blocks m2 WHERE m2.block_number=r.block_number)
                         ) x WHERE x.single_count BETWEEN 0 AND 7
                         ORDER BY x.block_number LIMIT 1),
                         settled_at=COALESCE(p.settled_at,NOW())
                     WHERE p.actual IS NULL
                       AND EXISTS (SELECT 1 FROM (
                           SELECT m.block_number,m.single_count FROM manual_tail_blocks m
                           WHERE m.tail=p.tail AND m.block_number>p.source_block
                           UNION ALL
                           SELECT r.block_number,r.single_count FROM raw_blocks r
                           WHERE MOD(r.block_number,10)=p.tail AND r.block_number>p.source_block
                             AND NOT EXISTS (SELECT 1 FROM manual_tail_blocks m2 WHERE m2.block_number=r.block_number)
                         ) y WHERE y.single_count BETWEEN 0 AND 7)''')
        changed = q.rowcount
        q.close()
    return changed


def select_tail(tail):
    tail = int(tail)
    if not 0 <= tail <= 9:
        raise ValueError('tail must be 0..9')
    state = {'tail': tail, 'mode': 'manual-independent', 'changedAt': _now().isoformat(),
             'note': 'independent from target_block/360 clock'}
    set_meta('manual_tail_selected', state)
    return state


def selected_tail():
    try:
        value = int((get_meta('manual_tail_selected') or {}).get('tail', 9))
        return value if 0 <= value <= 9 else 9
    except (TypeError, ValueError):
        return 9


def _synthetic_rows(q, tail):
    q.execute(_source_cte() + '''SELECT single_count,numbers FROM manual_source
                 ORDER BY block_number''', _source_params(tail))
    data = q.fetchall()
    rows = []
    for offset, (single, numbers) in enumerate(data):
        ds, no = from_index(SYNTHETIC_BASE + offset)
        rows.append((f'{ds}:{no:04d}', single, numbers))
    return rows


def _engine_preview(q, tail):
    rows = _synthetic_rows(q, tail)
    if not rows:
        return None, {'historyRows': 0, 'engine': 'history_simulation'}
    result = simulate(rows, evaluation_window=250)
    preview = result.get('preview')
    meta = {'historyRows': len(rows), 'validRows': result.get('valid', 0),
            'evaluated': result.get('evaluated', 0), 'engine': 'history_simulation',
            'historyScope': 'all-manual-tail-history', 'methodEvaluationRows': 250}
    return preview, meta


def prediction_step(tail=None):
    """Create the selected-tail forecast after the same 10s result / 10s analysis cadence."""
    settle_predictions()
    tail = selected_tail() if tail is None else int(tail)
    if not 0 <= tail <= 9:
        raise ValueError('tail must be 0..9')
    now = _now()
    with DB() as conn:
        q = conn.cursor()
        q.execute(_source_cte() + '''SELECT block_number,single_count,COALESCE(block_time,copied_at)
                     FROM manual_source ORDER BY block_number DESC LIMIT 1''', _source_params(tail))
        latest = q.fetchone()
        if not latest or latest[1] is None:
            q.close()
            return {'status': 'waiting-valid-source', 'tail': tail}
        source_block, latest_single, result_at = int(latest[0]), int(latest[1]), latest[2]
        q.execute('''SELECT prediction_a,prediction_b,evidence,created_at,actual,settled_at
                     FROM manual_tail_predictions WHERE tail=%s AND source_block=%s''',
                  (tail, source_block))
        existing = q.fetchone()
        if existing:
            q.close()
            return {'status': 'locked', 'tail': tail, 'sourceBlock': source_block,
                    'choices': [int(existing[0]), int(existing[1])]}

        q.execute('''SELECT settled_at FROM manual_tail_predictions
                     WHERE tail=%s AND actual IS NOT NULL
                     ORDER BY settled_at DESC NULLS LAST LIMIT 1''', (tail,))
        settled = q.fetchone()
        reference = settled[0] if settled and settled[0] else result_at
        age = (now - reference).total_seconds() if reference else ANALYSIS_SECONDS
        if age < RESULT_HOLD_SECONDS:
            q.close()
            return {'status': 'holding-result', 'tail': tail, 'sourceBlock': source_block,
                    'remaining': round(RESULT_HOLD_SECONDS - age, 1)}
        if age < ANALYSIS_SECONDS:
            q.close()
            return {'status': 'analyzing', 'tail': tail, 'sourceBlock': source_block,
                    'remaining': round(ANALYSIS_SECONDS - age, 1)}

        preview, meta = _engine_preview(q, tail)
        if not preview or len(preview.get('predictions') or []) < 2:
            q.close()
            return {'status': 'insufficient-evidence', 'tail': tail, 'sourceBlock': source_block,
                    **meta}
        choices = [int(x) for x in preview['predictions'][:2]]
        evidence = {'match': preview.get('match') or {}, 'note': preview.get('note'), **meta}
        q.execute('''INSERT INTO manual_tail_predictions
                     (tail,source_block,prediction_a,prediction_b,evidence)
                     VALUES(%s,%s,%s,%s,%s::jsonb)
                     ON CONFLICT(tail,source_block) DO NOTHING''',
                  (tail, source_block, choices[0], choices[1], json.dumps(evidence)))
        q.close()
    return {'status': 'locked', 'tail': tail, 'sourceBlock': source_block,
            'choices': choices, **meta}


def _forecast_view(q, tail, latest_block):
    """Return the card phase for the manual homepage without running heavy simulation."""
    q.execute('''SELECT source_block,prediction_a,prediction_b,evidence,created_at,actual,settled_at
                 FROM manual_tail_predictions WHERE tail=%s AND source_block=%s''',
              (tail, latest_block))
    current = q.fetchone()
    if current and current[5] is None:
        evidence = current[3] or {}
        return 'forecast', {'sourceBlock': int(current[0]),
            'choices': [int(current[1]), int(current[2])], 'match': evidence.get('match') or {},
            'evidence': evidence, 'lockedAt': _iso(current[4]), 'actual': None, 'settledAt': None}

    q.execute('''SELECT source_block,prediction_a,prediction_b,evidence,created_at,actual,settled_at
                 FROM manual_tail_predictions WHERE tail=%s AND actual IS NOT NULL
                 ORDER BY settled_at DESC NULLS LAST LIMIT 1''', (tail,))
    previous = q.fetchone()
    if previous and previous[6]:
        age = (_now() - previous[6]).total_seconds()
        if age < RESULT_HOLD_SECONDS:
            evidence = previous[3] or {}
            return 'result', {'sourceBlock': int(previous[0]),
                'choices': [int(previous[1]), int(previous[2])], 'match': evidence.get('match') or {},
                'evidence': evidence, 'lockedAt': _iso(previous[4]), 'actual': int(previous[5]),
                'settledAt': _iso(previous[6])}
        if age < ANALYSIS_SECONDS:
            return 'analyzing', None
    runtime = get_meta('manual_tail_prediction_runtime') or {}
    if runtime.get('tail') == tail and runtime.get('status') == 'insufficient-evidence':
        return 'waiting', None
    return 'analyzing', None


def report(tail=None):
    tail = selected_tail() if tail is None else int(tail)
    if not 0 <= tail <= 9:
        raise ValueError('tail must be 0..9')
    with DB() as conn:
        q = conn.cursor()
        q.execute(_source_cte() + '''SELECT COUNT(*),MIN(block_number),MAX(block_number) FROM manual_source''', _source_params(tail))
        total, first, last = q.fetchone(); total = int(total or 0)
        q.execute(_source_cte() + '''SELECT single_count,COUNT(*) FROM manual_source
                     WHERE single_count BETWEEN 0 AND 7
                     GROUP BY single_count ORDER BY single_count''', _source_params(tail))
        dist = {int(s): int(n) for s, n in q.fetchall()}
        q.execute(_source_cte() + '''SELECT block_number,single_count,numbers,COALESCE(block_time,copied_at)
                     FROM manual_source ORDER BY block_number DESC LIMIT 1''', _source_params(tail))
        latest = q.fetchone()
        latest_single = int(latest[1]) if latest and latest[1] is not None else None
        omissions = []
        for single in range(8):
            q.execute(_source_cte() + '''SELECT COUNT(*) FROM manual_source
                         WHERE block_number>(SELECT COALESCE(MAX(block_number),-1)
                         FROM manual_source WHERE single_count=%s)''', _source_params(tail) + (single,))
            gap = int(q.fetchone()[0] or 0) if total else None
            omissions.append({'single': single, 'gap': gap, 'hits': dist.get(single, 0),
                              'rate': (dist.get(single, 0) / total if total else None)})
        q.execute('''SELECT COUNT(*),
                            COUNT(*) FILTER (WHERE actual=prediction_a),
                            COUNT(*) FILTER (WHERE actual=prediction_b),
                            COUNT(*) FILTER (WHERE actual IN (prediction_a,prediction_b))
                     FROM manual_tail_predictions WHERE tail=%s AND actual IS NOT NULL''', (tail,))
        verified, first_hits, second_hits, either_hits = [int(v or 0) for v in q.fetchone()]
        phase, forecast = _forecast_view(q, tail, int(latest[0])) if latest else ('waiting', None)
        q.close()

    chain = get_meta('chain_head') or {}
    head = chain.get('block')
    next_block = None
    if head is not None:
        head = int(head)
        next_block = head + 1 + ((tail - ((head + 1) % 10)) % 10)
    latest_payload = None
    if latest:
        latest_payload = {'period': f'manual:{tail}:{int(latest[0])}',
                          'issue': f'{tail}尾 · 最新同尾结果',
                          'block': int(latest[0]), 'single': latest_single,
                          'numbers': latest[2], 'observedAt': _iso(latest[3])}
    return {'tail': tail, 'selected': tail == selected_tail(), 'total': total,
            'firstBlock': int(first) if first is not None else None,
            'lastBlock': int(last) if last is not None else None,
            'latest': latest_payload,
            'nextBlock': next_block, 'chainHead': head,
            'distribution': [{'single': s, 'hits': dist.get(s, 0),
                              'rate': (dist.get(s, 0) / total if total else None)} for s in range(8)],
            'omission': omissions, 'phase': phase, 'forecast': forecast,
            'stats': {'verified': verified,
                      'firstRate': first_hits / verified if verified else None,
                      'secondRate': second_hits / verified if verified else None,
                      'eitherRate': either_hits / verified if verified else None},
            'backfill': get_meta('manual_tail_backfill') or {'enabled': False, 'status': 'paused'},
            'audit': get_meta('manual_tail_audit') or {},
            'liveSync': get_meta('manual_tail_live_sync') or {},
            'worker': get_meta('manual_tail_worker') or {},
            'workerError': get_meta('manual_tail_worker_error') or {},
            'parentWorker': {
                'runtime': get_meta('god8_worker_heartbeat') or {},
                'startup': get_meta('god8_worker_startup_heartbeat') or {},
                'handoff': get_meta('god8_worker_handoff') or {},
                'release': get_meta('god8_worker_release') or {},
            },
            'predictionRuntime': get_meta('manual_tail_prediction_runtime') or {},
            'clockIndependent': True,
            'engine': 'same-history-simulation-framework-as-home',
            'readSource': 'manual-tail-plus-raw-fallback'}


def history(tail, page=1, page_size=100):
    tail = int(tail); page = max(1, int(page)); page_size = max(1, min(100, int(page_size)))
    with DB() as conn:
        q = conn.cursor()
        q.execute(_source_cte() + 'SELECT COUNT(*) FROM manual_source', _source_params(tail))
        total = int(q.fetchone()[0] or 0)
        pages = max(1, (total + page_size - 1) // page_size); page = min(page, pages)
        q.execute(_source_cte() + '''SELECT block_number,single_count,numbers,block_time,source
                     FROM manual_source ORDER BY block_number DESC
                     LIMIT %s OFFSET %s''', _source_params(tail) + (page_size, (page - 1) * page_size))
        data = q.fetchall(); q.close()
    return {'tail': tail, 'page': page, 'pages': pages, 'total': total, 'pageSize': page_size,
            'rows': [{'block': int(n), 'single': s, 'numbers': nums,
                      'blockTime': t.isoformat() if t else None, 'source': src}
                     for n, s, nums, t, src in data]}
