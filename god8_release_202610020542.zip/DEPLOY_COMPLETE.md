# God8 v2.0.7 完整部署包

版本：`god8-v2.0.7-manual-9tail-clock`

本版重点：Worker 双通道心跳。进程启动即通过 Render 私网直报 Web，不依赖 PostgreSQL；数据库可用后继续保留原数据库心跳。手动尾数中心沿用上一版的数据兜底与 Collector 双写。
