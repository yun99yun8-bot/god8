"""God8 worker: forward backfill and independent stage audit."""
import threading
import time
from datetime import datetime, timezone

from audit_service import verify_forever
from backfill_worker import forward_forever
from core import init_db, pool, set_meta
from live_replay import advance_guarded as advance_replay
from manual_tail_center import live_sync_step, backfill_step, backfill_enabled, audit_snapshot, settle_predictions


def supervised_forward():
    while True:
        try:
            forward_forever()
        except Exception as exc:
            try:
                set_meta('god8_forward_worker_error',{'error':str(exc)[:400],
                    'at':datetime.now(timezone.utc).isoformat()})
            except Exception:
                pass
            time.sleep(5)



def prediction_watchdog():
    """Redundant pre-block forecast scheduler shared with Collector."""
    while True:
        try:
            result=advance_replay() or {}
            if result.get('status') != 'busy-other-watchdog':
                set_meta('prediction_worker_watchdog',{'status':result.get('status','ok'),
                    'reportedAt':datetime.now(timezone.utc).isoformat()})
        except Exception as exc:
            try:
                set_meta('prediction_worker_error',{'error':str(exc)[:400],
                    'at':datetime.now(timezone.utc).isoformat()})
            except Exception:
                pass
        time.sleep(2)


def manual_tail_worker():
    """Cheap live 0-9 tail sync plus user-controlled bulk history backfill/audit."""
    last_audit=0.0
    while True:
        try:
            live_sync_step(500)
            if backfill_enabled():
                result=backfill_step(2500)
                settle_predictions()
                now=time.monotonic()
                if result.get('status')=='complete' or now-last_audit>=20:
                    audit_snapshot();last_audit=now
            else:
                settle_predictions()
        except Exception as exc:
            try:
                set_meta('manual_tail_worker_error',{'error':str(exc)[:400],
                    'at':datetime.now(timezone.utc).isoformat()})
            except Exception:
                pass
        time.sleep(3)

def main():
    init_db()
    lease=pool().getconn()
    try:
        while True:
            q=lease.cursor()
            q.execute('SELECT pg_try_advisory_lock(%s)',(80086420,))
            leader=bool(q.fetchone()[0])
            q.close();lease.commit()
            if leader:
                break
            try:
                set_meta('god8_worker_handoff',{'status':'waiting-for-previous-instance',
                    'reportedAt':datetime.now(timezone.utc).isoformat()})
            except Exception:
                pass
            time.sleep(1)
        set_meta('god8_worker_handoff',{'status':'leader',
            'reportedAt':datetime.now(timezone.utc).isoformat()})
        threading.Thread(target=supervised_forward,name='god8-forward',daemon=True).start()
        threading.Thread(target=verify_forever,name='god8-stage-audit',daemon=True).start()
        threading.Thread(target=prediction_watchdog,name='prediction-watchdog',daemon=True).start()
        threading.Thread(target=manual_tail_worker,name='manual-tail-center',daemon=True).start()
        # Retain the existing Render worker name; no AI thread is started.
        # The main thread stays alive so backfill and auditing remain active.
        while True:
            try:
                set_meta('god8_worker_heartbeat', {'status':'backfill-audit-prediction-watchdog-manual-tail',
                    'ai':'disabled', 'reportedAt':datetime.now(timezone.utc).isoformat()})
            except Exception:
                pass
            time.sleep(15)
    finally:
        q=lease.cursor()
        q.execute('SELECT pg_advisory_unlock(%s)',(80086420,))
        q.close();lease.commit()
        pool().putconn(lease)


if __name__=='__main__':main()
