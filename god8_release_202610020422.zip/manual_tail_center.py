"""Independent manual block-tail data center.

This module deliberately does not call or modify ``target_block``.  It keeps a
separate 0-9 tail history so a manually selected tail can be researched across
*all* matching block history without changing the platform's 360-period clock.
"""
import json
from datetime import datetime, timezone

from core import DB, get_meta, set_meta, valid_result


def _legacy_exists(cursor):
    cursor.execute("SELECT to_regclass('public.historical_raw_blocks')")
    return bool(cursor.fetchone()[0])


def _insert_rows(cursor, rows):
    if not rows:
        return 0
    from psycopg2.extras import execute_values
    execute_values(cursor, '''INSERT INTO manual_tail_blocks
        (block_number,tail,block_hash,block_time,numbers,single_count,source)
        VALUES %s ON CONFLICT(block_number) DO UPDATE SET
          tail=EXCLUDED.tail, block_hash=EXCLUDED.block_hash,
          block_time=COALESCE(EXCLUDED.block_time,manual_tail_blocks.block_time),
          numbers=COALESCE(EXCLUDED.numbers,manual_tail_blocks.numbers),
          single_count=COALESCE(EXCLUDED.single_count,manual_tail_blocks.single_count),
          source=CASE WHEN manual_tail_blocks.source='raw' THEN manual_tail_blocks.source ELSE EXCLUDED.source END''',
        rows, template='(%s,%s,%s,%s,%s::jsonb,%s,%s)', page_size=500)
    return len(rows)


def live_sync_step(limit=500):
    """Copy only blocks newer than the worker's live cursor.

    The first call anchors to the current raw head instead of bulk copying old
    rows, so day-to-day collection remains cheap even while historical backfill
    is switched off.
    """
    state=get_meta('manual_tail_live_sync') or {}
    cursor=state.get('cursor')
    with DB() as c:
        q=c.cursor()
        if cursor is None:
            q.execute('SELECT MAX(block_number) FROM raw_blocks')
            cursor=int(q.fetchone()[0] or 0)
            q.close()
            set_meta('manual_tail_live_sync',{'cursor':cursor,'status':'anchored',
                'reportedAt':datetime.now(timezone.utc).isoformat()})
            return 0
        q.execute('''SELECT block_number,block_hash,block_time,numbers,single_count
                     FROM raw_blocks WHERE block_number>%s
                     ORDER BY block_number LIMIT %s''',(int(cursor),int(limit)))
        found=q.fetchall()
        if found:
            prepared=[(int(n),int(n)%10,h,t,
                       json.dumps(nums) if nums is not None else None,s,'raw')
                      for n,h,t,nums,s in found]
            _insert_rows(q,prepared)
            cursor=max(int(r[0]) for r in found)
        q.close()
    set_meta('manual_tail_live_sync',{'cursor':int(cursor),'status':'live',
        'copied':len(found),'reportedAt':datetime.now(timezone.utc).isoformat()})
    return len(found)


def backfill_enabled():
    return bool((get_meta('manual_tail_backfill') or {}).get('enabled'))


def set_backfill_enabled(enabled):
    previous=get_meta('manual_tail_backfill') or {}
    state={**previous,'enabled':bool(enabled),
           'status':'running' if enabled else 'paused',
           'changedAt':datetime.now(timezone.utc).isoformat()}
    set_meta('manual_tail_backfill',state)
    return state


def backfill_step(limit=2500):
    """Copy a bounded historical batch from existing DB stores only.

    No Tron/API request is made.  The heavy historical work therefore stays on
    the backfill worker and never increases Collector network pressure.
    """
    if not backfill_enabled():
        return {'status':'paused','copied':0}
    raw_rows=[];legacy_rows=[]
    with DB() as c:
        q=c.cursor()
        q.execute('''SELECT r.block_number,r.block_hash,r.block_time,r.numbers,r.single_count
                     FROM raw_blocks r
                     WHERE NOT EXISTS (SELECT 1 FROM manual_tail_blocks m
                                       WHERE m.block_number=r.block_number)
                     ORDER BY r.block_number LIMIT %s''',(int(limit),))
        raw_rows=q.fetchall()
        if raw_rows:
            prepared=[(int(n),int(n)%10,h,t,
                       json.dumps(nums) if nums is not None else None,s,'raw')
                      for n,h,t,nums,s in raw_rows]
            _insert_rows(q,prepared)
        elif _legacy_exists(q):
            q.execute('''SELECT h.block_number,h.block_hash
                         FROM historical_raw_blocks h
                         WHERE NOT EXISTS (SELECT 1 FROM manual_tail_blocks m
                                           WHERE m.block_number=h.block_number)
                         ORDER BY h.block_number LIMIT %s''',(int(limit),))
            legacy_rows=q.fetchall()
            prepared=[]
            for n,h in legacy_rows:
                nums,single=valid_result(h)
                prepared.append((int(n),int(n)%10,h,None,
                    json.dumps(nums) if nums is not None else None,single,'legacy'))
            _insert_rows(q,prepared)
        q.close()
    copied=len(raw_rows)+len(legacy_rows)
    state=get_meta('manual_tail_backfill') or {}
    total=int(state.get('copied',0))+copied
    status='running' if copied else 'complete'
    set_meta('manual_tail_backfill',{**state,'enabled':True,'status':status,
        'copied':total,'lastBatch':copied,'reportedAt':datetime.now(timezone.utc).isoformat()})
    return {'status':status,'copied':copied,'allTimeCopied':total}


def audit_snapshot():
    with DB() as c:
        q=c.cursor()
        q.execute('SELECT COUNT(*) FROM manual_tail_blocks')
        stored=int(q.fetchone()[0] or 0)
        q.execute('SELECT COUNT(*) FROM raw_blocks')
        raw=int(q.fetchone()[0] or 0)
        q.execute('''SELECT COUNT(*) FROM raw_blocks r
                     WHERE NOT EXISTS (SELECT 1 FROM manual_tail_blocks m
                                       WHERE m.block_number=r.block_number)''')
        missing_raw=int(q.fetchone()[0] or 0)
        q.execute('''SELECT COUNT(*) FROM manual_tail_blocks m JOIN raw_blocks r USING(block_number)
                     WHERE m.block_hash<>r.block_hash OR m.tail<>MOD(m.block_number,10)''')
        mismatches=int(q.fetchone()[0] or 0)
        legacy_missing=0
        if _legacy_exists(q):
            q.execute('''SELECT COUNT(*) FROM historical_raw_blocks h
                         WHERE NOT EXISTS (SELECT 1 FROM manual_tail_blocks m
                                           WHERE m.block_number=h.block_number)''')
            legacy_missing=int(q.fetchone()[0] or 0)
        q.execute('''SELECT tail,COUNT(*) FROM manual_tail_blocks GROUP BY tail ORDER BY tail''')
        by_tail={str(int(t)):int(n) for t,n in q.fetchall()}
        q.close()
    report={'stored':stored,'rawBlocks':raw,'missingRaw':missing_raw,
            'missingLegacy':legacy_missing,'mismatches':mismatches,
            'byTail':by_tail,'pass':missing_raw==0 and legacy_missing==0 and mismatches==0,
            'reportedAt':datetime.now(timezone.utc).isoformat()}
    set_meta('manual_tail_audit',report)
    return report


def settle_predictions():
    with DB() as c:
        q=c.cursor()
        q.execute('''UPDATE manual_tail_predictions p
                     SET actual=(SELECT b.single_count FROM manual_tail_blocks b
                                 WHERE b.tail=p.tail AND b.block_number>p.source_block
                                   AND b.single_count BETWEEN 0 AND 7
                                 ORDER BY b.block_number LIMIT 1),
                         settled_at=NOW()
                     WHERE p.actual IS NULL
                       AND EXISTS (SELECT 1 FROM manual_tail_blocks b
                                   WHERE b.tail=p.tail AND b.block_number>p.source_block
                                     AND b.single_count BETWEEN 0 AND 7)''')
        changed=q.rowcount
        q.close()
    return changed


def select_tail(tail):
    tail=int(tail)
    if not 0<=tail<=9:
        raise ValueError('tail must be 0..9')
    state={'tail':tail,'mode':'manual-independent','changedAt':datetime.now(timezone.utc).isoformat(),
           'note':'independent from target_block/360 clock'}
    set_meta('manual_tail_selected',state)
    return state


def selected_tail():
    try:
        value=int((get_meta('manual_tail_selected') or {}).get('tail',9))
        return value if 0<=value<=9 else 9
    except (TypeError,ValueError):
        return 9


def _prediction(cursor,tail,latest_single):
    if latest_single is None:
        return {'choices':[],'method':'等待有效同尾记录','support':0}
    cursor.execute('''WITH seq AS (
        SELECT single_count,LAG(single_count) OVER (ORDER BY block_number) AS previous
        FROM manual_tail_blocks WHERE tail=%s AND single_count BETWEEN 0 AND 7)
        SELECT single_count,COUNT(*) FROM seq WHERE previous=%s
        GROUP BY single_count ORDER BY COUNT(*) DESC,single_count LIMIT 8''',(tail,latest_single))
    counts=[(int(s),int(n)) for s,n in cursor.fetchall()]
    method='全历史同尾转移'
    if not counts:
        cursor.execute('''SELECT single_count,COUNT(*) FROM manual_tail_blocks
                          WHERE tail=%s AND single_count BETWEEN 0 AND 7
                          GROUP BY single_count ORDER BY COUNT(*) DESC,single_count LIMIT 8''',(tail,))
        counts=[(int(s),int(n)) for s,n in cursor.fetchall()]
        method='全历史同尾频率'
    total=sum(n for _,n in counts)
    choices=[{'single':s,'hits':n,'rate':(n/total if total else None)} for s,n in counts[:2]]
    return {'choices':choices,'method':method,'support':total,'afterSingle':int(latest_single)}


def report(tail=None):
    tail=selected_tail() if tail is None else int(tail)
    if not 0<=tail<=9: raise ValueError('tail must be 0..9')
    with DB() as c:
        q=c.cursor()
        q.execute('''SELECT COUNT(*),MIN(block_number),MAX(block_number) FROM manual_tail_blocks
                     WHERE tail=%s''',(tail,))
        total,first,last=q.fetchone();total=int(total or 0)
        q.execute('''SELECT single_count,COUNT(*) FROM manual_tail_blocks
                     WHERE tail=%s AND single_count BETWEEN 0 AND 7
                     GROUP BY single_count ORDER BY single_count''',(tail,))
        dist={int(s):int(n) for s,n in q.fetchall()}
        q.execute('''SELECT block_number,single_count,numbers FROM manual_tail_blocks
                     WHERE tail=%s ORDER BY block_number DESC LIMIT 1''',(tail,))
        latest=q.fetchone()
        latest_single=int(latest[1]) if latest and latest[1] is not None else None
        pred=_prediction(q,tail,latest_single)
        omissions=[]
        for single in range(8):
            q.execute('SELECT MAX(block_number) FROM manual_tail_blocks WHERE tail=%s AND single_count=%s',(tail,single))
            lb=q.fetchone()[0]
            if lb is None:
                gap=total if total else None
            else:
                q.execute('SELECT COUNT(*) FROM manual_tail_blocks WHERE tail=%s AND block_number>%s',(tail,lb))
                gap=int(q.fetchone()[0] or 0)
            omissions.append({'single':single,'gap':gap,'hits':dist.get(single,0),
                              'rate':(dist.get(single,0)/total if total else None)})
        verified=hits=0
        q.execute('''SELECT COUNT(*),COUNT(*) FILTER (WHERE actual IN (prediction_a,prediction_b))
                     FROM manual_tail_predictions WHERE tail=%s AND actual IS NOT NULL''',(tail,))
        verified,hits=q.fetchone();verified=int(verified or 0);hits=int(hits or 0)
        if latest and len(pred['choices'])>=1:
            a=pred['choices'][0]['single'];b=pred['choices'][1]['single'] if len(pred['choices'])>1 else a
            q.execute('''INSERT INTO manual_tail_predictions(tail,source_block,prediction_a,prediction_b,evidence)
                         VALUES(%s,%s,%s,%s,%s::jsonb) ON CONFLICT(tail,source_block) DO NOTHING''',
                      (tail,int(latest[0]),a,b,json.dumps(pred)))
        q.close()
    return {'tail':tail,'selected':tail==selected_tail(),'total':total,
            'firstBlock':int(first) if first is not None else None,
            'lastBlock':int(last) if last is not None else None,
            'latest':{'block':int(latest[0]),'single':latest_single,'numbers':latest[2]} if latest else None,
            'distribution':[{'single':s,'hits':dist.get(s,0),'rate':(dist.get(s,0)/total if total else None)} for s in range(8)],
            'omission':omissions,'prediction':pred,
            'predictionHistory':{'verified':verified,'hits':hits,'rate':(hits/verified if verified else None)},
            'backfill':get_meta('manual_tail_backfill') or {'enabled':False,'status':'paused'},
            'audit':get_meta('manual_tail_audit') or {},
            'liveSync':get_meta('manual_tail_live_sync') or {},
            'clockIndependent':True}


def history(tail,page=1,page_size=100):
    tail=int(tail);page=max(1,int(page));page_size=max(1,min(100,int(page_size)))
    with DB() as c:
        q=c.cursor();q.execute('SELECT COUNT(*) FROM manual_tail_blocks WHERE tail=%s',(tail,));total=int(q.fetchone()[0] or 0)
        pages=max(1,(total+page_size-1)//page_size);page=min(page,pages)
        q.execute('''SELECT block_number,single_count,numbers,block_time,source
                     FROM manual_tail_blocks WHERE tail=%s ORDER BY block_number DESC
                     LIMIT %s OFFSET %s''',(tail,page_size,(page-1)*page_size))
        data=q.fetchall();q.close()
    return {'tail':tail,'page':page,'pages':pages,'total':total,'pageSize':page_size,
            'rows':[{'block':int(n),'single':s,'numbers':nums,'blockTime':t.isoformat() if t else None,'source':src}
                    for n,s,nums,t,src in data]}
