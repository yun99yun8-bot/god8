"""Shared database watermarks: immutable origin, forward progress and bounded results."""
import hashlib
import json
from datetime import datetime, timezone

from core import (ANCHOR_BLOCK, ANCHOR_INDEX, DB, RETAIN_PERIODS,
                  TRAIN_N, from_index, get_meta, pindex, set_meta, target_block)


def first_complete_index(min_block):
    """Find the first period whose entire 20-block window starts at/after min_block."""
    diff = max(100000, abs(int(min_block)-ANCHOR_BLOCK)//18+1000)
    low, high = ANCHOR_INDEX-diff, ANCHOR_INDEX+diff
    while low < high:
        mid = (low+high)//2
        if target_block(*from_index(mid))-19 < min_block:
            low = mid+1
        else:
            high = mid
    return low


def origin_index():
    saved = get_meta('god8_origin') or {}
    if 'index' in saved:
        return int(saved['index'])
    with DB() as c:
        q=c.cursor()
        q.execute('SELECT period_date::text,period_no FROM periods ORDER BY period_date,period_no LIMIT 1')
        period=q.fetchone()
        q.execute('SELECT MIN(block_number) FROM raw_blocks')
        raw=q.fetchone()[0]
        q.execute("SELECT to_regclass('public.historical_raw_blocks')")
        if q.fetchone()[0]:
            q.execute('SELECT MIN(block_number) FROM historical_raw_blocks')
            historical=q.fetchone()[0]
            raw=min(x for x in (raw,historical) if x is not None) if raw is not None or historical is not None else None
        q.close()
    existing = []
    if period:
        existing.append(pindex(*period))
    if raw is not None:
        existing.append(first_complete_index(raw))
    if existing:
        first=min(existing)
        source='earliest-existing-data'
    else:
        head=(get_meta('chain_head') or {}).get('block')
        if head is None:
            return None
        first=first_complete_index(head+1)
        source='first-future-complete-period'
    meta={'index':first,'period':f'{from_index(first)[0]}:{from_index(first)[1]:04d}',
          'source':source,'noBackwardFetch':True,
          'recordedAt':datetime.now(timezone.utc).isoformat()}
    # Initialize once: restarting or pruning must never move the start point.
    with DB() as c:
        q=c.cursor()
        q.execute('''INSERT INTO meta(k,v) VALUES('god8_origin',%s::jsonb)
                     ON CONFLICT(k) DO NOTHING''',(json.dumps(meta),))
        q.execute("SELECT v FROM meta WHERE k='god8_origin'")
        result=q.fetchone()[0]
        q.close()
    return int(result['index'])


def stage_window(origin, stage_no):
    start=origin+int(stage_no)*TRAIN_N
    return start,start+TRAIN_N-1


def stage_rows(start,end):
    first=from_index(start);last=from_index(end)
    with DB() as c:
        q=c.cursor()
        q.execute('''SELECT period_key,target_block,block_hash,numbers,single_count
                     FROM periods WHERE period_key BETWEEN %s AND %s
                     ORDER BY period_date,period_no''',
                  (f'{first[0]}:{first[1]:04d}',f'{last[0]}:{last[1]:04d}'))
        rows=q.fetchall()
        q.close()
    return rows


def stage_fingerprint(rows):
    h=hashlib.sha256()
    for row in rows:
        h.update(json.dumps(row,default=str,sort_keys=True,separators=(',',':')).encode())
    return h.hexdigest()


def prune_old_periods():
    """Atomically remove only the oldest COMPLETE periods after the 60,000th."""
    with DB() as c:
        q=c.cursor()
        q.execute('SELECT pg_advisory_xact_lock(%s)',(60000864,))
        q.execute('SELECT COUNT(*) FROM periods')
        excess=max(0,q.fetchone()[0]-RETAIN_PERIODS)
        if excess:
            q.execute('''SELECT period_key FROM periods ORDER BY period_date,period_no LIMIT %s''',(excess,))
            oldest=[r[0] for r in q.fetchall()]
            q.execute('DELETE FROM ai_predictions WHERE period_key=ANY(%s)',(oldest,))
            q.execute('DELETE FROM ai_simulations WHERE period_key=ANY(%s)',(oldest,))
            q.execute('DELETE FROM groups WHERE period_key=ANY(%s)',(oldest,))
            q.execute('DELETE FROM periods WHERE period_key=ANY(%s)',(oldest,))
            q.execute('SELECT MIN(target_block) FROM periods')
            first_target=q.fetchone()[0]
            # Retain exactly the blocks needed by the first retained 20-group round.
            if first_target is not None:
                cutoff=first_target-19
                q.execute('DELETE FROM repair_queue WHERE block_number<%s',(cutoff,))
                q.execute('DELETE FROM raw_blocks WHERE block_number<%s',(cutoff,))
                q.execute("SELECT to_regclass('public.historical_raw_blocks')")
                if q.fetchone()[0]:
                    q.execute('DELETE FROM historical_raw_blocks WHERE block_number<%s',(cutoff,))
        q.execute('SELECT COUNT(*),MIN(period_key),MAX(period_key) FROM periods')
        count,first,last=q.fetchone()
        q.close()
    set_meta('god8_retention',{'retainedPeriods':count,'limit':RETAIN_PERIODS,
             'oldest':first,'newest':last,'deletedInLastPass':excess})
    return excess
