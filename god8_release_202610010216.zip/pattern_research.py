"""Time ordered suffix matches for completed rounds; never use a future label."""
from collections import Counter, defaultdict

from streak_research import issue_index

MIN_SUPPORT=5
MAX_LENGTH=12


def _contiguous(keys, start, end):
    return keys is None or all(keys[k]==keys[k-1]+1 for k in range(start+1,end+1))


def replay_guess(labels, keys=None, window=10000):
    """Predict the NEXT result from prior outcomes only, with short-prefix fallback."""
    labels=list(labels[-window:])
    keys=list(keys[-window:]) if keys is not None else None
    baseline=Counter(labels)
    if not baseline:return 3
    tables=[defaultdict(Counter) for _ in range(MAX_LENGTH+1)]
    for j in range(1,len(labels)):
        for length in range(1,min(MAX_LENGTH,j)+1):
            if not _contiguous(keys,j-length,j):break
            tables[length][tuple(labels[j-length:j])][labels[j]]+=1
    for length in range(min(MAX_LENGTH,len(labels)),0,-1):
        if not _contiguous(keys,len(labels)-length,len(labels)-1):break
        votes=tables[length].get(tuple(labels[-length:]),Counter())
        if sum(votes.values())>=MIN_SUPPORT:
            return max(range(8),key=lambda k:(votes[k],-k))
    return max(range(8),key=lambda k:(baseline[k],-k))


def replay_simulation(labels, keys, window):
    """Generator of guesses: first 1,000 periods seed history, later targets stay unseen."""
    from ai_research import TRAIN_START
    tables=[defaultdict(Counter) for _ in range(MAX_LENGTH+1)]
    baseline=Counter(labels[:TRAIN_START])

    def add(j,start=0):
        for length in range(1,min(MAX_LENGTH,j)+1):
            if j-length<start:break
            if not _contiguous(keys,j-length,j):break
            key=tuple(labels[j-length:j])
            tables[length][key][labels[j]]+=1

    for j in range(TRAIN_START):add(j)
    for i in range(TRAIN_START,len(labels)):
        guess=None
        for length in range(min(MAX_LENGTH,i),0,-1):
            if not _contiguous(keys,i-length,i):break
            votes=tables[length].get(tuple(labels[i-length:i]),Counter())
            if sum(votes.values())>=MIN_SUPPORT:
                guess=max(range(8),key=lambda k:(votes[k],-k));break
        if guess is None:guess=max(range(8),key=lambda k:(baseline[k],-k))
        yield guess
        if i>=window:
            old=i-window
            baseline[labels[old]]-=1
            # Each left-boundary prefix now contains a period outside the
            # window. Remove exactly those examples before adding the target.
            for length in range(1,MAX_LENGTH+1):
                j=old+length
                if j>=i:break
                if not _contiguous(keys,old,j):continue
                tables[length][tuple(labels[old:j])][labels[j]]-=1
        baseline[labels[i]]+=1
        add(i,max(0,i-window+1))


def pattern_report(rows):
    """Expose both the longest literal replay and the longest supported replay."""
    rows=list(rows)
    labels=[int(v) if v is not None and 0<=int(v)<=7 else None for _,v in rows]
    keys=[issue_index(k) for k,_ in rows]
    if not rows or labels[-1] is None:
        return {'status':'等待有效的最新一期','sample':len(rows),'exact':None,'supported':None,'omissions':[]}
    suffix=0
    for i in range(len(rows)-1,-1,-1):
        if labels[i] is None or i<len(rows)-1 and keys[i+1]!=keys[i]+1:break
        suffix+=1
    exact=supported=None
    for length in range(min(MAX_LENGTH,suffix),1,-1):
        needle=tuple(labels[-length:])
        counts=Counter()
        examples=[]
        for j in range(length,len(rows)):
            if labels[j] is None or tuple(labels[j-length:j])!=needle:continue
            if not _contiguous(keys,j-length,j):continue
            counts[labels[j]]+=1
            if len(examples)<5:examples.append(rows[j][0])
        observations=sum(counts.values())
        if observations:
            item={'length':length,'sequence':list(needle),'samples':observations,
                  'counts':[counts[k] for k in range(8)],
                  'group16':(counts[1]+counts[6])/observations,
                  'examples':examples}
            if exact is None:exact=item
            if supported is None and observations>=MIN_SUPPORT:supported=item
        if exact and supported:break
    omissions=[]
    for target in range(8):
        complete=[];gap=None
        for i,label in enumerate(labels):
            if label is None or i and keys[i]!=keys[i-1]+1:
                gap=None
            if label is None:continue
            if label==target:
                if gap is not None:complete.append(gap)
                gap=0
            elif gap is not None:gap+=1
        at_risk=sum(x>=gap for x in complete) if gap is not None else 0
        next_hit=sum(x==gap for x in complete) if gap is not None else 0
        omissions.append({'single':target,'currentGap':gap,
                          'historicalMaxCompleted':max(complete) if complete else None,
                          'completeRuns':len(complete),'atRisk':at_risk,
                          'nextHits':next_hit,
                          'nextRate':next_hit/at_risk if at_risk>=MIN_SUPPORT else None})
    return {'status':'ready' if supported else '样本不足','sample':len(rows),
            'lastPeriod':rows[-1][0],'exact':exact,'supported':supported,
            'omissions':omissions,
            'minimumSupport':MIN_SUPPORT,
            'note':'历史序列后继比例仅为描述；不足5次只展示，不用于首名预测。遗漏统计只用完整间隔；缺期中断，不存在必出的最高期限。须与固定基线和后续真实新期比较。'}
