"""Read block-tail history across the current and legacy raw-block stores.

Some long-running God8 databases still contain older captured hashes in
``historical_raw_blocks``.  Tail browsing must not silently ignore those
hashes just because they have not yet been copied into ``raw_blocks``.
"""
from core import DB, from_index, save_blocks_batch, target_block, valid_result
from god8_flow import first_complete_index


def _legacy_exists(cursor):
    cursor.execute("SELECT to_regclass('public.historical_raw_blocks')")
    return bool(cursor.fetchone()[0])


def _decoded(row):
    """Return a normalized row and derive legacy values from the immutable hash."""
    block, block_hash, numbers, single, materialized = row
    if not materialized:
        numbers, single = valid_result(block_hash)
    return {
        'block': int(block), 'hash': block_hash,
        'numbers': numbers, 'single': single,
        'materialized': bool(materialized),
    }


def tail_total(tail):
    with DB() as c:
        q=c.cursor()
        if _legacy_exists(q):
            q.execute('''SELECT
                (SELECT COUNT(*) FROM raw_blocks WHERE MOD(block_number,10)=%s) +
                (SELECT COUNT(*) FROM historical_raw_blocks h
                 WHERE MOD(h.block_number,10)=%s
                   AND NOT EXISTS (SELECT 1 FROM raw_blocks r WHERE r.block_number=h.block_number))''',
                      (tail,tail))
        else:
            q.execute('SELECT COUNT(*) FROM raw_blocks WHERE MOD(block_number,10)=%s',(tail,))
        total=int(q.fetchone()[0] or 0)
        q.close()
    return total


def tail_rows(tail, limit, offset=0):
    """Newest distinct rows for a decimal block tail, including legacy-only hashes."""
    with DB() as c:
        q=c.cursor()
        if _legacy_exists(q):
            q.execute('''SELECT block_number,block_hash,numbers,single_count,materialized
                         FROM (
                           SELECT r.block_number,r.block_hash,r.numbers,r.single_count,TRUE AS materialized
                           FROM raw_blocks r WHERE MOD(r.block_number,10)=%s
                           UNION ALL
                           SELECT h.block_number,h.block_hash,NULL::jsonb,NULL::smallint,FALSE AS materialized
                           FROM historical_raw_blocks h
                           WHERE MOD(h.block_number,10)=%s
                             AND NOT EXISTS (SELECT 1 FROM raw_blocks r WHERE r.block_number=h.block_number)
                         ) u
                         ORDER BY block_number DESC LIMIT %s OFFSET %s''',
                      (tail,tail,int(limit),int(offset)))
        else:
            q.execute('''SELECT block_number,block_hash,numbers,single_count,TRUE AS materialized
                         FROM raw_blocks WHERE MOD(block_number,10)=%s
                         ORDER BY block_number DESC LIMIT %s OFFSET %s''',
                      (tail,int(limit),int(offset)))
        data=[_decoded(r) for r in q.fetchall()]
        q.close()
    return data


def materialize_legacy(rows, limit=250):
    """Copy viewed legacy hashes into raw_blocks without doing any network fetch.

    The UI gets complete results immediately from the union; this small bounded
    migration merely makes future reads cheaper and gradually normalizes an old DB.
    """
    pending=[r for r in rows if not r['materialized']][:max(0,int(limit))]
    if not pending:
        return 0, None
    try:
        save_blocks_batch([{'number':r['block'],'hash':r['hash'],'timestamp':None} for r in pending])
        return len(pending), None
    except Exception as exc:
        # Reading remains valid even if a legacy row cannot be materialized.  Never
        # hide history because of a background compatibility migration problem.
        return 0, str(exc)[:240]


def period_map(blocks):
    blocks=list(blocks)
    if not blocks:
        return {}
    with DB() as c:
        q=c.cursor()
        q.execute('SELECT target_block,period_key FROM periods WHERE target_block=ANY(%s)',(blocks,))
        pairs=q.fetchall();q.close()
    mapped={}
    for block,key in pairs:
        try:
            ds,no=key.split(':',1)
            if int(block)==target_block(ds,int(no)):
                mapped[int(block)]=key
        except (TypeError,ValueError):
            continue
    # A raw block may already be present while its formal period is still being
    # rebuilt. Infer the exact issue from the monotonic target mapping so tail
    # history never loses period labels during a transition repair.
    for block in map(int,blocks):
        if block in mapped:continue
        try:
            idx=first_complete_index(block-19)
            ds,no=from_index(idx)
            if target_block(ds,no)==block:
                mapped[block]=f'{ds}:{no:04d}'
        except (TypeError,ValueError,OverflowError):
            pass
    return mapped
