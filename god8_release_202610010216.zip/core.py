import os, json, time, hashlib, threading
from datetime import datetime, date, timedelta, timezone
from urllib.request import Request, urlopen
from urllib.error import HTTPError

CN = timezone(timedelta(hours=8))
DATABASE_URL=os.getenv('DATABASE_URL','')
TRON_API=os.getenv('TRON_API','https://api.trongrid.io/wallet').rstrip('/')
TRON_KEY=os.getenv('TRON_PRO_API_KEY','')
ANCHOR_DATE='2026-09-24'; ANCHOR_PERIOD=481; ANCHOR_BLOCK=86511906
PHASE=360
# 0991 is a single historical exception. The 0992 platform correction is a
# persistent -2 block offset, not a reset of the original 360-period clock.
CALIBRATION_DATE='2026-09-29'
CALIBRATION_FIRST=991
CALIBRATION_STABLE=992
CALIBRATION_BLOCK=86666082
TAIL_CYCLE=(8,6,4,2,0)
# Platform evidence confirms a temporary tail override inside the normal 2-tail phase:
# 2026-09-30 issue 1300 starts 3-tail; 2026-10-01 issue 0046 is the last
# 3-tail result (block 86704733); issue 0047 resumes 2-tail at block 86704752.
# The original 360-period clock is not reset, so issue 0121 still moves to 0-tail.
TRAIN_N=10000
RETAIN_PERIODS=60000

# v2.0.48: runtime rules live in Postgres and are reloaded without restarting.
# ``delta`` is applied on top of the stable post-0992 baseline mapping.
DEFAULT_RUNTIME_CONFIG = {
    "revision": 1,
    "reloadSeconds": 2.0,
    "tailMapping": {
        "segments": [
            {"start": "2026-09-30:1295", "end": "2026-09-30:1299", "delta": -18, "label": "confirmed-4-tail"},
            {"start": "2026-09-30:1300", "end": "2026-10-01:0046", "delta": -19, "label": "temporary-3-tail"},
            {"start": "2026-10-01:0047", "end": None, "delta": -20, "label": "resume-2-tail"},
        ]
    },
    "prediction": {
        "minimumTraining": 120,
        "minReplayLength": 4,
        "replaySupport": {"4": 1, "5": 1, "6": 1, "7": 1, "8": 1},
        "allowAdaptiveSecond": True,
        "trendWindows": [20, 50, 100],
        "trendWeights": [0.55, 0.30, 0.15],
        "hotLift": 1.20,
        "coldLift": 0.82,
    },
    "calibration": {"lookbackPeriods": 2500}
}
_RUNTIME_CACHE={"value":None,"checked":0.0}
_RUNTIME_CACHE_LOCK=threading.Lock()

try:
 import psycopg2
 from psycopg2.pool import ThreadedConnectionPool
except Exception:
 psycopg2=None; ThreadedConnectionPool=None
_pool=None; _pool_lock=threading.Lock()

def pindex(ds,p): return date.fromisoformat(ds).toordinal()*1440+int(p)-1
ANCHOR_INDEX=pindex(ANCHOR_DATE,ANCHOR_PERIOD)
SEP30_CONFIRMED_4=pindex('2026-09-30',1295)
SEP30_TEMP_3=pindex('2026-09-30',1300)
OCT1_RESUME_2=pindex('2026-10-01',47)
NEXT_ZERO_PHASE=pindex('2026-10-01',121)

def from_index(idx):
 o,z=divmod(int(idx),1440); return date.fromordinal(o).isoformat(),z+1

def period_key(ds,p): return f'{ds}:{int(p):04d}'

def _baseline_target_block(ds,p):
 d=pindex(ds,p)-ANCHOR_INDEX
 # Stable original 360-period clock plus the confirmed Sep-29 correction.
 base=ANCHOR_BLOCK + d*20 - 2*(d//PHASE)
 idx=pindex(ds,p)
 if idx>=pindex(CALIBRATION_DATE,CALIBRATION_STABLE):
  return base-2
 if idx==pindex(CALIBRATION_DATE,CALIBRATION_FIRST):
  return base-1
 return base

def _rule_index(value):
 if not value: return None
 ds,no=str(value).split(':',1)
 return pindex(ds,int(no))

def target_block(ds,p):
 base=_baseline_target_block(ds,p)
 idx=pindex(ds,p)
 cfg=runtime_config()
 for rule in reversed(cfg.get('tailMapping',{}).get('segments',[])):
  try:
   first=_rule_index(rule.get('start')); last=_rule_index(rule.get('end'))
   if first is not None and idx>=first and (last is None or idx<=last):
    return base+int(rule.get('delta',0))
  except (TypeError,ValueError,KeyError):
   continue
 return base

def expected_tail(ds,p): return target_block(ds,p)%10

def tail_is_high_standard(ds,p):
 tail=expected_tail(ds,p)
 return tail in TAIL_CYCLE and tail==target_block(ds,p)%10

def calc_numbers(block_hash):
 s=str(block_hash).upper()[::-1]
 letters=[c for c in s if c in 'ABCDE']; digits=[c for c in s if c.isdigit()]
 out=[]; used=set(); i=j=0
 while len(out)<7 and i<len(letters) and j<len(digits):
  v='ABCDE'.index(letters[i])*10+int(digits[j]); i+=1; j+=1
  if v==0 or v>49 or v in used: continue
  used.add(v); out.append(v)
 if len(out)!=7: raise ValueError('hash cannot produce 7 valid 01-49 numbers')
 return out

def single_count(nums): return sum(int(x)%2 for x in nums)

def valid_result(block_hash):
 """A hash may be real yet yield fewer than seven valid, distinct numbers."""
 try: nums=calc_numbers(block_hash)
 except ValueError: return None,None
 return nums,single_count(nums)

def http_json(url,payload=None,timeout=8):
 headers={'Content-Type':'application/json','User-Agent':'god8-v1/1.0'}
 if TRON_KEY: headers['TRON-PRO-API-KEY']=TRON_KEY
 data=json.dumps(payload).encode() if payload is not None else None
 req=Request(url,data=data,headers=headers,method='POST' if payload is not None else 'GET')
 with urlopen(req,timeout=timeout) as r: return json.loads(r.read().decode())

def fetch_block(n):
 d=http_json(TRON_API+'/getblockbynum',{'num':int(n)})
 h=d.get('blockID'); raw=d.get('block_header',{}).get('raw_data',{})
 if not h or int(raw.get('number',-1))!=int(n): raise RuntimeError(f'block {n} unavailable')
 return {'number':int(n),'hash':h,'timestamp':raw.get('timestamp')}

def fetch_block_range(start,end):
 """Fetch [start,end] inclusively. The remote endNum is exclusive."""
 payload={'startNum':int(start),'endNum':int(end)+1}
 data=http_json(TRON_API+'/getblockbylimitnext',payload,timeout=15)
 if data.get('Error'):
  raise RuntimeError(str(data['Error'])[:300])
 result={}
 for block in data.get('block',[]):
  raw=block.get('block_header',{}).get('raw_data',{})
  n=int(raw.get('number',-1)); h=block.get('blockID')
  if start<=n<=end and h:result[n]={'number':n,'hash':h,'timestamp':raw.get('timestamp')}
 return result

def fetch_latest():
 d=http_json(TRON_API+'/getnowblock',{})
 raw=d.get('block_header',{}).get('raw_data',{})
 return {'number':int(raw['number']),'hash':d['blockID'],'timestamp':raw.get('timestamp')}

def pool():
 global _pool
 if not DATABASE_URL or not psycopg2: raise RuntimeError('DATABASE_URL/psycopg2 required')
 with _pool_lock:
  if _pool is None: _pool=ThreadedConnectionPool(1,int(os.getenv('DB_POOL_MAX','8')),DATABASE_URL,connect_timeout=8)
 return _pool

class DB:
 def __enter__(self): self.c=pool().getconn(); return self.c
 def __exit__(self,t,v,b):
  try: self.c.rollback() if t else self.c.commit()
  finally: pool().putconn(self.c)

def init_db():
 with DB() as c:
  q=c.cursor();q.execute('SELECT pg_advisory_xact_lock(%s)',(80086421,)); q.execute('''CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY,v JSONB NOT NULL,updated_at TIMESTAMPTZ DEFAULT NOW());
 CREATE TABLE IF NOT EXISTS raw_blocks(block_number BIGINT PRIMARY KEY,block_hash TEXT NOT NULL,block_time TIMESTAMPTZ,numbers JSONB,single_count SMALLINT,fetched_at TIMESTAMPTZ DEFAULT NOW());
 CREATE TABLE IF NOT EXISTS periods(period_key TEXT PRIMARY KEY,period_date DATE NOT NULL,period_no INT NOT NULL,target_block BIGINT NOT NULL UNIQUE,block_hash TEXT NOT NULL,numbers JSONB,single_count SMALLINT,source TEXT NOT NULL,training_set BOOLEAN DEFAULT FALSE,audit_ok BOOLEAN DEFAULT FALSE,created_at TIMESTAMPTZ DEFAULT NOW());
 CREATE INDEX IF NOT EXISTS periods_date_no ON periods(period_date DESC,period_no DESC);
 CREATE INDEX IF NOT EXISTS periods_single_latest ON periods(single_count,period_date DESC,period_no DESC);
 CREATE TABLE IF NOT EXISTS groups(period_key TEXT NOT NULL,group_no SMALLINT NOT NULL,block_number BIGINT NOT NULL,block_hash TEXT NOT NULL,numbers JSONB,single_count SMALLINT,PRIMARY KEY(period_key,group_no),UNIQUE(period_key,block_number));
 CREATE TABLE IF NOT EXISTS repair_queue(block_number BIGINT PRIMARY KEY,attempts INT DEFAULT 0,last_error TEXT,next_try TIMESTAMPTZ DEFAULT NOW());
 CREATE TABLE IF NOT EXISTS audit_runs(id BIGSERIAL PRIMARY KEY,started_at TIMESTAMPTZ DEFAULT NOW(),finished_at TIMESTAMPTZ,checked INT DEFAULT 0,errors INT DEFAULT 0,report JSONB,pass BOOLEAN DEFAULT FALSE);
 CREATE TABLE IF NOT EXISTS ai_models(id BIGSERIAL PRIMARY KEY,created_at TIMESTAMPTZ DEFAULT NOW(),trainset_id TEXT NOT NULL,method TEXT NOT NULL,params JSONB,metrics JSONB NOT NULL,tier INT,adopted BOOLEAN DEFAULT FALSE,artifact JSONB);
 CREATE TABLE IF NOT EXISTS ai_predictions(id BIGSERIAL PRIMARY KEY,model_id BIGINT REFERENCES ai_models(id),period_key TEXT NOT NULL,prediction SMALLINT,actual SMALLINT,mode TEXT NOT NULL,created_at TIMESTAMPTZ DEFAULT NOW(),UNIQUE(model_id,period_key,mode));
 CREATE TABLE IF NOT EXISTS ai_simulations(trainset_id TEXT NOT NULL,method TEXT NOT NULL,period_key TEXT NOT NULL,phase TEXT NOT NULL,prediction SMALLINT,actual SMALLINT NOT NULL,created_at TIMESTAMPTZ DEFAULT NOW(),PRIMARY KEY(trainset_id,method,period_key));
 CREATE TABLE IF NOT EXISTS replay_forecasts(period_key TEXT PRIMARY KEY,source_period TEXT NOT NULL,source_block BIGINT NOT NULL,choices JSONB NOT NULL,match JSONB NOT NULL,locked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),actual SMALLINT,settled_at TIMESTAMPTZ);
 CREATE TABLE IF NOT EXISTS pattern_memories(period_key TEXT PRIMARY KEY, single_count SMALLINT NOT NULL, report JSONB NOT NULL, recorded_at TIMESTAMPTZ DEFAULT NOW());
 CREATE INDEX IF NOT EXISTS replay_forecasts_locked ON replay_forecasts(locked_at DESC);
 CREATE TABLE IF NOT EXISTS lab_forecasts(period_key TEXT PRIMARY KEY,source_period TEXT NOT NULL,choices JSONB NOT NULL,ai_prediction SMALLINT NOT NULL,ai_method TEXT NOT NULL,weights JSONB NOT NULL,locked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),actual SMALLINT,settled_at TIMESTAMPTZ);
 CREATE TABLE IF NOT EXISTS ai_adoptions(id BIGSERIAL PRIMARY KEY,model_id BIGINT NOT NULL REFERENCES ai_models(id),previous_model_id BIGINT,authorized_at TIMESTAMPTZ DEFAULT NOW(),approval_method TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS ai_switches(id BIGSERIAL PRIMARY KEY,from_model_id BIGINT,to_model_id BIGINT,reason TEXT NOT NULL,occurred_at TIMESTAMPTZ DEFAULT NOW());
 CREATE TABLE IF NOT EXISTS ai2_models(id BIGSERIAL PRIMARY KEY,stage_no INT NOT NULL,method TEXT NOT NULL,fingerprint TEXT NOT NULL,metrics JSONB NOT NULL,artifact JSONB NOT NULL,created_at TIMESTAMPTZ DEFAULT NOW(),UNIQUE(stage_no,method,fingerprint));
 CREATE TABLE IF NOT EXISTS ai2_predictions(id BIGSERIAL PRIMARY KEY,model_id BIGINT NOT NULL REFERENCES ai2_models(id),period_key TEXT NOT NULL,prediction SMALLINT NOT NULL,actual SMALLINT,feature_block BIGINT NOT NULL,locked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),valid BOOLEAN,UNIQUE(model_id,period_key));
 CREATE INDEX IF NOT EXISTS ai2_predictions_pending ON ai2_predictions(period_key) WHERE actual IS NULL;
 CREATE TABLE IF NOT EXISTS god8_stage_checks(stage_no INT PRIMARY KEY,start_index BIGINT NOT NULL,end_index BIGINT NOT NULL,fingerprint TEXT,report JSONB NOT NULL,audited_at TIMESTAMPTZ DEFAULT NOW());
 CREATE TABLE IF NOT EXISTS god8_stage_reviews(stage_no INT NOT NULL,model_id BIGINT NOT NULL REFERENCES ai_models(id),metrics JSONB NOT NULL,created_at TIMESTAMPTZ DEFAULT NOW(),PRIMARY KEY(stage_no,model_id));
 ALTER TABLE periods ALTER COLUMN numbers DROP NOT NULL;
 ALTER TABLE periods ALTER COLUMN single_count DROP NOT NULL;
 ALTER TABLE groups ALTER COLUMN numbers DROP NOT NULL;
 ALTER TABLE groups ALTER COLUMN single_count DROP NOT NULL;
 ALTER TABLE ai_predictions ADD COLUMN IF NOT EXISTS feature_block BIGINT;
 ALTER TABLE ai_predictions ADD COLUMN IF NOT EXISTS locked_at TIMESTAMPTZ;
 ALTER TABLE ai_predictions ADD COLUMN IF NOT EXISTS valid BOOLEAN;
 CREATE INDEX IF NOT EXISTS ai_predictions_pending ON ai_predictions(period_key) WHERE actual IS NULL;'''); q.execute("INSERT INTO meta(k,v,updated_at) VALUES('runtime_config',%s::jsonb,NOW()) ON CONFLICT(k) DO NOTHING",(json.dumps(DEFAULT_RUNTIME_CONFIG),)); q.close()

def set_meta(k,v):
 with DB() as c:
  q=c.cursor(); q.execute("INSERT INTO meta(k,v,updated_at) VALUES(%s,%s::jsonb,NOW()) ON CONFLICT(k) DO UPDATE SET v=EXCLUDED.v,updated_at=NOW()",(k,json.dumps(v)));q.close()

def get_meta(k,default=None):
 with DB() as c:
  q=c.cursor();q.execute('SELECT v FROM meta WHERE k=%s',(k,));r=q.fetchone();q.close();return r[0] if r else default

def _clone_default_runtime():
 return json.loads(json.dumps(DEFAULT_RUNTIME_CONFIG))

def _normalize_runtime_config(raw):
 cfg=_clone_default_runtime()
 if not isinstance(raw,dict):
  return cfg
 try: cfg['revision']=max(1,int(raw.get('revision',cfg['revision'])))
 except (TypeError,ValueError): pass
 try: cfg['reloadSeconds']=max(.5,min(30.0,float(raw.get('reloadSeconds',cfg['reloadSeconds']))))
 except (TypeError,ValueError): pass
 mapping=raw.get('tailMapping') if isinstance(raw.get('tailMapping'),dict) else {}
 segments=mapping.get('segments') if isinstance(mapping.get('segments'),list) else cfg['tailMapping']['segments']
 clean=[]
 for item in segments[:32]:
  if not isinstance(item,dict): continue
  try:
   start=str(item['start']); _rule_index(start)
   end=item.get('end')
   if end is not None:
    end=str(end); _rule_index(end)
    if _rule_index(end)<_rule_index(start): raise ValueError('end before start')
   delta=int(item.get('delta',0))
   if not -100<=delta<=100: raise ValueError('delta out of range')
  except (KeyError,TypeError,ValueError):
   continue
  clean.append({'start':start,'end':end,'delta':delta,'label':str(item.get('label',''))[:80]})
 if clean: cfg['tailMapping']['segments']=clean
 pred=raw.get('prediction') if isinstance(raw.get('prediction'),dict) else {}
 out=cfg['prediction']
 for key,lo,hi in [('minimumTraining',20,5000),('minReplayLength',4,8)]:
  try: out[key]=max(lo,min(hi,int(pred.get(key,out[key]))))
  except (TypeError,ValueError): pass
 out['allowAdaptiveSecond']=bool(pred.get('allowAdaptiveSecond',out['allowAdaptiveSecond']))
 support=pred.get('replaySupport') if isinstance(pred.get('replaySupport'),dict) else {}
 for length in range(4,9):
  try: out['replaySupport'][str(length)]=max(1,min(50,int(support.get(str(length),out['replaySupport'][str(length)]))))
  except (TypeError,ValueError): pass
 windows=pred.get('trendWindows')
 weights=pred.get('trendWeights')
 if isinstance(windows,list) and isinstance(weights,list) and len(windows)==len(weights) and 1<=len(windows)<=5:
  try:
   ws=[max(5,min(1000,int(x))) for x in windows]; wt=[max(0.0,float(x)) for x in weights]
   total=sum(wt)
   if total>0:
    out['trendWindows']=ws; out['trendWeights']=[x/total for x in wt]
  except (TypeError,ValueError): pass
 for key,lo,hi in [('hotLift',1.0,3.0),('coldLift',0.1,1.0)]:
  try: out[key]=max(lo,min(hi,float(pred.get(key,out[key]))))
  except (TypeError,ValueError): pass
 cal=raw.get('calibration') if isinstance(raw.get('calibration'),dict) else {}
 try: cfg['calibration']['lookbackPeriods']=max(200,min(10000,int(cal.get('lookbackPeriods',cfg['calibration']['lookbackPeriods']))))
 except (TypeError,ValueError): pass
 return cfg

def runtime_config(force=False):
 now=time.monotonic()
 with _RUNTIME_CACHE_LOCK:
  cached=_RUNTIME_CACHE.get('value')
  ttl=(cached or DEFAULT_RUNTIME_CONFIG).get('reloadSeconds',2.0)
  if cached is not None and not force and now-_RUNTIME_CACHE.get('checked',0.0)<ttl:
   return cached
 try:
  with DB() as c:
   q=c.cursor();q.execute("SELECT v FROM meta WHERE k='runtime_config'");row=q.fetchone();q.close()
  value=_normalize_runtime_config(row[0] if row else None)
 except Exception:
  value=_normalize_runtime_config(cached or DEFAULT_RUNTIME_CONFIG)
 with _RUNTIME_CACHE_LOCK:
  _RUNTIME_CACHE['value']=value;_RUNTIME_CACHE['checked']=now
 return value

def runtime_config_revision():
 return int(runtime_config().get('revision',1))

def set_runtime_config(value):
 clean=_normalize_runtime_config(value)
 with DB() as c:
  q=c.cursor();q.execute('SELECT pg_advisory_xact_lock(%s)',(80086422,))
  q.execute("SELECT v FROM meta WHERE k='runtime_config' FOR UPDATE");row=q.fetchone()
  old=_normalize_runtime_config(row[0] if row else None)
  clean['revision']=max(int(old.get('revision',1))+1,int(clean.get('revision',1)))
  q.execute("INSERT INTO meta(k,v,updated_at) VALUES('runtime_config',%s::jsonb,NOW()) ON CONFLICT(k) DO UPDATE SET v=EXCLUDED.v,updated_at=NOW()",(json.dumps(clean),))
  q.execute("INSERT INTO meta(k,v,updated_at) VALUES('runtime_repair_request',%s::jsonb,NOW()) ON CONFLICT(k) DO UPDATE SET v=EXCLUDED.v,updated_at=NOW()",(json.dumps({'revision':clean['revision'],'requestedAt':datetime.now(timezone.utc).isoformat()}),))
  q.close()
 with _RUNTIME_CACHE_LOCK:
  _RUNTIME_CACHE['value']=clean;_RUNTIME_CACHE['checked']=time.monotonic()
 return clean

def add_runtime_tail_override(start_period,end_period,tail,label='hot-tail-override'):
 """Append a last-wins tail override and persist it as a new runtime revision."""
 ds,no=str(start_period).split(':',1); no=int(no)
 if not 0<=int(tail)<=9: raise ValueError('tail must be 0..9')
 start_key=f'{ds}:{no:04d}'
 _rule_index(start_key)
 end_key=None
 if end_period:
  eds,eno=str(end_period).split(':',1);end_key=f'{eds}:{int(eno):04d}'
  if _rule_index(end_key)<_rule_index(start_key): raise ValueError('end before start')
 cfg=runtime_config(force=True)
 current=target_block(ds,no)
 baseline=_baseline_target_block(ds,no)
 current_delta=current-baseline
 diff=(int(tail)-(current%10))%10
 if diff>5: diff-=10
 new_delta=int(current_delta+diff)
 segments=list(cfg.get('tailMapping',{}).get('segments',[]))
 segments.append({'start':start_key,'end':end_key,'delta':new_delta,'label':str(label)[:80]})
 cfg['tailMapping']={'segments':segments[-32:]}
 return set_runtime_config(cfg)

def save_block(b):
 nums,sc=valid_result(b['hash']); ts=datetime.fromtimestamp(b['timestamp']/1000,timezone.utc) if b.get('timestamp') else None
 with DB() as c:
  q=c.cursor();q.execute('''INSERT INTO raw_blocks(block_number,block_hash,block_time,numbers,single_count) VALUES(%s,%s,%s,%s::jsonb,%s)
 ON CONFLICT(block_number) DO NOTHING''',(b['number'],b['hash'],ts,json.dumps(nums) if nums is not None else None,sc))
  q.execute('SELECT block_hash FROM raw_blocks WHERE block_number=%s',(b['number'],)); stored=q.fetchone()[0]
  if stored.lower()!=b['hash'].lower():raise ValueError('conflicting block hash at %s'%b['number'])
  q.close()
 return nums,sc

def save_blocks_batch(blocks):
 """Store a range in one transaction; conflicting hashes are never replaced."""
 if not blocks: return 0
 from psycopg2.extras import execute_values
 items=[]
 for b in blocks:
  nums,sc=valid_result(b['hash'])
  ts=datetime.fromtimestamp(b['timestamp']/1000,timezone.utc) if b.get('timestamp') else None
  items.append((int(b['number']),b['hash'],ts,json.dumps(nums) if nums is not None else None,sc))
 if not items: return 0
 with DB() as c:
  q=c.cursor()
  execute_values(q,'''INSERT INTO raw_blocks(block_number,block_hash,block_time,numbers,single_count)
    VALUES %s ON CONFLICT(block_number) DO NOTHING''',items,
    template='(%s,%s,%s,%s::jsonb,%s)',page_size=100)
  q.execute('SELECT block_number,block_hash FROM raw_blocks WHERE block_number=ANY(%s)',
            ([item[0] for item in items],))
  saved=dict(q.fetchall())
  for item in items:
   if saved.get(item[0],'').lower()!=item[1].lower():
    raise ValueError('conflicting block hash at %s'%item[0])
  q.close()
 return len(items)

def save_period(ds,p,source='history',training=False):
 from psycopg2.extras import execute_values
 tb=target_block(ds,p); needed=list(range(tb-19,tb+1))
 with DB() as c:
  q=c.cursor();q.execute('SELECT block_number,block_hash,numbers,single_count FROM raw_blocks WHERE block_number=ANY(%s)',(needed,)); rows={int(r[0]):r for r in q.fetchall()};q.close()
 missing=[n for n in needed if n not in rows]
 if missing: return False,missing
 key=period_key(ds,p); last=rows[tb]; nums=last[2] if isinstance(last[2],list) else json.loads(last[2]) if last[2] is not None else None
 with DB() as c:
  q=c.cursor()
  q.execute('SELECT target_block FROM periods WHERE period_key=%s FOR UPDATE',(key,))
  previous=q.fetchone()
  if previous and previous[0]!=tb:
   # A forward phase shift can point a new group at a height occupied by a
   # different old group. Rebuild all 20 atomically instead of hitting the
   # UNIQUE(period_key,block_number) constraint during row-by-row UPSERT.
   q.execute('DELETE FROM groups WHERE period_key=%s',(key,))
  q.execute('''INSERT INTO periods(period_key,period_date,period_no,target_block,block_hash,numbers,single_count,source,training_set)
 VALUES(%s,%s,%s,%s,%s,%s::jsonb,%s,%s,%s) ON CONFLICT(period_key) DO UPDATE SET target_block=EXCLUDED.target_block,block_hash=EXCLUDED.block_hash,numbers=EXCLUDED.numbers,single_count=EXCLUDED.single_count,source=EXCLUDED.source,training_set=(periods.training_set OR EXCLUDED.training_set)''',(key,ds,p,tb,last[1],json.dumps(nums) if nums is not None else None,last[3],source if nums is not None else 'invalid-hash',training))
  group_rows=[]
  for g,bn in enumerate(needed,1):
   r=rows[bn]; gn=r[2] if isinstance(r[2],list) else json.loads(r[2]) if r[2] is not None else None
   group_rows.append((key,g,bn,r[1],json.dumps(gn) if gn is not None else None,r[3]))
  execute_values(q,'''INSERT INTO groups(period_key,group_no,block_number,block_hash,numbers,single_count)
   VALUES %s ON CONFLICT(period_key,group_no) DO UPDATE SET
   block_number=EXCLUDED.block_number,block_hash=EXCLUDED.block_hash,
   numbers=EXCLUDED.numbers,single_count=EXCLUDED.single_count''',group_rows,
   template='(%s,%s,%s,%s,%s::jsonb,%s)',page_size=20)
  q.close()
 return True,[]

def training_fingerprint():
 with DB() as c:
  q=c.cursor();q.execute("SELECT period_key,target_block,block_hash,numbers,single_count FROM periods WHERE training_set=TRUE ORDER BY period_date,period_no");rows=q.fetchall();q.close()
 h=hashlib.sha256()
 for r in rows: h.update(json.dumps(r,default=str,sort_keys=True,separators=(',',':')).encode())
 return h.hexdigest(),len(rows)
