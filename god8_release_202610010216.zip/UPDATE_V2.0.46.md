# v2.0.46 · 3尾过渡全链路规范化

## 修复范围

- 新增 `canonical_history.py` 统一规范化开奖记录读取层。
- 3尾窗口 1300→0046 强制 raw block 校验；0047 起按2尾；0121起按0尾。
- 首页历史、历史分页/搜索、遗漏全套接口、统计研究、更多玩法复盘、实验复盘统一使用规范化结果。
- 两组预判 `live_replay.py` 与实验预判 `lab_live.py` 的最近10,000期样本改为规范化历史。
- 模式记忆历史样本改为规范化历史。
- `fate` 证据页使用当前 target_block 与 raw block 时间核验，不再依赖旧 period target。
- 尾数历史的期号映射增加 target_block 反推，正式期记录尚未重建时也不会丢失期号标签。
- 平台启动校准从20批提升到80批，并报告 remainingMismatch / remainingMissing。
- 历史结果修正同步回写 replay/lab actual；AI/AI2 同时重算 actual 与开奖前 valid 标记；删除受影响 pattern_memories 归档等待重算。
- `/api/ai/streaks` 与 `/api/ai/patterns` 改为实时读取规范化历史，不再返回尾数修正前缓存报告。

## 数据原则

正确 target raw block 有结果时，以 raw block 为准；正式表目标错误或处于本次过渡窗口但 raw 尚未核对时，不使用旧结果参与遗漏、统计或预测。

## 回归

已通过64项不依赖 Flask 的核心测试，其中新增4项 v2.0.46 规范化历史测试，覆盖0046最后3尾、0047恢复2尾、错误正式行不泄漏、遗漏按规范化结果计算。Web 相关测试在当前离线打包环境因未安装 Flask 无法执行，所有修改 Python 文件均已通过 `py_compile`。
