"""Descriptive historical game categories. No predictions or model training."""
from collections import Counter

from streak_research import issue_index

RED = frozenset((1,2,7,8,12,13,18,19,23,24,29,30,34,35,40,45,46))
BLUE = frozenset((3,4,9,10,14,15,20,25,26,31,36,37,41,42,47,48))
MODES = ('single', 'special', 'all')
KINDS = ('single', 'number', 'tail', 'head', 'wave', 'parity', 'size')
OPTIONS = {
    'single': [str(n) for n in range(8)],
    'number': [str(n) for n in range(1, 50)],
    'tail': [str(n) for n in range(10)],
    'head': [str(n) for n in range(5)],
    'wave': ['红波', '蓝波', '绿波'],
    'parity': ['单', '双'],
    'size': ['小', '大'],
}


def _matches(number, kind, value):
    if kind == 'number': return number == int(value)
    if kind == 'tail': return number % 10 == int(value)
    if kind == 'head': return number // 10 == int(value)
    if kind == 'wave':
        return ('红波' if number in RED else '蓝波' if number in BLUE else '绿波') == value
    if kind == 'parity': return ('单' if number % 2 else '双') == value
    if kind == 'size': return ('小' if number <= 24 else '大') == value
    return False


def _valid_numbers(numbers):
    return (isinstance(numbers, list) and len(numbers) == 7 and
            all(type(n) is int and 1 <= n <= 49 for n in numbers) and
            len(set(numbers)) == 7)


def summarize(rows, mode='special', kind='wave', value='红波', wave='', parity='', size=''):
    """Rows newest first. A hit means at least one matching ball in a valid draw."""
    if mode not in MODES or kind not in KINDS or value not in OPTIONS[kind]:
        raise ValueError('玩法或选项无效')
    if (mode == 'single') != (kind == 'single'):
        raise ValueError('单几玩法只可选择单0至单7')
    if any((wave and wave not in OPTIONS['wave'],
            parity and parity not in OPTIONS['parity'], size and size not in OPTIONS['size'])):
        raise ValueError('组合条件无效')
    if mode == 'single' and any((wave, parity, size)):
        raise ValueError('单几玩法不能和号码条件组合')
    matched_numbers = ([int(value)] if mode == 'single' else
        [n for n in range(1, 50) if _matches(n, kind, value) and
         (not wave or _matches(n, 'wave', wave)) and
         (not parity or _matches(n, 'parity', parity)) and
         (not size or _matches(n, 'size', size))])
    sample, invalid, hits, last, newest_index, gap = 0, 0, 0, [], None, 0
    counts = Counter()
    for key, numbers, label in rows:
        index = issue_index(key)
        valid = type(label) is int and 0 <= label <= 7 if mode == 'single' else _valid_numbers(numbers)
        if not valid:
            invalid += 1
            if not hits: gap = None
            continue
        sample += 1
        selected = [label] if mode == 'single' else [numbers[6]] if mode == 'special' else numbers
        for option in OPTIONS[kind]:
            if any(int(option) == n if mode == 'single' else _matches(n, kind, option) for n in selected):
                counts[option] += 1
        hit = any(n in matched_numbers for n in selected)
        if not hits:
            if newest_index is not None and newest_index - index != 1: gap = None
            if gap is not None and not hit: gap += 1
            newest_index = index
        if hit:
            hits += 1
            if len(last) < 10: last.append(key)
    return {'mode':mode, 'kind':kind, 'value':value,
            'filters':{'wave':wave,'parity':parity,'size':size},
            'stored':len(rows),'valid':sample,'invalid':invalid,
            'hits':hits,'rate':hits/sample if sample else None,
            'currentGap':gap, 'matchingNumbers':matched_numbers,
            'recentHits':last,
            'options':[{'value':option,'hits':counts[option],
                        'rate':counts[option]/sample if sample else None}
                       for option in OPTIONS[kind]],
            'note':'分母只含本玩法所需字段有效的已存期开奖；缺期会中断连续遗漏。比例描述过去，不代表下一期概率或盈利。'}
