"""Record adaptive single-choice research independently from homepage replay."""
import json
from datetime import datetime, timezone

from core import DB, get_meta
from live_replay import forecast_due, target_for_latest
from research_lab import analyze
from canonical_history import load as canonical_load, as_analysis as canonical_analysis


def advance(now=None):
    now=now or datetime.now(timezone.utc)
    with DB() as conn:
        q=conn.cursor()
        q.execute('''UPDATE lab_forecasts f SET actual=p.single_count,settled_at=NOW()
                     FROM periods p WHERE f.period_key=p.period_key AND f.settled_at IS NULL''')
        q.close()
    latest_rows=canonical_load(limit=1,newest_first=True)
    if not latest_rows:
        return
    c=latest_rows[0]
    latest=(c[0],c[6],c[3],c[7])
    if latest[1] is None or not c[8]:
        return
    target,next_block=target_for_latest(latest[0])
    with DB() as conn:
        q=conn.cursor();q.execute('SELECT 1 FROM lab_forecasts WHERE period_key=%s',(target,))
        already=q.fetchone() is not None;q.close()
    if already or not forecast_due(now,latest[0],latest[3],next_block,
                                   (get_meta('chain_head') or {}).get('block')):
        return
    canonical=canonical_load(limit=10000,newest_first=True)
    history=canonical_analysis(canonical)
    if not history or history[0][0]!=latest[0]:
        return
    preview=analyze(history)['preview']
    if not preview or preview['issue'] != target[2:4]+target[5:7]+target[8:10]+target[11:]:
        return
    with DB() as conn:
        q=conn.cursor()
        q.execute('''INSERT INTO lab_forecasts(period_key,source_period,choices,ai_prediction,ai_method,weights)
                     SELECT %s,%s,%s::jsonb,%s,%s,%s::jsonb
                     WHERE NOT EXISTS(SELECT 1 FROM periods WHERE period_key=%s)
                       AND NOT EXISTS(SELECT 1 FROM raw_blocks WHERE block_number=%s)
                     ON CONFLICT(period_key) DO NOTHING''',
                  (target,latest[0],json.dumps(preview['predictions']),
                   preview['aiPrediction'],preview['aiMethod'],json.dumps(preview['weights']),
                   target,next_block))
        q.close()
