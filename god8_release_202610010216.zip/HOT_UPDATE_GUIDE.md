# v2.0.48 热更新使用说明（iPhone）

第一次升级 v2.0.48 仍需要正常部署一次。部署完成后：

1. 打开 `https://god8-web.onrender.com/runtime-config`。
2. 第一次使用时，从 Render → god8-web → Environment 复制 `ADMIN_TOKEN`，粘贴到页面。浏览器会只在本机保存它。
3. 平台临时改尾数时，在“快速尾数切换”输入十位期号（例如 `2610010047`）和目标尾数，结束期号不知道可以留空。
4. 点击“保存尾数规则并热生效”。配置写入 PostgreSQL，Web/Collector/Worker 约2秒内自动读取，无需 Restart。
5. 平台后来恢复时，再新增一条从恢复期号开始的尾数规则；最后新增的规则优先生效。
6. 已经锁定的当期两组预判不会被事后篡改；新参数从下一次计算使用。

高级 JSON 可调整：`minimumTraining`、`minReplayLength`、`replaySupport`、`allowAdaptiveSecond`、`trendWindows`、`trendWeights`、`hotLift`、`coldLift`、`calibration.lookbackPeriods`。

代码/UI 本身发生变化仍需部署新代码；GitHub 提交会触发 Render 自动部署。Collector 和 Worker 使用 PostgreSQL advisory lock 顺序接管，避免新旧实例重叠写库。
