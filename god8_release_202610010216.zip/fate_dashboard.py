"""Strict, read-only evidence ledger for forecasts locked before the draw block."""
from ai_research import wilson
from streak_research import issue_index


def summarize_ledger(rows):
    """Rows: period, source, choices, match, lock, actual, settle, block time, source block, target block, saved source target."""
    eligible = []
    excluded = {'unsettled': 0, 'invalidResult': 0, 'missingBlockTime': 0,
                'lateLock': 0, 'invalidChoices': 0, 'invalidSource': 0}
    for period, source, choices, match, locked, actual, settled, block_time, source_block, target_block, saved_source_block in rows:
        reason = None
        if settled is None:
            reason = 'unsettled'
        elif type(actual) is not int or not 0 <= actual <= 7:
            reason = 'invalidResult'
        elif not isinstance(choices, list) or len(choices) != 2 or any(type(n) is not int or not 0 <= n <= 7 for n in choices) or choices[0] == choices[1]:
            reason = 'invalidChoices'
        elif source is None or issue_index(source) != issue_index(period)-1 or source_block is None or target_block is None or saved_source_block != source_block or source_block >= target_block:
            reason = 'invalidSource'
        elif block_time is None:
            reason = 'missingBlockTime'
        elif locked is None or locked >= block_time:
            reason = 'lateLock'
        if reason:
            excluded[reason] += 1
            continue
        eligible.append({'period': period, 'issue': period[2:4]+period[5:7]+period[8:10]+period[11:],
                         'sourcePeriod': source, 'choices': choices, 'actual': actual,
                         'firstHit': choices[0] == actual, 'secondHit': choices[1] == actual,
                         'eitherHit': actual in choices, 'lockedAt': locked.isoformat(),
                         'blockAt': block_time.isoformat(),
                         'leadSeconds': round((block_time-locked).total_seconds(), 2),
                         'match': {'length': (match or {}).get('length', 0),
                                   'support': (match or {}).get('support', 0),
                                   'backoff': (match or {}).get('backoff')}})
    eligible.sort(key=lambda x: issue_index(x['period']))

    def metrics(part):
        n = len(part)
        counts = {name: sum(bool(row[name]) for row in part)
                  for name in ('firstHit', 'secondHit', 'eitherHit')}
        return {'verified': n,
                'first': {'hits': counts['firstHit'], 'rate': counts['firstHit']/n if n else None},
                'second': {'hits': counts['secondHit'], 'rate': counts['secondHit']/n if n else None},
                'either': {'hits': counts['eitherHit'], 'rate': counts['eitherHit']/n if n else None,
                           'lower95': wilson(counts['eitherHit'], n) if n else None}}

    streaks = {'first': 0, 'second': 0, 'either': 0}
    longest = streaks.copy()
    previous = None
    for row in eligible:
        current = issue_index(row['period'])
        if previous is not None and current != previous+1:
            streaks = dict.fromkeys(streaks, 0)
        for key, hit in (('first', row['firstHit']), ('second', row['secondHit']), ('either', row['eitherHit'])):
            streaks[key] = 0 if hit else streaks[key]+1
            longest[key] = max(longest[key], streaks[key])
        previous = current
    return {'all': metrics(eligible), 'last50': metrics(eligible[-50:]),
            'last200': metrics(eligible[-200:]),
            'streaks': {'current': streaks, 'longest': longest},
            'excluded': excluded, 'loaded': len(rows),
            'recent': list(reversed(eligible[-30:])),
            'note': '仅核对开奖前锁定且目标区块时间可核实的两码；缺失时间、迟锁、无效结果不计成绩。最近50/200按有效锁定记录计，并非自然连续50/200期。区块时间是链上时间戳。'}
