"""One leader within Monitor polls the chain head and adapts to measured responses."""
import os
import threading
import time
from collections import deque
from datetime import datetime, timezone
from urllib.error import HTTPError

from core import fetch_latest, get_meta, init_db, pool, save_block, set_meta

LOCK_ID = 86511906
HEAD_UPDATED = threading.Event()
HEAD_NUMBER = None


def next_interval(current, successful, errors, latency, floor=0.4, ceiling=3.0):
    """Slow quickly after throttling; speed up cautiously after stable samples."""
    if errors:
        return min(ceiling, max(floor, current * 1.7))
    if successful >= 20 and latency < 1.0:
        return max(floor, round(current * 0.9, 2))
    return min(ceiling, max(floor, current))


def recover_after_success(delay):
    """A successful node response ends the long 429 backoff immediately."""
    return min(3.0, delay)


def run_forever(already_locked=False):
    global HEAD_NUMBER
    init_db()
    lease = None
    if not already_locked:
        lease = pool().getconn()
        cur = lease.cursor()
        cur.execute('SELECT pg_try_advisory_lock(%s)', (LOCK_ID,))
        owned = cur.fetchone()[0]
        cur.close()
        lease.commit()
        if not owned:
            pool().putconn(lease)
            return  # another collector already owns the live stream
    try:
        delay = max(.4, min(3., float(os.getenv('MONITOR_POLL_SECONDS', '1.2'))))
        batch = deque(maxlen=30)
        last = None
        polls = changes = failures = 0
        while True:
            began = time.monotonic()
            try:
                latest = fetch_latest()
                polls += 1
                delay = recover_after_success(delay)
                if latest['number'] != last:
                    save_block(latest)
                    HEAD_NUMBER=latest['number']
                    HEAD_UPDATED.set()
                    # The live period builder must see the target as soon as
                    # the original block is stored, not at the 5s report tick.
                    set_meta('chain_head', {'block': latest['number'],
                        'seenAt': datetime.now(timezone.utc).isoformat(),
                        'source': 'monitor'})
                    last = latest['number']
                    changes += 1
                elapsed = time.monotonic() - began
                batch.append((True, elapsed))
                # Runtime report is rate-limited; one database write per ~5 seconds.
                if time.monotonic() - getattr(run_forever, '_reported', 0) >= 5:
                    samples = sorted(x[1] for x in batch if x[0])
                    p50 = samples[len(samples)//2] if samples else None
                    observed_errors = sum(not ok for ok, _ in batch)
                    # Old failures in the rolling report must not keep a
                    # successful poll at the throttled 30-60 second interval.
                    if not observed_errors:
                        delay = next_interval(delay, len(samples), 0, p50 or 0)
                    set_meta('monitor_stats', {'status': 'collecting',
                        'latestBlock': last, 'polls': polls, 'newBlocks': changes,
                        'errors': failures, 'medianLatencySeconds': p50,
                        'pollIntervalSeconds': delay, 'recentFailures': observed_errors,
                        'reportedAt': datetime.now(timezone.utc).isoformat()})
                    run_forever._reported = time.monotonic()
            except Exception as exc:
                failures += 1
                batch.append((False, time.monotonic() - began))
                if isinstance(exc,HTTPError) and exc.code in (403,429):
                    retry = exc.headers.get('Retry-After','')
                    try: retry = float(retry)
                    except (TypeError,ValueError): retry = 0
                    delay = min(60.0,max(3.0,delay*2,retry))
                else:
                    delay = next_interval(delay, 0, 1, 0)
                if time.monotonic() - getattr(run_forever, '_reported', 0) >= 5:
                    set_meta('monitor_stats', {'status': 'retrying', 'latestBlock': last,
                        'polls': polls, 'newBlocks': changes, 'errors': failures,
                        'pollIntervalSeconds': delay, 'lastError': str(exc)[:300],
                        'reportedAt': datetime.now(timezone.utc).isoformat()})
                    run_forever._reported = time.monotonic()
            time.sleep(max(.05, delay - (time.monotonic() - began)))
    finally:
        if not already_locked and lease is not None:
            try:
                cur = lease.cursor()
                cur.execute('SELECT pg_advisory_unlock(%s)', (LOCK_ID,))
                cur.close()
                lease.commit()
            finally:
                pool().putconn(lease)


def start():
    def supervise():
        while True:
            try:
                run_forever()
            except Exception:
                pass  # Audit failover remains active; retry Monitor without killing Web.
            time.sleep(5)
    threading.Thread(target=supervise, name='monitor-chain-head', daemon=True).start()
