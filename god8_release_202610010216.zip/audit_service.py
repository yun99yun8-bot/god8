"""Live capture, gap repair and post-backfill auditing; independent of the AI worker."""
import time
import threading
import json
from datetime import datetime, timedelta, timezone

from audit import run_audit
from core import (CN, DB, TRAIN_N, fetch_block, fetch_block_range, fetch_latest, from_index,
                  get_meta, init_db, pindex, save_block, save_period,
                  set_meta, target_block, training_fingerprint, period_key)
from god8_flow import origin_index, stage_window, stage_rows, stage_fingerprint, prune_old_periods


def period_ready(ds, no):
    with DB() as c:
        q = c.cursor()
        q.execute('''SELECT p.target_block,COUNT(g.group_no) FROM periods p
                     LEFT JOIN groups g ON g.period_key=p.period_key
                     WHERE p.period_key=%s GROUP BY p.target_block''', (period_key(ds, no),))
        row = q.fetchone()
        q.close()
    return bool(row and row[0] == target_block(ds, no) and row[1] == 20)


def repair_one(number):
    try:
        save_block(fetch_block(number))
        with DB() as c:
            q = c.cursor()
            q.execute('DELETE FROM repair_queue WHERE block_number=%s', (number,))
            q.close()
        return True
    except Exception as exc:
        with DB() as c:
            q = c.cursor()
            q.execute('''INSERT INTO repair_queue(block_number,attempts,last_error,next_try)
                         VALUES(%s,1,%s,NOW()+interval '10 seconds')
                         ON CONFLICT(block_number) DO UPDATE SET attempts=repair_queue.attempts+1,
                         last_error=EXCLUDED.last_error,
                         next_try=NOW()+LEAST(300,10*(repair_queue.attempts+1))*interval '1 second' ''',
                      (number, str(exc)[:400]))
            q.close()
        return False


def queued_repairs(limit=12, minimum=0):
    with DB() as c:
        q = c.cursor()
        q.execute('''SELECT r.block_number FROM repair_queue r
                     LEFT JOIN raw_blocks b ON b.block_number=r.block_number
                     WHERE r.next_try<=NOW() AND b.block_number IS NULL
                       AND r.block_number >= %s
                     ORDER BY r.attempts,r.block_number DESC LIMIT %s''', (minimum,limit))
        numbers = [r[0] for r in q.fetchall()]
        q.execute('DELETE FROM repair_queue r USING raw_blocks b WHERE r.block_number=b.block_number')
        q.close()
    for n in numbers:
        repair_one(n)


def recent_periods(head):
    now = datetime.now(CN)
    origin=origin_index()
    if origin is None:
        return
    for back in range(0, 5):
        t = now - timedelta(minutes=back)
        ds, no = t.date().isoformat(), t.hour * 60 + t.minute
        if no == 0:
            ds = (t.date() - timedelta(days=1)).isoformat()
            no = 1440
        if pindex(ds,no)<origin:
            continue
        target = target_block(ds, no)
        if target > head:
            continue
        if period_ready(ds, no):
            continue
        ok, missing = save_period(ds, no, 'live', False)
        if ok and (get_meta('god8_forward') or {}).get('completedSinceOrigin',0)>=59980:
            prune_old_periods()
        if not ok and missing:
            with DB() as c:
                q = c.cursor()
                for n in missing:
                    q.execute('''INSERT INTO repair_queue(block_number,last_error)
                                 VALUES(%s,'recent live group missing') ON CONFLICT DO NOTHING''', (n,))
                q.close()


def catchup_periods(head):
    origin=origin_index()
    if origin is None:
        return
    saved = get_meta('audit_period_cursor') or {}
    if 'index' in saved:
        index = max(origin-1,int(saved['index']))
    else:
        index=origin-1
    for following in range(index+1, index+6):
        ds, no = from_index(following)
        if target_block(ds, no) > head:
            break
        ok, missing = (True, []) if period_ready(ds, no) else save_period(ds, no, 'live', False)
        if not ok:
            with DB() as c:
                q = c.cursor()
                for n in missing:
                    q.execute('''INSERT INTO repair_queue(block_number,last_error)
                                 VALUES(%s,'catch-up period group missing') ON CONFLICT DO NOTHING''', (n,))
                q.close()
            break
        index = following
        if (get_meta('god8_forward') or {}).get('completedSinceOrigin',0)>=59980:
            prune_old_periods()
    set_meta('audit_period_cursor', {'index': index})


def capture_forever():
    while True:
        try:
            observed = get_meta('chain_head') or {}
            stamp = observed.get('seenAt')
            age = (datetime.now(timezone.utc) - datetime.fromisoformat(stamp)).total_seconds() if stamp else 999
            monitor = get_meta('monitor_stats') or {}
            updated = monitor.get('reportedAt')
            retrying = (monitor.get('status') == 'retrying' and updated and
                        (datetime.now(timezone.utc)-datetime.fromisoformat(updated)).total_seconds()<12)
            if not retrying and (age >= 12 or observed.get('source') == 'audit-failover'):
                latest = fetch_latest()
                save_block(latest)
                set_meta('chain_head', {'block': latest['number'],
                    'seenAt': datetime.now(timezone.utc).isoformat(), 'source': 'audit-failover'})
                set_meta('audit_failover', {'active': True, 'reason': 'monitor heartbeat stale',
                    'lastBlock': latest['number']})
            elif (get_meta('audit_failover') or {}).get('active'):
                set_meta('audit_failover', {'active': False, 'reason': 'monitor collecting'})
        except Exception as exc:
            set_meta('audit_live_error', {'error': str(exc)[:400],
                                          'at': datetime.now(timezone.utc).isoformat()})
        time.sleep(2)


def repair_forever():
    cursor = (get_meta('audit_cursor') or {}).get('block')
    while True:
        try:
            monitor=get_meta('monitor_stats') or {}
            updated=monitor.get('reportedAt')
            if monitor.get('status')=='retrying' and updated and \
               (datetime.now(timezone.utc)-datetime.fromisoformat(updated)).total_seconds()<12:
                time.sleep(5)
                continue
            chain = get_meta('chain_head') or {}
            seen = chain.get('seenAt')
            if not seen or (datetime.now(timezone.utc)-datetime.fromisoformat(seen)).total_seconds()>8:
                time.sleep(4)
                continue
            head = chain.get('block')
            if head is not None:
                origin=origin_index()
                if origin is None:
                    time.sleep(2)
                    continue
                retained=(get_meta('god8_retention') or {}).get('oldest')
                first_index=max(origin,pindex(retained[:10],int(retained[11:])) if retained else origin)
                floor=target_block(*from_index(first_index))-20
                if cursor is None:
                    cursor=floor
                cursor=max(floor,cursor)
                rate=get_meta('monitor_stats') or {}
                good=rate.get('status')=='collecting' and not rate.get('recentFailures')
                batch=20 if good else 8
                end = min(head, cursor + batch)
                if cursor < end:
                    try:
                        got = fetch_block_range(cursor+1, end)
                    except Exception as exc:
                        got = {}
                        set_meta('audit_range_error', {'error': str(exc)[:300]})
                    for n, block in got.items():
                        save_block(block)
                    missing = set(range(cursor+1,end+1)) - set(got)
                    if missing:
                        with DB() as c:
                            q=c.cursor()
                            for n in missing:
                                q.execute('''INSERT INTO repair_queue(block_number,last_error)
                                             VALUES(%s,'range response incomplete') ON CONFLICT DO NOTHING''',(n,))
                            q.close()
                    cursor = end  # missing heights are persisted before advancing
                set_meta('audit_cursor', {'block': cursor, 'catchupBlocks': max(0, head - cursor)})
                queued_repairs(8 if good else 2, floor+1)
                recent_periods(head)
                catchup_periods(head)
                if time.monotonic() - getattr(repair_forever, '_reported', 0) > 10:
                    with DB() as c:
                        q = c.cursor()
                        q.execute('SELECT COUNT(*) FROM repair_queue')
                        queued = q.fetchone()[0]
                        q.close()
                    set_meta('audit_stats', {'status': 'repairing', 'chainHead': head,
                        'checkedThroughBlock': cursor, 'catchupBlocks': max(0, head-cursor),
                        'queuedMissingBlocks': queued,
                        'monitorIntervalSeconds':rate.get('pollIntervalSeconds'),
                        'adaptiveRepairBatch':batch,
                        'reportedAt': datetime.now(timezone.utc).isoformat()})
                    repair_forever._reported = time.monotonic()
        except Exception as exc:
            set_meta('audit_repair_error', {'error': str(exc)[:400]})
        time.sleep(1)


def verify_forever():
    while True:
        try:
            origin=origin_index()
            forward=(get_meta('god8_forward') or {})
            finished=max(int((get_meta('god8_completed_stages') or {}).get('highest',-1)),
                         int(forward.get('completedSinceOrigin',0))//TRAIN_N-1)
            if origin is not None and finished<0:
                set_meta('god8_audit_progress',{'status':'waiting-for-10000',
                    'checked':int(forward.get('completedSinceOrigin',0)),
                    'total':TRAIN_N,'updatedAt':datetime.now(timezone.utc).isoformat()})
            if origin is not None and finished>=0:
                with DB() as c:
                    q=c.cursor()
                    q.execute('SELECT stage_no FROM god8_stage_checks WHERE report->>\'pass\'=\'true\'')
                    checked={r[0] for r in q.fetchall()}
                    q.close()
                for stage in range(finished+1):
                    if stage in checked:
                        continue
                    begin,end=stage_window(origin,stage)
                    rows=stage_rows(begin,end)
                    if len(rows)!=TRAIN_N:
                        first=from_index(begin);last=from_index(end)
                        with DB() as c:
                            q=c.cursor()
                            q.execute('SELECT MIN(period_key),MAX(period_key) FROM periods')
                            saved_first,saved_last=q.fetchone()
                            q.close()
                        range_info={'firstPeriod':period_key(*first),
                                    'lastPeriod':period_key(*last),
                                    'savedFirstPeriod':saved_first,
                                    'savedLastPeriod':saved_last,
                                    'forwardCompleted':int(forward.get('completedSinceOrigin',0))}
                        set_meta('god8_audit_wait',{'stage':stage,'found':len(rows),
                            'reason':'missing or pruned period; no synthetic audit',
                            **range_info})
                        set_meta('god8_audit_progress',{'status':'waiting-for-complete-stage',
                            'stage':stage,'checked':len(rows),'total':TRAIN_N,
                            **range_info,
                            'updatedAt':datetime.now(timezone.utc).isoformat()})
                        continue
                    report=run_audit(False,begin,end)
                    fingerprint=stage_fingerprint(rows) if report['pass'] else None
                    with DB() as c:
                        q=c.cursor()
                        q.execute('''INSERT INTO god8_stage_checks(stage_no,start_index,end_index,fingerprint,report)
                                     VALUES(%s,%s,%s,%s,%s::jsonb)
                                     ON CONFLICT(stage_no) DO UPDATE SET fingerprint=EXCLUDED.fingerprint,
                                         report=EXCLUDED.report,audited_at=NOW()''',
                                  (stage,begin,end,fingerprint,json.dumps(report)))
                        q.close()
                    set_meta('god8_stage_audit_latest',{'stage':stage,'pass':report['pass'],
                        'checked':report['checkedPeriods'],'fingerprint':fingerprint})
                    if stage==0:
                        trainset=get_meta('god8_trainset') or {}
                        if report['pass']:
                            trainset.update({'locked':True,'count':TRAIN_N,
                                'fingerprint':fingerprint,'status':'ready-for-ai'})
                            set_meta('god8_trainset',trainset)
                            set_meta('ai_gate',{'allowed':True,
                                'status':'ready-for-ai-not-trained','fingerprint':fingerprint,
                                'trainsetId':'GOD8_STAGE0'})
                        else:
                            set_meta('ai_gate',{'allowed':False,'reason':'stage zero audit failed',
                                'errors':report['errors']})
                    if not report['pass']:
                        time.sleep(60)
                        break
        except Exception as exc:
            set_meta('audit_error', {'error': str(exc)[:400]})
            set_meta('god8_audit_progress',{'status':'error','error':str(exc)[:400],
                'updatedAt':datetime.now(timezone.utc).isoformat()})
        time.sleep(20)


def main():
    init_db()
    threading.Thread(target=verify_forever, daemon=True).start()
    threading.Thread(target=repair_forever, daemon=True).start()
    capture_forever()


if __name__ == '__main__':
    main()
