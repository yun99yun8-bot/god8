# The web process only reads the shared database. Collector runs separately.
workers = 1
threads = 4
timeout = 45
