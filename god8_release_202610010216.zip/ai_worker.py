"""AI component of the single Worker/AI service: stage research and G17 trials."""
import threading
import time
from datetime import datetime, timezone

from ai_research import (METHODS, REVISION, feature_rows, predict_future, wilson)
from core import (DB, from_index, get_meta, init_db, pindex, set_meta, target_block)
from god8_training import train_once
from streak_research import report as streak_report
from pattern_research import pattern_report


def latest_candidate():
    with DB() as c:
        q = c.cursor()
        q.execute('''SELECT period_date::text,period_no FROM periods
                     ORDER BY period_date DESC,period_no DESC LIMIT 1''')
        row = q.fetchone()
        q.close()
    if not row:
        mark_lock_status('no completed period in database')
        return None
    ds, no = from_index(pindex(*row)+1)
    block = target_block(ds, no)
    head = (get_meta('chain_head') or {}).get('block')
    if head is None or not block-3 <= head < block:
        mark_lock_status('waiting for group 17 or target already mined')
        return None
    with DB() as c:
        q = c.cursor()
        q.execute('''SELECT block_hash,single_count FROM raw_blocks WHERE block_number=%s''', (block-3,))
        g17 = q.fetchone()
        q.execute('''SELECT block_number,single_count FROM raw_blocks
                     WHERE block_number=ANY(%s)''',
                  ([block-20+v for v in (1,5,9,13,16)],))
        position_rows = dict(q.fetchall())
        q.execute('SELECT 1 FROM raw_blocks WHERE block_number=%s', (block,))
        already = q.fetchone()
        q.close()
    if not g17 or already or len(position_rows)!=5:
        mark_lock_status('required pre-result group missing or target already saved')
        return None
    extras = {v:position_rows[block-20+v] for v in (1,5,9,13,16)}
    return f'{ds}:{no:04d}', block, g17, extras


def mark_lock_status(reason):
    if time.monotonic()-getattr(mark_lock_status,'reported',0) >= 10:
        set_meta('ai_lock_status',{'reason':reason,
            'at':datetime.now(timezone.utc).isoformat()})
        mark_lock_status.reported=time.monotonic()


def lock_future():
    status = get_meta('ai_status') or {}
    picks = list(status.get('selectedTopTwo') or [])
    with DB() as c:
        q = c.cursor()
        q.execute('SELECT id,method FROM ai_models WHERE adopted=TRUE LIMIT 1')
        adopted = q.fetchone()
        q.close()
    if adopted and all(x['id'] != adopted[0] for x in picks):
        picks.append({'id':adopted[0],'method':adopted[1]})
    target = latest_candidate()
    if not picks:
        mark_lock_status('no approved shadow candidates; waiting for historical research')
    if not target or not picks:
        return
    period, target_block_number, g17, extras = target
    with DB() as c:
        q = c.cursor()
        q.execute('''SELECT period_key,single_count,block_hash FROM periods
                     WHERE period_key < %s AND single_count IS NOT NULL
                     ORDER BY period_date DESC,period_no DESC LIMIT 10000''',
                  (period,))
        prior = list(reversed(q.fetchall()))
        q.close()
    if len(prior) < 1000:
        mark_lock_status('fewer than 1000 prior completed periods')
        return
    context = [(r[0],int(r[1]),r[2],None,None,{}) for r in prior]
    context.append((period,0,'',g17[0],g17[1],extras))
    features = feature_rows(context)[-1]
    labels = [int(r[1]) for r in prior]
    with DB() as c:
        q = c.cursor()
        for picked in picks:
            q.execute('SELECT artifact FROM ai_models WHERE id=%s', (picked['id'],))
            artifact = q.fetchone()
            if not artifact or (artifact[0].get('fingerprint') != status.get('trainsetFingerprint')
                                and not (adopted and picked['id']==adopted[0])):
                continue
            prediction = predict_future(picked['method'], artifact[0], features, labels,
                                        prior_keys=[r[0] for r in prior])
            q.execute('''INSERT INTO ai_predictions
                (model_id,period_key,prediction,mode,feature_block,locked_at)
                VALUES(%s,%s,%s,'future-g17',%s,NOW())
                ON CONFLICT(model_id,period_key,mode) DO NOTHING''',
                (picked['id'], period, prediction, target_block_number-3))
        q.close()
    mark_lock_status('pre-result predictions stored when a new G17 is available')


def verify_future():
    with DB() as c:
        q = c.cursor()
        q.execute('''UPDATE ai_predictions a SET actual=p.single_count,
                     valid=COALESCE((a.locked_at < b.block_time AND a.feature_block=p.target_block-3),FALSE)
                     FROM periods p JOIN raw_blocks b ON b.block_number=p.target_block
                     WHERE a.period_key=p.period_key AND a.actual IS NULL AND p.single_count IS NOT NULL
                     AND a.mode='future-g17'
                     RETURNING a.id''')
        changed = len(q.fetchall())
        q.close()
    if changed:
        set_meta('ai_shadow', {'verifiedNow': changed,
            'updatedAt':datetime.now(timezone.utc).isoformat()})


def review_shadow():
    """Rotate the challenger after 100 valid new outcomes; never change adoption."""
    status = get_meta('ai_status') or {}
    selected = status.get('selectedTopTwo') or []
    if len(selected) < 2:
        return
    challenger = selected[1]
    with DB() as c:
        q = c.cursor()
        q.execute('''SELECT COUNT(*),COUNT(*) FILTER (WHERE prediction=actual)
                     FROM ai_predictions WHERE model_id=%s AND valid=TRUE''',
                  (challenger['id'],))
        n,hits = q.fetchone()
        q.close()
    if n < 100 or (hits/n >= .8 and wilson(hits,n) < .8):
        return  # promising but not yet proven: accumulate another 100+ rounds
    if wilson(hits,n) >= .8:
        return
    explored = get_meta('ai_exploration') or {}
    if explored.get('currentChallenger') == challenger['id'] and \
       n - int(explored.get('lastReviewedCount',0)) < 100:
        return
    with DB() as c:
        q = c.cursor()
        q.execute('''SELECT id,method,metrics FROM ai_models WHERE trainset_id=%s
                     AND artifact->>'revision'=%s''',
                  (status.get('trainsetId'), REVISION))
        ranks = sorted(q.fetchall(),
            key=lambda x:(x[2]['validation']['accuracy'],x[1]),reverse=True)
        q.close()
    pool = [x for x in ranks if x[0] != selected[0]['id']]
    if len(pool) < 2:
        return
    position = next((i for i,x in enumerate(pool) if x[0]==challenger['id']),-1)
    following = pool[(position+1)%len(pool)]
    if following[0] == challenger['id']:
        return
    replacement = {'id': following[0], 'method': following[1],
        'validation':following[2]['validation'], 'holdout':following[2]['holdout']}
    status['selectedTopTwo'] = [selected[0], replacement]
    status['lastSwitchReason'] = f'挑战者新期次 {hits}/{n}；继续比较其他方法'
    with DB() as c:
        q = c.cursor()
        q.execute('''INSERT INTO ai_switches(from_model_id,to_model_id,reason)
                     VALUES(%s,%s,%s)''', (challenger['id'], following[0],
                     status['lastSwitchReason']))
        q.execute('''SELECT COUNT(*) FROM ai_predictions
                     WHERE model_id=%s AND valid=TRUE''', (following[0],))
        replacement_baseline = q.fetchone()[0]
        q.close()
    set_meta('ai_status',status)
    set_meta('ai_exploration',{'lastModelId':challenger['id'],
        'lastReviewedCount':replacement_baseline,'currentChallenger':following[0]})


def refresh_streak_report():
    """Once per observed round, publish historical frequencies without betting claims."""
    with DB() as c:
        q=c.cursor()
        q.execute('''SELECT period_key,single_count FROM periods
                     ORDER BY period_date DESC,period_no DESC LIMIT 10001''')
        data=list(reversed(q.fetchall()))
        q.close()
    result=streak_report(data)
    result['updatedAt']=datetime.now(timezone.utc).isoformat()
    set_meta('ai_streak_report',result)
    patterns=pattern_report(data)
    patterns['updatedAt']=result['updatedAt']
    set_meta('ai_pattern_report',patterns)
    return result['lastPeriod']


def training_loop():
    while True:
        try:
            train_once()
        except Exception as exc:
            set_meta('ai_error', {'error': str(exc)[:400], 'at':time.time()})
        time.sleep(60)


def main():
    init_db()
    threading.Thread(target=training_loop, name='ai-research', daemon=True).start()
    last_heartbeat=0
    last_streak_check=0
    reported_period=None
    while True:
        try:
            verify_future()
            review_shadow()
            lock_future()
            if time.monotonic()-last_streak_check>=10:
                with DB() as c:
                    q=c.cursor()
                    q.execute('''SELECT period_key FROM periods
                                 ORDER BY period_date DESC,period_no DESC LIMIT 1''')
                    newest=q.fetchone()
                    q.close()
                if newest and newest[0]!=reported_period:
                    reported_period=refresh_streak_report()
                last_streak_check=time.monotonic()
            if time.monotonic()-last_heartbeat >= 15:
                set_meta('ai_heartbeat', {'status':'running',
                    'reportedAt':datetime.now(timezone.utc).isoformat()})
                last_heartbeat=time.monotonic()
        except Exception as exc:
            set_meta('ai_shadow_error', {'error': str(exc)[:400], 'at':time.time()})
        time.sleep(1)


if __name__ == '__main__':
    main()
