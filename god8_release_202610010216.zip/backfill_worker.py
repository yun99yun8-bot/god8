"""Forward-only period builder, intended to run inside the Worker/AI service."""
import os
import time
from datetime import datetime, timedelta

from core import (CN, DB, TRAIN_N, RETAIN_PERIODS, fetch_block_range, from_index,
                  get_meta, init_db, pindex, save_block, save_period, set_meta,
                  target_block, training_fingerprint, valid_result)
import json
from god8_flow import origin_index, prune_old_periods


def window():
    start=origin_index()
    if start is None:
        return None
    saved=get_meta('god8_trainset')
    if saved and int(saved['startIndex'])!=start:
        raise RuntimeError('God8 origin is immutable; existing training window mismatch')
    if not saved:
        saved={'id':'GOD8_STAGE0','startIndex':start,'endIndex':start+TRAIN_N-1,
               'locked':False,'status':'collecting-forward'}
        set_meta('god8_trainset',saved)
        set_meta('ai_gate',{'allowed':False,'reason':'waiting for first forward 10000 periods'})
    return saved,start,start+TRAIN_N-1


def enqueue_repair(numbers, reason):
    with DB() as c:
        q = c.cursor()
        for number in numbers:
            q.execute('''INSERT INTO repair_queue(block_number,attempts,last_error,next_try)
                         VALUES(%s,0,%s,NOW()) ON CONFLICT(block_number) DO NOTHING''',
                      (number, str(reason)[:400]))
        q.close()


def missing_blocks(start, end):
    with DB() as c:
        q = c.cursor()
        q.execute('SELECT block_number FROM raw_blocks WHERE block_number BETWEEN %s AND %s',
                  (start, end))
        existing = {r[0] for r in q.fetchall()}
        q.close()
    return set(range(start, end + 1)) - existing


def import_existing(start, end, missing):
    """Reuse previously collected hashes before any network request; never delete them."""
    with DB() as c:
        q = c.cursor()
        q.execute("SELECT to_regclass('public.historical_raw_blocks')")
        legacy = q.fetchone()[0]
        if legacy:
            q.execute('''SELECT block_number,block_hash FROM historical_raw_blocks
                         WHERE block_number BETWEEN %s AND %s''', (start, end))
            hashes = [(int(n), h) for n, h in q.fetchall() if int(n) in missing]
        else:
            hashes = []
        q.execute('''SELECT block_number,block_hash FROM groups
                     WHERE block_number BETWEEN %s AND %s''',(start,end))
        hashes.extend((int(n),h) for n,h in q.fetchall() if int(n) in missing)
        q.close()
    for n, h in dict(hashes).items():
        save_block({'number': n, 'hash': h, 'timestamp': None})


def repair_derived(start,end):
    """Recompute derived values from saved hashes without replacing hashes/timestamps."""
    with DB() as c:
        q = c.cursor()
        q.execute('''SELECT block_number,block_hash,numbers,single_count FROM raw_blocks
                     WHERE block_number BETWEEN %s AND %s''', (start,end))
        for n,h,nums,count in q.fetchall():
            expected,expected_count = valid_result(h)
            if nums != expected or count != expected_count:
                q.execute('''UPDATE raw_blocks SET numbers=%s::jsonb,single_count=%s
                             WHERE block_number=%s AND block_hash=%s''',
                          (json.dumps(expected) if expected is not None else None,expected_count,n,h))
        q.close()


def fetch_period(ds, no, training=False):
    target = target_block(ds, no)
    missing = missing_blocks(target - 19, target)
    if missing:
        import_existing(target - 19, target, missing)
        missing = missing_blocks(target - 19, target)
    if missing:
        try:
            # One range request per period, not twenty per-block requests.
            blocks = fetch_block_range(target - 19, target)
            for n in sorted(missing & blocks.keys()):
                save_block(blocks[n])
        except Exception as exc:
            enqueue_repair(missing, exc)
        missing = missing_blocks(target - 19, target)
    if missing:
        enqueue_repair(missing, 'range response incomplete')
        return False
    repair_derived(target-19,target)
    ok, missing = save_period(ds, no, 'god8-forward', training)
    if missing:
        enqueue_repair(missing, 'period incomplete')
    return ok


def already_complete(ds,no,training):
    key=f'{ds}:{no:04d}'
    target=target_block(ds,no)
    with DB() as c:
        q=c.cursor()
        q.execute('''SELECT p.target_block,p.block_hash,p.numbers,p.single_count,COUNT(g.group_no)
                     FROM periods p LEFT JOIN groups g ON g.period_key=p.period_key
                     WHERE p.period_key=%s
                     GROUP BY p.target_block,p.block_hash,p.numbers,p.single_count''',(key,))
        row=q.fetchone()
        if row and row[0]==target and row[4]==20:
            q.execute('''SELECT COUNT(*) FROM groups g JOIN raw_blocks b
                         ON b.block_number=g.block_number AND b.block_hash=g.block_hash
                         WHERE g.period_key=%s AND b.block_number BETWEEN %s AND %s''',
                      (key,target-19,target))
            expected,expected_count=valid_result(row[1])
            valid=(q.fetchone()[0]==20 and row[2]==expected and row[3]==expected_count)
            if valid and training:
                q.execute('UPDATE periods SET training_set=TRUE WHERE period_key=%s',(key,))
        else:
            valid=False
        q.close()
    return valid


def reconcile_first_stage(start,cursor):
    """A cursor is a checkpoint, not proof that all 10k period rows survived."""
    end=start+TRAIN_N-1
    if cursor<end:
        return cursor
    first=from_index(start);last=from_index(end)
    first_key=f'{first[0]}:{first[1]:04d}'
    last_key=f'{last[0]}:{last[1]:04d}'
    with DB() as c:
        q=c.cursor()
        q.execute('SELECT COUNT(*) FROM periods WHERE period_key BETWEEN %s AND %s',
                  (first_key,last_key))
        count=q.fetchone()[0]
        q.close()
    if count==TRAIN_N:
        return cursor
    oldest=(get_meta('god8_retention') or {}).get('oldest')
    if cursor-start+1>RETAIN_PERIODS and oldest and oldest>first_key:
        set_meta('god8_forward_recovery',{'status':'cannot-replay-pruned-stage',
            'first':first_key,'last':last_key,'found':count})
        return cursor
    set_meta('god8_forward_recovery',{'status':'replaying-missing-first-stage',
        'first':first_key,'last':last_key,'found':count,
        'missing':TRAIN_N-count,'previousCursor':cursor})
    set_meta('god8_completed_stages',{'highest':-1,'allTimeCompleted':0})
    set_meta('god8_forward',{'index':start-1,'completedSinceOrigin':0,
        'stage':0,'direction':'rebuilding-missing-first-stage'})
    set_meta('history_progress',{'complete':0,'total':TRAIN_N,
        'allTimeCompleted':0,'stage':'rebuilding-missing-first-stage','percent':0})
    return start-1


def forward_forever():
    init_db()
    while (get_meta('historical_capture') or {}).get('status') != 'raw-complete':
        time.sleep(3)
    while window() is None:
        time.sleep(3)
    saved,start,_=window()
    progress=get_meta('god8_forward') or {}
    cursor=max(start-1,int(progress.get('index',start-1)))
    cursor=reconcile_first_stage(start,cursor)
    if cursor-start+1>=TRAIN_N:
        set_meta('god8_completed_stages',{'highest':(cursor-start+1)//TRAIN_N-1,
                 'allTimeCompleted':cursor-start+1})
    prune_old_periods()  # normalize an existing oversized database once
    earliest=(get_meta('god8_retention') or {}).get('oldest')
    # A newer oldest *saved* period can simply mean the historic stage was
    # never built. Only an actual retention cutoff justifies skipping it.
    if (cursor-start+1>RETAIN_PERIODS and earliest and
            cursor < pindex(earliest[:10],int(earliest[11:]))-1):
        cursor=pindex(earliest[:10],int(earliest[11:]))-1
        set_meta('god8_warning',{'reason':'earlier records already outside 60000-period retention; cannot reconstruct first-stage training'})
    while True:
        idx=cursor+1
        ds,no=from_index(idx)
        head=(get_meta('chain_head') or {}).get('block')
        if head is None or target_block(ds,no)>head:
            time.sleep(2)
            continue
        existing=already_complete(ds,no,training=idx-start<TRAIN_N)
        if not existing and not fetch_period(ds,no,training=idx-start<TRAIN_N):
            set_meta('god8_forward_error',{'period':f'{ds}:{no:04d}',
                     'reason':'waiting for all 20 original blocks'})
            time.sleep(4)
            continue
        cursor=idx
        total=cursor-start+1
        set_meta('god8_forward',{'index':cursor,'period':f'{ds}:{no:04d}',
            'completedSinceOrigin':total,'stage':total//TRAIN_N,
            'chainHead':head,'direction':'forward-only'})
        if total <= TRAIN_N or total%20==0:
            set_meta('history_progress',{'complete':min(TRAIN_N,total),'total':TRAIN_N,
                'allTimeCompleted':total,'stage':'forward-collecting',
                'percent':round(100*min(TRAIN_N,total)/TRAIN_N,2)})
        if total%TRAIN_N==0:
            set_meta('god8_completed_stages',{'highest':total//TRAIN_N-1,
                     'allTimeCompleted':total})
            recovery=get_meta('god8_forward_recovery') or {}
            if total==TRAIN_N and recovery.get('status')=='replaying-missing-first-stage':
                set_meta('god8_forward_recovery',{**recovery,'status':'recovered',
                    'missing':0,'completedAt':datetime.now(CN).isoformat()})
        if total>60000:
            prune_old_periods()
        monitor=get_meta('monitor_stats') or {}
        cooldown=3.0 if monitor.get('status')=='retrying' else 0.0
        if not existing:
            time.sleep(max(.1,cooldown,float(os.getenv('HISTORY_REQUEST_PAUSE','.5'))))


def main():
    forward_forever()


if __name__ == '__main__':
    main()
