"""Pre-result streak hypotheses and transparent, time-ordered outcome counts."""
from datetime import date

HORIZONS=(5,10,20,30,60)


def issue_index(key):
    day, number = key.split(':', 1)
    return date.fromisoformat(day).toordinal() * 1440 + int(number) - 1


def states(rows):
    """Every state uses only earlier, adjacent valid outcomes; missing rounds reset it."""
    state = {'run34':0, 'run25':0, 'gap25':0, 'gap16':0, 'gap07':0}
    previous = None
    result = []
    for key, label in rows:
        index = issue_index(key)
        if previous is not None and index != previous + 1:
            state = dict.fromkeys(state, 0)
        result.append(state.copy())
        if label is None:
            state = dict.fromkeys(state, 0)
        else:
            label = int(label)
            state = {'run34':state['run34']+1 if label in (3,4) else 0,
                     'run25':state['run25']+1 if label in (2,5) else 0,
                     'gap25':0 if label in (2,5) else state['gap25']+1,
                     'gap16':0 if label in (1,6) else state['gap16']+1,
                     'gap07':0 if label in (0,7) else state['gap07']+1}
        previous = index
    return result, state


CONDITIONS = (
    ('run34', '单3/4连续至少10期', lambda s:s['run34']>=10),
    ('gap25', '单2/5连续缺席至少15期', lambda s:s['gap25']>=15),
    ('run34_no16', '单3/4连续10期且单1/6缺席10期',
     lambda s:s['run34']>=10 and s['gap16']>=10),
    ('gap25_no16', '单2/5缺席15期且单1/6缺席15期',
     lambda s:s['gap25']>=15 and s['gap16']>=15),
)


def report(rows):
    """Count first hits by fixed chase horizon, including unresolved attempts."""
    from ai_research import wilson
    rows = list(rows)
    indexed, current = states(rows)
    valid = [(i,state,int(label)) for i,(state, (_, label)) in enumerate(zip(indexed,rows))
             if label is not None]
    n = len(valid)
    targets=((1,6),(0,7),(1,),(6,),(0,),(7,))
    indices=[issue_index(key) for key,_ in rows]
    labels=[int(value) if value is not None else None for _,value in rows]
    tracks={}
    for target in targets:
        positions=[(None,0)]*len(rows)
        for i in range(len(rows)-1,-1,-1):
            if labels[i] is None:continue
            joins=i+1<len(rows) and indices[i+1]==indices[i]+1 and labels[i+1] is not None
            next_hit,next_length=positions[i+1] if joins else (None,0)
            first=1 if labels[i] in target else next_hit+1 if next_hit is not None else None
            positions[i]=(first,next_length+1)
        tracks[target]=positions
    # Descriptive random-start baseline for identical horizons, not a
    # strategy outcome; horizons must not be selected retrospectively.
    baselines={}
    for target in targets:
        baseline_tracks=[tracks[target][i] for i,_,_ in valid]
        baselines[target]={}
        for h in HORIZONS:
            base_hits=sum(hit is not None and hit<=h for hit,_ in baseline_tracks)
            base_n=sum(hit is not None and hit<=h or length>=h
                       for hit,length in baseline_tracks)
            baselines[target][h]={'rate':base_hits/base_n if base_n else None,
                                  'eligible':base_n}
    hypotheses = []
    for code, title, predicate in CONDITIONS:
        # Count the first exposure of each streak, not each overlapping
        # minute in one run; otherwise one long run inflates evidence.
        matched = [i for i,state,label in valid
                   if predicate(state) and (i == 0 or not predicate(indexed[i-1]))]
        total = len(matched)
        groups = []
        for target in targets:
            attempts=[tracks[target][i] for i in matched]
            found=sorted(hit for hit,_ in attempts if hit is not None)
            chase={}
            for h in HORIZONS:
                eligible=sum(hit is not None and hit<=h or length>=h
                             for hit,length in attempts)
                hits=sum(hit is not None and hit<=h for hit,_ in attempts)
                baseline=baselines[target][h]['rate']
                lower=wilson(hits,eligible) if eligible else None
                chase[str(h)]={'hits':hits,'eligible':eligible,
                               'unresolved':total-eligible,
                               'rate':hits/eligible if eligible else None,
                               'baseline':baseline,'baselineEligible':baselines[target][h]['eligible'],
                               'lower95':lower,
                               'verdict':'样本不足' if eligible<100 else
                                         '下界高于基线' if baseline is not None and lower>baseline
                                         else '未证实增高'}
            groups.append({'target':'/'.join(f'单{k}' for k in target),
                           'firstHitsObserved':len(found),
                           'notYetHit':total-len(found),
                           'medianFirstHit':found[len(found)//2] if found else None,
                           'chase':chase})
        hypotheses.append({'code':code,'title':title,'active':predicate(current),
                           'samples':total,'groups':groups})
    return {'schemaVersion':'chase-v2','periods':n,'current':current,'conditions':hypotheses,
            'lastPeriod':rows[-1][0] if rows else None,
            'basis':'每段首次达阈值算一次机会；单1/6或单0/7任一首次出现即算该段命中；分别检验5/10/20/30/60期；不足观察窗口的机会单列未结，不计作胜利'}
