# V2.0.15 开奖显示提速

开奖链路调整：

1. 采集器取到目标区块并写入 `raw_blocks` 后立即唤醒建期线程。
2. 首页 `/api/live` 从已保存的目标区块哈希直接计算并展示该期结果；在每期 20 组尚未完成前明确标记 `provisional`，然后由完整 `periods` 行替换。无效哈希不显示成有效开奖结果。
3. 每期 20 组改为一次批量数据库写入，保留事务、唯一约束、缺块补取和后续审计。
4. 首页在可能出现开奖结果的时段以约 0.8 秒间隔查询，其他时段约 3 秒；更新静态资源版本以避免手机继续使用旧脚本。

不能早于链上实际产生目标区块显示结果。采集接口若持续返回 429、Render 服务暂停或数据库不可用，仍会造成延迟；可从 `/api/services` 查看 `monitor.pollIntervalSeconds`、`monitor.lastError` 与 `liveLatency.blockToSavedSeconds`。公开服务的实时指标此次未能从执行环境读取，所以未声称线上已达到固定秒数。

解压完整部署包并覆盖仓库根目录，保留数据库。三个应用服务 `god8-web`、`god8-collector`、`god8-worker-ai` 部署同一提交。`/health` 应显示 `god8-v2.0.15-fast-live-result`。

主要改动：`monitor_collector.py`、`collector_service.py`、`core.py`、`web.py`、`static/app.js`、`templates/base.html`、`tests/test_live_speed.py`。继承 V2.0.13 的 0991/0992 平台校准与 V2.0.14 的首页预判 10 秒展示。
