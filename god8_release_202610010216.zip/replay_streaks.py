"""Independent audit of the two already-locked homepage replay candidates.

The first settled hit anchors a segment. A gap, invalid result or malformed
forecast breaks it; no censored segment is treated as a completed streak.
"""
from core import pindex
from omission_research import issue


def _candidate(rows, rank):
    complete = []
    anchored = False
    current = 0
    previous_index = previous_hit = last_key = None
    verified = hits = invalid = gaps = known_ten_failures = 0
    leading_misses = 0
    longest_observed = 0

    for key, choices, actual, locked, settled in rows:
        try:
            ds, number = key.split(':')
            index = pindex(ds, number)
        except (AttributeError, ValueError, TypeError):
            invalid += 1
            anchored = False
            previous_index = None
            leading_misses = current = 0
            continue

        if previous_index is not None and index != previous_index + 1:
            gaps += 1
            if anchored and current >= 10:
                known_ten_failures += 1
            anchored = False
            current = leading_misses = 0
        previous_index = index
        last_key = key
        valid = (isinstance(choices, list) and len(choices) == 2 and
                 type(choices[rank]) is int and 0 <= choices[rank] <= 7 and
                 type(actual) is int and 0 <= actual <= 7 and
                 settled is not None and locked is not None and locked < settled)
        if not valid:
            invalid += 1
            if anchored and current >= 10:
                known_ten_failures += 1
            anchored = False
            current = leading_misses = 0
            continue
        verified += 1
        if choices[rank] == actual:
            hits += 1
            if anchored:
                complete.append({'afterIssue': issue(pindex(*previous_hit.split(':'))),
                                 'hitIssue': issue(index), 'wrong': current,
                                 'wait': current + 1})
            anchored = True
            previous_hit = key
            current = leading_misses = 0
        elif anchored:
            current += 1
            longest_observed = max(longest_observed,current)
        else:
            leading_misses += 1
            longest_observed = max(longest_observed,leading_misses)

    wrongs = [r['wrong'] for r in complete]
    waits = [r['wait'] for r in complete]
    within_ten = sum(wait <= 10 for wait in waits)
    known_failures = known_ten_failures + int(anchored and current >= 10)
    eligible = len(waits) + known_failures
    return {'rank': rank + 1, 'verified': verified, 'hits': hits,
            'singleRoundRate': hits / verified if verified else None,
            'completedRuns': len(complete),
            'shortestWrong': min(wrongs) if wrongs else None,
            'longestWrong': max(wrongs) if wrongs else None,
            'longestObservedWrong': longest_observed if verified else None,
            'averageWrong': sum(wrongs) / len(wrongs) if wrongs else None,
            'shortestWait': min(waits) if waits else None,
            'longestWait': max(waits) if waits else None,
            'averageWait': sum(waits) / len(waits) if waits else None,
            'currentWrong': current if anchored else None,
            'currentLowerBound': leading_misses if not anchored and leading_misses else None,
            'lastObservedIssue': issue(pindex(*last_key.split(':'))) if last_key else None,
            'withinTen': within_ten, 'tenEligible': eligible,
            'tenRate': within_ten / eligible if eligible else None,
            'knownTenFailures': known_failures,
            'invalidRows': invalid, 'brokenGaps': gaps,
            'recentRuns': list(reversed(complete[-20:]))}


def summarize(rows):
    ordered = list(reversed(rows))  # SQL sends the newest first.
    return {'sampleRows': len(ordered),
            'candidates': [_candidate(ordered, 0), _candidate(ordered, 1)],
            'note': '仅使用数据库真实开奖前锁定并已结算的两码。连续错误以相邻期号计算；缺期和无效结果中断。最短/最长/平均仅统计两次命中之间已完成的段，开头未有锚点和当前未结段不伪装成已完成。十把比例是样本描述，不代表以后十把会命中。'}
