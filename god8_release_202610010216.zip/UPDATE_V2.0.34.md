# v2.0.34 · 开奖链头停滞补探测

- 目标区块优先采集不再完全依赖 Monitor 线程：链头连续 9 秒不前进时，独立限频探测一次真实新区块，并优先保存该期目标结果；接口限流时遵守 Retry-After 退避。
- 实时 API 可从 `fast_target_latest` 已验证目标区块读取结果，即使完整 20 组审计尚未完成、普通链头状态尚未更新。
- 首页显示链头停滞秒数与「区块→入库」耗时，不把旧期伪装为实时开奖。
- 不按倒计时虚构开奖结果；外部链或 API 故障期间仍可能延迟，需检查采集服务 `monitor_stats`、`fast_target_error` 和 `collector_live_error`。

将 `god8_release_YYYYMMDDHHMM.zip` 直接上传 GitHub 根目录，等待 Render 的三个服务完成自动部署，检查中心版本应为 v2.0.34。
