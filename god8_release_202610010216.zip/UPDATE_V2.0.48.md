# v2.0.48 · 运行规则热更新与免手动重启部署

本版在 v2.0.47 的规范化历史与两组预判基础上加入运行时配置层。

## 1. 规则热更新
- 新增 PostgreSQL `meta.runtime_config` 配置，Web、Collector、Worker 共用。
- `target_block()` 每约 2 秒重新读取配置；尾数映射变化不再要求重启 Python 进程。
- 默认映射与 v2.0.47 完全一致：1299=4尾、1300~0046=3尾、0047~0120=2尾、0121进入0尾。
- 尾数覆盖规则按“最后新增优先”处理，支持以后临时 2→3、3→2 等平台变化。
- 修改映射会写入新的配置修订号并触发后台校准；首页先按新目标区块读取，数据库正式记录随后重建。

## 2. 手机热更新页面
- 新增 `/runtime-config`。
- 可直接填十位起始期号、结束期号（可空）和目标尾数，保存后数据库热生效。
- 也可编辑完整 JSON：预测最少训练期数、最短复现长度、各长度支持数、是否允许趋势补位、趋势窗口/权重、冷热阈值、校准回看期数。
- 保存需要 Web 服务的 `ADMIN_TOKEN`；Token 仅存浏览器 localStorage。
- 已经锁定的当期预测不追改，后续预测使用新配置，避免事后改预测。

## 3. 预测参数热更新
- `minimumTraining`、`minReplayLength`、`replaySupport`、`allowAdaptiveSecond`、`trendWindows`、`trendWeights`、`hotLift`、`coldLift` 从运行配置读取。
- 每次新计算都会使用当前配置；无需重启 Collector。
- 运行配置修订号加入复现预测身份，之前因“证据不足”缓存过的本期尝试在规则变更后可以重新评估（前提是开奖目标仍未产生）。

## 4. 自动部署交接
- `render.yaml` 明确 `autoDeployTrigger: commit`，代码真正变化时由 Git 提交触发 Render 自动部署，无需人工 Restart。
- Web/Collector/Worker 设置 60 秒优雅退出窗口。
- Collector 使用既有链头 advisory lock 作为整个进程的领导锁；新版实例会等待旧实例释放后再接管，防止自动部署时双写开奖。
- Worker 同样由“抢不到锁就报错退出”改为“等待旧实例释放后接管”。

## 5. 一次性升级说明
第一次从 v2.0.47 升级到 v2.0.48 仍需要完成一次正常部署，让热更新代码进入运行进程。以后规则/参数修改直接用 `/runtime-config`，不需要上传新 ZIP 或重启。代码/UI 本身发生变化时仍需要部署新代码，但 GitHub→Render 自动部署可替代手动 Restart。
