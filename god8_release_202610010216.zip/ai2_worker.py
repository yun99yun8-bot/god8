"""Independent numeric/wave/parity/zodiac research. No AI1 tables or adoption."""
import json
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from math import sqrt

from core import DB, from_index, get_meta, pindex, set_meta, target_block
from god8_flow import origin_index, stage_fingerprint, stage_rows, stage_window

REVISION='god8-ai2-v1'
METHODS=('numbers_shape','wave_mix','odd_even','domestic_wild','combined_profile')
RED={1,2,7,8,12,13,18,19,23,24,29,30,34,35,40,45,46}
BLUE={3,4,9,10,14,15,20,25,26,31,36,37,41,42,47,48}
DOMESTIC={'牛','马','羊','鸡','狗','猪'}
ZODIAC=('马','蛇','龙','兔','虎','牛','鼠','猪','狗','鸡','猴','羊')


def features(numbers,year):
    if not isinstance(numbers,list) or len(numbers)!=7 or any(not isinstance(n,int) or not 1<=n<=49 for n in numbers):
        return None
    reds=sum(n in RED for n in numbers)
    blues=sum(n in BLUE for n in numbers)
    odds=sum(n%2 for n in numbers)
    domestic=sum(ZODIAC[((n-1-(year-2026))%12+12)%12] in DOMESTIC for n in numbers)
    high=sum(n>=25 for n in numbers)
    return {'numbers_shape':(high,min(4,sum(numbers)//70),len({n%10 for n in numbers})//2),
            'wave_mix':(reds,blues),
            'odd_even':(odds,high//2),
            'domestic_wild':(domestic,odds//2),
            'combined_profile':(max(0,reds-blues+3)//2,odds//2,domestic//2)}


def wilson(hits,total):
    if not total:return 0.0
    p=hits/total;z=1.96;k=1+z*z/total
    return max(0,(p+z*z/(2*total)-z*sqrt((p*(1-p)+z*z/(4*total))/total))/k)


def pick(signal,base):
    support=sum(signal.values());total=sum(base.values())
    if support<25 or total<100:
        return max(range(8),key=lambda k:(base[k],-k))
    # Shrink a conditional signal toward the empirical prior; the prediction
    # must win an actual conditional comparison instead of a forced class quota.
    return max(range(8),key=lambda k:((signal[k]+40*(base[k]+1)/(total+8))/(support+40),-k))


def simulate(records,method):
    """Records are chronologically sorted (period, target, G17 numbers)."""
    if method not in METHODS:raise ValueError('unknown AI2 method')
    if len(records)<2000:raise ValueError('insufficient completed audited records')
    labels=[int(x[1]) for x in records]
    keys=[repr(features(x[2],int(x[0][:4]))[method]) for x in records]
    base=Counter(labels[:1000]);conditional=defaultdict(Counter)
    for key,label in zip(keys[:1000],labels[:1000]):conditional[key][label]+=1
    split1=max(1000,len(records)-3000);split2=max(split1,len(records)-1500)
    scores={p:{'hits':0,'predictions':0,'predicted':{str(k):0 for k in range(8)}}
            for p in ('training','validation','holdout')}
    for i in range(1000,len(records)):
        phase='training' if i<split1 else 'validation' if i<split2 else 'holdout'
        guess=pick(conditional[keys[i]],base)
        score=scores[phase];score['predictions']+=1
        score['hits']+=int(guess==labels[i]);score['predicted'][str(guess)]+=1
        old=i-1000
        base[labels[old]]-=1;conditional[keys[old]][labels[old]]-=1
        base[labels[i]]+=1;conditional[keys[i]][labels[i]]+=1
    for score in scores.values():
        score['accuracy']=score['hits']/score['predictions'] if score['predictions'] else 0
        score['wilsonLower95']=wilson(score['hits'],score['predictions'])
    artifact={'revision':REVISION,'method':method,'counts':dict(base),
              'conditional':{k:dict(v) for k,v in conditional.items() if sum(v.values())>=25}}
    return scores,artifact


def predict(artifact,numbers,year):
    f=features(numbers,year)
    if not f:raise ValueError('invalid G17 numbers')
    key=repr(f[artifact['method']])
    base=Counter({int(k):v for k,v in artifact['counts'].items()})
    signal=Counter({int(k):v for k,v in artifact['conditional'].get(key,{}).items()})
    return pick(signal,base)


def load_stage(begin,end):
    first,last=from_index(begin),from_index(end)
    first=f'{first[0]}:{first[1]:04d}';last=f'{last[0]}:{last[1]:04d}'
    with DB() as c:
        q=c.cursor()
        q.execute('''SELECT p.period_key,p.single_count,g.numbers
                     FROM periods p LEFT JOIN groups g ON g.period_key=p.period_key AND g.group_no=17
                     WHERE p.period_key BETWEEN %s AND %s ORDER BY p.period_date,p.period_no''',(first,last))
        records=q.fetchall();q.close()
    if len(records)!=10000:
        raise RuntimeError('AI2 audited stage is incomplete')
    valid=[r for r in records if r[1] is not None and features(r[2],int(r[0][:4]))]
    if len(valid)<9000:
        raise RuntimeError('AI2 stage has too few valid number/G17 pairs')
    return valid


def train_once():
    origin=origin_index()
    if origin is None:return
    with DB() as c:
        q=c.cursor();q.execute("SELECT stage_no,fingerprint FROM god8_stage_checks WHERE report->>'pass'='true' ORDER BY stage_no DESC LIMIT 1")
        audited=q.fetchone();q.close()
    if not audited:
        set_meta('ai2_status',{'status':'waiting-for-audited-history','revision':REVISION});return
    stage,fp=audited
    status=get_meta('ai2_status') or {}
    if status.get('stage')==stage and status.get('fingerprint')==fp and status.get('revision')==REVISION and status.get('status')=='shadow-testing':return
    begin,end=stage_window(origin,stage)
    evidence=stage_rows(begin,end)
    if len(evidence)!=10000 or stage_fingerprint(evidence)!=fp:
        raise RuntimeError('AI2 stage fingerprint does not match audit')
    records=load_stage(begin,end)
    for method in METHODS:
        set_meta('ai2_status',{'status':'simulating','method':method,'stage':stage,
                                'fingerprint':fp,'revision':REVISION,'sample':len(records)})
        with DB() as c:
            q=c.cursor();q.execute('SELECT id FROM ai2_models WHERE stage_no=%s AND method=%s AND fingerprint=%s',(stage,method,fp))
            exists=q.fetchone();q.close()
        if exists:continue
        metrics,artifact=simulate(records,method)
        with DB() as c:
            q=c.cursor();q.execute('''INSERT INTO ai2_models(stage_no,method,fingerprint,metrics,artifact)
                VALUES(%s,%s,%s,%s::jsonb,%s::jsonb) ON CONFLICT(stage_no,method,fingerprint) DO NOTHING''',
                (stage,method,fp,json.dumps(metrics),json.dumps(artifact)));q.close()
    with DB() as c:
        q=c.cursor();q.execute('SELECT id,method,metrics FROM ai2_models WHERE stage_no=%s AND fingerprint=%s',(stage,fp))
        models=q.fetchall();q.close()
    if len(models)<len(METHODS):raise RuntimeError('AI2 methods incomplete')
    ranked=sorted(models,key=lambda r:(r[2]['validation']['accuracy'],r[2]['validation']['hits'],r[1]),reverse=True)
    selected=[{'id':r[0],'method':r[1],'validation':r[2]['validation'],'holdout':r[2]['holdout']} for r in ranked[:2]]
    set_meta('ai2_status',{'status':'shadow-testing','stage':stage,'fingerprint':fp,
                            'revision':REVISION,'sample':len(records),
                            'completedMethods':len(models),'totalMethods':len(METHODS),
                            'selected':selected,'selectionBasis':'validation-only',
                            'updatedAt':datetime.now(timezone.utc).isoformat()})


def lock_future():
    status=get_meta('ai2_status') or {}
    selected=status.get('selected') or []
    if not selected:return
    with DB() as c:
        q=c.cursor();q.execute('SELECT period_date::text,period_no FROM periods ORDER BY period_date DESC,period_no DESC LIMIT 1')
        latest=q.fetchone();q.close()
    if not latest:return
    day,no=from_index(pindex(*latest)+1);target=target_block(day,no)
    head=(get_meta('chain_head') or {}).get('block')
    if head is None or not target-3<=int(head)<target:return
    with DB() as c:
        q=c.cursor();q.execute('SELECT numbers FROM raw_blocks WHERE block_number=%s',(target-3,))
        group=q.fetchone()
        q.execute('SELECT 1 FROM raw_blocks WHERE block_number=%s',(target,))
        already=q.fetchone()
        if not group or already or not features(group[0],int(day[:4])):
            q.close();return
        period=f'{day}:{no:04d}'
        for model in selected:
            q.execute('SELECT artifact FROM ai2_models WHERE id=%s',(model['id'],))
            row=q.fetchone()
            if not row or row[0].get('revision')!=REVISION:continue
            guess=predict(row[0],group[0],int(day[:4]))
            q.execute('''INSERT INTO ai2_predictions(model_id,period_key,prediction,feature_block,locked_at)
                         VALUES(%s,%s,%s,%s,NOW()) ON CONFLICT(model_id,period_key) DO NOTHING''',
                      (model['id'],period,guess,target-3))
        q.close()


def verify_future():
    with DB() as c:
        q=c.cursor();q.execute('''UPDATE ai2_predictions a SET actual=p.single_count,
                       valid=COALESCE(a.locked_at<b.block_time AND a.feature_block=p.target_block-3,FALSE)
                       FROM periods p JOIN raw_blocks b ON b.block_number=p.target_block
                       WHERE a.period_key=p.period_key AND a.actual IS NULL AND p.single_count IS NOT NULL''')
        q.close()


def main():
    last_train=0;last_heartbeat=0
    while True:
        try:
            now=time.monotonic()
            if now-last_train>=60:
                train_once();last_train=now
            lock_future();verify_future()
            if now-last_heartbeat>=15:
                set_meta('ai2_heartbeat',{'at':datetime.now(timezone.utc).isoformat(),'status':'running'})
                last_heartbeat=now
        except Exception as exc:
            set_meta('ai2_error',{'error':str(exc)[:400],'at':datetime.now(timezone.utc).isoformat()})
        time.sleep(1)
