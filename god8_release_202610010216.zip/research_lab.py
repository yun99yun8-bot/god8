"""Walk-forward comparison used by the independent replay lab.

Historical replication is intentionally limited to four synchronized periods;
shorter sequence matches are not eligible. Trend windows compete with replay and
long-run frequency, and method weights are based only on already-settled rows.
"""
from collections import Counter, defaultdict, deque

from history_simulation import _chronological, _valid
from omission_research import issue

METHODS = ('seq4', 'recent20', 'recent50', 'recent100', 'frequency')
LABELS = {
    'seq4':'四期序列复现', 'recent20':'近20期活跃', 'recent50':'近50期趋势',
    'recent100':'近100期趋势', 'frequency':'长期频数基线'
}


def _rank(counts):
    return sorted(range(8), key=lambda k: (-counts[k], k))


def analyze(rows, minimum_training=100, recent_limit=25):
    patterns = defaultdict(Counter)
    long_counts, recent, sequence = Counter(), deque(maxlen=100), []
    performance = {name: deque(maxlen=200) for name in METHODS}
    total = Counter();method_totals=Counter();method_hits=Counter()
    examples=deque(maxlen=recent_limit);switches=deque(maxlen=12)
    previous_method=None;previous=newest=None;ready=0

    def proposal():
        candidates={}
        if len(sequence)>=4:
            key=tuple(sequence[-4:]);found=patterns.get(key,Counter())
            if sum(found.values())>=6:
                candidates['seq4']=(found,sum(found.values()))
        for window,name in ((20,'recent20'),(50,'recent50'),(100,'recent100')):
            if len(recent)>=window:
                candidates[name]=(Counter(list(recent)[-window:]),window)
        if long_counts:
            candidates['frequency']=(long_counts,sum(long_counts.values()))
        return candidates

    def choose():
        available=proposal()
        if not available:return None
        weights={}
        for name in available:
            values=performance[name]
            posterior=(sum(values)+3)/(len(values)+16)
            streak=0
            for hit in reversed(values):
                if hit:break
                streak+=1
            penalty=max(.60,.88**max(0,streak-2))
            weights[name]=posterior*penalty*(.70 if name=='frequency' else 1.0)
        selected=max(available,key=lambda name:(weights[name],len(performance[name]),-METHODS.index(name)))
        votes=Counter();prior_total=sum(long_counts.values())
        for name,(counts,support) in available.items():
            for single in range(8):
                prior=long_counts[single]/prior_total if prior_total else 1/8
                votes[single]+=weights[name]*(counts[single]+12*prior)/(support+12)
        picks=sorted(range(8),key=lambda k:(-votes[k],-long_counts[k],k))[:2]
        return {'predictions':picks,'aiPrediction':_rank(available[selected][0])[0],
                'aiMethod':selected,'methodPredictions':{name:_rank(item[0])[0] for name,item in available.items()},
                'methodSupport':{name:item[1] for name,item in available.items()},
                'weights':{name:round(weights[name],4) for name in available}}

    for at,key,actual,numbers in _chronological(rows):
        if previous is not None and at!=previous+1:
            sequence=[];recent.clear()
        previous=at
        if not _valid(actual):
            sequence=[];recent.clear();continue
        choice=choose() if ready>=minimum_training and sequence else None
        if choice:
            first,second=choice['predictions']
            if previous_method and previous_method!=choice['aiMethod']:
                switches.append({'issue':issue(at),'from':previous_method,'to':choice['aiMethod']})
            previous_method=choice['aiMethod'];total['evaluated']+=1
            total['first']+=actual==first;total['second']+=actual==second;total['either']+=actual in (first,second);total['ai']+=actual==choice['aiPrediction']
            for name,guess in choice['methodPredictions'].items():
                success=int(guess==actual);performance[name].append(success);method_totals[name]+=1;method_hits[name]+=success
            examples.append({'issue':issue(at),'predictions':[first,second],'aiPrediction':choice['aiPrediction'],
                             'aiMethod':choice['aiMethod'],'actual':actual,'firstHit':first==actual,'secondHit':second==actual,
                             'aiHit':choice['aiPrediction']==actual,'methods':choice['methodPredictions']})
        if len(sequence)>=4:
            patterns[tuple(sequence[-4:])][actual]+=1
        long_counts[actual]+=1;recent.append(actual);sequence=(sequence+[actual])[-4:];ready+=1;newest=at
    preview=choose() if newest is not None and ready>=minimum_training and sequence else None
    insight=None
    if preview:
        selected=preview['aiMethod'];values=performance[selected]
        insight={'selectedMethod':selected,'name':LABELS[selected],'recentVerified':len(values),'recentHits':sum(values),
                 'recentRate':sum(values)/len(values) if values else None,'selectionWeight':preview['weights'][selected],
                 'switches':list(reversed(switches)),
                 'reason':'仅在4期同步复现有足够样本时启用复现；其余时段由近期活跃与长期基线竞争，连续失准会降低方法权重。'}
        preview={'issue':issue(newest+1),**preview}
    n=total['evaluated']
    return {'stored':len(rows),'valid':ready,'evaluated':n,
            'first':{'hits':total['first'],'rate':total['first']/n if n else None},
            'second':{'hits':total['second'],'rate':total['second']/n if n else None},
            'either':{'hits':total['either'],'rate':total['either']/n if n else None},
            'ai':{'hits':total['ai'],'rate':total['ai']/n if n else None},
            'methods':[{'key':name,'name':LABELS[name],'evaluated':method_totals[name],'hits':method_hits[name],
                        'rate':method_hits[name]/method_totals[name] if method_totals[name] else None} for name in METHODS],
            'preview':preview,'insight':insight,'recent':list(reversed(examples)),
            'note':'滚动复盘只使用目标期以前的数据；复现必须4期同步且至少6个历史样本。近20/50/100期活跃趋势与长期频数同时竞争，方法连续失准自动降权。历史命中率不代表下一期概率。'}
