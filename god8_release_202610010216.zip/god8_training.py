"""Sequential 10k-stage experiments, using only audited periods already observed."""
import json
from datetime import datetime, timezone

from psycopg2.extras import execute_values

from ai_research import METHODS, REVISION, feature_rows, predict_future, simulate, wilson
from core import DB, TRAIN_N, from_index, get_meta, set_meta
from god8_flow import origin_index, stage_window, stage_fingerprint, stage_rows


def loaded_periods(start,end):
    a,b=from_index(start),from_index(end)
    first,last=f'{a[0]}:{a[1]:04d}',f'{b[0]}:{b[1]:04d}'
    with DB() as c:
        q=c.cursor()
        q.execute('''SELECT p.period_key,p.single_count,p.block_hash,
                     g.block_hash,g.single_count,
                     g1.single_count,g5.single_count,g9.single_count,
                     g13.single_count,g16.single_count FROM periods p
                     LEFT JOIN groups g ON g.period_key=p.period_key AND g.group_no=17
                     LEFT JOIN groups g1 ON g1.period_key=p.period_key AND g1.group_no=1
                     LEFT JOIN groups g5 ON g5.period_key=p.period_key AND g5.group_no=5
                     LEFT JOIN groups g9 ON g9.period_key=p.period_key AND g9.group_no=9
                     LEFT JOIN groups g13 ON g13.period_key=p.period_key AND g13.group_no=13
                     LEFT JOIN groups g16 ON g16.period_key=p.period_key AND g16.group_no=16
                     WHERE p.period_key BETWEEN %s AND %s AND p.single_count IS NOT NULL
                     ORDER BY p.period_date,p.period_no''',(first,last))
        records=[(r[0],r[1],r[2],r[3],r[4],dict(zip((1,5,9,13,16),r[5:])))
                 for r in q.fetchall()]
        q.close()
    if len(records)<1001 or any(r[3] is None for r in records):
        raise RuntimeError('missing or pruned audited periods/groups in requested stage')
    return records


def save_batch(train_id,batch):
    with DB() as c:
        q=c.cursor()
        execute_values(q,'''INSERT INTO ai_simulations
          (trainset_id,method,period_key,phase,prediction,actual) VALUES %s
          ON CONFLICT(trainset_id,method,period_key) DO UPDATE SET
          phase=EXCLUDED.phase,prediction=EXCLUDED.prediction,actual=EXCLUDED.actual''',
          [(train_id,*r) for r in batch],page_size=500)
        q.close()


def train_models(rows,stage,fingerprint):
    train_id=f'GOD8:stage{stage}:{fingerprint[:16]}:{REVISION}'
    for order,method in enumerate(METHODS,1):
        with DB() as c:
            q=c.cursor()
            q.execute('SELECT id FROM ai_models WHERE trainset_id=%s AND method=%s LIMIT 1',
                      (train_id,method))
            exists=q.fetchone()
            q.close()
        if exists:
            continue
        set_meta('ai_status',{'status':'simulating','currentStage':stage,
            'method':method,'finishedMethods':order-1,'totalMethods':len(METHODS),
            'trainsetFingerprint':fingerprint,'trainsetId':train_id,'revision':REVISION})
        # One transaction per candidate avoids round trips after every 1,000
        # historical guesses; 10k/20k tuples fit comfortably in worker RAM.
        predictions=[]
        metrics,artifact=simulate(rows,method,on_batch=predictions.extend)
        save_batch(train_id,predictions)
        lower=metrics['holdout']['wilsonLower95']
        tier=max((t for t in (80,85,90,95) if lower>=t/100),default=None)
        artifact.update({'fingerprint':fingerprint,'stage':stage,'trainsetId':train_id})
        with DB() as c:
            q=c.cursor()
            q.execute('''INSERT INTO ai_models(trainset_id,method,params,metrics,tier,artifact)
                         VALUES(%s,%s,%s::jsonb,%s::jsonb,%s,%s::jsonb)''',
                      (train_id,method,json.dumps({'revision':REVISION,'window':1000,
                          'corpusPeriods':len(rows)}),json.dumps(metrics),tier,json.dumps(artifact)))
            q.close()
    with DB() as c:
        q=c.cursor()
        q.execute('SELECT id,method,metrics FROM ai_models WHERE trainset_id=%s',
                  (train_id,))
        all_models=q.fetchall()
        q.close()
    ranked=sorted(all_models,key=lambda x:(x[2]['validation']['accuracy'],
        x[2]['validation']['hits'],x[1]),reverse=True)
    picks=[{'id':r[0],'method':r[1],'validation':r[2]['validation'],
            'holdout':r[2]['holdout']} for r in ranked[:2]]
    fixed=next((r for r in all_models if r[1]=='fixed_3'),None)
    baseline=fixed[2]['validation']['accuracy'] if fixed else None
    improvement=(picks[0]['validation']['accuracy']-baseline) if baseline is not None else None
    status={'status':'shadow-testing','currentStage':stage,
        'finishedMethods':len(all_models),'totalMethods':len(METHODS),
        'trainsetFingerprint':fingerprint,'trainsetId':train_id,'revision':REVISION,
        'selectedTopTwo':picks,'selectionBasis':'validation-only',
        'corpusPeriods':len(rows),'completedAt':datetime.now(timezone.utc).isoformat(),
        'fixed3Validation':baseline,'validationLiftVsFixed3':improvement,
        'practiceMode':'distinct-contexts-ordered-replay',
        'practiceExplanation':'每个不同方法按期号顺序复盘一次；相同数据和方法重复运行不计新增证据'}
    set_meta('ai_status',status)
    return picks,status


def check_new_stage(stage,selected,begin,end):
    """Freeze old artifacts. Evaluate the NEXT stage only after that stage completes."""
    history_start=begin-1000
    data=loaded_periods(history_start,end)
    features=feature_rows(data)
    outcome=[]
    for chosen in selected:
        with DB() as c:
            q=c.cursor()
            q.execute('SELECT trainset_id,artifact FROM ai_models WHERE id=%s',(chosen['id'],))
            model=q.fetchone()
            q.close()
        if not model:
            continue
        train_id,artifact=model
        labels=[int(r[1]) for r in data]
        batch=[];hits=0
        for i in range(1000,len(data)):
            window=10000 if chosen['method'].startswith('sequence_suffix_') else 1000
            lower=max(0,i-window)
            guess=predict_future(chosen['method'],artifact,features[i],labels[lower:i],
                                 prior_keys=[r[0] for r in data[lower:i]])
            hit=int(guess==labels[i]);hits+=hit
            batch.append((chosen['method'],data[i][0],f'next_stage_{stage}',guess,labels[i]))
            if len(batch)>=1000:
                save_batch(train_id,batch)
                batch=[]
        if batch:save_batch(train_id,batch)
        total=len(data)-1000
        result={'hits':hits,'predictions':total,'accuracy':hits/total,
                'wilsonLower95':wilson(hits,total),'sourceModelId':chosen['id'],
                'sourceTrainsetId':train_id,'evaluationStage':stage}
        with DB() as c:
            q=c.cursor()
            q.execute('''INSERT INTO god8_stage_reviews(stage_no,model_id,metrics)
                         VALUES(%s,%s,%s::jsonb)
                         ON CONFLICT(stage_no,model_id) DO UPDATE SET metrics=EXCLUDED.metrics''',
                      (stage,chosen['id'],json.dumps(result)))
            q.close()
        outcome.append(result)
    return outcome


def train_once():
    origin=origin_index()
    if origin is None:
        return False
    state=get_meta('god8_ai_stage') or {}
    previous=int(state.get('processed',-1))
    with DB() as c:
        q=c.cursor()
        q.execute("SELECT stage_no,fingerprint FROM god8_stage_checks WHERE report->>'pass'='true' ORDER BY stage_no")
        audited=dict(q.fetchall())
        q.close()
    # A code revision can safely re-run the frozen audited first stage without
    # resetting the forward cursor or counting the same history as new evidence.
    current_status=get_meta('ai_status') or {}
    if previous >= 0 and (current_status.get('revision') != REVISION or
                          current_status.get('status') == 'simulating') and 0 in audited:
        first_begin,first_end=stage_window(origin,0)
        evidence=stage_rows(first_begin,first_end)
        if len(evidence)==TRAIN_N and stage_fingerprint(evidence)==audited[0]:
            picks,status=train_models(loaded_periods(first_begin,first_end),0,audited[0])
            state['selection']=picks
            state['benchmark']=picks[0]['holdout']['accuracy']
            state['lastModelTrainset']=status['trainsetId']
            set_meta('god8_ai_stage',state)
        return False
    stage=previous+1
    if stage not in audited:
        if previous<0:set_meta('ai_status',{'status':'waiting-for-first-audited-10000'})
        return False
    begin,end=stage_window(origin,stage)
    original=stage_rows(begin,end)
    if len(original)!=TRAIN_N or stage_fingerprint(original)!=audited[stage]:
        set_meta('god8_ai_warning',{'stage':stage,
            'reason':'stage evidence pruned or fingerprint changed; cannot pretend it was trained'})
        return False
    if stage==0:
        picks,status=train_models(loaded_periods(begin,end),0,audited[0])
        state={'processed':0,'selection':picks,'benchmark':picks[0]['holdout']['accuracy'],
               'lastModelTrainset':status['trainsetId'],'stageResults':[]}
    else:
        selected=state.get('selection') or []
        reviews=check_new_stage(stage,selected,begin,end)
        benchmark=float(state.get('benchmark',0))
        best=reviews[0]['accuracy'] if reviews else 0
        dropped=best<benchmark-.02 or best<.8
        set_meta('god8_stage_comparison',{'stage':stage,'previousBenchmark':benchmark,
            'newStageTopOneRate':best,'dropped':dropped,
            'reason':'below prior rate by >2 points or below 80% target' if dropped else 'continue observing',
            'allReviews':reviews})
        if dropped:
            recent_start=max(origin,end-19999)
            corpus=stage_rows(recent_start,end)
            fingerprint=stage_fingerprint(corpus)
            picks,status=train_models(loaded_periods(recent_start,end),stage,fingerprint)
            state['selection']=picks
            state['benchmark']=picks[0]['holdout']['accuracy']
            state['lastModelTrainset']=status['trainsetId']
        else:
            set_meta('ai_status',{'status':'shadow-testing','currentStage':stage,
                'selectedTopTwo':selected,'trainsetId':state['lastModelTrainset'],
                'trainsetFingerprint':(get_meta('ai_status') or {}).get('trainsetFingerprint'),
                'revision':REVISION,'finishedMethods':len(METHODS),'totalMethods':len(METHODS),
                'lastStageRate':best,'comparison':'maintained on a new 10000-period stage'})
        state['processed']=stage
        state['stageResults']=(state.get('stageResults') or [])[-5:]+[{'stage':stage,
            'topOneRate':best,'previousBenchmark':benchmark,'retrained':dropped}]
    set_meta('god8_ai_stage',state)
    return True
