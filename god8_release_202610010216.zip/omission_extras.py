"""Daily over-threshold episodes and independent historical omission comparisons."""
from omission_research import THRESHOLDS
from streak_research import issue_index


def recommend_recent(rows, window=200, min_occurrences=3, max_overdue=2,
                     mapping_valid=True, latest_age=None):
    """Two explainable low-overdue labels, not a forecast or wagering edge.

    The SQL caller loads newest valid results; oldest incomplete runs are left-censored.
    Only a run that starts after an observed hit may count as an over-threshold episode.
    """
    ordered = sorted(((row[0], row[1]) for row in rows),
                     key=lambda row: issue_index(row[0]))[-window:]
    invalid = sum(type(value) is not int or value not in range(8)
                  for _, value in ordered)
    missing = sum(max(0, issue_index(ordered[i][0]) - issue_index(ordered[i-1][0]) - 1)
                  for i in range(1, len(ordered)))
    duplicates = sum(issue_index(ordered[i][0]) <= issue_index(ordered[i-1][0])
                     for i in range(1, len(ordered)))
    valid = [(key, value) for key, value in ordered
             if type(value) is int and 0 <= value <= 7]
    completed = (len(ordered) == window and invalid == 0 and missing == 0
                 and duplicates == 0 and mapping_valid
                 and (latest_age is None or 0 <= latest_age <= 2))
    status = ('校准未完成' if not mapping_valid else
              '最近开奖延迟，等待同步' if latest_age is not None and latest_age > 2 else
              '期号超前，等待核对' if latest_age is not None and latest_age < 0 else
              '期号有缺口或重复' if missing or duplicates else
              '含无效开奖' if invalid else
              f'不足{window}期' if len(ordered) < window else '连续期已核对')
    gaps = [0]*8
    hits = [0]*8
    seen = [False]*8
    overdue = [0]*8
    peak = [0]*8
    last = [None]*8
    for key, result in valid:
        for label in range(8):
            if label == result:
                hits[label] += 1
                seen[label] = True
                last[label] = key
                gaps[label] = 0
            elif seen[label]:
                gaps[label] += 1
                peak[label] = max(peak[label], gaps[label])
                if gaps[label] == THRESHOLDS[label] + 1:
                    overdue[label] += 1
    items = []
    for label in range(8):
        eligible = (completed and hits[label] >= min_occurrences and
                    overdue[label] <= max_overdue and gaps[label] <= THRESHOLDS[label])
        items.append({'single': label, 'hits': hits[label], 'currentGap': gaps[label] if seen[label] else None,
                      'threshold': THRESHOLDS[label], 'overdueCount': overdue[label],
                      'maxObservedGap': peak[label] if seen[label] else None,
                      'lastIssue': last[label], 'eligible': eligible,
                      'reason': (status if not completed else
                                 '窗口内未出现或不足3次' if hits[label] < min_occurrences else
                                 '当前已超期' if gaps[label] > THRESHOLDS[label] else
                                 '窗口内超期超过2段' if overdue[label] > max_overdue else
                                 '满足历史低超期筛选')} )
    ranked = sorted((x for x in items if x['eligible']),
                    key=lambda x: (x['overdueCount'],
                                   x['currentGap']/x['threshold'],
                                   -x['hits'], x['single']))
    return {'window':window, 'valid':len(valid), 'complete':completed,
            'invalid':invalid, 'missing':missing, 'duplicates':duplicates,
            'mappingValid':mapping_valid, 'latestAge':latest_age, 'status':status,
            'firstIssue':ordered[0][0] if ordered else None,
            'lastIssue':ordered[-1][0] if ordered else None,
            'candidates':ranked[:2] if completed else [], 'items':items,
            'note':'仅使用数据库最新200个连续期；缺期、重复、无效开奖、目标区块未校准或最近开奖延迟超过2期时暂停筛选。某单几出现后，连续遗漏首次超阈值计一次；要求至少出现3次、超期不超过2段、当前未超期。此筛选不是下一期命中率或投注建议。'}


def daily_overdue(rows):
    """Today-only valid draws in chronological order, as (issue, single)."""
    records = [(key, value) for key, value in rows if type(value) is int and 0 <= value <= 7]
    state = [{'gap': 0, 'event': None, 'events': []} for _ in range(8)]
    for key, value in records:
        for label, item in enumerate(state):
            threshold = THRESHOLDS[label]
            if label == value:
                if item['event'] is not None:
                    item['event']['endedBy'] = key
                    item['events'].append(item['event'])
                    item['event'] = None
                item['gap'] = 0
                continue
            item['gap'] += 1
            if item['gap'] == threshold + 1:
                item['event'] = {'startIssue': key, 'endIssue': key,
                                 'threshold': threshold, 'peakGap': item['gap'],
                                 'endedBy': None, 'active': True}
            elif item['event'] is not None:
                item['event']['endIssue'] = key
                item['event']['peakGap'] = item['gap']
    result = []
    for label, item in enumerate(state):
        if item['event'] is not None:
            item['events'].append(item['event'])
        for event in item['events']:
            event['active'] = event['endedBy'] is None
            event['excess'] = event['peakGap'] - event['threshold']
        result.append({'single': label, 'threshold': THRESHOLDS[label],
                       'count': len(item['events']), 'currentGap': item['gap'],
                       'events': list(reversed(item['events']))})
    return {'valid': len(records), 'total': sum(x['count'] for x in result),
            'items': result,
            'note': '北京时间当天的有效开奖记录中，每段连续遗漏首次超过该单几阈值记一次；结束和进行中分开标注，缺期与无效记录不计数。'}


def overdue_page(rows, single, page=1, size=20):
    if single not in range(8) or page < 1 or size not in range(1, 101):
        raise ValueError('invalid overdue page')
    report = daily_overdue(rows)
    item = report['items'][single]
    events = item['events']
    return {'single': single, 'threshold': item['threshold'], 'count': item['count'],
            'page': page, 'totalPages': (len(events)+size-1)//size,
            'events': events[(page-1)*size:page*size], 'note': report['note']}


def chase_comparison(rows, horizon=10):
    """One observation per completed omission episode; active intervals are censored."""
    labels = [value for _, value in rows if type(value) is int and 0 <= value <= 7]
    n = len(labels)
    output = []
    for label in range(8):
        positions = [i for i, x in enumerate(labels) if x == label]
        current = n - 1 - positions[-1] if positions else n
        completed = [positions[i]-positions[i-1]-1 for i in range(1, len(positions))]
        eligible = [gap for gap in completed if gap >= current]
        hit = sum(gap - current + 1 <= horizon for gap in eligible)
        # Empirical rolling-window comparator; overlapping windows are descriptive only.
        baseline_samples = max(0, n-horizon)
        baseline_hits = sum(label in labels[i+1:i+horizon+1]
                            for i in range(baseline_samples))
        rate = hit/len(eligible) if eligible else None
        baseline = baseline_hits/baseline_samples if baseline_samples else None
        verdict = ('暂不追：历史可比区间不足' if len(eligible) < 30 else
                   '暂不追：未观察到稳定优势' if baseline is None or rate <= baseline else
                   '只供观察：历史比例高于基线，不构成追投建议')
        output.append({'single': label, 'currentGap': current, 'horizon': horizon,
                       'episodes': len(eligible), 'hits': hit, 'rate': rate,
                       'baseline': baseline, 'status': verdict})
    return {'valid': n, 'items': output,
            'note': '按历史已结束的独立遗漏段，比较在当前遗漏长度后10条有效开奖内是否首次出现；进行中的段不计命中。相关窗口与短样本可能误导，不能推断下一期必出。'}
