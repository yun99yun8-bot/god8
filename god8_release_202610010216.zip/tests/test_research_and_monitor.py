import os
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from ai_research import feature_rows, simulate, tier_pick, wilson
from collections import Counter
from monitor_collector import next_interval, recover_after_success
from web import app, parse_issue


class ResearchAndMonitor(unittest.TestCase):
    def test_current_actual_never_enters_own_features(self):
        rows = [('2026-09-24:0481',3,'A1'*32,'B2'*32,3),
                ('2026-09-24:0482',4,'A2'*32,'C3'*32,4)]
        features = feature_rows(rows)[-1]
        changed = rows[:-1]+[(rows[-1][0],0,'F'*64,rows[-1][3],rows[-1][4])]
        self.assertEqual(features,feature_rows(changed)[-1])

    def test_issue_search_preserves_missing_neighbors_across_midnight(self):
        self.assertEqual(parse_issue('2609270001'),('2026-09-27',1))
        from core import target_block
        self.assertEqual(target_block(*parse_issue('2609270409')),86596844)
        with patch('web.rows', return_value=[('2026-09-27:0001',4,86590000,[1,2,3,4,5,6,7])]):
            response=app.test_client().get('/api/history/search?issue=2609270001')
        self.assertEqual(response.status_code,200)
        body=response.get_json()
        self.assertEqual(len(body['rows']),21)
        self.assertEqual(body['rows'][9]['issue'],'2609261440')
        self.assertTrue(body['rows'][9]['missing'])
        self.assertTrue(body['rows'][10]['center'])
        self.assertEqual(body['rows'][10]['numbers'],[1,2,3,4,5,6,7])

    def test_real_signal_beats_fixed_baseline_in_walk_forward(self):
        rows = [(f'2026-09-25:{i:04d}',i%8,'A1'*32,'B2'*32,i%8)
                for i in range(1400)]
        good,_ = simulate(rows,'g17_single')
        baseline,_ = simulate(rows,'fixed_3')
        self.assertGreater(good['training']['accuracy'],.95)
        self.assertLess(baseline['training']['accuracy'],.2)

    def test_context_can_select_rare_class_only_when_it_has_evidence(self):
        baseline=Counter({3:250,6:40})
        self.assertEqual(tier_pick(Counter({6:35}),baseline),6)
        self.assertEqual(tier_pick(Counter({6:5}),baseline),3)

    def test_eighty_percent_needs_evidence(self):
        self.assertLess(wilson(80,100),.8)
        self.assertLess(wilson(0,0),.8)

    def test_polling_retreats_after_error_and_cautiously_recovers(self):
        self.assertGreater(next_interval(.5,20,1,.1),.5)
        self.assertLess(next_interval(1.,30,0,.3),1.)
        self.assertGreaterEqual(next_interval(.4,30,0,.3),.4)
        self.assertEqual(recover_after_success(60),3.)
        self.assertEqual(recover_after_success(1.2),1.2)

    def test_four_role_pages_and_ai_placeholder_render(self):
        client=app.test_client()
        for route in ('/','/history','/playbook','/services/monitor','/services/worker','/services/audit',
                      '/services/db','/services/ai','/ai-lab','/ai-lab-2','/checks'):
            self.assertEqual(client.get(route).status_code,200)

    def test_check_center_links_are_get_routes(self):
        from html.parser import HTMLParser
        class Links(HTMLParser):
            def __init__(self): super().__init__(); self.paths=[]
            def handle_starttag(self,tag,attrs):
                if tag=='a': self.paths.extend(v for k,v in attrs if k=='href')
        links=Links(); links.feed(app.test_client().get('/checks').get_data(as_text=True))
        self.assertIn('/api/live',links.paths)
        self.assertIn('/api/statistics/research',links.paths)
        self.assertIn('/services/audit',links.paths)
        self.assertIn('/playbook',links.paths)
        routes=app.url_map.bind('localhost')
        for path in links.paths:
            endpoint,_=routes.match(path.split('?',1)[0],method='GET')
            self.assertIsNotNone(endpoint,path)

    def test_streak_report_endpoint_returns_worker_evidence(self):
        payload={'lastPeriod':'2026-09-27:0050','conditions':[{'samples':2}]}
        with patch('web.get_meta',return_value=payload):
            response=app.test_client().get('/api/ai/streaks')
        self.assertEqual(response.get_json(),payload)

    def test_home_omission_does_not_reset_at_midnight(self):
        with patch('web.rows',return_value=[
            ('2026-09-27:1440',3),('2026-09-28:0001',4),
            ('2026-09-28:0002',5)
        ]):
            payload=app.test_client().get('/api/omission').get_json()
        self.assertEqual(payload['values'][3],2)
        self.assertTrue(payload['exact'][3])
        self.assertTrue(payload['complete'])
        self.assertEqual(payload['scope'],'retained-valid-history')

    def test_history_retained_omission_and_paged_run(self):
        values=[('2026-09-27:1439',3),('2026-09-27:1440',4),
                ('2026-09-28:0001',4),('2026-09-28:0002',1)]
        with patch('web.rows',return_value=values):
            client=app.test_client()
            summary=client.get('/api/omission/retained').get_json()
            detail=client.get('/api/omission/retained/run?single=3&page=1').get_json()
        self.assertEqual(summary['items'][3]['gap'],3)
        self.assertEqual(summary['items'][3]['longest']['startIssue'],'2609271440')
        self.assertEqual(detail['counts'][4],2)
        self.assertEqual(detail['rows'][-1]['issue'],'2609280002')

    def test_ai_diagnostic_explains_frozen_stage_and_valid_locks(self):
        from datetime import datetime,timezone
        metadata={'ai_status':{'status':'shadow-testing','selectedTopTwo':[
            {'id':10,'method':'g17_single'},{'id':11,'method':'fixed_3'}]},
                  'god8_ai_stage':{'processed':0},
                  'god8_forward':{'completedSinceOrigin':12880},
                  'ai_heartbeat':{'reportedAt':datetime.now(timezone.utc).isoformat()},
                  'ai_lock_status':{'reason':'waiting for group 17'}}
        with patch('web.get_meta',side_effect=lambda key,default=None:metadata.get(key,default)),patch(
                'web.rows',return_value=[(10,1,0,0,33),(11,0,4,1,2)]):
            data=app.test_client().get('/api/ai/diagnostic').get_json()
        self.assertEqual(data['roundsUntilNextStage'],7120)
        self.assertTrue(data['workerAlive'])
        self.assertEqual(data['candidates'][0]['valid'],0)
        self.assertIsNone(data['candidates'][0]['rate'])
        self.assertEqual(data['candidates'][0]['late'],33)
        self.assertIn('下一轮',data['explanation'])

    def test_health_reports_missing_database_not_false_success(self):
        with patch('web.DB',side_effect=RuntimeError('DATABASE_URL required')):
            response=app.test_client().get('/health')
        self.assertEqual(response.status_code,503)
        self.assertFalse(response.get_json()['databaseConnected'])

    def test_manual_adoption_denies_missing_token_without_db_write(self):
        with patch('web.DB') as db, patch.dict(os.environ,{'ADMIN_TOKEN':'required'}):
            response=app.test_client().post('/api/adopt/3')
        self.assertEqual(response.status_code,410)
        db.assert_not_called()

    def test_manual_adoption_waits_for_ai_service(self):
        with patch('web.DB') as db, patch('web.get_meta',return_value={}), \
             patch.dict(os.environ,{'ADMIN_TOKEN':'required'}):
            response=app.test_client().post('/api/adopt/3',headers={'X-Admin-Token':'required'})
        self.assertEqual(response.status_code,410)
        db.assert_not_called()

    def test_authorized_model_is_hidden_after_target_block(self):
        with patch('web.rows',return_value=[('2026-09-24:0481',3,'fixed_3')]), \
             patch('web.get_meta',return_value={'block':86511906}):
            result=app.test_client().get('/api/official-prediction').get_json()
        self.assertFalse(result['active'])


if __name__=='__main__':unittest.main()
