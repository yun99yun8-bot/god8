import unittest
from collections import Counter, defaultdict, deque

from history_simulation import (
    _method_weight, _omission_method, _replay_method, _trend_method, simulate,
    REPLAY_LENGTHS,
)
from core import from_index, pindex


class AdaptivePredictorTests(unittest.TestCase):
    def test_replay_never_uses_less_than_four_synced_periods(self):
        counters={length:defaultdict(Counter) for length in REPLAY_LENGTHS}
        sources={length:defaultdict(list) for length in REPLAY_LENGTHS}
        self.assertIsNone(_replay_method([1,2,3],counters,sources,[.125]*8))
        key=(0,1,2,3)
        counters[4][key].update({6:5,5:1})
        found=_replay_method(list(key),counters,sources,[.125]*8)
        self.assertEqual(found['length'],4)
        self.assertEqual(found['support'],6)
        self.assertEqual(found['top'][0],6)

    def test_hot_trend_can_move_away_from_three_four(self):
        recent=deque(([3,4]*50)+([5]*20),maxlen=500)
        method=_trend_method(recent,[.10,.10,.10,.20,.20,.10,.10,.10])
        self.assertIsNotNone(method)
        self.assertIn(5,method['hot'])
        self.assertIn(5,method['top'])

    def test_overdue_three_is_squeezed_without_historical_next_hit_support(self):
        gaps=[0]*8;gaps[3]=8
        completed=[deque([1,2,3,4,5]*20,maxlen=5000) for _ in range(8)]
        completed[3]=deque(([5]*92)+([12]*8),maxlen=5000)
        method=_omission_method(gaps,completed,[.1,.1,.1,.2,.2,.1,.1,.1])
        self.assertTrue(method['gaps']['3']['squeezed'])
        self.assertFalse(method['gaps']['3']['boosted'])

    def test_repeated_misses_lower_method_weight(self):
        perf={name:deque(maxlen=100) for name in ('replay','trend','omission','frequency')}
        perf['replay'].extend([True,True,False,False,False])
        low,_=_method_weight('replay',perf,{'replay':6,'trend':0,'omission':0,'frequency':0})
        high,_=_method_weight('replay',perf,{'replay':0,'trend':0,'omission':0,'frequency':0})
        self.assertLess(low,high)

    def test_walk_forward_can_recommend_non_34(self):
        start=pindex('2026-09-20',1)
        values=([0,1,2,5,6]*80)+([5,6,5,6,2]*40)
        values += [2,3,4,5,1,2,3,4,5,6]*12+[2,3,4,5]
        rows=[]
        for i,value in enumerate(values):
            day,no=from_index(start+i)
            rows.append((f'{day}:{no:04d}',value,[]))
        report=simulate(rows,minimum_training=80)
        self.assertIsNotNone(report['preview'])
        self.assertTrue(any(x not in (3,4) for x in report['preview']['predictions']))
        self.assertTrue(all(m['name'] in ('replay','trend','omission','frequency') for m in report['preview']['match']['methods']))

    def test_hot_frequency_cannot_fill_unobserved_replay_slots(self):
        from history_simulation import _ensemble, _frequency_method, _replay_method
        names=('replay','trend','omission','frequency')
        perf={name:deque(maxlen=100) for name in names}
        streak={name:0 for name in names}
        hot=[.02,.06,.04,.36,.35,.05,.07,.05]
        self.assertIsNone(_ensemble([_frequency_method(hot)],perf,streak))
        counters={length:defaultdict(Counter) for length in REPLAY_LENGTHS}
        sources={length:defaultdict(list) for length in REPLAY_LENGTHS}
        counters[4][(0,1,2,5)].update({1:5,6:4})
        replay=_replay_method([0,1,2,5],counters,sources,hot)
        choices,match=_ensemble([replay,_frequency_method(hot)],perf,streak)
        self.assertEqual(choices,[1,6])
        self.assertEqual(match['selectionPolicy'],'observed-replay-successors')
        counters[4][(0,1,2,5)]=Counter({1:9})
        replay=_replay_method([0,1,2,5],counters,sources,hot)
        self.assertIsNone(_ensemble([replay,_frequency_method(hot)],perf,streak))

    def test_single_replay_successor_uses_trend_for_second_choice(self):
        from history_simulation import _ensemble, _frequency_method, _replay_method, _trend_method
        names=('replay','trend','omission','frequency')
        perf={name:deque(maxlen=100) for name in names}
        streak={name:0 for name in names}
        base=[.08,.08,.08,.18,.18,.16,.12,.12]
        counters={length:defaultdict(Counter) for length in REPLAY_LENGTHS}
        sources={length:defaultdict(list) for length in REPLAY_LENGTHS}
        counters[4][(0,1,2,5)].update({1:1})
        replay=_replay_method([0,1,2,5],counters,sources,base)
        trend=_trend_method(deque(([3,4,5,6]*20)+([6]*20),maxlen=500),base)
        choices,match=_ensemble([replay,trend,_frequency_method(base)],perf,streak)
        self.assertEqual(choices[0],1)
        self.assertNotEqual(choices[1],1)
        self.assertEqual(match['selectionPolicy'],'replay-anchor-plus-adaptive')
        self.assertEqual(match['secondCandidateMode'],'adaptive')
        self.assertTrue(match['selectedEvidence'][1]['auxiliary'])


if __name__=='__main__':
    unittest.main()
