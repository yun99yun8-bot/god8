import time
import unittest
from collections import Counter, defaultdict

import core
from history_simulation import _replay_method, REPLAY_LENGTHS


class RuntimeHotConfigTests(unittest.TestCase):
    def setUp(self):
        self.old_value=core._RUNTIME_CACHE.get('value')
        self.old_checked=core._RUNTIME_CACHE.get('checked',0.0)

    def tearDown(self):
        with core._RUNTIME_CACHE_LOCK:
            core._RUNTIME_CACHE['value']=self.old_value
            core._RUNTIME_CACHE['checked']=self.old_checked

    def apply(self,cfg):
        with core._RUNTIME_CACHE_LOCK:
            core._RUNTIME_CACHE['value']=core._normalize_runtime_config(cfg)
            core._RUNTIME_CACHE['checked']=time.monotonic()

    def test_target_mapping_changes_without_reimport_or_restart(self):
        cfg=core._clone_default_runtime()
        self.apply(cfg)
        original=core.target_block('2026-10-01',47)
        self.assertEqual(original,86704752)
        cfg['tailMapping']['segments'][-1]['delta']=-19
        cfg['revision']=2
        self.apply(cfg)
        changed=core.target_block('2026-10-01',47)
        self.assertEqual(changed,original+1)
        self.assertEqual(changed%10,3)

    def test_replay_min_length_hot_setting_changes_next_calculation(self):
        counters={length:defaultdict(Counter) for length in REPLAY_LENGTHS}
        sources={length:defaultdict(list) for length in REPLAY_LENGTHS}
        key=(0,1,2,5)
        counters[4][key].update({6:2})
        cfg=core._clone_default_runtime()
        cfg['prediction']['minReplayLength']=5
        self.apply(cfg)
        self.assertIsNone(_replay_method(list(key),counters,sources,[.125]*8))
        cfg['prediction']['minReplayLength']=4
        cfg['revision']=2
        self.apply(cfg)
        found=_replay_method(list(key),counters,sources,[.125]*8)
        self.assertIsNotNone(found)
        self.assertEqual(found['length'],4)
        self.assertEqual(found['top'][0],6)


if __name__=='__main__':
    unittest.main()
