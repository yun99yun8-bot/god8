import os
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))
from omission_research import current_snapshot,retained_stats,run_page


class RetainedOmissionTests(unittest.TestCase):
    def test_midnight_does_not_reset_current_gap(self):
        data=[('2026-09-27:1438',3),('2026-09-27:1439',4),
              ('2026-09-27:1440',2),('2026-09-28:0001',4),
              ('2026-09-28:0002',5)]
        stats=retained_stats(data)
        self.assertTrue(stats['complete'])
        self.assertEqual(stats['items'][3]['gap'],4)
        self.assertEqual(stats['items'][3]['lastIssue'],'2609271438')
        self.assertEqual(stats['items'][5]['gap'],0)
        self.assertEqual(stats['sample'],5)

    def test_missing_and_invalid_are_marked_not_pretended_valid(self):
        data=[('2026-09-27:1439',3),('2026-09-27:1440',None),
              ('2026-09-28:0002',4)]
        stats=retained_stats(data)
        self.assertTrue(stats['complete'])
        self.assertEqual((stats['missing'],stats['invalid']),(1,1))
        self.assertEqual(stats['missingRanges'],[{'firstIssue':'2609280001',
                                                 'lastIssue':'2609280001','count':1}])
        self.assertEqual(stats['invalidIssues'],['2609271440'])
        self.assertFalse(stats['sourceComplete'])
        self.assertEqual(stats['items'][3]['gap'],1)
        self.assertEqual(stats['items'][3]['lowerBound'],1)
        report=run_page(data,3)
        self.assertEqual(report['rows'][0]['issue'],'2609280002')
        self.assertTrue(report['complete'])
        self.assertFalse(report['sourceComplete'])

    def test_old_invalid_result_does_not_hide_new_exact_gaps(self):
        data=[('2026-09-28:0001',None),('2026-09-28:0002',3),
              ('2026-09-28:0003',4),('2026-09-28:0004',5)]
        result=current_snapshot(data)
        self.assertEqual(result['invalid'],1)
        self.assertTrue(result['complete'])
        self.assertFalse(result['sourceComplete'])
        self.assertEqual(result['values'][3],2)
        self.assertEqual(result['values'][4],1)
        self.assertEqual(result['values'][5],0)
        self.assertEqual(result['values'][0],3)
        self.assertEqual(result['lowerBounds'][0],3)
        self.assertFalse(result['exact'][0])
        history=retained_stats(data)
        self.assertEqual(history['items'][3]['gap'],2)
        self.assertEqual(history['items'][0]['lowerBound'],3)

    def test_longest_run_is_paginated_without_dropping_total_counts(self):
        from core import from_index,pindex
        start=pindex('2026-09-27',1)
        data=[(f'{ds}:{period:04d}',4) for ds,period in
              (from_index(start+i) for i in range(150))]
        first=run_page(data,3,1);second=run_page(data,3,2)
        self.assertEqual(first['totalPages'],2)
        self.assertEqual(len(first['rows']),100)
        self.assertEqual(len(second['rows']),50)
        self.assertEqual(first['counts'][4],150)


if __name__=='__main__':unittest.main()
