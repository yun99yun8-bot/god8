import os
import sys
import unittest

sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))
from ai_research import METHODS, SEARCH_CONTEXTS, feature_rows, method_key, predict_future, simulate, tier_pick
from collections import Counter
from streak_research import report, states


class StreakResearchTest(unittest.TestCase):
    def test_trigger_uses_only_earlier_results(self):
        rows=[(f'2026-09-27:{i:04d}',3) for i in range(1,12)]
        before,_=states(rows)
        self.assertEqual(before[9]['run34'],9)
        self.assertEqual(before[10]['run34'],10)
        alternate=rows[:-1]+[(rows[-1][0],7)]
        self.assertEqual(feature_rows([(key,value,'A1'*32,'B2'*32,3)
                                       for key,value in rows])[-1],
                         feature_rows([(key,value,'A1'*32,'B2'*32,3)
                                       for key,value in alternate])[-1])

    def test_gap_and_invalid_period_break_streak(self):
        rows=[('2026-09-27:0001',3),('2026-09-27:0002',4),
              ('2026-09-27:0004',3),('2026-09-27:0005',None),
              ('2026-09-27:0006',3)]
        before,_=states(rows)
        self.assertEqual(before[2]['run34'],0)
        self.assertEqual(before[4]['run34'],0)

    def test_first_hit_after_several_rounds_counts_once(self):
        rows=[(f'2026-09-27:{i:04d}',value) for i,value in enumerate(
              [3]*10+[4,4,6],1)]
        evidence=report(rows)
        condition=evidence['conditions'][0]
        self.assertEqual(condition['samples'],1)
        group=condition['groups'][0]
        self.assertEqual(group['firstHitsObserved'],1)
        self.assertEqual(group['medianFirstHit'],3)
        self.assertEqual(group['chase']['5']['hits'],1)
        self.assertEqual(group['chase']['5']['verdict'],'样本不足')

    def test_unfinished_chase_is_not_reported_as_certain_hit(self):
        rows=[(f'2026-09-27:{i:04d}',3) for i in range(1,12)]
        evidence=report(rows)
        group=evidence['conditions'][0]['groups'][0]
        self.assertEqual(group['firstHitsObserved'],0)
        self.assertEqual(group['notYetHit'],1)
        self.assertEqual(group['chase']['5']['eligible'],0)
        self.assertIsNone(group['chase']['5']['rate'])

    def test_later_hit_counts_only_in_horizons_that_include_it(self):
        values=[3]*10+[4]*6+[1]
        data=[(f'2026-09-27:{i:04d}',value) for i,value in enumerate(values,1)]
        group=report(data)['conditions'][0]['groups'][0]
        self.assertEqual(group['medianFirstHit'],7)
        self.assertEqual((group['chase']['5']['hits'],group['chase']['5']['eligible']),(0,1))
        self.assertEqual((group['chase']['10']['hits'],group['chase']['10']['eligible']),(1,1))

    def test_invalid_middle_does_not_create_fake_chase_hit(self):
        values=[3]*10+[4,None,6]
        data=[(f'2026-09-27:{i:04d}',value) for i,value in enumerate(values,1)]
        group=report(data)['conditions'][0]['groups'][0]
        self.assertEqual(group['firstHitsObserved'],0)
        self.assertEqual(group['chase']['5']['eligible'],0)

    def test_fifteen_round_absence_and_secondary_branch(self):
        rows=[(f'2026-09-27:{i:04d}',4) for i in range(1,17)]
        before,_=states(rows)
        self.assertEqual(before[-1]['gap25'],15)
        self.assertEqual(before[-1]['gap16'],15)
        evidence=report(rows)
        self.assertTrue(evidence['conditions'][1]['active'])
        self.assertTrue(evidence['conditions'][3]['active'])
        self.assertEqual(evidence['conditions'][0]['samples'],1)
        self.assertEqual(evidence['conditions'][1]['samples'],1)

    def test_four_regime_candidates_replay_and_predict(self):
        self.assertEqual(len(METHODS),49)
        rows=[(f'2026-09-{27+i//1440:02d}:{i%1440+1:04d}',3 if i%2 else 4,
               'A1'*32,'B2'*32,3,{}) for i in range(1120)]
        method='regime_34_5000'
        metrics,artifact=simulate(rows,method)
        self.assertEqual(metrics['training']['predictions'],120)
        features=feature_rows(rows)
        self.assertIn(predict_future(method,artifact,features[-1],[r[1] for r in rows]),range(8))

    def test_regime_sliding_window_uses_only_prior_examples(self):
        rows=[(f'2026-09-27:{i:04d}',6 if i>1000 else 3,
               'A1'*32,'B2'*32,3,{}) for i in range(1,1031)]
        forecasts=[]
        method='regime_34_5000'
        simulate(rows,method,on_batch=lambda batch:forecasts.extend(batch))
        self.assertEqual(forecasts[0][3],3)
        features=feature_rows(rows)
        for offset in (1000,1010,1029):
            key=repr(method_key(method,features[offset]))
            past=rows[:offset]
            condition=Counter(r[1] for r,f in zip(past,features[:offset])
                              if repr(method_key(method,f))==key)
            guess=tier_pick(condition,Counter(r[1] for r in past))
            self.assertEqual(forecasts[offset-1000][3],guess)

    def test_new_contexts_have_distinct_replay_and_future_predictions(self):
        method='probe_g17_last_350'
        self.assertIn(method,SEARCH_CONTEXTS)
        rows=[(f'2026-09-27:{i:04d}',6 if i%4==0 else 3,
               'A1'*32,'B2'*32,6 if i%4==0 else 3,{}) for i in range(1,1451)]
        metrics,artifact=simulate(rows,method)
        self.assertGreater(metrics['training']['predictions'],0)
        features=feature_rows(rows)
        self.assertIn(predict_future(method,artifact,features[-1],[r[1] for r in rows]),range(8))
        altered=rows[:-1]+[(rows[-1][0],0,rows[-1][2],rows[-1][3],rows[-1][4],{})]
        self.assertEqual(method_key(method,features[-1]),method_key(method,feature_rows(altered)[-1]))


if __name__ == '__main__':unittest.main()
