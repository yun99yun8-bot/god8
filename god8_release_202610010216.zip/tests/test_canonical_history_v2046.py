import unittest
from canonical_history import canonicalize
from omission_research import current_snapshot
from core import target_block


class CanonicalHistoryV2046Tests(unittest.TestCase):
    def row(self,key,stored_target,single,numbers=None,block_hash='old'):
        ds,no=key.split(':')
        return (key,ds,int(no),stored_target,block_hash,numbers or [1,2,3,4,5,6,7],single,None)

    def test_last_three_tail_uses_raw_even_when_target_already_matches(self):
        key='2026-10-01:0046'; exp=target_block('2026-10-01',46)
        formal=[self.row(key,exp,3,block_hash='stale')]
        raw=[(exp,'raw46',[2,4,6,8,10,12,13],1)]
        out=canonicalize(formal,raw)[0]
        self.assertEqual(out[3],86704733)
        self.assertEqual(out[4],'raw46')
        self.assertEqual(out[6],1)
        self.assertTrue(out[8])

    def test_first_resumed_two_tail_replaces_old_three_tail_payload(self):
        key='2026-10-01:0047'; exp=target_block('2026-10-01',47)
        self.assertEqual(exp,86704752)
        formal=[self.row(key,86704753,4,block_hash='wrong3tail')]
        raw=[(exp,'right2tail',[1,3,5,7,9,11,12],6)]
        out=canonicalize(formal,raw)[0]
        self.assertEqual(out[3],86704752)
        self.assertEqual(out[4],'right2tail')
        self.assertEqual(out[6],6)
        self.assertTrue(out[8])

    def test_wrong_target_without_raw_never_leaks_old_single(self):
        key='2026-10-01:0048'; exp=target_block('2026-10-01',48)
        formal=[self.row(key,exp+1,3)]
        out=canonicalize(formal,[])[0]
        self.assertEqual(out[3],exp)
        self.assertIsNone(out[6])
        self.assertFalse(out[8])

    def test_omission_uses_canonical_results_not_old_payloads(self):
        keys=['2026-10-01:0045','2026-10-01:0046','2026-10-01:0047','2026-10-01:0048']
        formal=[];raw=[]
        canonical_singles=[3,1,6,2]
        for i,(key,single) in enumerate(zip(keys,canonical_singles)):
            ds,no=key.split(':');exp=target_block(ds,int(no))
            # Pretend old formal rows were all single3, including resumed 2-tail issues.
            formal.append(self.row(key,exp+(1 if int(no)>=47 else 0),3))
            raw.append((exp,f'h{i}',[1,2,3,4,5,6,7],single))
        merged=canonicalize(formal,raw)
        snapshot=current_snapshot([(r[0],r[6]) for r in merged])
        # Latest sequence is 3,1,6,2: single2 gap=0; single3 has missed 3 valid draws.
        self.assertEqual(snapshot['values'][2],0)
        self.assertEqual(snapshot['values'][3],3)
        self.assertEqual(snapshot['values'][6],1)


if __name__=='__main__':
    unittest.main()
