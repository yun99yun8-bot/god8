import os
import unittest
from datetime import datetime, timedelta, timezone

from fate_dashboard import summarize_ledger

ROOT=os.path.dirname(os.path.dirname(__file__))


class FateDashboardTests(unittest.TestCase):
    def test_only_proven_pre_block_locks_are_scored(self):
        block=datetime(2026,9,30,0,30,tzinfo=timezone.utc)
        def record(no, choices, actual, locked, block_time=block, settled=True):
            return (f'2026-09-30:{no:04d}',f'2026-09-30:{no-1:04d}',choices,
                    {'length':4,'support':10},locked,actual,block if settled else None,
                    block_time,100+no,120+no,100+no)
        rows=[record(3,[1,6],1,block-timedelta(seconds=12)),
              record(4,[1,6],4,block-timedelta(seconds=8)),
              record(5,[1,6],6,block+timedelta(seconds=1)),
              record(6,[1,6],1,block-timedelta(seconds=8),block_time=None),
              record(7,[1,6],1,block-timedelta(seconds=8),settled=False),
              record(8,[1,1],1,block-timedelta(seconds=8))]
        report=summarize_ledger(list(reversed(rows)))
        self.assertEqual(report['all']['verified'],2)
        self.assertEqual(report['all']['first']['hits'],1)
        self.assertEqual(report['all']['either']['hits'],1)
        self.assertEqual(report['excluded']['lateLock'],1)
        self.assertEqual(report['excluded']['missingBlockTime'],1)
        self.assertEqual(report['excluded']['unsettled'],1)
        self.assertEqual(report['excluded']['invalidChoices'],1)
        self.assertEqual(report['streaks']['current']['either'],1)
        self.assertEqual(report['recent'][0]['issue'],'2609300004')

    def test_wrong_source_mapping_is_not_scored(self):
        block=datetime(2026,9,30,tzinfo=timezone.utc)
        data=[('2026-09-30:0002','2026-09-30:0001',[1,6],{},
               block-timedelta(seconds=5),1,block,block,101,121,999)]
        report=summarize_ledger(data)
        self.assertEqual(report['all']['verified'],0)
        self.assertEqual(report['excluded']['invalidSource'],1)

    def test_no_sample_does_not_claim_accuracy(self):
        report=summarize_ledger([])
        self.assertIsNone(report['all']['either']['rate'])
        self.assertIsNone(report['all']['either']['lower95'])

    def test_navigation_and_history_entry_are_independent(self):
        with open(os.path.join(ROOT,'templates/base.html'),encoding='utf8') as f:
            nav=f.read()
        with open(os.path.join(ROOT,'templates/statistics.html'),encoding='utf8') as f:
            stats=f.read()
        with open(os.path.join(ROOT,'templates/fate.html'),encoding='utf8') as f:
            fate=f.read()
        self.assertIn('href="/fate"',nav)
        self.assertNotIn('href="/history"',nav)
        self.assertIn('href="/history"',stats)
        self.assertIn('id="fateLedger"',fate)
        self.assertIn('id="fateBacktest"',fate)


if __name__=='__main__':unittest.main()
