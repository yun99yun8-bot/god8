import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from pattern_memory import analyze, practice_view


def rows(values):
    return [(f'2026-09-30:{i:04d}', value) for i, value in enumerate(values, 1)]


class PatternMemoryTests(unittest.TestCase):
    def test_07_triggers_replay_without_using_own_future(self):
        episode = [2, 3, 4, 0] + [1, 6, 1, 6, 3, 4, 2, 3, 4, 5]
        report = analyze(rows(episode * 14 + [2, 3, 4, 0]))
        self.assertGreaterEqual(report['replay']['samples'], 12)
        self.assertEqual(report['replay']['highFrequencyCases'], report['replay']['samples'])
        self.assertGreaterEqual(report['replay']['length'], 4)
        self.assertEqual(report['status'], 'replay')

    def test_insufficient_matches_never_warns_high_frequency(self):
        report = analyze(rows([2, 3, 4, 7] + [1, 6, 1, 6, 3, 4, 2, 3, 4, 5] + [2, 3, 4, 7]))
        self.assertEqual(report['replay']['samples'], 1)
        self.assertFalse(report['highFrequency'])

    def test_invalid_and_missing_rounds_break_recent_activity(self):
        self.assertIsNone(analyze(rows([1, 6, 1, 6, None, 2, 3, 4, 0]))['recent16'])
        data = rows([1, 6, 1, 6, 2, 3, 4, 0])
        data[-1] = ('2026-09-30:0010', 0)
        self.assertIsNone(analyze(data)['replay'])

    def test_active_only_counts_observed_recent_ten(self):
        report = analyze(rows([1, 6, 1, 6, 2, 3, 4, 5, 2, 3]))
        self.assertTrue(report['highFrequency'])
        self.assertEqual(report['status'], 'active')
        self.assertIsNone(report['replay'])
        self.assertEqual(report['practice']['highFrequencyEpisodes'], 1)

    def test_practice_merges_overlapping_high_frequency_windows(self):
        report = analyze(rows([2, 3, 0, 4, 2, 3, 4, 5, 2, 3] + [1, 6, 1, 6, 1, 6, 2]))
        self.assertEqual(report['practice']['highFrequencyEpisodes'], 1)
        self.assertEqual(report['practice']['preceded07InFour'], 1)

    def test_inactive_api_view_removes_future_replay_and_notice(self):
        episode = [2, 3, 4, 0] + [1, 6, 1, 6, 3, 4, 2, 3, 4, 5]
        complete = analyze(rows(episode * 14 + [2, 3, 4, 0]))
        inactive = practice_view(complete)
        self.assertEqual(inactive['status'], 'practice')
        self.assertNotIn('replay', inactive)
        self.assertNotIn('notice', inactive)
        self.assertNotIn('highFrequency', inactive)
        self.assertIsNotNone(inactive['practice'])


if __name__ == '__main__':
    unittest.main()
