import os
import sys
import unittest
from unittest.mock import patch, MagicMock

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from core import ANCHOR_INDEX, from_index, target_block
from backfill_worker import window, fetch_period
from god8_flow import stage_window, first_complete_index, prune_old_periods
from web import app


class FourRoleTests(unittest.TestCase):
    def test_backfill_reuses_existing_blocks_without_chain_fetch(self):
        ds, no = from_index(ANCHOR_INDEX)
        with patch('backfill_worker.missing_blocks', return_value=set()), \
             patch('backfill_worker.fetch_block_range') as external, \
             patch('backfill_worker.repair_derived') as derive, \
             patch('backfill_worker.save_period', return_value=(True, [])) as saved:
            self.assertTrue(fetch_period(ds, no))
            external.assert_not_called()
            derive.assert_called_once()
            saved.assert_called_once_with(ds, no, 'god8-forward', False)

    def test_existing_window_cannot_silently_change(self):
        with patch('backfill_worker.origin_index', return_value=ANCHOR_INDEX), \
             patch('backfill_worker.get_meta', return_value={
                 'startIndex': 1, 'endIndex': 9999, 'locked': False}):
            with self.assertRaisesRegex(RuntimeError, 'origin is immutable'):
                window()

    def test_history_uses_real_issue_number_and_paging(self):
        with patch('web.rows', side_effect=[[(124,)], [('2026-09-24:0481', 3, 86511906, [1,2,3,4,5,6,7])]]):
            response = app.test_client().get('/api/history?page=2&count=all')
        self.assertEqual(response.status_code, 200)
        body = response.get_json()
        self.assertEqual(body['pageSize'],100)
        self.assertEqual(body['rows'], [{'period': '2026-09-24:0481', 'issue':'2609240481',
            'single': 3, 'block':86511906,'numbers':[1,2,3,4,5,6,7]}])

    def test_daily_omission_keeps_valid_history_despite_holes(self):
        from web import daily_omission_stats
        data=daily_omission_stats([
            ('2026-09-27:0001','2026-09-27',1,3),
            ('2026-09-27:0003','2026-09-27',3,4)],'2026-09-27')
        self.assertTrue(data['complete'])
        self.assertFalse(data['sourceComplete'])
        self.assertEqual(data['missing'],1)
        self.assertEqual(data['items'][3]['gap'],1)
        self.assertEqual(data['items'][3]['lowerBound'],1)
        self.assertEqual(data['items'][0]['gap'],2)
        self.assertEqual(data['items'][0]['level'],'正常')

    def test_daily_recent_valid_labels_stay_exact_after_old_invalid(self):
        from web import daily_omission_stats
        day='2026-09-27'
        data=daily_omission_stats([(f'{day}:{n:04d}',day,n,k) for n,k in
            [(1,None),(2,3),(3,4),(4,5)]],day)
        self.assertTrue(data['complete'])
        self.assertFalse(data['sourceComplete'])
        self.assertEqual(data['invalid'],1)
        self.assertEqual(data['items'][3]['gap'],2)
        self.assertEqual(data['items'][4]['gap'],1)
        self.assertEqual(data['items'][0]['gap'],3)
        self.assertEqual(data['items'][0]['lowerBound'],3)

    def test_360_boundary_18_then_20(self):
        before = from_index(ANCHOR_INDEX - 1)
        anchor = from_index(ANCHOR_INDEX)
        after = from_index(ANCHOR_INDEX + 1)
        self.assertEqual(target_block(*anchor) - target_block(*before), 18)
        self.assertEqual(target_block(*after) - target_block(*anchor), 20)

    def test_raw_origin_skips_incomplete_first_20_group(self):
        self.assertEqual(first_complete_index(target_block(*from_index(ANCHOR_INDEX))-18),
                         ANCHOR_INDEX+1)
        self.assertEqual(stage_window(ANCHOR_INDEX,1),(ANCHOR_INDEX+10000,ANCHOR_INDEX+19999))

    def test_60001st_period_prunes_one_and_preserves_new_oldest_window(self):
        connection=MagicMock()
        q=connection.cursor.return_value
        q.fetchone.side_effect=[(60001,),(123,),(None,),
                                (60000,'2026-09-24:0482','2026-11-05:0001')]
        q.fetchall.return_value=[('2026-09-24:0481',)]
        manager=MagicMock()
        manager.__enter__.return_value=connection
        with patch('god8_flow.DB',return_value=manager), patch('god8_flow.set_meta') as state:
            self.assertEqual(prune_old_periods(),1)
        commands=[(args[0][0],args[0][1] if len(args[0])>1 else ())
                  for args in q.execute.call_args_list]
        self.assertIn(('DELETE FROM periods WHERE period_key=ANY(%s)', (['2026-09-24:0481'],)),commands)
        self.assertIn(('DELETE FROM raw_blocks WHERE block_number<%s',(104,)),commands)
        self.assertEqual(state.call_args[0][1]['retainedPeriods'],60000)


if __name__ == '__main__':
    unittest.main()
