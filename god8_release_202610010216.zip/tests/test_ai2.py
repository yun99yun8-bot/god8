import os
import sys
import unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from ai2_worker import features, simulate, predict
from web import daily_omission_stats


class AI2Research(unittest.TestCase):
    def test_balls_and_target_are_separate(self):
        numbers=[1,2,7,8,12,13,18]
        a=features(numbers,2026)
        self.assertEqual(a['wave_mix'],(7,0))
        self.assertEqual(a['odd_even'][0],3)
        self.assertEqual(features(numbers,2027)['wave_mix'],a['wave_mix'])
        self.assertNotEqual(features(numbers,2027)['domestic_wild'],a['domestic_wild'])

    def test_walk_forward_signal_and_frozen_future_model(self):
        red=[1,2,7,8,12,13,18];blue=[3,4,9,10,14,15,20]
        records=[(f'2026-09-27:{i:04d}',2 if i%2 else 6,red if i%2 else blue)
                 for i in range(2200)]
        metrics,artifact=simulate(records,'wave_mix')
        self.assertGreater(metrics['holdout']['accuracy'],.9)
        self.assertEqual(predict(artifact,red,2026),2)
        self.assertEqual(predict(artifact,blue,2026),6)

    def test_daily_longest_run_includes_first_and_active_intervals(self):
        rows=[(f'2026-09-27:{i:04d}','2026-09-27',i,k)
              for i,k in enumerate([1,2,1,2,2,1],1)]
        report=daily_omission_stats(rows,'2026-09-27')
        self.assertTrue(report['complete'])
        self.assertEqual(report['items'][1]['longest']['length'],2)
        self.assertEqual(report['items'][0]['longest']['length'],6)
        self.assertTrue(report['items'][0]['longest']['active'])
        self.assertEqual(report['items'][1]['count'],3)

if __name__=='__main__':unittest.main()
