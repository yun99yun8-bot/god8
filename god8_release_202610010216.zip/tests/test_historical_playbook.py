import os
import sys
import unittest
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from historical_playbook import summarize
from web import app
import worker_ai


class HistoricalPlaybookTests(unittest.TestCase):
    def setUp(self):
        self.draws = [
            ('2026-09-27:0003', [1, 2, 3, 4, 5, 6, 7], 4),
            ('2026-09-27:0002', [8, 9, 10, 11, 12, 13, 14], 3),
            ('2026-09-27:0001', [15, 16, 17, 18, 19, 20, 21], 4),
        ]

    def test_history_modes_and_intersection_use_same_ball(self):
        special=summarize(self.draws,'special','wave','红波')
        self.assertEqual(special['hits'],1)
        self.assertEqual(special['currentGap'],0)
        self.assertEqual(special['valid'],3)
        combo=summarize(self.draws,'all','wave','红波',parity='双',size='小')
        self.assertEqual(combo['hits'],3)
        self.assertTrue(all(n % 2 == 0 and n <= 24 for n in combo['matchingNumbers']))
        singles=summarize(self.draws,'single','single','3')
        self.assertEqual(singles['hits'],1)
        self.assertEqual(singles['currentGap'],1)

    def test_missing_or_invalid_period_prevents_trusted_omission(self):
        missing=self.draws[:1]+self.draws[2:]
        result=summarize(missing,'special','number','49')
        self.assertIsNone(result['currentGap'])
        self.assertEqual(result['valid'],2)
        broken=[self.draws[0],('2026-09-27:0002',None,None),self.draws[2]]
        result=summarize(broken,'single','single','7')
        self.assertEqual(result['invalid'],1)
        self.assertIsNone(result['currentGap'])

    def test_endpoints_and_page_separation(self):
        client=app.test_client()
        home=client.get('/').get_data(as_text=True)
        history=client.get('/history').get_data(as_text=True)
        stats=client.get('/statistics').get_data(as_text=True)
        self.assertNotIn('streakFeedback',home)
        self.assertIn('homeOmission',home)
        self.assertIn('/statistics#omission',home)
        self.assertNotIn('retainedOmissionRows',history)
        self.assertIn('retainedOmissionRows',stats)
        self.assertIn('playbookForm',client.get('/playbook').get_data(as_text=True))
        self.assertEqual(client.get('/api/playbook?mode=single&kind=wave&value=红波').status_code,400)
        with patch('web.rows',return_value=self.draws):
            response=client.get('/api/playbook?mode=single&kind=single&value=3&window=30')
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.get_json()['hits'],1)
        self.assertEqual(client.get('/api/official-prediction').get_json()['active'],False)
        self.assertEqual(client.post('/api/adopt/1').status_code,410)

    def test_worker_starts_backfill_and_audit_without_ai_training(self):
        connection=MagicMock()
        connection.cursor.return_value.fetchone.return_value=(True,)
        pool=MagicMock()
        pool.getconn.return_value=connection
        with patch.object(worker_ai,'init_db'), patch.object(worker_ai,'pool',return_value=pool), \
             patch.object(worker_ai.threading,'Thread') as threads, \
             patch.object(worker_ai,'set_meta') as heartbeat, \
             patch.object(worker_ai.time,'sleep',side_effect=RuntimeError('stop test')):
            with self.assertRaisesRegex(RuntimeError,'stop test'):
                worker_ai.main()
        self.assertEqual([call.kwargs['name'] for call in threads.call_args_list],
                         ['god8-forward','god8-stage-audit'])
        self.assertEqual(heartbeat.call_args.args[0],'god8_worker_heartbeat')


if __name__ == '__main__':
    unittest.main()
