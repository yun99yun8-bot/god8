import os,sys,unittest
sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))
from core import pindex,from_index,target_block

class TailTransitionV2045(unittest.TestCase):
    def test_temporary_three_window_ends_at_0046(self):
        for idx in range(pindex('2026-09-30',1300),pindex('2026-10-01',46)+1):
            ds,no=from_index(idx)
            self.assertEqual(target_block(ds,no)%10,3,(ds,no))
        self.assertEqual(target_block('2026-10-01',46),86704733)

    def test_0047_resumes_two_tail_exactly(self):
        self.assertEqual(target_block('2026-10-01',47),86704752)
        self.assertEqual(target_block('2026-10-01',48),86704772)
        for idx in range(pindex('2026-10-01',47),pindex('2026-10-01',120)+1):
            ds,no=from_index(idx)
            self.assertEqual(target_block(ds,no)%10,2,(ds,no))

    def test_original_zero_boundary_remains(self):
        self.assertEqual(target_block('2026-10-01',120),86706212)
        self.assertEqual(target_block('2026-10-01',121),86706230)
        self.assertEqual(target_block('2026-10-01',121)%10,0)
        self.assertEqual(target_block('2026-10-01',481)%10,8)

    def test_transition_step_sizes_match_platform(self):
        self.assertEqual(target_block('2026-10-01',47)-target_block('2026-10-01',46),19)
        self.assertEqual(target_block('2026-10-01',48)-target_block('2026-10-01',47),20)
        self.assertEqual(target_block('2026-10-01',121)-target_block('2026-10-01',120),18)

if __name__=='__main__':unittest.main()
