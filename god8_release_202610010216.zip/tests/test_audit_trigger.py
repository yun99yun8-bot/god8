import os
import sys
import unittest
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from audit_service import verify_forever
from backfill_worker import reconcile_first_stage
from core import ANCHOR_INDEX


class StopAfterOnePass(Exception):
    pass


class AuditTriggerTests(unittest.TestCase):
    def test_completed_cursor_replays_when_first_stage_rows_are_missing(self):
        connection = MagicMock()
        connection.cursor.return_value.fetchone.return_value = (0,)
        manager = MagicMock()
        manager.__enter__.return_value = connection
        with patch('backfill_worker.DB', return_value=manager), \
             patch('backfill_worker.get_meta', return_value={}), \
             patch('backfill_worker.set_meta') as save:
            self.assertEqual(reconcile_first_stage(ANCHOR_INDEX, ANCHOR_INDEX+9999), ANCHOR_INDEX-1)
        self.assertIn('replaying-missing-first-stage',
                      [call.args[1].get('status') for call in save.call_args_list])

    def test_newer_oldest_live_period_is_not_evidence_of_60000_prune(self):
        connection = MagicMock()
        connection.cursor.return_value.fetchone.return_value = (0,)
        manager = MagicMock()
        manager.__enter__.return_value = connection
        with patch('backfill_worker.DB', return_value=manager), \
             patch('backfill_worker.get_meta', return_value={
                 'oldest':'2026-09-26:0968','retainedPeriods':745}), \
             patch('backfill_worker.set_meta') as save:
            self.assertEqual(reconcile_first_stage(1065425367, 1065425367+10744),
                             1065425366)
        self.assertIn('replaying-missing-first-stage',
                      [call.args[1].get('status') for call in save.call_args_list])

    def test_complete_first_stage_does_not_replay(self):
        connection = MagicMock()
        connection.cursor.return_value.fetchone.return_value = (10000,)
        manager = MagicMock()
        manager.__enter__.return_value = connection
        with patch('backfill_worker.DB', return_value=manager), \
             patch('backfill_worker.set_meta') as save:
            self.assertEqual(reconcile_first_stage(ANCHOR_INDEX, ANCHOR_INDEX+9999), ANCHOR_INDEX+9999)
        save.assert_not_called()

    def test_full_forward_stage_triggers_audit_without_completed_marker(self):
        connection = MagicMock()
        connection.cursor.return_value.fetchall.return_value = []
        manager = MagicMock()
        manager.__enter__.return_value = connection

        def state(name, default=None):
            return {'god8_forward': {'completedSinceOrigin': 10000},
                    'god8_completed_stages': {}}.get(name, default)

        with patch('audit_service.origin_index', return_value=100), \
             patch('audit_service.get_meta', side_effect=state), \
             patch('audit_service.DB', return_value=manager), \
             patch('audit_service.stage_window', return_value=(100, 10099)), \
             patch('audit_service.stage_rows', return_value=[None]*10000), \
             patch('audit_service.stage_fingerprint', return_value='fingerprint'), \
             patch('audit_service.run_audit', return_value={
                 'pass': True, 'checkedPeriods': 10000, 'errors': 0}) as audit, \
             patch('audit_service.set_meta'), \
             patch('audit_service.time.sleep', side_effect=StopAfterOnePass):
            with self.assertRaises(StopAfterOnePass):
                verify_forever()
        audit.assert_called_once_with(False, 100, 10099)


if __name__ == '__main__':
    unittest.main()
