import os,sys,unittest
sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))

from core import from_index,pindex
from pattern_research import pattern_report,replay_guess,replay_simulation


def rows(values):
    start=pindex('2026-09-27',1)
    return [(f'{day}:{no:04d}',value) for day,no,value in
            ((*(from_index(start+i)),v) for i,v in enumerate(values))]


class PatternReplayTests(unittest.TestCase):
    def test_full_user_prefix_is_replayed_without_pretending_one_match_is_certain(self):
        pattern=[int(c) for c in '434343462555']
        history=rows((pattern+[4,0])*7+pattern)
        report=pattern_report(history)
        self.assertEqual(report['exact']['length'],12)
        self.assertEqual(report['exact']['counts'][4],7)
        self.assertEqual(report['supported']['length'],12)
        self.assertEqual(replay_guess([value for _,value in history]),4)

    def test_one_matching_episode_is_insufficient_to_pick_single_one(self):
        pattern=[int(c) for c in '434343462555']
        values=pattern+[1,0]+pattern
        result=pattern_report(rows(values))
        self.assertEqual(result['exact']['samples'],1)
        self.assertIsNone(result['supported'])

    def test_next_result_cannot_train_its_own_prediction(self):
        values=[3]*1000+[6,6,6,6]
        keys=[pindex('2026-09-27',1)+i for i in range(len(values))]
        first=next(replay_simulation(values,keys,5000))
        values[-4]=0
        second=next(replay_simulation(values,keys,5000))
        self.assertEqual(first,second)

    def test_missing_round_does_not_join_sequences_or_omission_episodes(self):
        entries=[('2026-09-27:0001',1),('2026-09-27:0002',3),
                 ('2026-09-27:0004',3),('2026-09-27:0005',3)]
        result=pattern_report(entries)
        self.assertEqual(result['omissions'][1]['currentGap'],None)
        self.assertIsNone(result['supported'])

    def test_incremental_backtest_matches_online_replay(self):
        values=([3,4,3,4,6,2,5,5,5,4,0]*103)[:1130]
        index=[pindex('2026-09-27',1)+i for i in range(len(values))]
        generated=replay_simulation(values,index,5000)
        for i in range(1000,1100):
            self.assertEqual(next(generated),replay_guess(values[:i],index[:i],5000))

    def test_incremental_window_boundary_matches_online_replay(self):
        values=([3,4,3,4,6,2,5,5,5,4,0]*480)[:5200]
        index=[pindex('2026-09-27',1)+i for i in range(len(values))]
        generated=replay_simulation(values,index,5000)
        for i in range(1000,5110):
            actual=next(generated)
            if i in (4999,5000,5001,5109):
                self.assertEqual(actual,replay_guess(values[:i],index[:i],5000))


if __name__=='__main__':unittest.main()
