"""Canonical history read layer shared by UI statistics and live forecasting.

A formal ``periods`` row can temporarily lag a platform mapping correction.  The
immutable raw block at ``target_block(period)`` is therefore authoritative for
recent/affected data.  Missing formal rows are also materialized virtually from
raw_blocks for already-completed periods, so omission counters never lag simply
because the formal writer is still catching up.
"""
from core import DB, from_index, get_meta, pindex, target_block
from god8_flow import first_complete_index

VERIFY_START = pindex('2026-09-30', 1300)
VERIFY_END = pindex('2026-10-01', 1440)


def _index(period_key):
    ds, no = period_key.split(':', 1)
    return pindex(ds, int(no))


def _expected(period_key):
    ds, no = period_key.split(':', 1)
    return target_block(ds, int(no))


def _latest_complete_index():
    candidates=[]
    chain=(get_meta('chain_head',{}) or {}).get('block')
    fast=(get_meta('fast_target_latest',{}) or {}).get('targetBlock')
    for value in (chain,fast):
        try:
            if value is not None:candidates.append(int(value))
        except (TypeError,ValueError):
            pass
    if not candidates:
        return None
    head=max(candidates)
    idx=first_complete_index(head+1)-1
    while target_block(*from_index(idx))>head:
        idx-=1
    return idx


def _raw_parts(row):
    # block_number, block_hash, numbers, single_count[, fetched_at]
    fetched=row[4] if len(row)>4 else None
    return int(row[0]),row[1],row[2],row[3],fetched


def canonicalize(formal_rows, raw_rows):
    """Overlay formal rows with immutable canonical raw outcomes.

    Formal shape:
      (period_key, period_date_text, period_no, target_block, block_hash,
       numbers, single_count, created_at)
    Returned shape is the same logical data plus ``canonical_ok`` at index 8.

    Within the known transition window, raw verification is mandatory.  If raw
    is absent we return an unavailable result instead of leaking an old payload.
    """
    raw={_raw_parts(r)[0]:_raw_parts(r) for r in raw_rows}
    output=[]
    for row in formal_rows:
        key,ds,no,stored_target,stored_hash,stored_numbers,stored_single,created=row
        expected=_expected(key);idx=_index(key)
        verify=VERIFY_START<=idx<=VERIFY_END or int(stored_target)!=int(expected)
        rr=raw.get(int(expected))
        if rr is not None and (verify or stored_hash is None):
            _,block_hash,numbers,single,fetched=rr
            output.append((key,ds,int(no),int(expected),block_hash,numbers,single,
                           fetched or created,True))
            continue
        if verify:
            # Mandatory verification failed: never count a potentially stale
            # formal result in omissions, statistics or prediction inputs.
            output.append((key,ds,int(no),int(expected),None,None,None,created,False))
            continue
        ok=int(stored_target)==int(expected) and stored_hash is not None
        output.append((key,ds,int(no),int(stored_target),stored_hash,stored_numbers,
                       stored_single,created,ok))
    return output


def _fetch(formal_sql,args,extra_specs=()):
    """Fetch formal rows plus optional synthetic period specs.

    ``extra_specs`` entries are (key, ds, no, expected_target).  They are added
    only when the formal row is absent and are resolved from raw_blocks.
    """
    with DB() as conn:
        q=conn.cursor();q.execute(formal_sql,args);formal=list(q.fetchall())
        by_key={r[0]:r for r in formal}
        for key,ds,no,expected in extra_specs:
            if key not in by_key:
                placeholder=(key,ds,int(no),int(expected),None,None,None,None)
                formal.append(placeholder);by_key[key]=placeholder
        targets=set()
        for row in formal:
            expected=_expected(row[0]);idx=_index(row[0])
            if VERIFY_START<=idx<=VERIFY_END or int(row[3])!=int(expected) or row[4] is None:
                targets.add(int(expected))
        if targets:
            q.execute('''SELECT block_number,block_hash,numbers,single_count,fetched_at
                         FROM raw_blocks WHERE block_number=ANY(%s)''',(list(targets),))
            raw=q.fetchall()
        else:raw=[]
        q.close()
    return canonicalize(formal,raw)


def _recent(limit):
    latest=_latest_complete_index()
    if latest is None:return []
    indices=list(range(latest,latest-int(limit),-1))
    specs=[]
    for idx in indices:
        ds,no=from_index(idx);key=f'{ds}:{no:04d}'
        specs.append((key,ds,no,target_block(ds,no)))
    keys=[x[0] for x in specs]
    if not keys:return []
    placeholders=','.join(['%s']*len(keys))
    # ANY works with psycopg2 lists and keeps the query compact even at 10k rows.
    sql='''SELECT period_key,period_date::text,period_no,target_block,block_hash,
                  numbers,single_count,created_at FROM periods
           WHERE period_key=ANY(%s)'''
    merged=_fetch(sql,(keys,),specs)
    by_key={r[0]:r for r in merged}
    # Keep only rows with some evidence (raw or formal).  A not-yet-captured
    # target at the chain edge must not become a fake completed result.
    return [by_key[k] for k in keys if k in by_key and
            (by_key[k][4] is not None or by_key[k][7] is not None)]


def _day(day):
    latest=_latest_complete_index()
    if latest is None:
        latest_no=0
    else:
        latest_day,latest_no=from_index(latest)
        if day<latest_day:latest_no=1440
        elif day>latest_day:latest_no=0
    specs=[]
    for no in range(1,int(latest_no)+1):
        key=f'{day}:{no:04d}';specs.append((key,day,no,target_block(day,no)))
    sql='''SELECT period_key,period_date::text,period_no,target_block,block_hash,
                  numbers,single_count,created_at FROM periods
           WHERE period_date=%s'''
    merged=_fetch(sql,(day,),specs)
    by_key={r[0]:r for r in merged}
    # Return every completed issue position. Missing canonical raw data remains
    # as single=None/canonical_ok=False so daily omission reports a true gap.
    return [by_key[f'{day}:{no:04d}'] for no in range(1,int(latest_no)+1)
            if f'{day}:{no:04d}' in by_key]


def load(limit=None,newest_first=False,day=None):
    """Load canonical history.

    * ``day``: complete chain-finished issue sequence for that date.
    * ``newest_first`` + ``limit``: exact newest completed issue identities,
      including raw-only periods not yet materialized in ``periods``.
    * otherwise: retained formal history plus any missing completed rows in the
      bounded Sep30/Oct1 correction window.
    """
    if day is not None:
        rows=_day(str(day))
        return list(reversed(rows)) if newest_first else rows
    if newest_first and limit is not None:
        return _recent(max(1,int(limit)))

    latest=_latest_complete_index()
    extra=[]
    if latest is not None:
        end=min(int(latest),VERIFY_END)
        if end>=VERIFY_START:
            for idx in range(VERIFY_START,end+1):
                ds,no=from_index(idx);key=f'{ds}:{no:04d}'
                extra.append((key,ds,no,target_block(ds,no)))
    order='DESC' if newest_first else 'ASC'
    sql=f'''SELECT period_key,period_date::text,period_no,target_block,block_hash,
                   numbers,single_count,created_at FROM periods
            ORDER BY period_date {order},period_no {order}'''
    merged=_fetch(sql,(),extra)
    merged.sort(key=lambda r:_index(r[0]),reverse=newest_first)
    if limit is not None:merged=merged[:max(1,int(limit))]
    return merged


def as_pairs(rows):return [(r[0],r[6]) for r in rows]
def as_analysis(rows):return [(r[0],r[6],r[5]) for r in rows]

def quality(rows):
    return {'rows':len(rows),'canonical':sum(bool(r[8]) for r in rows),
            'pendingCanonical':sum(not bool(r[8]) for r in rows),
            'invalid':sum(r[6] is None for r in rows),
            'source':'canonical-target-overlay'}
