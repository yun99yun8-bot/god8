"""Descriptive single-count frequencies for a selected saved target-block tail."""
from core import pindex


def analyze_tail(rows, tail):
    """Rows are (period_key, single_count, target_block) in chronological order.

    A tail's omission run never crosses a gap in issue numbers, a void draw,
    or a transition to another tail. Completed runs are not left-censored.
    """
    if type(tail) is not int or tail not in range(10):
        raise ValueError('区块尾数须为0至9')
    rows=list(rows)
    if any(int(block)%10 != tail for _,_,block in rows):
        raise ValueError('历史记录与所选区块尾数不符')
    counts=[0]*8
    gaps=[0]*8
    seen=[False]*8
    runs=[[] for _ in range(8)]
    valid=invalid=0
    previous=None
    last_issue=None
    for key, single, _ in rows:
        ds,no=key.split(':',1)
        idx=pindex(ds,int(no))
        if previous is not None and idx!=previous+1:
            seen=[False]*8
            gaps=[0]*8
        previous=idx
        if type(single) is not int or single not in range(8):
            invalid+=1
            seen=[False]*8
            gaps=[0]*8
            continue
        valid+=1
        last_issue=key
        counts[single]+=1
        for label in range(8):
            if label==single:
                if seen[label]:
                    runs[label].append(gaps[label])
                seen[label]=True
                gaps[label]=0
            elif seen[label]:
                gaps[label]+=1
    items=[]
    for label in range(8):
        gap=gaps[label] if seen[label] else None
        completed=runs[label]
        reached=(sum(n>=gap for n in completed)/len(completed)
                 if gap is not None and gap>0 and len(completed)>=10 else None)
        items.append({'single':label,'hits':counts[label],
                      'hitRate':counts[label]/valid if valid else None,
                      'missRate':1-counts[label]/valid if valid else None,
                      'gap':gap,'completedRuns':len(completed),
                      'historicalGapReachRate':reached})
    return {'tail':tail,'stored':len(rows),'valid':valid,'invalid':invalid,
            'lastIssue':last_issue,'items':items,
            'note':('按已入库的目标区块尾数分组，开出率=该尾中出现次数/有效期数，'
                    '未出率=1-开出率。遗漏仅在连续同尾期内累加；切尾、缺期、无效结果即中断。'
                    '历史达到当前遗漏比例只使用已结束的遗漏段，少于10段不展示。'
                    '这些是历史描述，不是下期概率或投注保证。')}


def analyze_blocks(rows, tail):
    """Summarize actual saved raw blocks, not generated lottery periods.

    Rows are (block_number, single_count), ascending. Consecutive observations
    of a given decimal tail differ by 10 block heights; missing raw heights
    and invalid hashes break an omission run rather than silently bridging it.
    """
    if type(tail) is not int or tail not in range(10):
        raise ValueError('区块尾数须为0至9')
    rows=list(rows)
    if any(type(block) is not int or block%10!=tail for block,_ in rows):
        raise ValueError('原始区块与所选尾数不符')
    counts=[0]*8
    gaps=[0]*8
    seen=[False]*8
    runs=[[] for _ in range(8)]
    valid=invalid=0
    previous=None
    for block,single in rows:
        if previous is not None and block!=previous+10:
            seen=[False]*8
            gaps=[0]*8
        previous=block
        if type(single) is not int or single not in range(8):
            invalid+=1
            seen=[False]*8
            gaps=[0]*8
            continue
        valid+=1
        counts[single]+=1
        for label in range(8):
            if single==label:
                if seen[label]:runs[label].append(gaps[label])
                seen[label]=True
                gaps[label]=0
            elif seen[label]:
                gaps[label]+=1
    items=[]
    for label in range(8):
        gap=gaps[label] if seen[label] else None
        completed=runs[label]
        reached=(sum(length>=gap for length in completed)/len(completed)
                 if gap is not None and gap>0 and len(completed)>=10 else None)
        items.append({'single':label,'hits':counts[label],
                      'hitRate':counts[label]/valid if valid else None,
                      'missRate':1-counts[label]/valid if valid else None,
                      'gap':gap,'completedRuns':len(completed),
                      'historicalGapReachRate':reached})
    return {'tail':tail,'stored':len(rows),'valid':valid,'invalid':invalid,
            'lastBlock':rows[-1][0] if rows else None,'items':items,
            'note':('统计最近最多10000个已保存的同尾原始区块，不是10000期开奖期。'
                    '单几由该区块哈希的七个号码计算；开出率=出现次数/有效区块数，未出率=1-开出率。'
                    '同尾区块高度不连续或哈希无效时中断遗漏；少于10段的历史遗漏比例不展示。'
                    '原始区块统计不能当成下一期开奖预测。')}
