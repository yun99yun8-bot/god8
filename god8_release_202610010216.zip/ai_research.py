"""Time-ordered research: every historical guess sees at most 1,000 prior rows."""
from collections import Counter, defaultdict
from math import sqrt
from streak_research import issue_index, states as streak_states
from pattern_research import replay_guess, replay_simulation

TRAIN_START = 1000
VALIDATION_START = 7000
HOLDOUT_START = 8500
SEARCH_CONTEXTS = {
    'probe_g17_last_350': (350, ('g17_single','last')),
    'probe_g17_last_1000': (1000, ('g17_single','last')),
    'probe_g17_gap16_1000': (1000, ('g17_single','gap16band')),
    'probe_g17_gap16_5000': (5000, ('g17_single','gap16band')),
    'probe_g17_run34_1000': (1000, ('g17_single','run34band')),
    'probe_g17_run34_5000': (5000, ('g17_single','run34band')),
    'probe_g17_gap25_1000': (1000, ('g17_single','gap25band')),
    'probe_g17_gap25_5000': (5000, ('g17_single','gap25band')),
    'probe_g17_mode20_1000': (1000, ('g17_single','mode20')),
    'probe_g17_g16_1000': (1000, ('g17_single','g16')),
    'probe_g17_g13_1000': (1000, ('g17_single','g13')),
    'probe_tail8_last_1000': (1000, ('g17_tail8','last')),
}
BASE_METHODS = ('fixed_3', 'fixed_4', 'frequency_25', 'frequency_50',
           'frequency_75', 'frequency_200', 'frequency_350', 'frequency_750',
           'frequency_1000', 'transition_1', 'transition_2',
           'g1_single', 'g5_single', 'g9_single', 'g13_single', 'g16_single',
           'g17_single', 'g17_hash_tail', 'g17_hash_tail8',
           'g17_hash_tail32', 'g17_hash_shape', 'previous_hash_tail',
           'omission_state', 'combined_g17_history', 'combined_group_positions',
           'tier_g17_100', 'tier_g17_350', 'tier_g17_1000',
           'tier_transition_350', 'tier_omission_350', 'tier_groups_1000',
           'regime_34_1000', 'regime_34_5000', 'regime_25_5000',
           'regime_chain_5000')
REPLAY_METHODS=('sequence_suffix_5000','sequence_suffix_10000')
METHODS = BASE_METHODS + tuple(SEARCH_CONTEXTS) + REPLAY_METHODS
REVISION = 'god8-v1.9-historical-replay'


def bucket(hash_value):
    try:
        return int(str(hash_value)[-2:], 16) % 16
    except (TypeError, ValueError):
        return -1


def wilson(hits, total, z=1.96):
    if total <= 0:
        return 0.0
    p = hits / total
    k = 1 + z*z/total
    return max(0., (p + z*z/(2*total) - z*sqrt((p*(1-p)+z*z/(4*total))/total))/k)


def feature_rows(rows):
    """Rows are (period_key, actual, target_hash, g17_hash, g17_single)."""
    labels = []
    seen = {}
    features = []
    streaks,_ = streak_states([(r[0],r[1]) for r in rows])
    for i, row in enumerate(rows):
        _, actual, prev_target_hash, g17, g17_single = row[:5]
        extra = rows[i][5] if len(rows[i])>5 else {}
        recent = labels[-1000:]
        mode20 = Counter(recent[-20:]).most_common(1)
        gaps = {k: min(1000, i-seen[k]-1) if k in seen else min(1000, i)
                for k in range(8)}
        overdue = max(range(8), key=lambda x: (gaps[x], -x))
        features.append({'last': labels[-1] if labels else -1,
                         'pair': tuple(labels[-2:]) if len(labels)>1 else (),
                         'mode20': mode20[0][0] if mode20 else -1,
                         'overdue': overdue,
                         'g17_single': int(g17_single) if g17_single is not None else -1,
                         'g17_tail': bucket(g17),
                         'g17_tail32': (int(str(g17)[-2:],16)%32 if g17 else -1),
                         'g17_shape': str(g17).upper().count('A') // 5 if g17 else -1,
                         'prev_hash_tail': bucket(rows[i-1][2]) if i else -1})
        features[-1].update({f'g{position}':int(extra[position]) if extra.get(position) is not None else -1
                             for position in (1,5,9,13,16)})
        features[-1].update(streaks[i])
        labels.append(int(actual))
        seen[int(actual)] = i
    return features


def method_key(method, features):
    x = features
    if method in SEARCH_CONTEXTS:
        _,fields=SEARCH_CONTEXTS[method]
        def value(name):
            if name=='gap16band': return min(3,x['gap16']//10)
            if name=='run34band': return min(3,x['run34']//10)
            if name=='gap25band': return min(3,x['gap25']//15)
            if name=='g17_tail8': return x['g17_tail']%8 if x['g17_tail']>=0 else -1
            return x[name]
        return ('probe',method)+tuple(value(name) for name in fields)
    if method.startswith('regime_34_'):
        return ('regime34', min(2,x['run34']//10), x['gap16']>=15)
    if method == 'regime_25_5000':
        return ('regime25', min(2,x['gap25']//15), x['gap16']>=15)
    if method == 'regime_chain_5000':
        return ('regimechain', x['run34']>=10, x['gap25']>=15,
                x['gap16']>=15, x['gap07']>=30)
    if method.startswith('tier_g17_'): return ('tier17', x['g17_single'])
    if method == 'tier_transition_350': return ('tierlast', x['last'])
    if method == 'tier_omission_350': return ('tiergap', x['overdue'])
    if method == 'tier_groups_1000':
        return ('tiergroups', x['g13'], x['g16'], x['g17_single'])
    if method == 'transition_1': return ('t1', x['last'])
    if method == 'transition_2': return ('t2', x['pair'])
    if method == 'g17_single': return ('g17', x['g17_single'])
    if method == 'g17_hash_tail': return ('hash17', x['g17_tail'])
    if method == 'g17_hash_tail8': return ('hash17_8', x['g17_tail']%8)
    if method == 'g17_hash_tail32': return ('hash17_32', x['g17_tail32'])
    if method == 'g17_hash_shape': return ('shape', x['g17_shape'])
    if method == 'previous_hash_tail': return ('hash_prev', x['prev_hash_tail'])
    if method == 'omission_state': return ('gap', x['overdue'])
    if method == 'combined_g17_history':
        return ('combined', x['g17_single'], x['last'], x['g17_tail'])
    if method == 'combined_group_positions':
        return ('positions', x['g1'],x['g5'],x['g9'],x['g13'],x['g16'],x['g17_single'])
    if method.startswith('g') and method.endswith('_single'):
        return ('group', method, x[method.split('_')[0]])
    return ('freq',)


def phase_at(i,total=10000):
    validation=max(VALIDATION_START,total-3000)
    holdout=max(HOLDOUT_START,total-1500)
    if i < validation: return 'training'
    if i < holdout: return 'validation'
    return 'holdout'


def best(counter):
    return max(range(8), key=lambda n:(counter[n], -n))


def tier_pick(signal, baseline):
    """Shrink conditional lift toward the 8-class prior; no forced rare picks."""
    support = sum(signal.values())
    n = sum(baseline.values())
    if support < 18 or n < 50:
        return best(baseline)
    # Subtract the expected baseline rate. This rewards context-specific
    # evidence instead of predicting 3/4 solely because they are frequent.
    return max(range(8), key=lambda k: (
        (signal[k] - support * (baseline[k] + 1) / (n + 8)) / (support + 40),
        signal[k] / support, -k))


def simulate(rows, method, on_batch=None):
    if method not in METHODS:
        raise ValueError('unknown method')
    labels = [int(r[1]) for r in rows]
    feats = feature_rows(rows)
    keys = [repr(method_key(method, x)) for x in feats]
    chronology=[issue_index(r[0]) for r in rows]
    replay=replay_simulation(labels,chronology,int(method.rsplit('_',1)[-1])) if method in REPLAY_METHODS else None
    counts = Counter()
    by_key = defaultdict(Counter)
    window = 5000 if method.endswith('_5000') else 1000
    for j in range(min(TRAIN_START,len(rows))):
        counts[labels[j]] += 1
        by_key[keys[j]][labels[j]] += 1
    tier_span=(SEARCH_CONTEXTS[method][0] if method in SEARCH_CONTEXTS else
               int(method.rsplit('_',1)[-1]) if method.startswith(('tier_','regime_')) else 0)
    tier_counts=Counter()
    tier_by_key=defaultdict(Counter)
    if tier_span:
        for j in range(max(0,TRAIN_START-tier_span),min(TRAIN_START,len(rows))):
            tier_counts[labels[j]]+=1
            tier_by_key[keys[j]][labels[j]]+=1
    metrics = {phase: {'hits':0,'predictions':0} for phase in ('training','validation','holdout')}
    batch = []
    for i in range(TRAIN_START,len(rows)):
        if replay is not None:guess=next(replay)
        elif method == 'fixed_3': guess = 3
        elif method == 'fixed_4': guess = 4
        elif method.startswith('frequency_'):
            length = int(method.split('_')[1])
            guess = best(Counter(labels[max(0,i-length):i]))
        elif method.startswith(('tier_','regime_')) or method in SEARCH_CONTEXTS:
            guess = tier_pick(tier_by_key[keys[i]],tier_counts)
        else:
            signal = by_key[keys[i]]
            guess = best(signal) if sum(signal.values()) >= 25 else best(counts)
        phase = phase_at(i,len(rows))
        score = metrics[phase]
        score['predictions'] += 1
        score['hits'] += int(guess == labels[i])
        batch.append((method, rows[i][0], phase, guess, labels[i]))
        if on_batch and len(batch) >= 1000:
            on_batch(batch)
            batch = []
        if i >= window:
            j = i - window
            counts[labels[j]] -= 1
            by_key[keys[j]][labels[j]] -= 1
        counts[labels[i]] += 1
        by_key[keys[i]][labels[i]] += 1
        if tier_span:
            if i >= tier_span:
                old=i-tier_span
                tier_counts[labels[old]]-=1
                tier_by_key[keys[old]][labels[old]]-=1
            tier_counts[labels[i]]+=1
            tier_by_key[keys[i]][labels[i]]+=1
    if on_batch and batch:
        on_batch(batch)
    for score in metrics.values():
        score['accuracy'] = score['hits']/score['predictions'] if score['predictions'] else 0
        score['wilsonLower95'] = wilson(score['hits'],score['predictions'])
    # Only locked training data is used to construct the future model.
    artifact = {'counts': dict(counts),
                'conditional': {k: dict(v) for k,v in by_key.items() if sum(v.values()) >= 25},
                'method': method, 'revision': REVISION}
    if method.startswith(('tier_','regime_')) or method in SEARCH_CONTEXTS:
        span = tier_span
        artifact['tierWindow'] = span
        artifact['tierLabels'] = labels[-span:]
        artifact['tierKeys'] = keys[-span:]
    return metrics, artifact


def predict_future(method, artifact, features, prior_labels, prior_keys=None):
    if method in REPLAY_METHODS:
        chronology=[issue_index(key) for key in prior_keys] if prior_keys is not None else None
        return replay_guess(prior_labels,chronology,int(method.rsplit('_',1)[-1]))
    if method == 'fixed_3': return 3
    if method == 'fixed_4': return 4
    if method.startswith('frequency_'):
        return best(Counter(prior_labels[-int(method.split('_')[1]):]))
    key = repr(method_key(method, features))
    if method.startswith(('tier_','regime_')) or method in SEARCH_CONTEXTS:
        labels = artifact.get('tierLabels', [])
        keys = artifact.get('tierKeys', [])
        signal = Counter(label for label, observed in zip(labels, keys) if observed == key)
        return tier_pick(signal, Counter(labels))
    votes = Counter({int(k):int(v) for k,v in artifact.get('conditional',{}).get(key,{}).items()})
    if sum(votes.values())<25:
        votes = Counter({int(k):int(v) for k,v in artifact['counts'].items()})
    return best(votes)
