"""Independent omission statistics derived from canonical valid draw history.

Missing/invalid periods are reported as data-quality metadata, but they do not pause
or reset omission counters. An omission of N means N *valid stored draw results*
have occurred since the last appearance of that label.
"""
from core import from_index
from streak_research import issue_index

THRESHOLDS=(200,30,10,7,7,10,30,200)


def issue(index):
    day,no=from_index(index)
    return day[2:4]+day[5:7]+day[8:10]+f'{no:04d}'


def _valid(value):
    return value is not None and 0 <= int(value) <= 7


def _quality(rows):
    indexed=[(issue_index(key),value) for key,value in rows]
    missing=sum(max(0,indexed[i][0]-indexed[i-1][0]-1) for i in range(1,len(indexed)))
    invalid=sum(not _valid(value) for _,value in indexed)
    return indexed,missing,invalid


def current_snapshot(rows):
    """Current omission by valid historical draws, independent from audit/upload state."""
    rows=list(rows)
    if not rows:
        return {'values':[0]*8,'lowerBounds':[0]*8,'exact':[False]*8,
                'complete':False,'sourceComplete':False,'sample':0,'valid':0,
                'missing':0,'invalid':0,'firstIssue':None,'lastIssue':None,
                'limit':60000,'scope':'retained-valid-history'}
    indexed,missing,invalid=_quality(rows)
    valid_rows=[(at,int(value)) for at,value in indexed if _valid(value)]
    valid_count=len(valid_rows)
    last=[None]*8
    for pos,(_,label) in enumerate(valid_rows):last[label]=pos
    values=[];exact=[]
    for label in range(8):
        if last[label] is None:
            values.append(valid_count);exact.append(False)
        else:
            values.append(valid_count-1-last[label]);exact.append(True)
    return {'values':values,'lowerBounds':values[:],'exact':exact,
            'complete':valid_count>0,'sourceComplete':missing==0 and invalid==0,
            'sample':len(rows),'valid':valid_count,'missing':missing,'invalid':invalid,
            'firstIssue':issue(indexed[0][0]),'lastIssue':issue(indexed[-1][0]),
            'limit':60000,'scope':'retained-valid-history'}


def retained_stats(rows):
    """Long-term omission over stored valid outcomes; holes never reset the counters."""
    rows=list(rows)
    if not rows:
        return {'scope':'retained-valid-history','sample':0,'valid':0,'missing':0,'invalid':0,
                'complete':False,'sourceComplete':False,'oldestIssue':None,'newestIssue':None,
                'items':[],'missingRanges':[],'invalidIssues':[],'retentionLimit':60000}
    indexed,missing,invalid=_quality(rows)
    missing_ranges=[];invalid_issues=[];previous=None
    for at,value in indexed:
        if previous is not None and at>previous+1 and len(missing_ranges)<8:
            missing_ranges.append({'firstIssue':issue(previous+1),'lastIssue':issue(at-1),
                                   'count':at-previous-1})
        if not _valid(value) and len(invalid_issues)<8:invalid_issues.append(issue(at))
        previous=at

    valid_rows=[(at,int(value)) for at,value in indexed if _valid(value)]
    count=[0]*8;last_pos=[None]*8;last_issue=[None]*8;longest=[None]*8
    for pos,(at,label) in enumerate(valid_rows):
        if last_pos[label] is not None:
            length=pos-last_pos[label]-1
            start_pos=last_pos[label]+1; end_pos=pos-1
            run={'length':length,
                 'startIndex':valid_rows[start_pos][0] if length else at,
                 'endIndex':valid_rows[end_pos][0] if length else at-1,
                 'endedBy':issue(at),'active':False,'exact':True}
            if longest[label] is None or length>longest[label]['length']:longest[label]=run
        count[label]+=1;last_pos[label]=pos;last_issue[label]=issue(at)

    valid_count=len(valid_rows);newest_index=indexed[-1][0]
    items=[]
    for label in range(8):
        if last_pos[label] is None:
            gap=valid_count; exact=False
            start_index=valid_rows[0][0] if valid_rows else newest_index
        else:
            gap=valid_count-1-last_pos[label]; exact=True
            start_index=(valid_rows[last_pos[label]+1][0] if gap else newest_index+1)
        if gap:
            active={'length':gap,'startIndex':start_index,'endIndex':newest_index,
                    'endedBy':None,'active':True,'exact':exact}
            if longest[label] is None or gap>longest[label]['length']:longest[label]=active
        run=longest[label] or {'length':0,'startIndex':newest_index+1,'endIndex':newest_index,
                               'endedBy':None,'active':False,'exact':True}
        level=('超期' if gap>THRESHOLDS[label] else
               '接近' if gap>=THRESHOLDS[label]*.8 else '正常')
        items.append({'single':label,'count':count[label],'gap':gap,'lowerBound':gap,
                      'exact':exact,'lastIssue':last_issue[label],'longest':{
                          'length':run['length'],
                          'startIssue':issue(run['startIndex']) if run['length'] else None,
                          'endIssue':issue(run['endIndex']) if run['length'] else None,
                          'startIndex':run['startIndex'],'endIndex':run['endIndex'],
                          'endedBy':run['endedBy'],'active':run['active'],
                          'exact':run.get('exact',True)},
                      'threshold':THRESHOLDS[label],'level':level})
    return {'scope':'retained-valid-history','sample':len(rows),'valid':valid_count,
            'missing':missing,'invalid':invalid,'complete':valid_count>0,
            'sourceComplete':missing==0 and invalid==0,
            'missingRanges':missing_ranges,'invalidIssues':invalid_issues,
            'oldestIssue':issue(indexed[0][0]),'newestIssue':issue(indexed[-1][0]),
            'retentionLimit':60000,'items':items,
            'note':'按当前期号映射后的规范化有效开奖记录计算；缺失期和无效结果仅单独报告，不会重置或暂停遗漏。'}


def run_page(rows, single, page=1, size=100):
    rows=list(rows);stats=retained_stats(rows)
    if not stats['items']:
        return {'single':single,'length':0,'page':page,'totalPages':0,'rows':[],'counts':[0]*8}
    selection=stats['items'][single]['longest']
    first,last=selection['startIndex'],selection['endIndex']
    by_index={issue_index(key):value for key,value in rows}
    counts=[0]*8
    stored=[]
    for at in range(first,last+1):
        value=by_index.get(at)
        if _valid(value):counts[int(value)]+=1
        stored.append({'issue':issue(at),'single':value,'missing':at not in by_index,
                       'valid':_valid(value)})
    start=(page-1)*size;sequence=stored[start:start+size]
    return {'single':single,'length':selection['length'],'periodSpan':len(stored),
            'page':page,'totalPages':(len(stored)+size-1)//size if stored else 0,
            'rows':sequence,'counts':counts,'complete':True,
            'sourceComplete':stats['sourceComplete'],
            'startIssue':selection['startIssue'],'endIssue':selection['endIssue'],
            'endedBy':selection['endedBy'],'active':selection['active'],
            'sample':stats['sample'],'validSample':stats['valid']}
