import json
import os
import shutil
import subprocess
import unittest


ROOT = os.path.dirname(os.path.dirname(__file__))


@unittest.skipUnless(shutil.which('node'), 'Node.js unavailable')
class SpriteModeTests(unittest.TestCase):
    def test_stop_removes_forecast_but_keeps_observed_practice(self):
        code = r'''
const fs=require('fs'),vm=require('vm');
const source=fs.readFileSync('static/app.js','utf8').split('syncClock().then(tickClock)')[0];
const sandbox={};vm.runInNewContext(source+'\nthis.view=spriteMemoryView;',sandbox);
const report={status:'replay',highFrequency:true,notice:'历史相似片段提示单1/单6高发期',
  practice:{highFrequencyEpisodes:27,preceded07InFour:5},
  replay:{length:4,matchedPositions:4,samples:12,highFrequencyCases:7}};
const views=[sandbox.view(report,false),sandbox.view(report,true),sandbox.view(report,false)];
process.stdout.write(JSON.stringify(views));
'''
        output = subprocess.check_output(['node', '-e', code], cwd=ROOT, text=True)
        idle, started, stopped = json.loads(output)
        self.assertEqual(idle, stopped)
        self.assertEqual(idle['reason'], '')
        self.assertIn('27 段', idle['message'])
        self.assertNotIn('高发期', idle['message'])
        self.assertNotIn('7/12', idle['message'])
        self.assertIn('7/12', started['message'])
        self.assertIn('高发期', started['reason'])

    def test_template_cache_buster_advances_with_release(self):
        with open(os.path.join(ROOT, 'templates/base.html'), encoding='utf8') as source:
            html = source.read()
        self.assertIn('/static/app.js?v=2.0.29', html)
        self.assertIn('/static/app.css?v=2.0.29', html)


if __name__ == '__main__':
    unittest.main()
