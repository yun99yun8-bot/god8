"""Walk-forward adaptive historical prediction.

Every forecast uses only periods that were already known before the target issue.
Exact-sequence replay is never used with fewer than four synchronized periods.
Recent activity, hot/cold drift and omission hazard are auxiliary methods whose
weights are updated from their own already-settled predictions.
"""
from collections import Counter, defaultdict, deque
from math import ceil

from omission_research import issue
from streak_research import issue_index

REPLAY_LENGTHS = (8, 7, 6, 5, 4)
REPLAY_SUPPORT = {8: 3, 7: 3, 6: 4, 5: 5, 4: 6}
METHOD_LABELS = {
    'replay': '四期以上复现',
    'trend': '近期活跃趋势',
    'omission': '遗漏条件',
    'frequency': '长期频数',
}


def _chronological(rows):
    parsed = [(issue_index(key), key, value, numbers) for key, value, numbers in rows]
    parsed.sort(key=lambda row: row[0])
    return parsed


def _valid(value):
    return type(value) is int and 0 <= value <= 7


def _counter_prob(counter, total=None, alpha=0.5):
    total = total if total is not None else sum(counter.values())
    denom = total + alpha * 8
    if denom <= 0:
        return [1 / 8] * 8
    return [(counter[k] + alpha) / denom for k in range(8)]


def _normalize(values):
    clean = [max(0.0, float(v)) for v in values]
    total = sum(clean)
    return [v / total for v in clean] if total else [1 / 8] * 8


def _quantile(values, q):
    if not values:
        return None
    ordered = sorted(values)
    at = min(len(ordered) - 1, max(0, ceil(q * len(ordered)) - 1))
    return ordered[at]


def _replay_method(history, counters, sources, long_prob):
    for length in REPLAY_LENGTHS:
        if len(history) < length:
            continue
        sequence = tuple(history[-length:])
        votes = counters[length].get(sequence, Counter())
        support = sum(votes.values())
        minimum = REPLAY_SUPPORT[length]
        if support < minimum:
            continue
        # More synchronized periods get less shrinkage; short matches must have
        # more repeats before they can influence the forecast.
        prior_strength = max(5.0, 16.0 - length)
        probs = _normalize([(votes[k] + prior_strength * long_prob[k])
                            / (support + prior_strength) for k in range(8)])
        ranked = sorted(range(8), key=lambda k: (-probs[k], -votes[k], k))
        return {
            'name': 'replay', 'scores': probs, 'top': ranked[:2], 'length': length,
            'sequence': list(sequence), 'support': support, 'minimumSupport': minimum,
            'votes': {str(k): votes[k] for k in ranked[:4]},
            'sources': {str(k): sources[length].get((sequence, k), [])[-3:]
                        for k in ranked[:2]},
            'detail': f'{length}期同步 · 历史复现{support}次',
        }
    return None


def _trend_method(recent, long_prob):
    if len(recent) < 20:
        return None
    windows = [20, 50, 100]
    weights = [0.55, 0.30, 0.15]
    weighted = [0.0] * 8
    lifts = [1.0] * 8
    for window, weight in zip(windows, weights):
        sample = list(recent)[-min(window, len(recent)):]
        counts = Counter(sample)
        size = len(sample)
        probs = _counter_prob(counts, size, alpha=0.75)
        for k in range(8):
            weighted[k] += weight * probs[k]
    for k in range(8):
        lifts[k] = weighted[k] / max(long_prob[k], 1e-9)
    # Trend follows meaningful drift but remains partially shrunk to the long-run
    # distribution so a tiny hot streak does not become a fixed 3/4 loop.
    probs = _normalize([0.72 * weighted[k] + 0.28 * long_prob[k] for k in range(8)])
    ranked = sorted(range(8), key=lambda k: (-probs[k], -lifts[k], k))
    hot = [k for k in ranked if lifts[k] >= 1.20][:3]
    cold = [k for k in sorted(range(8), key=lambda k: (lifts[k], k)) if lifts[k] <= 0.82][:3]
    return {
        'name': 'trend', 'scores': probs, 'top': ranked[:2],
        'hot': hot, 'cold': cold,
        'lifts': {str(k): round(lifts[k], 3) for k in range(8)},
        'detail': '最近20/50/100期活跃度对比长期分布',
    }


def _omission_method(gaps, completed_gaps, long_prob):
    scores = []
    info = {}
    enough = False
    for k in range(8):
        gap = int(gaps[k])
        historical = list(completed_gaps[k])
        eligible = [value for value in historical if value >= gap]
        hits = sum(value == gap for value in eligible)
        baseline = long_prob[k]
        support = len(eligible)
        hazard = (hits + 12 * baseline) / (support + 12)
        p90 = _quantile(historical, 0.90)
        ratio = hazard / max(baseline, 1e-9)
        # Only adjust omission meaningfully when there is enough comparable
        # historical evidence. For 3/4, an overdue state that historically did
        # not improve next-period hazard is automatically squeezed down.
        strength = min(1.0, support / 24.0)
        adjusted = baseline * (1.0 + strength * (ratio - 1.0))
        squeeze = False
        boost = False
        if p90 is not None and gap >= p90 and support >= 8:
            if k in (3, 4) and hazard <= baseline * 0.95:
                adjusted *= 0.72
                squeeze = True
            elif hazard >= baseline * 1.15:
                adjusted *= 1.16
                boost = True
        scores.append(max(1e-6, adjusted))
        info[str(k)] = {
            'gap': gap, 'support': support, 'nextRate': round(hazard, 4),
            'baseline': round(baseline, 4), 'p90': p90,
            'squeezed': squeeze, 'boosted': boost,
        }
        enough = enough or support >= 8
    if not enough:
        return None
    probs = _normalize(scores)
    ranked = sorted(range(8), key=lambda k: (-probs[k], k))
    return {
        'name': 'omission', 'scores': probs, 'top': ranked[:2], 'gaps': info,
        'detail': '当前遗漏与历史同等遗漏后的下一期表现',
    }


def _frequency_method(long_prob):
    ranked = sorted(range(8), key=lambda k: (-long_prob[k], k))
    return {
        'name': 'frequency', 'scores': list(long_prob), 'top': ranked[:2],
        'detail': '长期频数仅作低权重基线',
    }


def _method_weight(name, performance, miss_streak):
    outcomes = performance[name]
    n = len(outcomes)
    hits = sum(outcomes)
    # Bayesian shrinkage toward a neutral two-of-eight rate. This keeps a method
    # from taking over because of a handful of lucky results.
    posterior = (hits + 10 * 0.25) / (n + 10)
    weight = 0.70 + 1.35 * (posterior - 0.25)
    if name == 'frequency':
        weight *= 0.62
    if miss_streak[name] >= 3:
        weight *= max(0.58, 0.88 ** (miss_streak[name] - 2))
    return max(0.45, min(1.45, weight)), posterior


def _ensemble(methods, performance, miss_streak):
    if not methods:
        return None
    combined = [0.0] * 8
    diagnostics = []
    for method in methods:
        weight, recent_rate = _method_weight(method['name'], performance, miss_streak)
        for k in range(8):
            combined[k] += weight * method['scores'][k]
        diagnostics.append({
            'name': method['name'], 'label': METHOD_LABELS[method['name']],
            'weight': round(weight, 3), 'recentRate': round(recent_rate, 4),
            'samples': len(performance[method['name']]), 'missStreak': miss_streak[method['name']],
            'top': method['top'], 'detail': method['detail'],
        })
    ranked = sorted(range(8), key=lambda k: (-combined[k], k))
    # Explain each selected label with the methods that actually placed it in
    # their own top two, rather than a generic "high probability" message.
    reasons = {}
    for choice in ranked[:2]:
        items = []
        for method in methods:
            if choice in method['top']:
                items.append(METHOD_LABELS[method['name']])
        reasons[str(choice)] = items
    replay = next((m for m in methods if m['name'] == 'replay'), None)
    trend = next((m for m in methods if m['name'] == 'trend'), None)
    omission = next((m for m in methods if m['name'] == 'omission'), None)
    match = {
        'length': replay['length'] if replay else 0,
        'sequence': replay['sequence'] if replay else [],
        'support': replay['support'] if replay else 0,
        'minimumSupport': replay['minimumSupport'] if replay else REPLAY_SUPPORT[4],
        'votes': replay['votes'] if replay else {},
        'sources': replay['sources'] if replay else {},
        'methods': diagnostics,
        'reasons': reasons,
        'hot': trend.get('hot', []) if trend else [],
        'cold': trend.get('cold', []) if trend else [],
        'omission': omission.get('gaps', {}) if omission else {},
        'scores': {str(k): round(combined[k], 6) for k in ranked[:4]},
    }
    return ranked[:2], match


def simulate(rows, minimum_training=120, recent_limit=30):
    """Strict walk-forward backtest with adaptive method weights."""
    if minimum_training < 1:
        raise ValueError('minimum_training must be positive')
    indexed = _chronological(rows)
    counters = {length: defaultdict(Counter) for length in REPLAY_LENGTHS}
    sources = {length: defaultdict(list) for length in REPLAY_LENGTHS}
    overall = Counter()
    history = []
    recent = deque(maxlen=500)
    gaps = [0] * 8
    completed_gaps = [deque(maxlen=5000) for _ in range(8)]
    performance = {name: deque(maxlen=100) for name in METHOD_LABELS}
    miss_streak = {name: 0 for name in METHOD_LABELS}
    previous = None
    newest = None
    evaluated = skipped = missing = 0
    rank_hits = [0, 0]
    either_hits = 0
    baseline_hits = [0, 0]
    by_method = Counter()
    recent_rows = deque(maxlen=200)
    examples = []

    def methods_now():
        total = sum(overall.values())
        if total < minimum_training:
            return []
        long_prob = _counter_prob(overall, total, alpha=1.0)
        methods = []
        replay = _replay_method(history, counters, sources, long_prob)
        if replay:
            methods.append(replay)
        trend = _trend_method(recent, long_prob)
        if trend:
            methods.append(trend)
        omission = _omission_method(gaps, completed_gaps, long_prob)
        if omission:
            methods.append(omission)
        methods.append(_frequency_method(long_prob))
        return methods

    for at, key, actual, numbers in indexed:
        if previous is not None and at != previous + 1:
            history = []
            recent.clear()
            gaps = [0] * 8
            missing += max(0, at - previous - 1)
        previous = at
        if not _valid(actual):
            history = []
            recent.clear()
            gaps = [0] * 8
            skipped += 1
            continue

        methods = methods_now()
        selected = _ensemble(methods, performance, miss_streak) if methods else None
        if selected:
            choices, match = selected
            total = sum(overall.values())
            baseline = sorted(range(8), key=lambda k: (-overall[k], k))[:2]
            evaluated += 1
            first_hit = actual == choices[0]
            second_hit = actual == choices[1]
            either_hit = actual in choices
            rank_hits[0] += first_hit
            rank_hits[1] += second_hit
            either_hits += either_hit
            baseline_hits[0] += actual == baseline[0]
            baseline_hits[1] += actual in baseline
            recent_rows.append((first_hit, second_hit, either_hit,
                                actual == baseline[0], actual in baseline))
            active_names = []
            for method in methods:
                hit = actual in method['top']
                performance[method['name']].append(hit)
                miss_streak[method['name']] = 0 if hit else miss_streak[method['name']] + 1
                active_names.append(method['name'])
            by_method['+'.join(active_names)] += 1
            record = {
                'issue': issue(at), 'predictions': choices, 'actual': actual,
                'numbers': numbers if isinstance(numbers, list) else None,
                'firstHit': first_hit, 'secondHit': second_hit, 'eitherHit': either_hit,
                'match': match,
            }
            examples.append(record)
            if len(examples) > recent_limit:
                examples.pop(0)

        # Register known successor only after the target has been scored.
        for length in REPLAY_LENGTHS:
            if len(history) >= length:
                context = tuple(history[-length:])
                counters[length][context][actual] += 1
                bucket = sources[length][(context, actual)]
                bucket.append({'issue': issue(at), 'single': actual,
                               'numbers': numbers if isinstance(numbers, list) else None})
                if len(bucket) > 3:
                    bucket.pop(0)
        overall[actual] += 1
        for k in range(8):
            if actual == k:
                completed_gaps[k].append(gaps[k])
                gaps[k] = 0
            else:
                gaps[k] += 1
        history.append(actual)
        if len(history) > max(REPLAY_LENGTHS):
            history.pop(0)
        recent.append(actual)
        newest = at

    preview = None
    methods = methods_now()
    selected = _ensemble(methods, performance, miss_streak) if newest is not None and methods else None
    if selected:
        choices, match = selected
        preview = {
            'issue': issue(newest + 1), 'predictions': choices, 'match': match,
            'note': '至少4期同步才启用复现；同时考虑近期活跃、冷热、遗漏条件与各方法近期实绩。',
        }
    n = len(recent_rows)
    rates = [sum(row[i] for row in recent_rows) / n if n else None for i in range(5)]
    return {
        'stored': len(indexed), 'valid': sum(overall.values()), 'invalid': skipped,
        'missing': missing, 'evaluated': evaluated,
        'first': {'hits': rank_hits[0], 'rate': rank_hits[0] / evaluated if evaluated else None},
        'second': {'hits': rank_hits[1], 'rate': rank_hits[1] / evaluated if evaluated else None},
        'either': {'hits': either_hits, 'rate': either_hits / evaluated if evaluated else None},
        'baseline': {
            'firstHits': baseline_hits[0], 'firstRate': baseline_hits[0] / evaluated if evaluated else None,
            'eitherHits': baseline_hits[1], 'eitherRate': baseline_hits[1] / evaluated if evaluated else None,
        },
        'recent200': {
            'verified': n, 'firstRate': rates[0], 'secondRate': rates[1], 'eitherRate': rates[2],
            'baselineFirstRate': rates[3], 'baselineEitherRate': rates[4],
        },
        'methodCounts': dict(by_method), 'recent': list(reversed(examples)),
        'preview': preview, 'minimumTraining': minimum_training,
        'note': '严格逐期滚动。历史复现只接受连续4期以上同步；近期活跃、冷热和遗漏条件各自独立评分，方法近期连续失准会自动降权，长期频数只保留低权重。单3/单4超期不会被直接判定必出：只有同遗漏历史样本足够且下一期表现支持时才加权，否则自动排挤。历史结果不保证未来命中。',
    }
