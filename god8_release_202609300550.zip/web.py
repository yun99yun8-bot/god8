"""Monitor dashboard; only manual adoption endpoint may mutate model state."""
import re
from datetime import datetime, timezone
from flask import Flask, jsonify, render_template, request
from ai_research import METHODS, REVISION, wilson
from core import CN, DB, from_index, get_meta, pindex, target_block
from god8_flow import first_complete_index
from omission_research import current_snapshot, retained_stats, run_page
from streak_research import issue_index
from streak_research import report as streak_report
from pattern_research import pattern_report
from historical_playbook import summarize
from history_simulation import simulate
from research_lab import analyze, LABELS
from replay_streaks import summarize as replay_streak_summary
from omission_extras import daily_overdue, overdue_page, chase_comparison, recommend_recent

app = Flask(__name__)
APP_VERSION = 'god8-v2.0.27-streak-window-sync'


@app.after_request
def prevent_api_cache(response):
    if request.path.startswith('/api/'):
        response.headers['Cache-Control']='no-store, max-age=0'
    return response


def rows(sql, args=()):
    with DB() as c:
        q = c.cursor()
        q.execute(sql, args)
        result = q.fetchall()
        q.close()
    return result


@app.get('/')
def home():
    return render_template('home.html')


@app.get('/playbook')
def playbook():
    return render_template('playbook.html')


@app.get('/replay')
def replay_page():
    return render_template('replay.html')


@app.get('/chase')
def chase_page():
    return render_template('chase.html')


@app.get('/api/chase/replay-streaks')
def chase_replay_streaks():
    history=rows('''SELECT period_key,choices,actual,locked_at,settled_at
                    FROM replay_forecasts WHERE settled_at IS NOT NULL
                    ORDER BY period_key DESC LIMIT 10000''')
    return jsonify(replay_streak_summary(history))


@app.get('/history')
def history():
    return render_template('history.html')


@app.get('/statistics')
def statistics():
    return render_template('statistics.html')


@app.get('/api/statistics/research')
def statistics_research():
    historical=rows('''SELECT period_key,single_count FROM periods
                       ORDER BY period_date DESC,period_no DESC LIMIT 10001''')
    historical.reverse()
    return jsonify({'sample':len(historical), 'streaks':streak_report(historical),
                    'patterns':pattern_report(historical)})


@app.get('/api/playbook')
def playbook_data():
    try:
        window=int(request.args.get('window','1000'))
        if window not in (30,100,500,1000,10000):raise ValueError('期数无效')
        mode=request.args.get('mode','special')
        kind=request.args.get('kind','wave')
        value=request.args.get('value','红波')
        filters={name:request.args.get(name,'') for name in ('wave','parity','size')}
        # Validate before hitting the database (also refuse empty combinations).
        summarize([],mode,kind,value,**filters)
    except ValueError as exc:
        return jsonify({'error':str(exc)}),400
    history_rows=rows('''SELECT period_key,numbers,single_count FROM periods
                         ORDER BY period_date DESC,period_no DESC LIMIT %s''',(window,))
    result=summarize(history_rows,mode,kind,value,**filters)
    return jsonify(result)


@app.get('/api/playbook/replay')
def playbook_replay():
    try:
        window=int(request.args.get('window','10000'))
        if window not in (500,1000,2500,10000):raise ValueError()
    except ValueError:
        return jsonify({'error':'复盘范围须为500、1000、2500或10000期'}),400
    data=rows('''SELECT period_key,single_count,numbers FROM periods
                 ORDER BY period_date DESC,period_no DESC LIMIT %s''',(window,))
    return jsonify(simulate(data))


@app.get('/api/replay/lab')
def lab_backtest():
    try:
        window=int(request.args.get('window','10000'))
        if window not in (500,1000,2500,10000):raise ValueError()
    except ValueError:
        return jsonify({'error':'复盘范围须为500、1000、2500或10000期'}),400
    data=rows('''SELECT period_key,single_count,numbers FROM periods
                 ORDER BY period_date DESC,period_no DESC LIMIT %s''',(window,))
    return jsonify(analyze(data))


@app.get('/api/replay/lab/live')
def lab_live():
    latest=rows('''SELECT period_key FROM periods
                   ORDER BY period_date DESC,period_no DESC LIMIT 1''')
    saved=rows('''SELECT period_key,source_period,choices,ai_prediction,ai_method,
                        weights,locked_at,actual,settled_at
                 FROM lab_forecasts ORDER BY locked_at DESC LIMIT 1''')
    counts=rows('''SELECT COUNT(*),
                      COUNT(*) FILTER (WHERE actual=(choices->>0)::int),
                      COUNT(*) FILTER (WHERE actual=(choices->>1)::int),
                      COUNT(*) FILTER (WHERE actual IN ((choices->>0)::int,(choices->>1)::int)),
                      COUNT(*) FILTER (WHERE actual=ai_prediction)
                 FROM lab_forecasts WHERE settled_at IS NOT NULL AND actual BETWEEN 0 AND 7''')[0]
    forecast=None
    if latest and saved:
        period,source,choices,guess,method,weights,locked,actual,settled=saved[0]
        if latest[0][0] in (period,source):
            forecast={'issue':issue_no(period),'choices':choices,'aiPrediction':guess,
                      'method':method,'methodName':LABELS.get(method,method),
                      'weights':weights,'lockedAt':locked.isoformat(),
                      'actual':actual,'settledAt':settled.isoformat() if settled else None}
    n,first,second,either,ai=counts
    return jsonify({'forecast':forecast,'verified':n,
                    'first':{'hits':first,'rate':first/n if n else None},
                    'second':{'hits':second,'rate':second/n if n else None},
                    'either':{'hits':either,'rate':either/n if n else None},
                    'ai':{'hits':ai,'rate':ai/n if n else None}})


@app.get('/api/replay/live')
def replay_live():
    """Read collector-locked predictions, never generate one during an HTTP request."""
    current = rows('''SELECT period_key,single_count,created_at FROM periods
                      ORDER BY period_date DESC,period_no DESC LIMIT 1''')
    saved = rows('''SELECT period_key,source_period,choices,match,locked_at,actual,settled_at
                    FROM replay_forecasts ORDER BY locked_at DESC LIMIT 2''')
    counts = rows('''SELECT COUNT(*),
                       COUNT(*) FILTER (WHERE actual=(choices->>0)::int),
                       COUNT(*) FILTER (WHERE actual=(choices->>1)::int),
                       COUNT(*) FILTER (WHERE actual IN ((choices->>0)::int,(choices->>1)::int))
                    FROM replay_forecasts WHERE settled_at IS NOT NULL AND actual BETWEEN 0 AND 7''')[0]
    latest = current[0] if current else None
    forecast = None
    hold_seconds = 0
    selected = None
    if latest:
        age=(datetime.now(timezone.utc)-latest[2]).total_seconds()
        if 0<=age<10:
            selected=next((r for r in saved if r[0]==latest[0] and r[6] is not None),None)
            if selected:hold_seconds=max(0,10-age)
        if selected is None:
            selected=next((r for r in saved if r[1]==latest[0] and r[6] is None),None)
    if selected:
        period,source,choices,match,locked,actual,settled = selected
        if latest and latest[0] in (source,period):
            forecast = {'period':period,'issue':issue_no(period),'sourcePeriod':source,
                        'choices':choices,'match':match,'lockedAt':locked.isoformat(),
                        'actual':actual,'settledAt':settled.isoformat() if settled else None,
                        'firstHit':actual==choices[0] if settled and actual is not None else None,
                        'secondHit':actual==choices[1] if settled and actual is not None else None}
    n,first,second,either = counts
    return jsonify({'forecast':forecast,'resultHoldSeconds':round(hold_seconds,1),
                    'latest':{'period':latest[0],
                    'savedAt':latest[2].isoformat()} if latest else None,
                    'stats':{'verified':n,'firstHits':first,'secondHits':second,
                             'eitherHits':either,'firstRate':first/n if n else None,
                             'secondRate':second/n if n else None,
                             'eitherRate':either/n if n else None}})


@app.get('/api/omission/chase')
def omission_chase():
    data=rows('''SELECT period_key,single_count FROM periods
                 ORDER BY period_date,period_no''')
    return jsonify(chase_comparison(data))


@app.get('/api/omission/recommend200')
def omission_recommend200():
    data=rows('''SELECT period_key,single_count,target_block FROM periods
                 ORDER BY period_date DESC,period_no DESC LIMIT 200''')
    mapping_valid=all(len(row)<3 or int(row[2])==target_block(*row[0].split(':'))
                      for row in data)
    now=datetime.now(CN)
    current=pindex(now.date().isoformat(),now.hour*60+now.minute)
    latest_age=current-issue_index(data[0][0]) if data else None
    return jsonify(recommend_recent(data,mapping_valid=mapping_valid,
                                    latest_age=latest_age))


NAMES = ('god8-collector', 'god8-worker-ai', 'god8-web', 'god8-db')


def ai_alive(heartbeat):
    stamped = heartbeat.get('reportedAt')
    if not stamped:
        return False
    try:
        return (datetime.now(timezone.utc)-datetime.fromisoformat(stamped)).total_seconds()<60
    except ValueError:
        return False


@app.get('/services')
@app.get('/services/<role>')
def services(role=None):
    if role and role not in ('monitor', 'worker', 'audit', 'db', 'ai'):
        return 'Unknown service', 404
    return render_template('services.html', role=role or 'all')


@app.get('/checks')
def checks():
    """Human-readable index of existing status reports and read-only checks."""
    return render_template('checks.html')


@app.get('/api/services')
def service_data():
    counts = rows('''SELECT (SELECT COUNT(*) FROM raw_blocks),
                            (SELECT COUNT(*) FROM periods),
                            (SELECT COUNT(*) FROM groups),
                            (SELECT COUNT(*) FROM repair_queue),
                            (SELECT COUNT(*) FROM ai_simulations),
                            (SELECT COUNT(*) FROM ai_models),
                            pg_database_size(current_database())''')[0]
    heartbeat = get_meta('ai_heartbeat', {}) or {}
    ai = get_meta('ai_status', {}) or {}
    if not ai_alive(heartbeat):
        ai = {'status':'not-started-or-offline', 'lastSavedStatus':ai.get('status')}
    history=get_meta('history_progress',{}) or {}
    history.update({'forward':get_meta('god8_forward',{}),
                    'origin':get_meta('god8_origin',{}),
                    'aiStage':get_meta('god8_ai_stage',{}),
                    'historicalCapture':get_meta('historical_capture',{}),
                    'recovery':get_meta('god8_forward_recovery',{}),
                    'live':get_meta('collector_live_cursor',{})})
    return jsonify({'names': NAMES, 'aiName': 'god8-worker-ai',
        'workerHeartbeat':get_meta('god8_worker_heartbeat',{}),
        'monitor': get_meta('monitor_stats', {}),
        'liveLatency':get_meta('collector_live_latency',{}),
        'platformCalibration':get_meta('platform_calibration',{}),
        'worker': history,
        'audit': {'repair': get_meta('audit_stats', {}),
                  'verification': get_meta('audit', {}),
                  'progress': get_meta('god8_audit_progress', {}),
                  'error': get_meta('audit_error', {}),
                  'failover': get_meta('audit_failover', {})},
        'db': dict(zip(('blocks','periods','groups','queuedRepairs','simulations','models','sizeBytes'),counts)) |
              {'retention':get_meta('god8_retention',{})},
        'ai': {'status': {'status':'disabled'}, 'gate': get_meta('ai_gate', {}),
               'shadow': get_meta('ai_shadow', {}),
               'regime': get_meta('ai_streak_report', {}),
               'heartbeat': get_meta('ai_heartbeat', {}),
               'lock': get_meta('ai_lock_status', {}),
               'stageComparison':get_meta('god8_stage_comparison',{})},
        'chain': get_meta('chain_head', {})})


@app.get('/ai-lab')
def ai_page():
    return render_template('statistics.html')


@app.get('/ai-lab-2')
def ai2_page():
    return render_template('statistics.html')


@app.get('/api/ai2')
def ai2_data():
    status=get_meta('ai2_status',{}) or {}
    models=rows('''SELECT m.id,m.method,m.stage_no,m.metrics,
                  COUNT(p.id) FILTER (WHERE p.valid=TRUE),
                  COUNT(p.id) FILTER (WHERE p.valid=TRUE AND p.prediction=p.actual)
                  FROM ai2_models m LEFT JOIN ai2_predictions p ON p.model_id=m.id
                  GROUP BY m.id ORDER BY m.id DESC LIMIT 50''')
    predictions=rows('''SELECT p.period_key,m.method,p.prediction,p.actual,p.valid,p.locked_at
                         FROM ai2_predictions p JOIN ai2_models m ON m.id=p.model_id
                         ORDER BY p.locked_at DESC LIMIT 50''')
    return jsonify({'status':status,'heartbeat':get_meta('ai2_heartbeat',{}),
                    'error':get_meta('ai2_error',{}),
                    'models':[{'id':r[0],'method':r[1],'stage':r[2],'metrics':r[3],
                               'realValid':r[4],'realHits':r[5],
                               'realRate':r[5]/r[4] if r[4] else None} for r in models],
                    'predictions':[{'issue':issue_no(r[0]),'method':r[1],
                                    'prediction':r[2],'actual':r[3],
                                    'valid':r[4],'lockedAt':r[5].isoformat()} for r in predictions]})


@app.get('/api/models')
def models():
    data = rows('''SELECT m.id,m.method,m.metrics,m.tier,m.adopted,m.artifact,
               COUNT(a.id) FILTER (WHERE a.valid=TRUE),
               COUNT(a.id) FILTER (WHERE a.valid=TRUE AND a.actual=a.prediction),
               COUNT(a.id) FILTER (WHERE a.valid=FALSE),
               COUNT(a.id) FILTER (WHERE a.actual IS NULL)
               FROM ai_models m LEFT JOIN ai_predictions a ON a.model_id=m.id
               GROUP BY m.id ORDER BY m.id DESC LIMIT 100''')
    result = []
    for mid,method,metrics,tier,adopted,artifact,n,hits,late,pending in data:
        result.append({'id':mid,'method':method,'metrics':metrics,'tier':tier,
            'adopted':adopted,'future':{'valid':n,'hits':hits,
            'late':late,'pending':pending,
            'rate':hits/n if n else 0,'wilsonLower95':wilson(hits,n),
            'eligible':(artifact or {}).get('revision')==REVISION and n>=300 and wilson(hits,n)>=.8 and
                       metrics.get('holdout',{}).get('wilsonLower95',0)>=.8}})
    return jsonify(result)


@app.get('/api/ai/simulations')
def simulations():
    method = request.args.get('method','')
    if method not in METHODS:
        return jsonify({'error':'请选择有效的练习方法'}),400
    try:
        page = max(1,min(1000,int(request.args.get('page','1'))))
    except ValueError:
        return jsonify({'error':'页码无效'}),400
    fp = (get_meta('ai_status') or {}).get('trainsetFingerprint','')
    train_id = (get_meta('ai_status') or {}).get('trainsetId','')
    result = rows('''SELECT period_key,phase,prediction,actual FROM ai_simulations
                     WHERE trainset_id=%s AND method=%s
                     ORDER BY period_key DESC LIMIT 100 OFFSET %s''',
                  (train_id,method,100*(page-1))) if fp else []
    return jsonify({'method':method,'page':page,'rows':[
        {'period':r[0],'phase':r[1],'prediction':r[2],'actual':r[3],
         'hit':r[2]==r[3]} for r in result]})


@app.get('/api/ai/switches')
def switches():
    data = rows('''SELECT occurred_at,from_model_id,to_model_id,reason
                   FROM ai_switches ORDER BY id DESC LIMIT 20''')
    return jsonify([{'at':r[0].isoformat(),'fromId':r[1],
                    'toId':r[2],'reason':r[3]} for r in data])


@app.get('/api/ai/streaks')
def streaks():
    return jsonify(get_meta('ai_streak_report',{}) or
                   {'status':'等待 AI1 读取历史开奖结果','conditions':[]})


@app.get('/api/ai/patterns')
def patterns():
    return jsonify(get_meta('ai_pattern_report',{}) or
                   {'status':'等待 Worker/AI 汇总历史序列','exact':None,'supported':None})


@app.get('/api/ai/diagnostic')
def ai_diagnostic():
    """Expose actual learning cadence and pre-result evidence, without creating predictions."""
    status=get_meta('ai_status',{}) or {}
    stage=get_meta('god8_ai_stage',{}) or {}
    forward=get_meta('god8_forward',{}) or {}
    heartbeat=get_meta('ai_heartbeat',{}) or {}
    lock=get_meta('ai_lock_status',{}) or {}
    completed=max(0,int(forward.get('completedSinceOrigin') or 0))
    processed=int(stage.get('processed',-1))
    next_target=(processed+2)*10000
    selected=[x for x in status.get('selectedTopTwo',[]) if isinstance(x,dict) and x.get('id')]
    ids=[x['id'] for x in selected]
    evidence=rows('''SELECT model_id,
                     COUNT(*) FILTER (WHERE actual IS NULL),
                     COUNT(*) FILTER (WHERE actual IS NOT NULL AND valid=TRUE),
                     COUNT(*) FILTER (WHERE actual IS NOT NULL AND valid=TRUE AND prediction=actual),
                     COUNT(*) FILTER (WHERE actual IS NOT NULL AND valid=FALSE)
                     FROM ai_predictions WHERE model_id=ANY(%s) GROUP BY model_id''',(ids,)) if ids else []
    by_id={r[0]:r[1:] for r in evidence}
    candidates=[]
    for chosen in selected:
        pending,valid,hits,late=by_id.get(chosen['id'],(0,0,0,0))
        candidates.append({'id':chosen['id'],'method':chosen.get('method'),
                           'pending':pending,'valid':valid,'hits':hits,'late':late,
                           'rate':hits/valid if valid else None})
    if not ai_alive(heartbeat): explanation='Worker/AI 心跳未更新；先检查服务运行状态。'
    elif status.get('status')=='simulating': explanation='正在运行一轮历史方法比较，查看已完成的方法数。'
    elif processed<0: explanation='首段10,000期还未完成审计与训练。'
    elif completed<next_target: explanation='现有审计历史已比较全部候选方法；下一轮新数据评估须等新一段10,000期通过审计，开奖前影子验证在持续进行。'
    else: explanation='新一段期数已够；等待阶段审计或下一轮训练启动。'
    return jsonify({'explanation':explanation,'workerAlive':ai_alive(heartbeat),
                    'status':status.get('status'),'revision':status.get('revision'),
                    'completedSinceOrigin':completed,'lastTrainedStage':processed,
                    'nextStageAt':next_target,'roundsUntilNextStage':max(0,next_target-completed),
                    'methodsFinished':status.get('finishedMethods',0),
                    'methodsTotal':status.get('totalMethods',0),'candidates':candidates,
                    'lock':lock,'heartbeat':heartbeat,
                    'note':'有效样本仅统计开奖前锁定并被数据库验证的预测；运行两天不等于完成新训练阶段。'})


@app.post('/api/adopt/<int:model_id>')
def adopt(model_id):
    return jsonify({'ok':False,'error':'AI练习已停用，不能授权旧模型'}),410


@app.get('/api/status')
def status():
    return jsonify({'history': get_meta('history_progress', {}),
                    'audit': get_meta('audit', {}),
                    'trainset': get_meta('god8_trainset', {}),
                    'origin':get_meta('god8_origin',{}),
                    'retention':get_meta('god8_retention',{}),
                    'chain': get_meta('chain_head', {}),
                    'platformCalibration':get_meta('platform_calibration',{}),
                    'gate': get_meta('ai_gate', {}),
                    'ai':get_meta('ai_status',{}),
                    'ai2':get_meta('ai2_status',{})})


@app.get('/api/recent')
def recent():
    data = rows('''SELECT period_key,single_count,target_block,numbers FROM periods
                   WHERE single_count IS NOT NULL
                   ORDER BY period_date DESC,period_no DESC LIMIT 30''')
    return jsonify([{'period': x[0], 'issue': issue_no(x[0]), 'single': x[1], 'block': x[2],
                     'numbers': x[3]} for x in data])


@app.get('/api/live')
def live_snapshot():
    """Show a saved target hash immediately, before the 20-group audit finishes."""
    with DB() as c:
        q=c.cursor()
        q.execute('''SELECT period_key,single_count,target_block,numbers,created_at
                     FROM periods ORDER BY period_date DESC,period_no DESC LIMIT 1''')
        newest=q.fetchone()
        q.execute('''SELECT period_key,single_count,target_block,numbers,created_at
                     FROM periods WHERE single_count IS NOT NULL
                     ORDER BY period_date DESC,period_no DESC LIMIT 1''')
        latest=q.fetchone()
        q.close()
    chain=get_meta('chain_head',{}) or {}
    head=chain.get('block')
    raw_candidate=None
    idx=None
    if head is not None:
        idx=first_complete_index(int(head)+1)-1
        while target_block(*from_index(idx))>int(head):
            idx-=1
    if newest:
        newest_idx=pindex(newest[0][:10],int(newest[0][11:]))
        # A provisional/invalid period row can precede its target block's raw
        # capture. Check that SAME period too, instead of skipping to the next.
        idx=max(idx,newest_idx) if idx is not None else newest_idx
    if idx is not None:
        ds,no=from_index(idx)
        tb=target_block(ds,no)
        with DB() as c:
            q=c.cursor()
            q.execute('''SELECT numbers,single_count,fetched_at,block_time
                         FROM raw_blocks WHERE block_number=%s''',(tb,))
            raw=q.fetchone()
            q.close()
        if raw:
            raw_candidate=(f'{ds}:{no:04d}',raw[1],tb,raw[0],raw[2])
    def draw(row,provisional=False):
        return ({'period':row[0],'issue':issue_no(row[0]),'single':row[1],
                 'block':row[2],'numbers':row[3],
                 'provisional':provisional,
                 'savedAt':row[4].isoformat() if row[4] else None}) if row else None
    latency=get_meta('collector_live_latency',{}) or {}
    if raw_candidate:
        if raw_candidate[1] is not None:
            latest=raw_candidate
        newest=raw_candidate
        # Distinguish chain capture from the slower 20-group materialization.
        if raw[3] and raw[2]:
            latency={'period':raw_candidate[0], 'targetBlock':raw_candidate[2],
                     'source':'target-block-before-group-audit',
                     'blockToSavedSeconds':round(max(0,(raw[2]-raw[3]).total_seconds()),3)}
    next_period=None; next_target=None
    if newest:
        ds,no=from_index(pindex(newest[0][:10],int(newest[0][11:]))+1)
        next_period=f'{ds}:{no:04d}';next_target=target_block(ds,no)
    return jsonify({'latest':draw(latest,latest is raw_candidate),'newest':draw(newest,newest is raw_candidate),
                    'nextPeriod':next_period,'nextTargetBlock':next_target,
                    'head':head,'headSeenAt':chain.get('seenAt'),
                    'latency':latency,
                    'serverEpochMs':int(datetime.now(timezone.utc).timestamp()*1000)})


def issue_no(period):
    ds,no = period.split(':',1)
    return ds[2:4]+ds[5:7]+ds[8:10]+f'{int(no):04d}'


def parse_issue(value):
    if not re.fullmatch(r'\d{10}',value):
        raise ValueError('请输入十位期号，如 2609270409')
    ds=f'20{value[:2]}-{value[2:4]}-{value[4:6]}'
    datetime.strptime(ds,'%Y-%m-%d')
    no=int(value[6:])
    if not 1<=no<=1440:
        raise ValueError('期数须为0001至1440')
    return ds,no


@app.get('/api/clock')
def clock():
    return jsonify({'serverEpochMs':int(datetime.now(timezone.utc).timestamp()*1000),
                    'zone':'Asia/Shanghai','displayOffsetSeconds':-3})


@app.get('/api/official-prediction')
def official_prediction():
    return jsonify({'active':False,'reason':'AI练习已停用'})


@app.get('/api/history')
def history_data():
    try:
        page = max(1, int(request.args.get('page', '1')))
        requested=request.args.get('count','30')
        selected=None if requested=='all' else int(requested)
        if selected is not None and not 1<=selected<=60000:
            raise ValueError()
    except ValueError:
        return jsonify({'error': '期数须在1至60000之间，或选择全部'}), 400
    page = min(page, 2000)
    count = rows('SELECT COUNT(*) FROM periods')[0][0]
    available=min(count,selected) if selected is not None else count
    page_size=min(100,selected or 100)
    offset=(page-1)*page_size
    take=max(0,min(page_size,available-offset))
    data = rows('''SELECT period_key,single_count,target_block,numbers FROM periods
                   ORDER BY period_date DESC,period_no DESC
                   LIMIT %s OFFSET %s''', (take,offset)) if take else []
    return jsonify({'page': page, 'pageSize':page_size,'total':available,
                    'stored':count,'selected':requested,
                    'rows':[{'period':r[0],'issue':issue_no(r[0]),'single':r[1],
                             'block':r[2],'numbers':r[3]} for r in data]})


@app.get('/api/history/search')
def history_search():
    try:
        ds,no=parse_issue(request.args.get('issue','').strip())
    except ValueError as exc:
        return jsonify({'error':str(exc)}),400
    center=pindex(ds,no)
    indices=range(center-10,center+11)
    keys=[f'{day}:{period:04d}' for day,period in map(from_index,indices)]
    data=rows('''SELECT period_key,single_count,target_block,numbers FROM periods
                 WHERE period_key=ANY(%s)''',(keys,))
    found={r[0]:r for r in data}
    if keys[10] not in found:
        return jsonify({'error':'数据库中没有这个期号','issue':issue_no(keys[10])}),404
    return jsonify({'center':issue_no(keys[10]),'rows':[
        {'period':key,'issue':issue_no(key),'single':found[key][1] if key in found else None,
         'block':found[key][2] if key in found else None,
         'numbers':found[key][3] if key in found else None,
         'missing':key not in found,'center':i==10} for i,key in enumerate(keys)]})


@app.get('/api/omission/detail')
def omission_detail():
    today=datetime.now(CN).date().isoformat()
    data=rows('''SELECT period_key,period_date::text,period_no,single_count
                 FROM periods WHERE period_date=%s ORDER BY period_no''',(today,))
    report=daily_omission_stats(data,today)
    overdue=daily_overdue([(key,label) for key,_,_,label in data])
    for item, extra in zip(report['items'], overdue['items']):
        item['overdueCount']=extra['count']
        item['overdueLatest']=extra['events'][0] if extra['events'] else None
    report['overdueTotal']=overdue['total']
    return jsonify(report)


@app.get('/api/omission/today/overdue')
def omission_today_overdue():
    try:
        single=int(request.args.get('single',''))
        page=int(request.args.get('page','1'))
        if single not in range(8) or page not in range(1,101):raise ValueError()
    except ValueError:
        return jsonify({'error':'单几须为0–7，页码须为1–100'}),400
    today=datetime.now(CN).date().isoformat()
    data=rows('''SELECT period_key,single_count FROM periods
                 WHERE period_date=%s ORDER BY period_no''',(today,))
    return jsonify(overdue_page(data,single,page))


@app.get('/api/omission/retained')
def retained_omission():
    data=rows('''SELECT period_key,single_count FROM periods
                 ORDER BY period_date,period_no''')
    return jsonify(retained_stats(data))


@app.get('/api/omission/retained/run')
def retained_omission_run():
    try:
        label=int(request.args.get('single',''))
        page=int(request.args.get('page','1'))
        if label not in range(8) or page not in range(1,601):raise ValueError()
    except ValueError:
        return jsonify({'error':'单几须为0–7，页码须为1–600'}),400
    data=rows('''SELECT period_key,single_count FROM periods
                 ORDER BY period_date,period_no''')
    return jsonify(run_page(data,label,page))


def daily_omission_stats(data,day):
    """Today's omission over stored valid results only; holes/invalid rows are metadata."""
    thresholds=(200,30,10,7,7,10,30,200)
    valid=[];invalid=0;missing=0;previous=None
    for key,ds,no,label in data:
        index=int(no)
        if previous is not None and index>previous+1: missing+=index-previous-1
        previous=index
        if label is None or not 0<=int(label)<=7:
            invalid+=1;continue
        valid.append((key,index,int(label)))
    counts=[0]*8;last_pos=[None]*8;last_issue=[None]*8;longest=[None]*8
    for pos,(key,index,label) in enumerate(valid):
        if last_pos[label] is not None:
            length=pos-last_pos[label]-1
            start_pos=last_pos[label]+1;end_pos=pos-1
            run={'length':length,
                 'startNo':valid[start_pos][1] if length else index,
                 'endNo':valid[end_pos][1] if length else index-1,
                 'endedBy':issue_no(key),'active':False,'exact':True}
            if longest[label] is None or length>longest[label]['length']:longest[label]=run
        counts[label]+=1;last_pos[label]=pos;last_issue[label]=issue_no(key)
    n=len(valid);newest=int(data[-1][2]) if data else 0
    items=[]
    for label in range(8):
        gap=n if last_pos[label] is None else n-1-last_pos[label]
        exact=last_pos[label] is not None
        if gap:
            start_no=(valid[last_pos[label]+1][1] if exact and last_pos[label]+1<n else
                      valid[0][1] if valid else newest)
            active={'length':gap,'startNo':start_no,'endNo':newest,
                    'endedBy':None,'active':True,'exact':exact}
            if longest[label] is None or gap>longest[label]['length']:longest[label]=active
        level=('超期' if gap>thresholds[label] else
               '接近' if gap>=thresholds[label]*.8 else '正常')
        items.append({'single':label,'count':counts[label],'gap':gap,'lowerBound':gap,
                      'exact':exact,'lastIssue':last_issue[label],'longest':longest[label],
                      'threshold':thresholds[label],'level':level})
    return {'day':day,'sample':len(data),'valid':n,'complete':n>0,
            'sourceComplete':missing==0 and invalid==0,'missing':missing,'invalid':invalid,
            'items':items,
            'note':'独立读取当天数据库已保存的有效开奖记录；缺失期和无效结果仅单独报告，不会重置遗漏。'}


@app.get('/api/omission/run')
def omission_run():
    try:
        label=int(request.args.get('single',''))
        if label not in range(8): raise ValueError()
    except ValueError:
        return jsonify({'error':'单几须为0–7'}),400
    day=datetime.now(CN).date().isoformat()
    data=rows('''SELECT period_key,period_date::text,period_no,single_count
                 FROM periods WHERE period_date=%s ORDER BY period_no''',(day,))
    report=daily_omission_stats(data,day)
    selected=report['items'][label]['longest']
    if selected is None:
        return jsonify({'day':day,'single':label,'length':0,'rows':[],'counts':[0]*8})
    lower,upper=selected['startNo'],selected['endNo']
    by_no={int(r[2]):r for r in data}
    sequence=[];counts=[0]*8
    for no in range(lower,upper+1):
        row=by_no.get(no)
        value=row[3] if row else None
        if value is not None and 0<=int(value)<=7:
            counts[int(value)]+=1
        sequence.append({'issue':issue_no(f'{day}:{no:04d}'),
                         'single':value,'missing':row is None})
    return jsonify({'day':day,'single':label,'length':selected['length'],
                    'startIssue':sequence[0]['issue'] if sequence else None,
                    'endIssue':sequence[-1]['issue'] if sequence else None,
                    'endedBy':selected['endedBy'],'active':selected['active'],
                    'complete':selected.get('exact',True),'counts':counts,'rows':sequence})


@app.get('/api/omission')
def omission():
    data=rows('''SELECT period_key,single_count FROM periods
                 ORDER BY period_date,period_no''')
    return jsonify(current_snapshot(data))


@app.get('/health')
def health():
    try:
        with DB() as connection:
            cursor=connection.cursor()
            cursor.execute("SELECT to_regclass('public.periods') IS NOT NULL")
            initialized=bool(cursor.fetchone()[0])
            cursor.close()
        if not initialized:
            return jsonify({'ok':False,'version':APP_VERSION,'aiEnabled':False,
                            'reason':'database connected but periods table not initialized'}),503
        return jsonify({'ok':True,'version':APP_VERSION,'aiEnabled':False,'databaseConnected':True,
                        'role':'god8-web'})
    except Exception as exc:
        return jsonify({'ok':False,'version':APP_VERSION,'aiEnabled':False,'databaseConnected':False,
                        'reason':type(exc).__name__}),503
