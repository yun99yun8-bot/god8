'use client';
import {useEffect,useMemo,useState} from 'react';
import Balls from './Balls';
import {zodiacForDrawNumber} from '@/lib/zodiac-map';
type Draw={expect?:string;open_time?:string;numbers?:number[];zodiacs?:string[]};
export default function LiveResults({initial}:{initial?:Draw|null}){
 const [draw,setDraw]=useState<Draw|null>(initial||null),[partial,setPartial]=useState<any>(null),[now,setNow]=useState(()=>new Date());
 useEffect(()=>{let alive=true;const poll=async()=>{try{const [a,b]=await Promise.all([fetch('/api/latest?x='+Date.now(),{cache:'no-store'}),fetch('/api/live-progress?x='+Date.now(),{cache:'no-store'})]);const j=await a.json(),p=await b.json();if(!alive)return;if(j.draw)setDraw(j.draw);setPartial(p.partial||null)}catch{}};poll();const t=setInterval(poll,2000),c=setInterval(()=>setNow(new Date()),1000);return()=>{alive=false;clearInterval(t);clearInterval(c)}},[]);
 const bj=useMemo(()=>{const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Shanghai',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).formatToParts(now);const v:any=Object.fromEntries(parts.map(x=>[x.type,x.value]));return {h:+v.hour,m:+v.minute,s:+v.second}},[now]);
 const standby=bj.h===21&&bj.m>=30;
 const isNew=!!(partial?.expect&&partial.expect!==draw?.expect);const nums=isNew?(partial?.numbers||[]):(draw?.numbers||[]);const rawLabels=isNew?partial?.zodiacs:draw?.zodiacs;const exp=isNew?partial?.expect:draw?.expect;
 const openTime=isNew?(partial?.openTime||now.toISOString()):(draw?.open_time||now.toISOString());
 const labels=useMemo(()=>nums.map((n:number,i:number)=>zodiacForDrawNumber(n,rawLabels?.[i],openTime,nums,rawLabels||[])),[nums,rawLabels,openTime]);
 return <div className="liveSyncResult"><div className="liveSyncHead"><b>{standby&&!isNew?'开奖待命中':isNew?`正在开奖 ${nums.length}/7`:'开奖结果同步'}</b><span>{exp?`第 ${exp} 期`:'等待官方数据'}</span></div><Balls numbers={standby&&!isNew?[]:nums} labels={labels}/></div>
}
