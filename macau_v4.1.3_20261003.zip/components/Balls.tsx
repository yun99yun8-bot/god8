const reds=new Set([1,2,7,8,12,13,18,19,23,24,29,30,34,35,40,45,46]);
const blues=new Set([3,4,9,10,14,15,20,25,26,31,36,37,41,42,47,48]);
export function waveClass(n:number){return reds.has(n)?'red':blues.has(n)?'blue':'green'}

export function OfficialBall({n,special=false,small=false,mini=false,hit=false,dim=false,placeholder=false,className=''}:{n?:number,special?:boolean,small?:boolean,mini?:boolean,hit?:boolean,dim?:boolean,placeholder?:boolean,className?:string}){
  const tone=typeof n==='number'?waveClass(n):'clear';
  return <span className={`officialBallV4 ball ${tone} ${special?'special':''} ${small?'small':''} ${mini?'mini':''} ${hit?'hit':''} ${dim?'dim':''} ${placeholder?'placeholder':''} ${className}`} aria-label={typeof n==='number'?String(n).padStart(2,'0'):'空球'}>
    <span className="officialBallShell"/>
    <span className="officialBallFace">{typeof n==='number'?String(n).padStart(2,'0'):''}</span>
    <span className="officialBallGloss"/>
    {hit&&<i className="officialBallHit">✓</i>}
  </span>
}

export function LotteryBall({n,label,special=false,small=false}:{n:number,label?:string,special?:boolean,small?:boolean}){
  return <div className={`ballWrap ${special?'specialWrap':''} ${small?'smallBallWrap':''}`}><OfficialBall n={n} special={special} small={small}/>{label&&<span className="ballLabel zodiacGoldLabel">{label}</span>}</div>
}

export default function Balls({numbers,labels}:{numbers:number[],labels?:string[]}){
  const regular=numbers.slice(0,Math.min(6,numbers.length));
  const special=numbers.length>=7?numbers[6]:undefined;
  return <div className="drawNumbersRow"><div className="regularGroup">{regular.map((n,i)=><LotteryBall n={n} label={labels?.[i]} key={`r-${i}`}/>)}{numbers.length<7&&Array.from({length:Math.max(0,6-regular.length)},(_,i)=><div className="ballWrap pendingBallWrap" key={`p-${i}`}><OfficialBall placeholder/><span className="ballLabel">待开</span></div>)}</div><div className="specialDivider"><span>特</span></div>{typeof special==='number'?<LotteryBall n={special} label={labels?.[6]} special/>:<div className="ballWrap specialWrap pendingBallWrap"><OfficialBall special placeholder/><span className="ballLabel">待开</span></div>}</div>
}
