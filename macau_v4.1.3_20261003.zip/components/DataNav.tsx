import Link from 'next/link';
type ActiveKey='special'|'regular'|'jump'|'library';
export default function DataNav({active}:{active:ActiveKey}){return <nav className="dataRail" aria-label="数据导航"><Link className="dataBack" href="/">‹</Link><Link className={active==='special'?'active':''} href="/data">特码数据</Link><Link className={active==='regular'?'active':''} href="/data/regular">正码数据</Link><Link className={active==='jump'?'active':''} href="/zodiac-jump">跳转记录</Link><Link className={active==='library'?'active':''} href="/library">资料大全</Link></nav>}
