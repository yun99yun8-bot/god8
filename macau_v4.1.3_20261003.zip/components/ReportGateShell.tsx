'use client';
import type {ReactNode} from 'react';
import Link from 'next/link';

export default function ReportGateShell({children}:{children:ReactNode}){
  return <main className="reportGatePage v411ReportGate">
    <section className="reportGateOrnate">
      <Link className="reportGateHome" href="/">‹ 返回主页</Link>
      <div className="reportGateLotus" aria-hidden="true">✦</div>
      <div className="reportGateDragon" aria-hidden="true"/>
      <div className="reportGateCity" aria-hidden="true"/>
      <div className="reportGateContent">{children}</div>
    </section>
  </main>;
}
