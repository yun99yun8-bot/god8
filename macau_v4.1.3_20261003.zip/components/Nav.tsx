'use client';
import Link from 'next/link';
import {usePathname} from 'next/navigation';
import {useEffect,useMemo,useState} from 'react';

function timeLabel(v?:string){if(!v)return '';try{return new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(v))}catch{return ''}}
export default function Nav(){
  const path=usePathname();
  const [bookmark,setBookmark]=useState(false);
  const [luckyTime,setLuckyTime]=useState('');
  const dataMode=path.startsWith('/data')||path.startsWith('/zodiac-jump')||path.startsWith('/library');
  const adminMode=path.startsWith('/admin')||path.startsWith('/bm');
  const device=useMemo(()=>{
    if(typeof navigator==='undefined')return 'other';
    const ua=navigator.userAgent||'';
    if(/iPhone|iPad|iPod/i.test(ua))return 'ios';
    if(/Android/i.test(ua))return 'android';
    return 'other';
  },[]);
  useEffect(()=>{let on=true;fetch('/api/lucky-zodiac?t='+Date.now(),{cache:'no-store'}).then(r=>r.json()).then(j=>{if(on)setLuckyTime(timeLabel(j?.data?.fetched_at))}).catch(()=>{});return()=>{on=false}},[]);
  if(adminMode)return null;
  return <>
    {!dataMode&&<header className="nav luxuryNav"><div className="navGlass"><nav className="navFour">
      <Link className={path==='/'?'active':''} href="/">开奖结果</Link>
      <Link className={path.startsWith('/history')||path.startsWith('/draw/')?'active':''} href="/history">历史记录</Link>
      <Link className={dataMode?'active':''} href="/data">数据中心</Link>
      <Link className={path.startsWith('/recommend')||path.startsWith('/publish')?'active':''} href="/recommend">本站推荐</Link>
    </nav></div></header>}
    {!dataMode&&<div className="quickDailyRail"><button type="button" className="sloganRail bookmarkRail" onClick={()=>setBookmark(true)}><span>添加书签</span><i>＋</i></button><Link className="luckyDailyLink" href="/lucky-zodiac"><span>每日幸运生肖走势</span>{luckyTime&&<b>{luckyTime}</b>}<i>›</i></Link></div>}
    {bookmark&&<div className="bookmarkShade" role="dialog" aria-modal="true"><section className="bookmarkCard"><button className="bookmarkClose" onClick={()=>setBookmark(false)} aria-label="关闭">×</button><div className="bookmarkIcon">◇</div><b>把本站留在手机上</b>{device==='ios'?<ol><li>点击 Safari 底部的“分享”按钮</li><li>选择“添加到主屏幕”或“加入个人收藏”</li></ol>:device==='android'?<ol><li>点击 Chrome 右上角菜单</li><li>选择“添加到主屏幕”或“添加书签”</li></ol>:<ol><li>打开浏览器菜单</li><li>选择“添加书签 / 收藏 / 添加到主屏幕”</li></ol>}<small>浏览器出于安全限制，网页不能替你直接添加书签。</small></section></div>}
  </>;
}
