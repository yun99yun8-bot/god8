'use client';
import {useEffect,useState} from 'react';
const ORDER=['鼠','牛','虎','兔','龙','蛇','马','羊','猴','鸡','狗','猪'];
type Item={zodiac:string;text?:string;score?:number|null;tag?:string};
type Daily={fortune_date?:string;source?:string;source_url?:string;source_time?:string;fetched_at?:string;content?:{items?:Item[];summary?:string}};
function fmt(v?:string){if(!v)return '等待更新';try{return new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(v)).replace('/','-')}catch{return v}}
export default function LuckyZodiacBoard(){
 const [data,setData]=useState<Daily|null>(null),[loading,setLoading]=useState(true);
 useEffect(()=>{let on=true;const load=async()=>{try{const r=await fetch('/api/lucky-zodiac?t='+Date.now(),{cache:'no-store'});const j=await r.json();if(on)setData(j.data||null)}catch{}finally{if(on)setLoading(false)}};load();return()=>{on=false}},[]);
 const map=new Map<string,Item>((data?.content?.items||[]).map((x:Item)=>[x.zodiac,x] as [string,Item]));
 return <main className="wrap luckyPage"><section className="luckyTop"><div><span>{data?.fortune_date?`资料日期：${data.fortune_date}`:'每天北京时间15:00自动获取最新网络资料'}</span><span>更新时间：{fmt(data?.fetched_at)}</span>{data?.source_url?<a href={data.source_url} target="_blank" rel="noreferrer">来源：{data.source||'网络资料'}</a>:<span>来源：等待网络资料</span>}</div><span className="luckyRefreshBadge">15:00 更新</span></section>{loading?<div className="luckyEmpty">正在读取今日生肖走势…</div>:data?<section className="luckyGrid">{ORDER.map(z=>{const x=map.get(z);return <article className="luckyCard" data-zodiac={z} key={z}><div className="luckyCardHead"><b>{z}</b><span>{typeof x?.score==='number'?`${x.score}分`:x?.tag||'今日走势'}</span></div><p>{x?.text||'该来源暂未提供此生肖的独立内容。'}</p></article>})}</section>:<div className="luckyEmpty">今日网络资料尚未获取成功。系统会在北京时间15:00后自动重试，并保留上一份成功数据。</div>}</main>
}
