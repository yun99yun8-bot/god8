'use client';
import {useEffect,useRef,useState} from 'react';
import {useRouter} from 'next/navigation';
const defs=[['zodiac','生肖'],['home','家野'],['element','五行'],['oe','单双'],['wave','波色']] as const;
const defaultState=Object.fromEntries(defs.map(([k])=>[k,k==='zodiac'])) as Record<string,boolean>;
export default function HistoryControls({latestExpect,autoRefresh=true}:{latestExpect?:string;autoRefresh?:boolean}){
  const [on,setOn]=useState<Record<string,boolean>>(()=>({...defaultState}));const [select,setSelect]=useState(false);
  const router=useRouter();const last=useRef(String(latestExpect||''));
  useEffect(()=>{const root=document.querySelector('.v411History, .archivePage');if(!root)return;defs.forEach(([k])=>root.classList.toggle('hide-'+k,!on[k]));root.classList.toggle('selectMode',select)},[on,select]);
  useEffect(()=>{
    if(!autoRefresh)return;let active=true,refreshing=false;
    const poll=async()=>{
      if(document.visibilityState==='hidden'||refreshing)return;
      try{const r=await fetch('/api/latest?ts='+Date.now(),{cache:'no-store'});const j=await r.json();const next=String(j?.draw?.expect||'');if(active&&next&&last.current&&next!==last.current){last.current=next;refreshing=true;router.refresh();setTimeout(()=>{refreshing=false},900)}else if(active&&next&&!last.current)last.current=next}catch{}
    };
    const id=setInterval(poll,5000);return()=>{active=false;clearInterval(id)};
  },[autoRefresh,router]);
  return <div className="historyControls v330HistoryControls"><div><b>显示</b>{defs.map(([k,n])=><label key={k}><input type="checkbox" checked={on[k]} onChange={e=>setOn(v=>({...v,[k]:e.target.checked}))}/><span>{n}</span></label>)}</div><button type="button" className={select?'active':''} onClick={()=>setSelect(v=>!v)}>{select?'完成':'👈可选择'}</button></div>;
}
