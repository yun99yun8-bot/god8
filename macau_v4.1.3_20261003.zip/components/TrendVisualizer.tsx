'use client';
import {useEffect,useMemo,useRef,useState,type CSSProperties} from 'react';
import {waveOf,headOf,tailOf,oddEven} from '@/lib/rules';
import {elementOf} from '@/lib/five-elements';
import {normalizeZodiac,rowZodiacOffset,zodiacByNumber} from '@/lib/zodiac-map';
import {OfficialBall} from '@/components/Balls';

type TrendRow={expect:string;open_time:string;numbers:number[];zodiacs:string[]};
type Metric='number'|'wave'|'oe'|'size'|'zodiac'|'element'|'head'|'tail';
const metrics:[Metric,string][]=[['number','号码'],['wave','波色'],['oe','单双'],['size','大小'],['zodiac','生肖'],['element','五行'],['head','头数'],['tail','尾数']];
const periods=[30,50,100,200,500];
const zodiacOrder=['鼠','牛','虎','兔','龙','蛇','马','羊','猴','鸡','狗','猪'];
const presets=[['overview','总览',.62],['standard','标准',.94],['detail','放大',1.16]] as const;

function short(v:string){return v.length>5?v.slice(-5):v}
function metricColumns(metric:Metric){
 if(metric==='number')return Array.from({length:49},(_,i)=>String(i+1).padStart(2,'0'));
 if(metric==='wave')return ['红波','蓝波','绿波'];
 if(metric==='oe')return ['单','双'];
 if(metric==='size')return ['小','大'];
 if(metric==='zodiac')return zodiacOrder;
 if(metric==='element')return ['金','木','水','火','土'];
 if(metric==='head')return ['0头','1头','2头','3头','4头'];
 return Array.from({length:10},(_,i)=>`${i}尾`);
}
function valueFor(metric:Metric,n:number,zodiac?:string){
 if(metric==='number')return String(n).padStart(2,'0');
 if(metric==='wave')return waveOf(n)==='red'?'红波':waveOf(n)==='blue'?'蓝波':'绿波';
 if(metric==='oe')return oddEven(n)==='odd'?'单':'双';
 if(metric==='size')return n<=24?'小':'大';
 if(metric==='zodiac')return zodiac||'';
 if(metric==='element')return elementOf(n);
 if(metric==='head')return `${headOf(n)}头`;
 return `${tailOf(n)}尾`;
}
function omissionColor(metric:Metric,col:string){
 if(metric==='wave')return col==='红波'?'#c84444':col==='蓝波'?'#3f72b9':'#37845f';
 if(metric==='element')return ({金:'#a77d36',木:'#3f7f55',水:'#4676a0',火:'#b34f3e',土:'#816548'} as Record<string,string>)[col]||'#80633b';
 if(metric==='zodiac')return '#8b6732';
 if(metric==='number')return '#705a3c';
 return '#755d3c';
}

export default function TrendVisualizer({mode,rows}:{mode:'special'|'regular';rows:TrendRow[]}){
 const [metric,setMetric]=useState<Metric>('number'),[limit,setLimit]=useState(100),[zoom,setZoom]=useState(.62);
 const [liveRows,setLiveRows]=useState<TrendRow[]>(rows);
 const [landscape,setLandscape]=useState(false),[virtualLandscape,setVirtualLandscape]=useState(false),[showSwipeHint,setShowSwipeHint]=useState(true);
 const deckRef=useRef<HTMLElement>(null),viewportRef=useRef<HTMLDivElement>(null),savedScroll=useRef({left:0});
 const cols=useMemo(()=>metricColumns(metric),[metric]);
 const noOmissionMetric=metric==='oe'||metric==='size';
 useEffect(()=>setLiveRows(rows),[rows]);
 useEffect(()=>{setShowSwipeHint(true)},[metric,limit,zoom]);
 useEffect(()=>{
   let active=true;
   const poll=async()=>{
     if(document.visibilityState==='hidden')return;
     try{
       const r=await fetch('/api/latest?ts='+Date.now(),{cache:'no-store'});
       const j=await r.json();const d=j?.draw;
       if(!active||!d?.expect||!Array.isArray(d?.numbers)||d.numbers.length!==7)return;
       setLiveRows(prev=>{
         const numbers=d.numbers.map(Number),rawZ=Array.isArray(d.zodiacs)?d.zodiacs:[];
         const offset=rowZodiacOffset(numbers,rawZ,d.open_time);
         const zodiacs=numbers.map((n:number,i:number)=>normalizeZodiac(rawZ[i])||zodiacByNumber(n,offset));
         const next:TrendRow={expect:String(d.expect),open_time:d.open_time,numbers,zodiacs};
         const index=prev.findIndex(x=>String(x.expect)===String(next.expect));
         if(index===0){const cur=prev[0];if(JSON.stringify(cur.numbers)===JSON.stringify(next.numbers)&&JSON.stringify(cur.zodiacs)===JSON.stringify(next.zodiacs)&&String(cur.open_time)===String(next.open_time))return prev}
         return [next,...prev.filter(x=>String(x.expect)!==String(next.expect))];
       });
     }catch{}
   };
   poll();const id=setInterval(poll,4000);return()=>{active=false;clearInterval(id)};
 },[]);

 // Always calculate from the complete server history, oldest -> newest.
 // 30/50/100/200/500 only changes how many rows are rendered.
 const allMapped=useMemo(()=>liveRows.map(r=>{
   const nums=(r.numbers||[]).map(Number),rowOffset=rowZodiacOffset(nums,r.zodiacs||[],r.open_time);
   const zs=nums.map((n,i)=>normalizeZodiac(r.zodiacs?.[i])||zodiacByNumber(n,rowOffset));
   const chosen=mode==='special'?nums.slice(6,7):nums.slice(0,6);
   const z=mode==='special'?zs.slice(6,7):zs.slice(0,6);
   const hits:Record<string,number[]>={};
   chosen.forEach((n,i)=>{const v=valueFor(metric,n,z[i]);if(v)(hits[v]||(hits[v]=[])).push(n)});
   return {...r,zodiacs:zs,hits};
 }),[liveRows,mode,metric]);

 const omissionByExpect=useMemo(()=>{
   const running:Record<string,number>={},out=new Map<string,Record<string,number>>();
   for(const r of [...allMapped].reverse()){
     const row:Record<string,number>={};
     for(const c of cols){if((r.hits[c]||[]).length){running[c]=0;row[c]=0}else{running[c]=(running[c]||0)+1;row[c]=running[c]}}
     out.set(String(r.expect),row);
   }
   return out;
 },[allMapped,cols]);

 const view=useMemo(()=>allMapped.slice(0,limit),[allMapped,limit]);
 const totals=useMemo(()=>{const out:Record<string,number>={};for(const r of view)for(const c of cols)out[c]=(out[c]||0)+(r.hits[c]?.length||0);return out},[view,cols]);
 const latestOmission=useMemo(()=>{const first=allMapped[0];return first?(omissionByExpect.get(String(first.expect))||{}):{} as Record<string,number>},[allMapped,omissionByExpect]);
 const cell=metric==='number'?42:metric==='zodiac'?70:metric==='tail'?58:68;
 const style={'--trendZoom':zoom,'--trendCell':`${cell}px`} as CSSProperties;
 const fullWidthMetric=['wave','oe','size','element','head'].includes(metric);

 const enterLandscape=async()=>{
   if(viewportRef.current)savedScroll.current={left:viewportRef.current.scrollLeft};
   setLandscape(true);try{await deckRef.current?.requestFullscreen?.()}catch{}try{const o=(screen.orientation as any);if(o?.lock)await o.lock('landscape')}catch{}
   setTimeout(()=>setVirtualLandscape(window.innerHeight>window.innerWidth),350);
 };
 const exitLandscape=async()=>{
   setVirtualLandscape(false);setLandscape(false);try{(screen.orientation as any)?.unlock?.()}catch{}try{if(document.fullscreenElement)await document.exitFullscreen()}catch{}
   requestAnimationFrame(()=>{if(viewportRef.current)viewportRef.current.scrollLeft=savedScroll.current.left});
 };
 useEffect(()=>{if(!landscape)return;const onResize=()=>setVirtualLandscape(window.innerHeight>window.innerWidth);window.addEventListener('resize',onResize);return()=>window.removeEventListener('resize',onResize)},[landscape]);
 useEffect(()=>()=>{try{(screen.orientation as any)?.unlock?.()}catch{}},[]);

 return <section ref={deckRef} className={`trendVisualDeck v326Trend v412TrendLocked metricDeck-${metric} ${fullWidthMetric?'trendFullWidthMetric':''} ${noOmissionMetric?'trendNoOmission':''} ${landscape?'trendLandscape':''} ${virtualLandscape?'trendLandscapeVirtual':''}`} style={style}>
   <div className="trendControlInside v324TrendControls v412TrendControls">
     <div className="trendMetricScroller" aria-label="走势类型">{metrics.map(([k,n])=><button type="button" className={metric===k?'active':''} onClick={()=>setMetric(k)} key={k}>{n}走势</button>)}</div>
     <div className="trendPeriodScroller"><span>{mode==='special'?'特码':'正码'} · {Math.min(limit,allMapped.length)}期</span>{periods.map(n=><button type="button" className={limit===n?'active':''} onClick={()=>setLimit(n)} key={n}>{n}期</button>)}</div>
     <div className="trendViewModes" aria-label="走势图显示比例">{presets.map(([,name,z])=><button key={name} type="button" className={Math.abs(zoom-z)<.03?'active':''} onClick={()=>setZoom(z)}>{name}</button>)}<div className="trendZoom"><button type="button" aria-label="缩小" onClick={()=>setZoom(v=>Math.max(.62,Number((v-.08).toFixed(2))))}>−</button><b>{Math.round(zoom*100)}%</b><button type="button" aria-label="放大" onClick={()=>setZoom(v=>Math.min(1.48,Number((v+.08).toFixed(2))))}>＋</button></div><button type="button" className="trendLandscapeBtn" onClick={landscape?exitLandscape:enterLandscape}>{landscape?'返回竖屏':'横向查看'}</button></div>
   </div>
   <div className="trendLockedBody">
     <div className="trendFixedPeriodPane" aria-hidden="true">
       <table className="trendFixedPeriodTable">
         <thead><tr><th>期号</th></tr></thead>
         <tbody>{view.map((r:any)=><tr key={r.expect}><td><b>{short(String(r.expect))}</b><small>{r.open_time?new Date(r.open_time).toLocaleDateString('zh-CN',{timeZone:'Asia/Shanghai',month:'2-digit',day:'2-digit'}):''}</small></td></tr>)}</tbody>
         <tfoot>{!noOmissionMetric&&<tr><th>当前遗漏</th></tr>}<tr><th>出现</th></tr></tfoot>
       </table>
     </div>
     <div className="trendDataPane">
       <div ref={viewportRef} className="trendDataScroller" role="region" aria-label={`${mode==='special'?'特码':'正码'}走势，仅数据区域可左右滑动`} onScroll={showSwipeHint?(e=>{if(e.currentTarget.scrollLeft>8)setShowSwipeHint(false)}):undefined} onPointerDown={()=>{if(showSwipeHint)setShowSwipeHint(false)}}>
         <table className={`trendDataMatrix metric-${metric}`}>
           <thead><tr>{cols.map(c=><th key={c}><span>{c}</span></th>)}</tr></thead>
           <tbody>{view.map((r:any)=><tr key={r.expect}>{cols.map(c=>{const hits=r.hits[c]||[],omit=omissionByExpect.get(String(r.expect))?.[c]||0;return <td key={c} className={hits.length?'trendHitCell':''}>{hits.length?(noOmissionMetric?<span className={`trendAttributeHit trendAttribute-${metric}`}>{c}</span>:<span className="trendHitBalls">{hits.map((n:number,i:number)=><OfficialBall n={n} small key={`${n}-${i}`} className="trendChartBall"/>)}</span>):(noOmissionMetric?<span className="trendAttributeBlank">·</span>:<span className="trendOmit" style={{'--omitColor':omissionColor(metric,c)} as CSSProperties}>{omit}</span>)}</td>})}</tr>)}</tbody>
           <tfoot>{!noOmissionMetric&&<tr>{cols.map(c=><td key={c}><b>{latestOmission[c]||0}</b></td>)}</tr>}<tr>{cols.map(c=><td key={c}><b>{totals[c]||0}</b></td>)}</tr></tfoot>
         </table>
       </div>
       {showSwipeHint&&cols.length>4&&<button type="button" className="trendSwipeHint v330SwipeHint v412SwipeHint" onClick={()=>{if(viewportRef.current){viewportRef.current.scrollBy({left:Math.max(180,viewportRef.current.clientWidth*.62),behavior:'smooth'});setShowSwipeHint(false)}}}><i>‹</i><span>左右滑动查看更多</span><i>›</i></button>}
     </div>
   </div>
 </section>;
}
