'use client';
import {useEffect,useMemo,useRef,useState} from 'react';
import Link from 'next/link';
import {OfficialBall} from './Balls';
type Daily={used:boolean;date?:string;result?:{number?:number;numbers?:number[]};created_at?:string};
const floatNums=[1,5,8,12,18,22,25,29,33,37,41,46,49,3,16,28];
function fmt(n:number){return String(n).padStart(2,'0')}
function timeText(v?:string){if(!v)return '';try{return new Date(v).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false})}catch{return ''}}
export default function RandomDrawMachine(){
 const [random,setRandom]=useState<Daily>({used:false}),[manual,setManual]=useState<Daily>({used:false}),[mode,setMode]=useState<'random'|'manual'>('random'),[spinning,setSpinning]=useState(false),[reveal,setReveal]=useState<number|null>(null),[inputs,setInputs]=useState(['','','','','','']),[error,setError]=useState('');
 const refs=useRef<Array<HTMLInputElement|null>>([]);
 const load=async(type:'random_number'|'manual_number')=>{try{const r=await fetch(`/api/daily-choice?type=${type}&ts=${Date.now()}`,{cache:'no-store'}),j=await r.json();if(j.ok){const state={used:!!j.used,date:j.date,result:j.result,created_at:j.created_at};type==='random_number'?setRandom(state):setManual(state)}}catch{}};
 useEffect(()=>{load('random_number');load('manual_number')},[]);
 useEffect(()=>{const d=mode==='random'?random:manual;if(d.used&&d.result?.number)setReveal(Number(d.result.number));else setReveal(null)},[mode,random,manual]);
 const complete=useMemo(()=>{const nums=inputs.map(v=>Number(v));return nums.length===6&&nums.every(n=>Number.isInteger(n)&&n>=1&&n<=49)&&new Set(nums).size===6},[inputs]);
 const setInput=(i:number,value:string)=>{setError('');let v=value.replace(/\D/g,'').slice(0,2);const next=[...inputs];next[i]=v;setInputs(next);if(v.length===2){const n=Number(v);if(n<1||n>49){setError('号码范围为01-49');return}if(next.some((x,idx)=>idx!==i&&x&&Number(x)===n)){setError('号码不能重复');next[i]='';setInputs(next);return}if(i<5)setTimeout(()=>refs.current[i+1]?.focus(),20)}};
 const run=async()=>{const type=mode==='random'?'random_number':'manual_number';const state=mode==='random'?random:manual;if(state.used||spinning)return;if(mode==='manual'&&!complete){setError('请依次输入6个不同的01-49号码');return}setSpinning(true);setError('');setReveal(null);try{const r=await fetch('/api/daily-choice',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({type,numbers:mode==='manual'?inputs.map(Number):undefined})}),j=await r.json();if(!r.ok){setError(j.error||'暂时无法摇号');return}await new Promise(resolve=>setTimeout(resolve,3000));const state2={used:true,date:j.date,result:j.result,created_at:j.created_at};type==='random_number'?setRandom(state2):setManual(state2);setReveal(Number(j.result?.number||0)||null)}catch{setError('暂时无法摇号，请稍后再试')}finally{setSpinning(false)}};
 const state=mode==='random'?random:manual;
 return <main className="v411RandomPage">
   <header className="v411RandomHeader"><Link href="/">‹ 返回开奖</Link><div><b>随机摇号</b><span>每日独立机会 · 仅摇出一个特码</span></div><i aria-hidden="true"/></header>
   <section className={`v411MachineStage v412MachineStage ${spinning?'isSpinning':''}`}>
     <div className="v412MachineArtwork" aria-hidden="true"/>
     <div className="v412GlassMotion" aria-hidden="true">{floatNums.slice(0,10).map((n,i)=><span className={`v412MotionBall mb${i+1}`} key={`${n}-${i}`}><OfficialBall n={n} mini/></span>)}</div>
     <div className="v412ResultPort" aria-label={reveal?`今日摇号结果 ${fmt(reveal)}`:'摇号结果出口'}>{spinning?<span className="v411LoadingDots"><i/><i/><i/></span>:reveal?<OfficialBall n={reveal} special/>:<em>?</em>}</div>
     <div className="v412MachineStatus"><span/><b>{spinning?'正在摇号':'单球摇奖机'}</b><span/></div>
   </section>

   <section className="v411ModeCards">
     <button type="button" className={`v411ModeCard ${mode==='random'?'active':''}`} onClick={()=>setMode('random')}><span className="v411ModeIcon">✦</span><div><b>随机摇号</b><small>{random.used?'今日结果已锁定':'系统从01-49中随机摇出1个'}</small></div><strong>{random.used?'已用':'可摇'}</strong></button>
     <button type="button" className={`v411ModeCard ${mode==='manual'?'active':''}`} onClick={()=>setMode('manual')}><span className="v411ModeIcon">⌨</span><div><b>手动六码</b><small>{manual.used?'今日结果已锁定':'输入6个号码，再从中摇出1个'}</small></div><strong>{manual.used?'已用':'可摇'}</strong></button>
   </section>

   {mode==='manual'&&<section className="v411ManualPanel"><header><b>依次输入6个号码</b><span>输入两位后自动跳到下一格</span></header><div className="v411SixInputs">{inputs.map((v,i)=><label className={v&&Number(v)>=1&&Number(v)<=49?'filled':''} key={i}><small>{i+1}</small><input ref={el=>{refs.current[i]=el}} inputMode="numeric" value={v} onChange={e=>setInput(i,e.target.value)} placeholder="00" maxLength={2}/></label>)}</div></section>}

   <section className="v411ResultCard v412ActionPanel"><div className="v411ResultMeta"><span>{state.used?'今日结果已锁定':mode==='manual'?'手动六码准备区':'随机摇号准备区'}</span><b>{state.used&&state.created_at?timeText(state.created_at):'每天一次机会'}</b></div><button type="button" className="v411StartButton v412StartButton" disabled={spinning||state.used||(mode==='manual'&&!complete)} onClick={run}>{state.used?`今日结果 · ${reveal?fmt(reveal):'—'}`:spinning?'正在摇号…':mode==='manual'?'从六码中摇出1个':'开始随机摇号'}</button>{error&&<small className="v411MachineError">{error}</small>}</section>

   <section className="v411RuleCard"><div><i/><b>使用说明</b><i/></div><p>随机摇号与手动六码各自每天可使用一次，两种机会互不占用。</p><p>手动六码需输入6个不同的01-49号码，系统从这6个号码中摇出1个结果。</p><p>结果仅作娱乐参考；浏览器清除网站数据后，网页可能无法继续识别为同一设备。</p></section>
 </main>;
}
