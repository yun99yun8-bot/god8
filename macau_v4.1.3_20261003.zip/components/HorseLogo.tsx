export default function HorseLogo({compact=false}:{compact?:boolean}){
  return <span className={`horseLogo horseLogoV324 ${compact?'compact':''}`} aria-hidden="true">
    <img src="/ai-sprite-v324.png?v=324" alt="" draggable={false}/>
  </span>
}
