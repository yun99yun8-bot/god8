'use client';
import LatestDraw from './LatestDraw';
import OmissionPanel from './OmissionPanel';
export default function HomeDraw({initial}:{initial:any}){return <section className="homeDrawWrap v31Home"><LatestDraw initial={initial}/><OmissionPanel/></section>}
