'use client';
import ShareCardButton from './ShareCardButton';
export default function DrawShareButton({expect,openTime,numbers,zodiacs}:{expect?:string;openTime?:string;numbers:number[];zodiacs:string[]}){const time=openTime?new Date(openTime).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false}):'';return <ShareCardButton className="drawShareBtn" label="分享" variant="draw" title="开奖结果分享卡" subtitle={`第 ${expect||'—'} 期 · ${time}`} sections={[{label:'开奖号码',values:numbers},{label:'生肖',values:zodiacs.filter(Boolean)}]}/>}
