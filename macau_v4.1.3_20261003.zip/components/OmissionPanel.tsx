'use client';
import {useEffect,useState} from 'react';
type Item={number:number;regularMiss:number;specialMiss:number;zodiac:string};
export default function OmissionPanel(){
 const [mode,setMode]=useState<'special'|'regular'>('special'),[items,setItems]=useState<Item[]>([]),[draws,setDraws]=useState(0);
 useEffect(()=>{let alive=true;const load=async()=>{try{const r=await fetch('/api/omission?ts='+Date.now(),{cache:'no-store'}),j=await r.json();if(alive&&j.ok){setItems(j.items||[]);setDraws(Number(j.drawsWindow||0))}}catch{}};load();const t=setInterval(load,10000);return()=>{alive=false;clearInterval(t)}},[]);
 return <section className="homeOmission v32Omission v330Omission"><div className="omissionTabs"><button className={mode==='special'?'active':''} onClick={()=>setMode('special')}>特码遗漏</button><button className={mode==='regular'?'active':''} onClick={()=>setMode('regular')}>正码遗漏</button><span>永久统计 · {draws}期</span></div><div className="omission49">{items.map(x=>{const miss=mode==='special'?x.specialMiss:x.regularMiss;return <div className={miss>100?'omitAlert omissionAlert':''} key={x.number}><b>{String(x.number).padStart(2,'0')}</b><span title={miss>100?'遗漏超过100期':undefined}>{miss}</span></div>})}</div></section>
}
