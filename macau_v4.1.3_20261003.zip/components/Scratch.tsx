'use client';
import {useEffect,useRef,useState,type PointerEvent} from 'react';
import Balls from './Balls';

type Point={x:number;y:number;pressure:number};

export default function Scratch({numbers,labels}:{numbers:number[],labels?:string[]}){
  const canvas=useRef<HTMLCanvasElement>(null);
  const zone=useRef<HTMLDivElement>(null);
  const dragging=useRef(false);
  const last=useRef<Point|null>(null);
  const lastMeasure=useRef(0);
  const [progress,setProgress]=useState(0);
  const [seed,setSeed]=useState(0);

  const measureProgress=(force=false)=>{
    const x=canvas.current;if(!x)return;
    const now=performance.now();if(!force&&now-lastMeasure.current<150)return;lastMeasure.current=now;
    const ctx=x.getContext('2d',{willReadFrequently:true});if(!ctx)return;
    const {width,height}=x;const img=ctx.getImageData(0,0,width,height).data;
    let transparent=0,total=0;
    const step=Math.max(6,Math.round((window.devicePixelRatio||1)*7));
    for(let py=0;py<height;py+=step){for(let px=0;px<width;px+=step){total++;if(img[(py*width+px)*4+3]<80)transparent++;}}
    setProgress(Math.min(99,Math.round((transparent/Math.max(1,total))*100)));
  };

  const paint=()=>{
    const x=canvas.current,z=zone.current;if(!x||!z)return;
    const rect=z.getBoundingClientRect(),dpr=Math.max(1,Math.min(3,window.devicePixelRatio||1));
    x.width=Math.max(1,Math.round(rect.width*dpr));x.height=Math.max(1,Math.round(rect.height*dpr));
    x.style.width=rect.width+'px';x.style.height=rect.height+'px';
    const ctx=x.getContext('2d')!;ctx.setTransform(dpr,0,0,dpr,0,0);ctx.globalCompositeOperation='source-over';ctx.globalAlpha=1;
    const g=ctx.createLinearGradient(0,0,rect.width,rect.height);
    g.addColorStop(0,'#777f84');g.addColorStop(.09,'#d7dcde');g.addColorStop(.22,'#8d959a');g.addColorStop(.38,'#f1f3f3');g.addColorStop(.55,'#a4acb0');g.addColorStop(.73,'#e3e6e7');g.addColorStop(.9,'#8c9499');g.addColorStop(1,'#cdd2d4');
    ctx.fillStyle=g;ctx.fillRect(0,0,rect.width,rect.height);
    // foil grain and soft scratches: deterministic, lightweight, looks like real silver coating
    for(let i=0;i<520;i++){
      const px=((i*73+seed*31)%1009)/1009*rect.width,py=((i*127+seed*17)%1013)/1013*rect.height;
      const a=.025+((i*11)%21)/350;
      ctx.fillStyle=`rgba(${i%3?255:56},${i%3?255:62},${i%3?255:67},${a})`;
      ctx.fillRect(px,py,0.7+(i%4)*.55,0.7+(i%3)*.45);
    }
    ctx.strokeStyle='rgba(70,76,81,.14)';ctx.lineWidth=.65;
    for(let i=0;i<26;i++){const y=(i+1)*rect.height/27;ctx.beginPath();ctx.moveTo(0,y);ctx.bezierCurveTo(rect.width*.27,y+((i%3)-1)*3,rect.width*.7,y-((i%4)-1.5)*2.2,rect.width,y+((i%5)-2)*1.2);ctx.stroke()}
    ctx.fillStyle='rgba(255,255,255,.92)';ctx.font='800 13px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif';ctx.textAlign='center';ctx.shadowColor='rgba(0,0,0,.22)';ctx.shadowBlur=2;ctx.fillText('用手指慢慢刮开号码',rect.width/2,rect.height/2+5);ctx.shadowBlur=0;
    setProgress(0);last.current=null;lastMeasure.current=0;
  };

  useEffect(()=>{paint()},[numbers.join(','),seed]);

  const eraseStroke=(from:Point,to:Point)=>{
    const x=canvas.current;if(!x)return;const ctx=x.getContext('2d')!,dpr=Math.max(1,Math.min(3,window.devicePixelRatio||1));
    const pressure=Math.max(.45,Math.min(1,to.pressure||.55));
    const width=7.5+pressure*3.5;
    ctx.save();ctx.setTransform(dpr,0,0,dpr,0,0);ctx.globalCompositeOperation='destination-out';ctx.lineCap='round';ctx.lineJoin='round';
    // primary scratch is intentionally narrow: it takes several passes to reveal one ball
    ctx.globalAlpha=.78;ctx.lineWidth=width;ctx.beginPath();ctx.moveTo(from.x,from.y);ctx.lineTo(to.x,to.y);ctx.stroke();
    // irregular micro-gaps make the edge look scraped rather than digitally erased
    const dx=to.x-from.x,dy=to.y-from.y,dist=Math.max(1,Math.hypot(dx,dy)),parts=Math.max(1,Math.ceil(dist/5));
    ctx.globalAlpha=.32;
    for(let s=0;s<=parts;s++){
      const t=s/parts,cx=from.x+dx*t,cy=from.y+dy*t;
      for(let k=0;k<2;k++){
        const phase=(s*2+k+seed%7)*2.31,rad=width*(.32+.18*k);
        ctx.beginPath();ctx.arc(cx+Math.cos(phase)*rad,cy+Math.sin(phase)*rad,1.15+(k*.55),0,Math.PI*2);ctx.fill();
      }
    }
    ctx.restore();measureProgress();
  };

  const point=(e:PointerEvent<HTMLCanvasElement>):Point=>{const r=e.currentTarget.getBoundingClientRect();return {x:e.clientX-r.left,y:e.clientY-r.top,pressure:e.pressure||.55}};
  const down=(e:PointerEvent<HTMLCanvasElement>)=>{dragging.current=true;e.preventDefault();e.currentTarget.setPointerCapture?.(e.pointerId);const p=point(e);last.current=p;eraseStroke(p,p)};
  const move=(e:PointerEvent<HTMLCanvasElement>)=>{if(!dragging.current)return;e.preventDefault();const p=point(e),prev=last.current;if(!prev){last.current=p;return}const dx=p.x-prev.x,dy=p.y-prev.y,d=Math.hypot(dx,dy),steps=Math.max(1,Math.ceil(d/4));let a=prev;for(let i=1;i<=steps;i++){const b={x:prev.x+dx*i/steps,y:prev.y+dy*i/steps,pressure:p.pressure};eraseStroke(a,b);a=b}last.current=p};
  const up=()=>{dragging.current=false;last.current=null;measureProgress(true)};

  return <div className="scratchReal v31Scratch v322Scratch">
    <div className="scratchNumberZone" ref={zone}>
      <Balls numbers={numbers} labels={labels}/>
      <canvas ref={canvas} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up}/>
    </div>
    <div className="scratchMeter"><span style={{width:`${progress}%`}}/><small>已刮 {progress}%</small><button type="button" onClick={()=>setSeed(v=>v+1)}>重新覆盖</button></div>
  </div>;
}
