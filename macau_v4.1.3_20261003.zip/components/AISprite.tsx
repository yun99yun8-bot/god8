'use client';
import {useEffect,useRef,useState} from 'react';
import {usePathname} from 'next/navigation';
import HorseLogo from './HorseLogo';
type Msg={role:'ai'|'user';text:string;meta?:any};
const quick=['明天特码什么生肖历史占比最高？','08多久没出了？','最近500期红波占比','兔最近都跳到哪些生肖？'];
const tips:Record<string,string>={
 '/':'我已连接历史开奖，可以直接问号码、生肖、波色、五行、遗漏和走势。',
 '/history':'正在看历史记录。你可以继续问某一期、某个号码或生肖的历史表现。',
 '/data':'这里是号码走势图。可以直接问某个号码在当前窗口出现了多少次。',
 '/zodiac-jump':'这里会重放真实历史生肖跳转。你可以问起点、落点、方向、转了几下和出现次数。',
 '/library':'可以问生肖、五行、波色、家野肖对应的号码。',
 '/publish':'可以询问当前公布期号、玩法规则和历史核对方式。'
};
function tip(path:string){return tips[path]||Object.entries(tips).find(([k])=>k!=='/'&&path.startsWith(k))?.[1]||tips['/']}
export default function AISprite(){
 const path=usePathname();const [open,setOpen]=useState(false),[hidden,setHidden]=useState(false),[holding,setHolding]=useState(false),[q,setQ]=useState(''),[busy,setBusy]=useState(false),[listening,setListening]=useState(false),[mode,setMode]=useState<'special'|'regular'|'all'>('special'),[limit,setLimit]=useState(500),[hint,setHint]=useState(''),[msgs,setMsgs]=useState<Msg[]>([{role:'ai',text:'你好，我是澳门资料 AI 精灵。我会先直接回答，再告诉你使用了哪些历史数据。长按精灵 5 秒可以隐藏。'}]);
 const holdTimer=useRef<any>(null),longDone=useRef(false),rec=useRef<any>(null),chat=useRef<HTMLDivElement>(null);
 useEffect(()=>{try{setHidden(localStorage.getItem('macau_ai_hidden_v31')==='1')}catch{}},[]);
 useEffect(()=>{if(open)requestAnimationFrame(()=>{if(chat.current)chat.current.scrollTop=chat.current.scrollHeight})},[msgs,busy,open]);
 useEffect(()=>{if(!path.startsWith('/zodiac-jump')||hidden||open){setHint('');return}let alive=true;const day=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());const key='macau_zodiac_random_tip_'+day;try{if(localStorage.getItem(key)==='1')return}catch{}fetch('/api/daily-choice?type=zodiac&ts='+Date.now(),{cache:'no-store'}).then(r=>r.json()).then(j=>{if(!alive||j?.used)return;setHint('不知道怎么选？交给天命和运气，试试「随机选一肖」');try{localStorage.setItem(key,'1')}catch{}setTimeout(()=>{if(alive)setHint('')},6000)}).catch(()=>{});return()=>{alive=false}},[path,hidden,open]);
 useEffect(()=>()=>{clearTimeout(holdTimer.current);try{rec.current?.stop()}catch{}},[]);
 if(path.startsWith('/admin')||path.startsWith('/bm'))return null;
 const context=()=>{const last=[...msgs].reverse().find(m=>m.meta);return last?.meta||null};
 const ask=async(text=q)=>{const question=text.trim();if(!question||busy)return;setMsgs(m=>[...m,{role:'user',text:question}]);setQ('');setBusy(true);try{const r=await fetch('/api/ai/history',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({question,limit,mode,context:context(),page:path})});const d=await r.json();setMsgs(m=>[...m,{role:'ai',text:d.answer||d.error||'暂时无法完成这次查询。',meta:d.meta}])}catch{setMsgs(m=>[...m,{role:'ai',text:'数据连接暂时不可用，请稍后再试。'}])}finally{setBusy(false)}};
 const voice=()=>{if(listening){try{rec.current?.stop()}catch{};return}const W=window as any,R=W.SpeechRecognition||W.webkitSpeechRecognition;if(!R){setMsgs(m=>[...m,{role:'ai',text:'当前浏览器没有开放网页语音识别，可以直接使用手机键盘自带的语音听写。'}]);return}const r=new R();rec.current=r;r.lang='zh-CN';r.interimResults=false;r.onstart=()=>setListening(true);r.onend=()=>setListening(false);r.onerror=()=>setListening(false);r.onresult=(e:any)=>{const t=e.results?.[0]?.[0]?.transcript||'';setQ(t);if(t)ask(t)};r.start()};
 const startHold=()=>{longDone.current=false;setHolding(true);holdTimer.current=setTimeout(()=>{longDone.current=true;setHolding(false);setOpen(false);setHidden(true);try{localStorage.setItem('macau_ai_hidden_v31','1')}catch{}},5000)};
 const stopHold=()=>{clearTimeout(holdTimer.current);setHolding(false)};
 const restore=()=>{setHidden(false);try{localStorage.removeItem('macau_ai_hidden_v31')}catch{}};
 if(hidden)return <button className="aiRestore" onClick={restore}><HorseLogo compact/> 恢复精灵</button>;
 return <div className={`spriteSystem ${open?'isOpen':''}`}>{hint&&!open&&<div className="aiWakeHint">{hint}</div>}
   {open&&<section className="aiDock v31AiDock"><header><div className="horseBadge"><HorseLogo/></div><div><small>MACAU · INTELLIGENCE</small><b>资料智能精灵</b></div><button onClick={()=>setOpen(false)} aria-label="关闭">×</button></header><div className="aiWelcome"><span>ONLINE</span><p>{tip(path)}</p><small>长按右下角精灵 5 秒可隐藏 · 支持连续追问和上下文</small></div><div className="aiModeRow"><select value={mode} onChange={e=>setMode(e.target.value as any)}><option value="special">特码</option><option value="regular">正码</option><option value="all">全部7码</option></select><select value={limit} onChange={e=>setLimit(Number(e.target.value))}>{[30,50,100,200,500,1000,2000,5000].map(n=><option value={n} key={n}>近{n}期</option>)}</select></div><div className="aiQuick">{quick.map(x=><button key={x} onClick={()=>ask(x)}>{x}</button>)}</div><div className="spriteChat" ref={chat}>{msgs.slice(-18).map((m,i)=><div className={`spriteMsg ${m.role}`} key={i}><span>{m.role==='ai'?<HorseLogo compact/>:'你'}</span><p>{m.text}</p></div>)}{busy&&<div className="spriteThinking"><i/><i/><i/> 正在读取历史数据</div>}</div><div className="spriteComposer"><button className={listening?'listening':''} onClick={voice}>{listening?'■':'🎙'}</button><input value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==='Enter'&&ask()} placeholder="直接问我，例如：兔最近从马左跳几？"/><button onClick={()=>ask()} disabled={busy}>发送</button></div></section>}
   <button className={`aiHorseOrb v31HorseOrb ${holding?'holding':''}`} onPointerDown={startHold} onPointerUp={stopHold} onPointerCancel={stopHold} onPointerLeave={stopHold} onClick={()=>{if(longDone.current){longDone.current=false;return}setOpen(v=>!v)}} aria-label="AI资料精灵"><span className="holdRing"/><HorseLogo/><small>待唤醒</small></button>
 </div>;
}
