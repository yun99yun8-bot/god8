'use client';
import {useEffect,useMemo,useRef,useState} from 'react';
const DIRECT='https://live-macaujc.com/live/livestream/new.flv';
const HLS=process.env.NEXT_PUBLIC_HLS_URL||'/api/live/hls/index.m3u8';

function videoSchedule(d=new Date()){
  const cst=new Date(d.getTime()+8*3600000),y=cst.getUTCFullYear(),m=cst.getUTCMonth(),day=cst.getUTCDate();
  const start=Date.UTC(y,m,day,13,30,0),end=Date.UTC(y,m,day,14,10,0),now=d.getTime();
  const ready=now>=start&&now<=end,nextStart=now<start?start:Date.UTC(y,m,day+1,13,30,0),diff=Math.max(0,nextStart-now);
  const h=Math.floor(diff/3600000),mi=Math.floor(diff%3600000/60000),s=Math.floor(diff%60000/1000);
  return {ready,countdown:`${String(h).padStart(2,'0')}:${String(mi).padStart(2,'0')}:${String(s).padStart(2,'0')}`};
}

export default function LivePlayer(){
  const video=useRef<HTMLVideoElement>(null),[now,setNow]=useState(()=>new Date()),schedule=useMemo(()=>videoSchedule(now),[now]);
  const [state,setState]=useState('等待开奖'),[attempt,setAttempt]=useState(0);
  useEffect(()=>{const t=setInterval(()=>setNow(new Date()),1000);return()=>clearInterval(t)},[]);
  useEffect(()=>{
    if(!schedule.ready){setState('等待开奖');setAttempt(0);return}
    let dead=false,engine:any=null,retry:any=null,videoError:((e:Event)=>void)|null=null,canPlay:((e:Event)=>void)|null=null;
    const cleanup=()=>{if(retry)clearTimeout(retry);retry=null;try{engine?.destroy?.()}catch{}engine=null;const v=video.current;if(v){if(videoError)v.removeEventListener('error',videoError);if(canPlay)v.removeEventListener('canplay',canPlay);videoError=null;canPlay=null;try{v.pause()}catch{}v.removeAttribute('src');try{v.load()}catch{}}};
    const later=(why:string,ms=2800)=>{if(dead)return;setState(why);if(retry)clearTimeout(retry);retry=setTimeout(()=>{setAttempt(v=>v+1);boot()},ms)};
    async function boot(){
      if(dead)return;cleanup();const v=video.current;if(!v)return;setState('正在连接直播');
      const isIOS=/iPad|iPhone|iPod/.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
      const useNative=!!v.canPlayType('application/vnd.apple.mpegurl');
      try{
        canPlay=()=>{if(!dead){setState('直播中');v.play().catch(()=>setState('点击播放'))}};v.addEventListener('canplay',canPlay);
        videoError=()=>later('连接中断，正在重试',3000);v.addEventListener('error',videoError);
        if(useNative){v.src=`${HLS}${HLS.includes('?')?'&':'?'}t=${Date.now()}`;v.load();await v.play().catch(()=>{});return}
        try{
          const mod=await import('hls.js'),Hls=mod.default;
          if(Hls.isSupported()){
            engine=new Hls({liveSyncDurationCount:2,maxBufferLength:12,maxLiveSyncPlaybackRate:1.1,manifestLoadingTimeOut:8000,levelLoadingTimeOut:8000,fragLoadingTimeOut:10000});
            engine.loadSource(`${HLS}${HLS.includes('?')?'&':'?'}t=${Date.now()}`);engine.attachMedia(v);
            engine.on(Hls.Events.MANIFEST_PARSED,()=>{if(!dead){setState('直播中');v.play().catch(()=>setState('点击播放'))}});
            engine.on(Hls.Events.ERROR,(_e:any,data:any)=>{if(dead||!data?.fatal)return;if(data.type===Hls.ErrorTypes.MEDIA_ERROR){try{engine?.recoverMediaError?.();setState('直播恢复中');return}catch{}}later('连接中断，正在重试',2800)});
            return;
          }
        }catch(e){if(isIOS)throw e}
        const mod:any=await import('mpegts.js'),mpegts=mod.default||mod;
        if(mpegts.getFeatureList?.().mseLivePlayback){
          engine=mpegts.createPlayer({type:'flv',isLive:true,url:process.env.NEXT_PUBLIC_LIVE_FLV_URL||DIRECT},{enableWorker:true,enableStashBuffer:false,stashInitialSize:128,lazyLoad:false});
          engine.attachMediaElement(v);engine.load();engine.on?.(mpegts.Events.ERROR,()=>later('连接中断，正在重试',3000));v.play().catch(()=>setState('点击播放'));return;
        }
        later('当前设备正在等待兼容直播流',3500);
      }catch{later('连接中断，正在重试',3000)}
    }
    boot();return()=>{dead=true;cleanup()};
  },[schedule.ready]);

  return <div className={`livebox premiumLive ${schedule.ready?'isLive':'isWaiting'}`}>
    <video ref={video} controls playsInline autoPlay muted preload="none" style={{display:schedule.ready?'block':'none'}} onPlay={()=>setState('直播中')}/>
    {!schedule.ready&&<div className="videoWaiting"><span>等待开奖时间</span><b>{schedule.countdown}</b><small>21:30（北京时间）自动切换视频开奖</small></div>}
    <div className="videoState"><i className={schedule.ready&&state==='直播中'?'on':''}/> {schedule.ready?state:`等待开奖 · ${schedule.countdown}`}{schedule.ready&&attempt>0?<small> · 自动重连 {attempt}</small>:null}</div>
  </div>
}
