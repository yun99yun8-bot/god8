import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import pg from 'pg';
const {Pool}=pg;

if(!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required');
const db=new Pool({
  connectionString:process.env.DATABASE_URL,
  ssl:process.env.DATABASE_URL.includes('localhost')?false:{rejectUnauthorized:false},
  max:4,
  idleTimeoutMillis:30000,
  connectionTimeoutMillis:10000
});
const live=process.env.LIVE_DRAW_URL||'https://macaumarksix.com/api/macaujc2.com';
const sec=Math.max(2,Number(process.env.POLL_SECONDS||3));
let lastLoggedExpect='';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

const ZODIAC_ORDER=['鼠','牛','虎','兔','龙','蛇','马','羊','猴','鸡','狗','猪'];
const LUCKY_SOURCE_URL=process.env.LUCKY_ZODIAC_SOURCE_URL||'https://astroverse.com.tw/zodiac-daily';
const LUCKY_SOURCE_NAME=process.env.LUCKY_ZODIAC_SOURCE_NAME||'星罗万象 · 每日生肖走势';
let luckyBusy=false;
let luckySchemaReady=false;
async function ensureLuckySchema(){
  if(luckySchemaReady)return;
  await db.query(`CREATE TABLE IF NOT EXISTS daily_zodiac_fortune (id BIGSERIAL PRIMARY KEY,fortune_date DATE NOT NULL UNIQUE,source VARCHAR(120) NOT NULL,source_url TEXT NOT NULL,source_time TEXT,content JSONB NOT NULL DEFAULT '{}'::jsonb,fetched_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
  luckySchemaReady=true;
}
function bjClock(){
  const p=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(new Date());
  const o=Object.fromEntries(p.map(x=>[x.type,x.value]));
  return {date:`${o.year}-${o.month}-${o.day}`,hour:Number(o.hour),minute:Number(o.minute)};
}
function cleanHtml(html=''){
  return String(html).replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,' ').replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,' ')
    .replace(/<(br|p|div|li|h1|h2|h3|h4|section|article)\b[^>]*>/gi,'\n').replace(/<[^>]+>/g,' ')
    .replace(/&nbsp;|&#160;/gi,' ').replace(/&amp;/gi,'&').replace(/&lt;/gi,'<').replace(/&gt;/gi,'>').replace(/&quot;/gi,'"').replace(/&#39;/gi,"'")
    .replace(/[ \t]+/g,' ').replace(/\n\s*\n+/g,'\n').trim()
    .replace(/龍/g,'龙').replace(/馬/g,'马').replace(/雞/g,'鸡').replace(/豬/g,'猪');
}
function extractFortuneItems(text){
  const positions=[];
  for(const z of ZODIAC_ORDER){
    const keys=[`生肖${z}`,`${z}今日`,`${z}：`,`${z}:`];
    let pos=-1,key='';
    for(const k of keys){const i=text.indexOf(k);if(i>=0&&(pos<0||i<pos)){pos=i;key=k}}
    if(pos>=0)positions.push({z,pos,key});
  }
  positions.sort((a,b)=>a.pos-b.pos);
  const items=[];
  for(let i=0;i<positions.length;i++){
    const cur=positions[i],end=positions[i+1]?.pos??Math.min(text.length,cur.pos+1800);
    let body=text.slice(cur.pos,end).replace(cur.key,'').trim();
    body=body.replace(/^[-—:：\s]+/,'').slice(0,1200);
    const sm=body.match(/(?:运势|運勢|综合|綜合)?(?:指数|評分|评分)?[^0-9]{0,8}(100|[1-9]?\d)\s*分/);
    const score=sm?Number(sm[1]):null;
    let tag='今日走势';
    if(/六合|三合|大吉|特吉|旺|顺吉|吉祥/.test(body))tag='走势较强';
    else if(/相冲|逢冲|六冲|低谷|不利|衰|谨慎|慎重/.test(body))tag='注意波动';
    else if(/平稳|一般|中平/.test(body))tag='走势平稳';
    items.push({zodiac:cur.z,text:body,score,tag});
  }
  return items;
}
async function refreshLuckyZodiac(force=false){
  if(luckyBusy)return;
  const c=bjClock();
  if(!force&&c.hour<15)return;
  await ensureLuckySchema();
  const exists=await db.query('SELECT 1 FROM daily_zodiac_fortune WHERE fortune_date=$1 LIMIT 1',[c.date]);
  if(exists.rows.length)return;
  luckyBusy=true;
  try{
    const ctl=new AbortController();const timer=setTimeout(()=>ctl.abort(),15000);
    let r;try{r=await fetch(LUCKY_SOURCE_URL,{cache:'no-store',signal:ctl.signal,headers:{'user-agent':'Mozilla/5.0 MacauData/4.0.0','accept':'text/html,application/xhtml+xml'}})}finally{clearTimeout(timer)}
    if(!r.ok)throw new Error(`lucky source HTTP ${r.status}`);
    const html=await r.text();const text=cleanHtml(html);const items=extractFortuneItems(text);
    if(items.length<6)throw new Error(`lucky source parse incomplete (${items.length}/12)`);
    const title=(text.match(/(?:12|十二)\s*生肖[^\n]{0,45}(?:运势|運勢|走势|走勢)/)?.[0]||'每日生肖走势').slice(0,80);
    const content={title,items,summary:text.slice(0,500),sourceFetchedAt:new Date().toISOString()};
    await db.query(`INSERT INTO daily_zodiac_fortune(fortune_date,source,source_url,source_time,content,fetched_at) VALUES($1,$2,$3,$4,$5,NOW()) ON CONFLICT(fortune_date) DO UPDATE SET source=EXCLUDED.source,source_url=EXCLUDED.source_url,source_time=EXCLUDED.source_time,content=EXCLUDED.content,fetched_at=NOW()`,[c.date,LUCKY_SOURCE_NAME,LUCKY_SOURCE_URL,null,content]);
    await setting('lucky_zodiac_updated',{date:c.date,source:LUCKY_SOURCE_NAME,at:new Date().toISOString(),count:items.length});
    console.log(new Date().toISOString(),`LUCKY ZODIAC ${c.date} saved ${items.length}/12`);
  }catch(e){console.error(new Date().toISOString(),'LUCKY ZODIAC',String(e));try{await setting('lucky_zodiac_error',{date:c.date,at:new Date().toISOString(),error:String(e)})}catch{}}
  finally{luckyBusy=false}
}

function candidates(payload){
  const list=Array.isArray(payload)?payload:Array.isArray(payload?.data)?payload.data:[payload?.data||payload];
  return list.filter(Boolean).map(d=>{
    const raw=Array.isArray(d.openCode)?d.openCode:String(d.openCode||d.code||'').split(',');
    const numbers=raw.map(x=>Number(String(x).trim())).filter(n=>n>=1&&n<=49).slice(0,7);
    const waves=String(d.wave||'').split(',').map(x=>x.trim()).filter(Boolean).slice(0,numbers.length);
    const zodiacs=String(d.zodiac||'').split(',').map(x=>x.trim()).filter(Boolean).slice(0,numbers.length);
    return {d,numbers,waves,zodiacs};
  }).filter(x=>x.d?.expect);
}

function rank(a,b){
  const at=Date.parse(a?.d?.openTime||a?.d?.open_time||'');
  const bt=Date.parse(b?.d?.openTime||b?.d?.open_time||'');
  if(Number.isFinite(at)&&Number.isFinite(bt)&&at!==bt)return bt-at;
  return String(b?.d?.expect||'').localeCompare(String(a?.d?.expect||''),'zh-CN',{numeric:true,sensitivity:'base'});
}

async function setting(key,value){
  await db.query(`INSERT INTO app_settings(key,value,updated_at) VALUES($1,$2,NOW()) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=NOW()`,[key,value]);
}

async function heartbeat(extra={}){
  try{await setting('worker_heartbeat',{at:new Date().toISOString(),pollSeconds:sec,...extra})}catch{}
}

async function savePartial(x){
  const value={expect:String(x.d.expect),openTime:x.d.openTime||x.d.open_time||null,numbers:x.numbers,waves:x.waves,zodiacs:x.zodiacs};
  await setting('live_partial_draw',value);
  await setting('live_partial_updated',new Date().toISOString());
}

async function resolvedOpenTime(d,expect){
  const official=d.openTime||d.open_time||d.open_time_string||d.time||null;
  if(official)return official;
  const old=await db.query('SELECT open_time FROM draws WHERE expect=$1 LIMIT 1',[String(expect)]);
  if(old.rows[0]?.open_time)return old.rows[0].open_time;
  // Do not block a complete seven-number draw only because the provider publishes
  // openTime later than openCode. The official time will overwrite this fallback
  // automatically on a later poll.
  return new Date();
}


async function settleReporting(expect,numbers,zodiacs=[]){
  try{
    const q=await db.query(`SELECT id,play_type,payload,amount,odds FROM report_orders WHERE status='waiting' AND target_expect=$1 ORDER BY id`,[String(expect)]);
    const regular=(numbers||[]).slice(0,6).map(Number),special=Number(numbers?.[6]),actualZ=[...new Set((zodiacs||[]).map(x=>String(x).trim()).filter(Boolean))],specialZ=String(zodiacs?.[6]||'').trim();
    for(const o of q.rows){
      if((o.play_type==='平特一肖'||String(o.play_type).includes('连肖'))&&(!Array.isArray(zodiacs)||zodiacs.length<7))continue;
      const p=o.payload||{};let hit=false;
      if(o.play_type==='特码'){hit=[...(p.main||[]),...(p.defense||[])].map(Number).includes(special)}
      else if(o.play_type==='平特一肖'){hit=(p.zodiacs||[]).includes(specialZ)}
      else if(String(o.play_type).includes('连肖')){const req=Number((/^(\d+)连肖$/.exec(String(o.play_type))||[])[1]||0),zs=p.zodiacs||[];hit=req>0&&zs.length===req&&zs.every(z=>actualZ.includes(z))}
      else if(String(o.play_type).includes('中2')||String(o.play_type).includes('中3')){const g=p.groups?.[0]||[];hit=g.length>0&&g.every(n=>regular.includes(Number(n)))}
      const payout=hit?Number((Number(o.amount)*Number(o.odds)).toFixed(2)):0;
      await db.query(`UPDATE report_orders SET status='settled',hit=$1,payout=$2,settled_at=NOW() WHERE id=$3 AND status='waiting'`,[hit,payout,o.id]);
    }
    await refreshReportingDailyStats();
  }catch(e){console.error(new Date().toISOString(),'REPORT SETTLE',String(e))}
}
async function refreshReportingDailyStats(){
  try{
    const c=bjClock(),b1=`${c.date}T00:00:00+08:00`,b2=`${c.date}T23:59:59.999+08:00`;
    const all=await db.query(`SELECT COUNT(*)::int orders,COUNT(DISTINCT user_id)::int participants,COALESCE(SUM(amount),0)::numeric amount,COALESCE(SUM(CASE WHEN status='settled' THEN payout ELSE 0 END),0)::numeric payout FROM report_orders WHERE status<>'void' AND created_at BETWEEN $1 AND $2`,[b1,b2]);
    const a=all.rows[0]||{},payload={orders:Number(a.orders||0),participants:Number(a.participants||0),amount:Number(a.amount||0),payout:Number(a.payout||0),net:Number(a.amount||0)-Number(a.payout||0)};
    await db.query(`INSERT INTO report_daily_stats(stat_date,scope_key,payload,updated_at) VALUES($1,'all',$2,NOW()) ON CONFLICT(stat_date,scope_key) DO UPDATE SET payload=EXCLUDED.payload,updated_at=NOW()`,[c.date,payload]);
    const roots=await db.query(`SELECT id FROM report_users WHERE parent_id IS NULL`);
    for(const r of roots.rows){
      const q=await db.query(`WITH RECURSIVE t AS (SELECT id FROM report_users WHERE id=$1 UNION ALL SELECT u.id FROM report_users u JOIN t ON u.parent_id=t.id) SELECT COUNT(o.id)::int orders,COUNT(DISTINCT o.user_id)::int participants,COALESCE(SUM(o.amount),0)::numeric amount,COALESCE(SUM(CASE WHEN o.status='settled' THEN o.payout ELSE 0 END),0)::numeric payout FROM t LEFT JOIN report_orders o ON o.user_id=t.id AND o.status<>'void' AND o.created_at BETWEEN $2 AND $3`,[r.id,b1,b2]);
      const x=q.rows[0]||{},p={orders:Number(x.orders||0),participants:Number(x.participants||0),amount:Number(x.amount||0),payout:Number(x.payout||0),net:Number(x.amount||0)-Number(x.payout||0)};
      await db.query(`INSERT INTO report_daily_stats(stat_date,scope_key,payload,updated_at) VALUES($1,$2,$3,NOW()) ON CONFLICT(stat_date,scope_key) DO UPDATE SET payload=EXCLUDED.payload,updated_at=NOW()`,[c.date,`root:${r.id}`,p]);
    }
  }catch{}
}

async function save(x){
  const d=x.d,numbers=x.numbers;
  const openTime=await resolvedOpenTime(d,d.expect);
  const raw={...d,_ingest:{complete:true,usedOpenTimeFallback:!(d.openTime||d.open_time),receivedAt:new Date().toISOString()}};
  await db.query(`INSERT INTO draws(expect,open_time,numbers,waves,zodiacs,raw_json)
    VALUES($1,$2,$3,$4,$5,$6)
    ON CONFLICT(expect) DO UPDATE SET
      open_time=CASE WHEN EXCLUDED.raw_json->'_ingest'->>'usedOpenTimeFallback'='true' AND draws.raw_json->'_ingest'->>'usedOpenTimeFallback' IS DISTINCT FROM 'true' THEN draws.open_time ELSE EXCLUDED.open_time END,
      numbers=EXCLUDED.numbers,waves=EXCLUDED.waves,zodiacs=EXCLUDED.zodiacs,raw_json=EXCLUDED.raw_json,received_at=NOW()`,
    [String(d.expect),openTime,numbers,x.waves,x.zodiacs,raw]);
  await settleReporting(String(d.expect),numbers,x.zodiacs);
  if(String(d.expect)!==lastLoggedExpect){
    lastLoggedExpect=String(d.expect);
    console.log(new Date().toISOString(),'FULL DRAW SAVED',d.expect,numbers.join(','),d.openTime?'official-time':'fallback-time');
    try{await db.query(`INSERT INTO source_logs(source,status,message) VALUES('live-api','ok',$1)`,[`full draw ${d.expect} saved (${numbers.length}/7)`])}catch{}
  }
}

async function syncStatus(liveRow){
  const q=await db.query(`SELECT expect,open_time,received_at FROM draws ORDER BY open_time DESC,id DESC LIMIT 1`);
  const latest=q.rows[0]||null;
  const liveExpect=liveRow?String(liveRow.d.expect):null;
  const dbExpect=latest?String(latest.expect):null;
  const complete=!!liveRow&&liveRow.numbers.length===7;
  const synced=!complete||liveExpect===dbExpect;
  const value={liveExpect,liveCount:liveRow?.numbers.length||0,dbExpect,synced,checkedAt:new Date().toISOString()};
  await setting('live_sync_status',value);
  return value;
}

async function fetchOfficial(){
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),12000);
  try{
    const u=new URL(live);u.searchParams.set('_t',Date.now().toString());
    const r=await fetch(u,{cache:'no-store',signal:controller.signal,headers:{'cache-control':'no-cache, no-store, must-revalidate','pragma':'no-cache','accept':'application/json'}});
    if(!r.ok)throw new Error('HTTP '+r.status);
    return await r.json();
  }finally{clearTimeout(timer)}
}

async function once(){
  try{
    const j=await fetchOfficial();
    const rows=candidates(j).sort(rank);
    if(!rows.length){
      console.log(new Date().toISOString(),'WAITING official API has no draw payload yet');
      await heartbeat({state:'waiting'});
      return;
    }

    // The partial snapshot must always be the newest candidate. Older rows returned
    // by the provider must never overwrite the current live card.
    const newest=rows[0];
    await savePartial(newest);

    // Save complete rows with an official time, plus the newest complete row even if
    // openTime has not arrived yet. This removes the old "7 numbers but no DB row" stall.
    for(const x of rows){
      if(x.numbers.length!==7)continue;
      if(x.d.openTime||x.d.open_time||x===newest)await save(x);
    }

    let status=await syncStatus(newest);
    // Reconcile once immediately if a complete newest draw still did not land in DB.
    if(newest.numbers.length===7&&!status.synced){
      console.warn(new Date().toISOString(),'RECONCILE',status);
      await save(newest);
      status=await syncStatus(newest);
    }

    await heartbeat({state:'ok',expect:String(newest.d.expect),count:newest.numbers.length,synced:status.synced});
    if(newest.numbers.length<7)console.log(new Date().toISOString(),`PARTIAL ${newest.d.expect} ${newest.numbers.length}/7`,newest.numbers.join(','));
  }catch(e){
    const message=e?.name==='AbortError'?'official API timeout':String(e);
    console.error(new Date().toISOString(),message);
    await heartbeat({state:'error',error:message});
    try{await db.query(`INSERT INTO source_logs(source,status,message) VALUES('live-api','error',$1)`,[message])}catch{}
  }
}

process.on('SIGTERM',async()=>{try{await heartbeat({state:'stopping'})}catch{};await db.end().catch(()=>{});process.exit(0)});
process.on('SIGINT',async()=>{try{await heartbeat({state:'stopping'})}catch{};await db.end().catch(()=>{});process.exit(0)});

function startHistoryBackfill(){
  try{
    const script=fileURLToPath(new URL('./sync-history.mjs',import.meta.url));
    const child=spawn(process.execPath,[script],{stdio:['ignore','inherit','inherit'],env:process.env});
    child.on('exit',code=>console.log(new Date().toISOString(),`[history-backfill] exit ${code}`));
    child.on('error',e=>console.error(new Date().toISOString(),'[history-backfill]',String(e)));
  }catch(e){console.error(new Date().toISOString(),'[history-backfill] start failed',String(e))}
}

console.log(`[worker] resilient official sync every ${sec}s: ${live}`);
await heartbeat({state:'starting'});
// Historical backfill runs independently so live 3-second collection never waits on a large import.
startHistoryBackfill();
setInterval(startHistoryBackfill,6*60*60*1000).unref();
refreshLuckyZodiac().catch(()=>{});
setInterval(()=>refreshLuckyZodiac().catch(()=>{}),5*60*1000).unref();
while(true){await once();await sleep(sec*1000)}
