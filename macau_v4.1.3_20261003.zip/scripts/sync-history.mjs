import pg from 'pg';
const {Pool}=pg;
if(!process.env.DATABASE_URL)throw new Error('DATABASE_URL is required');
const db=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_URL.includes('localhost')?false:{rejectUnauthorized:false},max:3,connectionTimeoutMillis:10000});
const now=new Date();
const defaultYears=[now.getFullYear()-2,now.getFullYear()-1,now.getFullYear()];
const years=(process.env.SYNC_YEARS||defaultYears.join(',')).split(',').map(x=>x.trim()).filter(Boolean);
const tpl=process.env.HISTORY_URL_TEMPLATE||'https://history.macaumarksix.com/history/macaujc2/y/{year}';
const cutoff=new Date(now);cutoff.setFullYear(cutoff.getFullYear()-2);
let totalSaved=0,earliest=null,latest=null;
async function setting(key,value){await db.query(`INSERT INTO app_settings(key,value,updated_at) VALUES($1,$2,NOW()) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=NOW()`,[key,value])}
for(const year of years){
 const url=tpl.replace('{year}',year);console.log('[history] sync',url);
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),20000);
 try{
  const r=await fetch(url,{cache:'no-store',signal:controller.signal,headers:{'cache-control':'no-cache','accept':'application/json'}});if(!r.ok)throw new Error(`${r.status} ${url}`);
  const j=await r.json();const items=Array.isArray(j)?j:(Array.isArray(j?.data)?j.data:[]);let saved=0;
  for(const d of items){
   const numbers=(Array.isArray(d.openCode)?d.openCode:String(d.openCode||'').split(',')).map(x=>Number(String(x).trim())).filter(n=>n>=1&&n<=49).slice(0,7);
   const time=d.openTime||d.open_time||null;if(numbers.length!==7||!d.expect||!time)continue;
   const dt=new Date(time);if(!Number.isFinite(dt.getTime()))continue;
   // Fetch three calendar years so the rolling two-year window is complete across year boundaries.
   // Older already-stored rows are harmless and are not deleted.
   const waves=String(d.wave||'').split(',').map(x=>x.trim()).filter(Boolean),zodiacs=String(d.zodiac||'').split(',').map(x=>x.trim()).filter(Boolean);
   await db.query(`INSERT INTO draws(expect,open_time,numbers,waves,zodiacs,raw_json) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(expect) DO UPDATE SET open_time=EXCLUDED.open_time,numbers=EXCLUDED.numbers,waves=EXCLUDED.waves,zodiacs=EXCLUDED.zodiacs,raw_json=EXCLUDED.raw_json,received_at=NOW()`,[String(d.expect),time,numbers,waves,zodiacs,d]);
   saved++;totalSaved++;if(!earliest||dt<earliest)earliest=dt;if(!latest||dt>latest)latest=dt;
  }
  console.log(`[history] ${year}: ${saved}/${items.length} checked`);
 }finally{clearTimeout(timer)}
}
const range=await db.query(`SELECT MIN(open_time) min_time,MAX(open_time) max_time,COUNT(*)::int count,COUNT(*) FILTER (WHERE open_time >= $1)::int rolling_two_year_count FROM draws`,[cutoff]);
await setting('history_backfill_status',{at:new Date().toISOString(),years,cutoff:cutoff.toISOString(),saved:totalSaved,...range.rows[0]});
console.log('[history] done',range.rows[0]);
await db.end();
