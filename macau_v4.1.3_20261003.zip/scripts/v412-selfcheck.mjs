import fs from 'fs';
const read=p=>fs.readFileSync(p,'utf8');
let total=0,failed=0;function test(name,ok){total++;console.log(ok?'PASS':'FAIL',name);if(!ok)failed++}
const pkg=JSON.parse(read('package.json'));
const css=read('app/globals.css');
const trend=read('components/TrendVisualizer.tsx');
const random=read('components/RandomDrawMachine.tsx');
const recommend=read('app/recommend/page.tsx');
const pub=read('components/PublicationBoard.tsx');
const ph=read('app/publish/history/page.tsx');
const history=read('app/history/page.tsx');
const library=read('app/library/page.tsx');
const nav=read('components/Nav.tsx');
const latest=read('components/LatestDraw.tsx');
const ai=read('components/AISprite.tsx');
const zspin=read('components/ZodiacSpinner.tsx');
const reportShell=read('components/ReportGateShell.tsx');
const reportHome=read('components/ReportHome.tsx');
const reportCode=read('components/ReportCodeGate.tsx');
const reportPass=read('components/ReportPasswordGate.tsx');
const share=read('components/ShareCardButton.tsx');
const daily=read('app/api/daily-choice/route.ts');
const schema=read('sql/schema.sql');
const omission=read('components/OmissionPanel.tsx');
const hcontrols=read('components/HistoryControls.tsx');

test('version 4.1.2',pkg.version==='4.1.2');
test('health V4.1.2',read('app/api/health/route.ts').includes('macau-v4.1.2-trend-machine-history-fix'));
test('selfcheck registered',pkg.scripts?.['check:v412']==='node scripts/v412-selfcheck.mjs');

// Main navigation / home regression
test('four main nav entries',nav.includes('开奖结果')&&nav.includes('历史记录')&&nav.includes('数据中心')&&nav.includes('本站推荐'));
test('home video entry',latest.includes('href="/live"'));
test('home report entry',latest.includes('href="/bm"')&&latest.includes('报幕系统'));
test('random draw before share',/randomDrawEntry[\s\S]*DrawShareButton/.test(latest));
test('scratch preserved',latest.includes('刮刮开奖'));
test('premium video and report classes',latest.includes('v411VideoBtn')&&latest.includes('v411ReportBtn'));
test('permanent omission preserved',omission.includes('/api/omission')&&omission.includes('永久统计'));
test('omission divider preserved',css.includes('.omission49>div>b:after'));

// AI / zodiac
test('AI dormant default',ai.includes('待唤醒'));
test('AI random zodiac prompt',ai.includes('交给天命和运气')&&ai.includes('随机选一肖'));
test('zodiac random wording',zspin.includes('随机选一肖'));
test('zodiac once-daily device API',zspin.includes("type:'zodiac'")&&daily.includes("type==='zodiac'"));

// History / library
test('main history one-card class',history.includes('v411HistoryCard')&&history.includes('v411HistoryList'));
test('main history period visible',history.includes('第 {short(r.expect)} 期'));
test('history chooser compact text',hcontrols.includes('👈可选择'));
test('history default zodiac-only state',history.includes('hide-home hide-element hide-oe hide-wave'));
test('library top seven draw numbers',library.includes('numbers.slice(0,7)'));
test('library only special marked',library.includes('latestSpecialBall')&&library.includes('isLatestSpecial'));
test('library premium section divider',library.includes('luxuryAttributeSection')&&css.includes('.v411Library .luxuryAttributeSection:before'));

// Trend: actual DOM split, no fake sticky patch
test('trend default 62%',trend.includes('[zoom,setZoom]=useState(.62)'));
test('trend outer locked class',trend.includes('v412TrendLocked'));
test('trend separate fixed period pane',trend.includes('trendFixedPeriodPane')&&trend.includes('trendFixedPeriodTable'));
test('trend separate data pane',trend.includes('trendDataPane')&&trend.includes('trendDataScroller'));
test('trend old combined viewport removed',!trend.includes('className="trendViewport v324TrendViewport"'));
test('trend controls are non-scroll wrapping',css.includes('.v412TrendControls .trendMetricScroller')&&css.includes('flex-wrap:wrap!important')&&css.includes('overflow:visible!important'));
test('only data pane has horizontal overflow',css.includes('.trendDataScroller{')&&css.includes('overflow-x:auto!important;overflow-y:hidden!important'));
test('outer trend blocks horizontal gesture',css.includes('.v412TrendLocked{')&&css.includes('overscroll-behavior-x:none!important'));
test('fixed period pane overflow hidden',css.includes('.trendFixedPeriodPane{')&&css.includes('overflow:hidden!important'));
test('trend data no vertical scrolling',css.includes('overflow-x:auto!important;overflow-y:hidden!important'));
test('trend full-history omission preserved',trend.includes('[...allMapped].reverse()'));
test('trend ranges preserved',trend.includes('const periods=[30,50,100,200,500]'));

// Random draw exact approved visual direction
test('machine artwork asset exists',fs.existsSync('public/random-machine-v412.png'));
test('machine component uses artwork',random.includes('v412MachineArtwork'));
test('machine has interactive motion overlay',random.includes('v412GlassMotion')&&random.includes('v412MotionBall'));
test('machine result port overlays static artwork',random.includes('v412ResultPort'));
test('machine CSS uses approved artwork',css.includes("url('/random-machine-v412.png')"));
test('machine page responsive image stage',css.includes('.v412MachineStage{')&&css.includes('aspect-ratio:881/970'));
test('random and manual chances independent',random.includes('random_number')&&random.includes('manual_number')&&daily.includes('manual_number'));
test('manual exactly six entries',random.includes("['','','','','','']")&&random.includes('6个不同'));
test('manual auto advances',random.includes('refs.current[i+1]?.focus()'));
test('single-number result',random.includes('j.result?.number'));

// Recommendation / publication history
test('recommend duplicate top rail removed',!recommend.includes('recommendRail')&&!recommend.includes('历史记录 ›'));
test('recommend current publication board remains',recommend.includes('PublicationBoard'));
test('recommend lower history link dark',css.includes('.v412Recommend .publishHistoryLink{color:#111!important'));
test('publication history route preserved',pub.includes('href="/publish/history"'));
test('publication history one-period card',ph.includes('pubFoldCard')&&ph.includes('key={s.expect}'));
test('publication history period rendered once in head',ph.includes('pubCompactExpect')&&ph.includes('第 {s.expect} 期'));
test('publication history detail does not repeat period title',!ph.includes('当时公布 · 第')&&!ph.includes('实际开奖 · 第')&&!ph.includes('最终核对 · 第'));
test('publication history lazy detail fetch',ph.includes('history-detail')&&ph.includes('detailLoading'));
test('publication history V4.1.2 premium class',ph.includes('v412PubHistory')&&css.includes('.v412PubHistory .pubFoldCard'));
test('history summary becomes two rows on narrow mobile',css.includes('@media(max-width:520px)')&&css.includes('grid-template-columns:repeat(2,minmax(0,1fr))'));

// Reporting regression
test('report entry has return home',reportShell.includes('返回主页')&&reportHome.includes('返回主页'));
test('report bad code returns site home',reportCode.includes("router.replace('/')"));
test('remember device modal preserved',reportPass.includes('rememberDeviceCard')&&reportPass.includes('记住本机'));
test('report number picker preserved',reportHome.includes('reportNumberPicker'));
test('report zodiac picker preserved',reportHome.includes('reportZodiacPicker'));
test('report amount preserved',reportHome.includes('输入模拟金额'));
test('report expected payout preserved',reportHome.includes('预计模拟中奖'));
test('report confirm preserved',reportHome.includes('确认报幕'));
test('report user tabs preserved',reportHome.includes('我的记录')&&reportHome.includes('下线')&&reportHome.includes('统计'));
test('report tables preserved',schema.includes('report_users')&&schema.includes('report_orders')&&schema.includes('report_devices'));

// Sharing / baseline assets
test('share poster dragon retained',share.includes('draw-dragon-head-v400.png'));
test('share poster Macau skyline retained',share.includes('share-skyline-v41.png'));
test('share settings admin-driven',share.includes('/api/site-settings'));
test('CSS no escaped newline',!css.includes('\\n'));
test('CSS braces balanced',(css.match(/{/g)||[]).length===(css.match(/}/g)||[]).length);

console.log(`\nV4.1.2 regression checks: ${total-failed}/${total} passed`);
process.exit(failed?1:0);
