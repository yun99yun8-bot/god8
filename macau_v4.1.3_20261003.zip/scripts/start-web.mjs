import {spawn} from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import ffmpegStatic from 'ffmpeg-static';

const port=String(process.env.PORT||3000);
const source=process.env.LIVE_FLV_URL||'https://live-macaujc.com/live/livestream/new.flv';
const out=process.env.HLS_DIR||'/tmp/macau-hls';
const ffmpeg=ffmpegStatic||process.env.FFMPEG_PATH||'ffmpeg';
let stopping=false,ffmpegChild=null,nextChild=null,restartTimer=null;

function liveWindow(d=new Date()){
  const bj=new Date(d.getTime()+8*3600000),mins=bj.getUTCHours()*60+bj.getUTCMinutes();
  return mins>=21*60+28&&mins<=22*60+12;
}
function prepare(){
  fs.mkdirSync(out,{recursive:true});
  for(const name of fs.readdirSync(out)){if(/\.(?:m3u8|ts|m4s|tmp)$/.test(name)){try{fs.rmSync(path.join(out,name),{force:true})}catch{}}}
}
function startFfmpeg(){
  if(stopping||ffmpegChild||!liveWindow())return;prepare();
  const index=path.join(out,'index.m3u8'),segment=path.join(out,'seg%06d.ts');
  const args=['-hide_banner','-loglevel','warning','-reconnect','1','-reconnect_streamed','1','-reconnect_delay_max','5','-rw_timeout','15000000','-i',source,'-map','0:v:0?','-map','0:a:0?','-c:v','copy','-c:a','aac','-ar','44100','-ac','2','-f','hls','-hls_time','2','-hls_list_size','8','-hls_flags','delete_segments+append_list+omit_endlist+program_date_time','-hls_segment_filename',segment,index];
  console.log('[live-hls] starting',source,'->',index);
  ffmpegChild=spawn(ffmpeg,args,{stdio:['ignore','inherit','inherit'],env:process.env});
  ffmpegChild.on('error',e=>console.error('[live-hls] ffmpeg start failed:',String(e)));
  ffmpegChild.on('exit',code=>{ffmpegChild=null;if(stopping)return;if(liveWindow()){console.error('[live-hls] ffmpeg exited',code,'restart in 4s');restartTimer=setTimeout(()=>{restartTimer=null;startFfmpeg()},4000)}});
}
function stopFfmpeg(){
  if(restartTimer){clearTimeout(restartTimer);restartTimer=null}
  if(ffmpegChild){console.log('[live-hls] outside live window, stop converter');try{ffmpegChild.kill('SIGTERM')}catch{}ffmpegChild=null}
}
function liveTick(){if(stopping)return;if(liveWindow())startFfmpeg();else stopFfmpeg()}
function startNext(){
  const nextBin=path.join(process.cwd(),'node_modules','next','dist','bin','next');
  nextChild=spawn(process.execPath,[nextBin,'start','-p',port],{stdio:'inherit',env:process.env});
  nextChild.on('exit',code=>{if(!stopping){console.error('[web] next exited',code);shutdown(code||1)}});
}
function shutdown(code=0){
  if(stopping)return;stopping=true;if(restartTimer)clearTimeout(restartTimer);
  try{ffmpegChild?.kill('SIGTERM')}catch{}try{nextChild?.kill('SIGTERM')}catch{}
  setTimeout(()=>process.exit(code),700).unref();
}
process.on('SIGTERM',()=>shutdown(0));process.on('SIGINT',()=>shutdown(0));
startNext();liveTick();setInterval(liveTick,30000).unref();
