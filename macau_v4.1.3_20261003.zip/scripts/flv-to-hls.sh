#!/usr/bin/env bash
set -euo pipefail
SRC="${LIVE_FLV_URL:-https://live-macaujc.com/live/livestream/new.flv}"
OUT="${HLS_DIR:-./public/live}"
mkdir -p "$OUT"
exec ffmpeg -hide_banner -loglevel warning -reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5 -i "$SRC" -c:v copy -c:a aac -f hls -hls_time 2 -hls_list_size 6 -hls_flags delete_segments+append_list "$OUT/index.m3u8"
