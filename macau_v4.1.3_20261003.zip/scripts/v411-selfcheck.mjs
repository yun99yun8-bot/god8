import fs from 'fs';
const read=p=>fs.readFileSync(p,'utf8');
let total=0,failed=0;
function test(name,ok){total++;console.log(ok?'PASS':'FAIL',name);if(!ok)failed++}
const pkg=JSON.parse(read('package.json'));
const css=read('app/globals.css');
const nav=read('components/Nav.tsx');
const latest=read('components/LatestDraw.tsx');
const omission=read('components/OmissionPanel.tsx');
const ai=read('components/AISprite.tsx');
const zspin=read('components/ZodiacSpinner.tsx');
const trend=read('components/TrendVisualizer.tsx');
const history=read('app/history/page.tsx');
const hcontrols=read('components/HistoryControls.tsx');
const library=read('app/library/page.tsx');
const recommend=read('app/recommend/page.tsx');
const pub=read('components/PublicationBoard.tsx');
const pubHistory=read('app/publish/history/page.tsx');
const share=read('components/ShareCardButton.tsx');
const random=read('components/RandomDrawMachine.tsx');
const reportShell=read('components/ReportGateShell.tsx');
const reportCode=read('components/ReportCodeGate.tsx');
const reportPass=read('components/ReportPasswordGate.tsx');
const reportHome=read('components/ReportHome.tsx');
const reportDevice=read('app/api/report/device/route.ts');
const reportOrders=read('app/api/report/orders/route.ts');
const dailyChoice=read('app/api/daily-choice/route.ts');
const schema=read('sql/schema.sql');

// Version / package
test('version 4.1.1',pkg.version==='4.1.1');
test('health id',read('app/api/health/route.ts').includes('macau-v4.1.1-ui-regression-luxury'));
test('V4.1.1 selfcheck command registered',pkg.scripts?.['check:v411']==='node scripts/v411-selfcheck.mjs');

// Main shell and navigation
test('main nav keeps four entries',nav.includes('开奖结果')&&nav.includes('历史记录')&&nav.includes('数据中心')&&nav.includes('本站推荐'));
test('premium main nav override',css.includes('MACAU V4.1.1')&&css.includes('.luxuryNav .navGlass')&&css.includes('.navFour a.active'));
test('daily lucky link preserved',nav.includes('每日幸运生肖走势')&&fs.existsSync('app/lucky-zodiac/page.tsx'));
test('bookmark workflow preserved',nav.includes('添加书签')&&nav.includes('bookmarkShade'));

// Home draw / live / scratch / omission
test('home draw realtime polling preserved',latest.includes('/api/latest?ts=')&&latest.includes('/api/live-progress?ts='));
test('random draw entry remains before share',/randomDrawEntry[\s\S]*DrawShareButton/.test(latest));
test('scratch draw remains',latest.includes('Scratch')&&latest.includes('刮刮开奖'));
test('video page route remains',latest.includes('href="/live"')&&fs.existsSync('app/live/page.tsx'));
test('report route remains',latest.includes('href="/bm"')&&latest.includes('报幕系统'));
test('premium video/report buttons',latest.includes('v411VideoBtn')&&latest.includes('v411ReportBtn')&&css.includes('.v411VideoBtn')&&css.includes('.v411ReportBtn'));
test('permanent omission API preserved',omission.includes('/api/omission')&&omission.includes('永久统计'));
test('omission >100 warning preserved',omission.includes('miss>100')&&css.includes('omissionAlert'));
test('omission number/count divider preserved',css.includes('.omission49>div>b:after'));

// AI
test('AI sprite default dormant wording',ai.includes('待唤醒'));
test('AI long hold hide preserved',ai.includes('5000')&&ai.includes('macau_ai_hidden_v31'));
test('AI random zodiac reminder preserved',ai.includes('交给天命和运气')&&ai.includes('随机选一肖'));
test('AI hidden on report/admin',ai.includes("path.startsWith('/admin')")&&ai.includes("path.startsWith('/bm')"));

// History
test('history one period one card',history.includes('v411HistoryCard')&&history.includes('v411HistoryList'));
test('history period visibly rendered',history.includes('第 {short(r.expect)} 期'));
test('history seven-number mapping',history.includes('(r.numbers||[]).map'));
test('history default zodiac only classes',history.includes('hide-home hide-element hide-oe hide-wave'));
test('history compact chooser wording',hcontrols.includes('👈可选择'));
test('history controls bind V411 root',hcontrols.includes('.v411History'));
test('history pagination preserved',history.includes('上一页')&&history.includes('下一页'));

// Data trends
test('special trend route exists',fs.existsSync('app/data/page.tsx'));
test('regular trend route exists',fs.existsSync('app/data/regular/page.tsx'));
test('trend default 62 percent',trend.includes('[zoom,setZoom]=useState(.62)')&&trend.includes("['overview','总览',.62]"));
test('trend has 30/50/100/200/500 ranges',trend.includes('const periods=[30,50,100,200,500]'));
test('trend historical omission uses full rows',trend.includes('[...allMapped].reverse()')&&trend.includes('omissionByExpect'));
test('trend outer deck locked',css.includes('.trendVisualDeck{width:100%!important')&&css.includes('touch-action:pan-y!important'));
test('trend inner matrix horizontally scrolls',css.includes('.trendViewport{position:relative!important')&&css.includes('overflow-x:auto!important')&&css.includes('touch-action:pan-x pan-y!important'));
test('trend left period column sticky',css.includes('.trendMatrix .trendPeriodCol{position:sticky!important'));
test('odd/even and size no omission mode preserved',trend.includes("metric==='oe'||metric==='size'"));

// Library
test('library legacy wrapper collision removed',library.includes('className="wrap v411Library"')&&!library.includes('v404Library'));
test('library seven latest balls and zodiac preserved',library.includes('numbers.slice(0,7)')&&library.includes('zodiacs[i]'));
test('library single-zodiac share removed',!library.includes('zodiacShare'));
test('library premium attribute dividers',library.includes('luxuryAttributeSection')&&css.includes('.v411Library .luxuryAttributeSection:before'));
test('library latest special marker preserved',library.includes('latestSpecialBall')&&library.includes('isLatestSpecial'));
test('library latest-group border neutralized',css.includes('.v411Library .zodiacResourceCard.isLatestGroup'));

// Recommendation / publication
test('recommend rail no repeated current period',recommend.includes('本期推荐')&&(recommend.match(/target_expect/g)||[]).length===1);
test('recommend history text dark',css.includes('.v411RecommendRail>a')&&css.includes('color:#121212'));
test('publication current period rendered once in board',pub.includes('当前展示 · 第 ${expect} 期'));
test('publication history fold cards preserved',pubHistory.includes('pubFoldCard')&&pubHistory.includes('SummaryChips'));
test('publication details lazy-loaded',pubHistory.includes('history-detail')&&pubHistory.includes('detailLoading'));
test('publication history no duplicate expect in detail layers',!pubHistory.includes('当时公布 · 第'));

// Share poster
test('share poster uses dragon',share.includes('draw-dragon-head-v400.png'));
test('share poster uses Macau skyline',share.includes('share-skyline-v41.png'));
test('share poster uses gold frame corners/lotus',share.includes('function lotus')&&share.includes('function corner')&&share.includes('baseFrame'));
test('share poster uses official red blue green palettes',share.includes('const RED=new Set')&&share.includes('const BLUE=new Set'));
test('share settings loaded from admin site settings',share.includes('/api/site-settings'));

// Zodiac random
test('zodiac random button wording exact',zspin.includes('随机选一肖'));
test('zodiac random daily device API',zspin.includes("type:'zodiac'")&&dailyChoice.includes("type==='zodiac'"));
test('zodiac safe bottom override',css.includes('.v41ZodiacSpinner .honeyCarouselStage{padding-bottom:126px'));

// Random number machine
test('random draw rebuilt premium machine',random.includes('v411MachineStage')&&random.includes('v411MachineOrb')&&css.includes('.v411MachineOrb'));
test('random and manual chances independent',random.includes('random_number')&&random.includes('manual_number')&&dailyChoice.includes('manual_number'));
test('manual mode exactly six inputs',random.includes("['','','','','','']")&&random.includes('6个不同'));
test('manual auto focus next box',random.includes('refs.current[i+1]?.focus()'));
test('random draw yields single number',random.includes('j.result?.number')&&dailyChoice.includes('payload={number:randomInt(1,50)}'));
test('daily public device table exists',schema.includes('public_daily_choices'));

// Reporting gate/security/device
test('report gate return homepage restored',reportShell.includes('返回主页')&&reportShell.includes('reportGateHome'));
test('report gate decorative 01/25/49 balls removed',!reportShell.includes('OfficialBall')&&!reportShell.includes('n={1}')&&!reportShell.includes('n={25}')&&!reportShell.includes('n={49}'));
test('report dragon fills visual and city remains',css.includes('.v411ReportGate .reportGateDragon')&&css.includes('.v411ReportGate .reportGateCity'));
test('bad report code returns homepage',reportCode.includes("router.replace('/')"));
test('remembered report device auto-routing',reportCode.includes("fetch('/api/report/device'")&&reportDevice.includes("next:'/bm/home'"));
test('remember-device modal preserved',reportPass.includes('rememberDeviceCard')&&reportPass.includes('记住本机？'));
test('remember-device copy does not reveal only-password behavior',!reportPass.includes('只需输入密码')&&!reportPass.includes('只输入密码'));
test('report app return homepage preserved',reportHome.includes('返回主页'));
test('report number picker preserved',reportHome.includes('reportNumberPicker'));
test('report zodiac picker preserved',reportHome.includes('reportZodiacPicker'));
test('report simulated amount and expected payout preserved',reportHome.includes('输入模拟金额')&&reportHome.includes('预计模拟中奖'));
test('report submit action preserved',reportHome.includes('确认报幕')&&reportOrders.includes('play_type'));
test('report records/downline/stats tabs preserved',reportHome.includes('我的记录')&&reportHome.includes('下线')&&reportHome.includes('统计'));
test('report device table exists',schema.includes('report_devices'));
test('report orders table exists',schema.includes('report_orders'));
test('report dividend tables exist',schema.includes('report_dividend_rules')&&schema.includes('report_dividend_entries'));

// General build-safety static checks
test('CSS has no escaped literal newline',!css.includes('\\n'));
test('CSS braces balanced',(css.match(/{/g)||[]).length===(css.match(/}/g)||[]).length);
test('no report decorative-ball class in shell',!reportShell.includes('reportGateBalls'));

console.log(`\nV4.1.1 regression checks: ${total-failed}/${total} passed`);
process.exit(failed?1:0);
