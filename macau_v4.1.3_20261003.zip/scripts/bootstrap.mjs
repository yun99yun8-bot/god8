import pg from 'pg';
import fs from 'fs';
const { Pool } = pg;
if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required');
const db = new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_URL.includes('localhost')?false:{rejectUnauthorized:false}});
try {
  const schema=fs.readFileSync(new URL('../sql/schema.sql',import.meta.url),'utf8');
  await db.query(schema);
  console.log('[bootstrap] database schema ready');
  const years=(process.env.SYNC_YEARS||`${new Date().getFullYear()-2},${new Date().getFullYear()-1},${new Date().getFullYear()}`).split(',').map(x=>x.trim()).filter(Boolean);
  const tpl=process.env.HISTORY_URL_TEMPLATE||'https://history.macaumarksix.com/history/macaujc2/y/{year}';
  for(const year of years){
    try{
      const url=tpl.replace('{year}',year); console.log('[bootstrap] backfill',url);
      const r=await fetch(url); if(!r.ok) throw new Error(`History HTTP ${r.status}: ${url}`);
      const j=await r.json(); const items=Array.isArray(j)?j:(Array.isArray(j?.data)?j.data:[]); let saved=0;
      for(const d of items){
        const numbers=String(d.openCode||'').split(',').map(x=>Number(x.trim())).filter(n=>n>=1&&n<=49).slice(0,7); if(numbers.length!==7||!d.expect||!d.openTime)continue;
        const waves=String(d.wave||'').split(',').map(x=>x.trim()).filter(Boolean); const zodiacs=String(d.zodiac||'').split(',').map(x=>x.trim()).filter(Boolean);
        await db.query(`INSERT INTO draws(expect,open_time,numbers,waves,zodiacs,raw_json) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(expect) DO UPDATE SET open_time=EXCLUDED.open_time,numbers=EXCLUDED.numbers,waves=EXCLUDED.waves,zodiacs=EXCLUDED.zodiacs,raw_json=EXCLUDED.raw_json`,[String(d.expect),d.openTime,numbers,waves,zodiacs,d]); saved++;
      }
      console.log(`[bootstrap] ${year}: ${saved} history rows checked`);
    }catch(e){console.error(`[bootstrap] ${year} backfill skipped:`,String(e))}
  }
} finally { await db.end(); }
