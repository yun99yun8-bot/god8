import type { NextConfig } from 'next';
const secure=[{key:'X-Robots-Tag',value:'noindex, nofollow, noarchive, nosnippet'},{key:'Cache-Control',value:'no-store, no-cache, must-revalidate'},{key:'Referrer-Policy',value:'no-referrer'},{key:'X-Frame-Options',value:'DENY'}];
const nextConfig: NextConfig = {
  reactStrictMode: true,
  async headers(){return [
    {source:'/bm/:path*',headers:secure},
    {source:'/api/report/:path*',headers:secure},
    {source:'/admin/reporting/:path*',headers:[...secure,{key:'X-Content-Type-Options',value:'nosniff'}]},
  ]}
};
export default nextConfig;
