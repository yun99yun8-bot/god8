import type {Metadata} from 'next';import ReportCodeGate from '@/components/ReportCodeGate';
export const metadata:Metadata={title:'',robots:{index:false,follow:false,noarchive:true,nosnippet:true}};export const dynamic='force-dynamic';
export default function Page(){return <ReportCodeGate/>}
