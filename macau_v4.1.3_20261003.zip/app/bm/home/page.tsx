import type {Metadata} from 'next';import ReportHome from '@/components/ReportHome';
export const metadata:Metadata={title:'',robots:{index:false,follow:false,noarchive:true,nosnippet:true}};export const dynamic='force-dynamic';
export default function Page(){return <ReportHome/>}
