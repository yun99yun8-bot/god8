import DataNav from '@/components/DataNav';
import TrendVisualizer from '@/components/TrendVisualizer';
import {db} from '@/lib/db';
import {normalizeZodiac,rowZodiacOffset,zodiacByNumber} from '@/lib/zodiac-map';
export const dynamic='force-dynamic';
export default async function SpecialTrend(){
 let rows:any[]=[];try{rows=(await db.query('SELECT expect,open_time,numbers,zodiacs FROM draws ORDER BY open_time DESC,id DESC')).rows}catch{}
 rows=rows.map(r=>{const numbers=(r.numbers||[]).map(Number),offset=rowZodiacOffset(numbers,r.zodiacs||[],r.open_time);return {...r,numbers,zodiacs:numbers.map((n:any,i:number)=>normalizeZodiac(r.zodiacs?.[i])||zodiacByNumber(Number(n),offset))}});
 return <main className="wrap trendDataPage specialTrendPage v328Data v330Data"><DataNav active="special"/><TrendVisualizer mode="special" rows={rows}/></main>
}
