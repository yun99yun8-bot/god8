import DataNav from '@/components/DataNav';
import ZodiacSpinner from '@/components/ZodiacSpinner';
import {buildDirectionalTransitions,loadSpecialZodiacDraws} from '@/lib/zodiac-jump';
export const dynamic='force-dynamic';
export default async function ZodiacJump(){let draws:any[]=[];try{draws=await loadSpecialZodiacDraws(500)}catch{}const transitions=buildDirectionalTransitions(draws).map(t=>({...t,toTime:new Date(t.toTime).toISOString()}));return <main className="wrap jumpV32 v330Jump"><DataNav active="jump"/><ZodiacSpinner transitions={transitions}/></main>}
