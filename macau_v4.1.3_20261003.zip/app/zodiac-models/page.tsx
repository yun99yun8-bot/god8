import {redirect} from 'next/navigation';
export default function ZodiacModels(){redirect('/zodiac-jump')}
