import Link from 'next/link';
import {db} from '@/lib/db';
import {waveOf,oddEven} from '@/lib/rules';
import {elementOf} from '@/lib/five-elements';
import {normalizeZodiac,rowZodiacOffset,zodiacByNumber} from '@/lib/zodiac-map';
import {OfficialBall} from '@/components/Balls';
import HistoryControls from '@/components/HistoryControls';

const PAGE_SIZE=24;
const domestic=new Set(['牛','马','羊','鸡','狗','猪']);
function short(v:any){const s=String(v||'');return s.length>5?s.slice(-5):s}
function attrs(n:number,z:any,offset:number|null){const zodiac=normalizeZodiac(z)||zodiacByNumber(n,offset),wave=waveOf(n);return {zodiac,element:elementOf(n),oe:oddEven(n)==='odd'?'单':'双',home:domestic.has(zodiac)?'家肖':'野肖',wave:wave==='red'?'红波':wave==='blue'?'蓝波':'绿波'} }

export default async function History({searchParams}:{searchParams:Promise<any>}){
  const p=await searchParams;const page=Math.max(1,Number(p?.page||1));const q=String(p?.q||'').trim();let rows:any[]=[];
  const offsetRows=(page-1)*PAGE_SIZE;
  try{
    rows=(await db.query(
      q
        ?'SELECT expect,open_time,numbers,zodiacs FROM draws WHERE expect ILIKE $1 ORDER BY open_time DESC,id DESC LIMIT $2 OFFSET $3'
        :'SELECT expect,open_time,numbers,zodiacs FROM draws ORDER BY open_time DESC,id DESC LIMIT $1 OFFSET $2',
      q?[`%${q}%`,PAGE_SIZE+1,offsetRows]:[PAGE_SIZE+1,offsetRows]
    )).rows;
  }catch{}
  const hasNext=rows.length>PAGE_SIZE;if(hasNext)rows=rows.slice(0,PAGE_SIZE);
  const querySuffix=q?`&q=${encodeURIComponent(q)}`:'';
  return <main className="wrap v411History hide-home hide-element hide-oe hide-wave">
    <form className="searchBar v411HistorySearch"><input className="input" name="q" defaultValue={q} placeholder="输入期号查找"/><button className="softBtn primary">查询</button></form>
    <HistoryControls latestExpect={rows[0]?.expect?String(rows[0].expect):undefined} autoRefresh={page===1&&!q}/>
    <section className="v411HistoryList">{rows.map(r=><article className="v411HistoryCard" key={r.expect}>
      <header><div><b>第 {short(r.expect)} 期</b><span>{new Date(r.open_time).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false,month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'})}</span></div><Link prefetch={false} href={`/draw/${r.expect}`}>详情 ›</Link></header>
      <div className="v411HistoryNums">{(r.numbers||[]).map((raw:any,i:number)=>{const n=Number(raw),offset=rowZodiacOffset(r.numbers||[],r.zodiacs||[],r.open_time),a=attrs(n,r.zodiacs?.[i],offset);return <div className={`v411HistoryNum ${i===6?'isSpecial':''}`} key={i}>
        <OfficialBall n={n} mini special={i===6}/>
        <div className="historyTextAttrs v32HistoryAttrs"><b className="attr-zodiac">{a.zodiac}</b><span className="attr-wave">{a.wave}</span><span className="attr-element">{a.element}</span><span className="attr-oe">{a.oe}</span><span className="attr-home">{a.home}</span></div>
        {i===6&&<em>特</em>}
      </div>})}</div>
    </article>)}</section>
    {!rows.length&&<div className="noCurrent">暂无记录</div>}
    {(page>1||hasNext)&&<nav className="archivePager"><Link className={page<=1?'disabled':''} href={`/history?page=${Math.max(1,page-1)}${querySuffix}`}>上一页</Link><span>第 {page} 页</span>{hasNext?<Link href={`/history?page=${page+1}${querySuffix}`}>下一页</Link>:<span className="disabled">已到最后</span>}</nav>}
  </main>
}
