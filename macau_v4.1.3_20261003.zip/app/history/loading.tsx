export default function HistoryLoading(){
  return <main className="wrap v322HistoryLoading" aria-label="历史记录加载中">
    <div className="historyLoadToolbar"/>
    {Array.from({length:6},(_,i)=><div className="historyLoadCard" key={i}><div className="historyLoadHead"/><div className="historyLoadBalls">{Array.from({length:7},(_,j)=><i key={j}/>)}</div></div>)}
  </main>;
}
