import DataNav from '@/components/DataNav';
import {OfficialBall,waveClass} from '@/components/Balls';
import {db} from '@/lib/db';
import {FIVE_ELEMENTS,elementOf} from '@/lib/five-elements';
import {normalizeZodiac,rowZodiacOffset,zodiacByNumber,ZODIACS} from '@/lib/zodiac-map';
import {headOf,tailOf,oddEven,waveOf} from '@/lib/rules';
import {ZODIAC_EMOJI,REDS,BLUES} from '@/lib/publication';
import ShareCardButton from '@/components/ShareCardButton';

const all=Array.from({length:49},(_,i)=>i+1);
const waves=[['红波',[...REDS]],['蓝波',[...BLUES]],['绿波',all.filter(n=>!REDS.has(n)&&!BLUES.has(n))]] as const;
const domestic=new Set(['牛','马','羊','鸡','狗','猪']);
const clashes:Record<string,string>={鼠:'马',牛:'羊',虎:'猴',兔:'鸡',龙:'狗',蛇:'猪',马:'鼠',羊:'牛',猴:'虎',鸡:'兔',狗:'龙',猪:'蛇'};

function WaveNums({numbers,latestSpecial,strong=false}:{numbers:number[],latestSpecial?:number,strong?:boolean}){
  return <div className={`waveNumberText ${strong?'strong':''}`}>{numbers.map(n=><span className={`waveNum ${waveClass(n)} ${latestSpecial===n?'isLatestSpecial':''}`} key={n}>{String(n).padStart(2,'0')}</span>)}</div>;
}
function ZodiacBalls({numbers,latestSpecial}:{numbers:number[],latestSpecial?:number}){
  return <div className="zodiacOfficialBalls">{numbers.map(n=><span className={latestSpecial===n?'latestSpecialBall':''} key={n}><OfficialBall n={n} mini/></span>)}</div>;
}
function waveName(n:number){const w=waveOf(n);return w==='red'?'红波':w==='blue'?'蓝波':'绿波'}

export default async function Library(){
  let latest:any=null;
  try{latest=(await db.query('SELECT expect,open_time,numbers,zodiacs FROM draws ORDER BY open_time DESC,id DESC LIMIT 1')).rows[0]}catch{}
  const numbers:number[]=Array.isArray(latest?.numbers)?latest.numbers.map((value:any)=>Number(value)).filter((value:number)=>Number.isFinite(value)):[];
  const offset=rowZodiacOffset(numbers,latest?.zodiacs||[],latest?.open_time);
  const zodiacs=numbers.map((n,i)=>normalizeZodiac(latest?.zodiacs?.[i])||zodiacByNumber(n,offset));
  const latestSpecial=Number(numbers?.[6])||undefined;
  const latestZodiac=latestSpecial?(zodiacs[6]||zodiacByNumber(latestSpecial,offset)):'';
  const latestElement=latestSpecial?elementOf(latestSpecial):'';
  const latestWave=latestSpecial?waveName(latestSpecial):'';
  const latestHome=latestZodiac?(domestic.has(latestZodiac)?'家肖':'野肖'):'';
  const latestOE=latestSpecial?(oddEven(latestSpecial)==='odd'?'单数':'双数'):'';
  const latestSize=latestSpecial?(latestSpecial<=24?'小数':'大数'):'';
  const latestHead=latestSpecial?`${headOf(latestSpecial)}头`:'';
  const latestTail=latestSpecial?`${tailOf(latestSpecial)}尾`:'';
  const zmap=Object.fromEntries(ZODIACS.map(z=>[z,all.filter(n=>zodiacByNumber(n,offset)===z)]));
  const groups=[
    ['家肖',all.filter(n=>domestic.has(zodiacByNumber(n,offset)))],
    ['野肖',all.filter(n=>!domestic.has(zodiacByNumber(n,offset)))],
    ['单数',all.filter(n=>n%2===1)],
    ['双数',all.filter(n=>n%2===0)],
    ['小数',all.filter(n=>n<=24)],
    ['大数',all.filter(n=>n>=25)]
  ] as const;
  const latestGroupSet=new Set([latestHome,latestOE,latestSize,latestHead,latestTail,latestWave,latestElement,latestZodiac].filter(Boolean));
  const allShareSections=[
    {label:'最新开奖号',values:numbers},
    {label:'开奖号生肖',values:zodiacs},
    ...ZODIACS.map(z=>({label:`${z}肖`,values:zmap[z]||[]})),
    ...(['金','木','水','火','土'] as const).map(name=>({label:`${name}行`,values:FIVE_ELEMENTS[name]||[]})),
    ...waves.map(([name,arr])=>({label:name,values:[...arr]}))
  ];
  return <main className="wrap v411Library v413Library"><DataNav active="library"/>
    {numbers.length>0&&<section className="libraryLatestDrawOnly">
      <div className="libraryLatestDrawMeta"><b>第 {latest?.expect||'—'} 期</b><ShareCardButton title="资料大全分享卡" subtitle={`第 ${latest?.expect||'—'} 期`} sections={allShareSections} label="分享资料" variant="library"/></div>
      <div className="libraryLatestDrawRow">{numbers.slice(0,7).map((n,i)=><div className={`libraryLatestDrawItem ${i===6?'isSpecial':''}`} key={`${n}-${i}`}><OfficialBall n={n} mini special={i===6}/><b>{zodiacs[i]||''}</b>{i===5&&<i>＋</i>}</div>)}</div>
    </section>}

    <section className="zodiacCardGrid luxuryAttributeSection">{ZODIACS.map(z=><article className={`zodiacResourceCard ${latestZodiac===z?'isLatestGroup':''}`} key={z}>
      <div className="zodiacArt"><span>{ZODIAC_EMOJI[z]}</span><b>{z}</b><small className="zodiacClash">相冲：{clashes[z]}</small></div>
      <ZodiacBalls numbers={zmap[z]||[]} latestSpecial={latestSpecial}/>
    </article>)}</section>

    <section className="fiveElementVertical luxuryAttributeSection">{(['金','木','水','火','土'] as const).map(name=><article className={`elementRow element-${name} ${latestElement===name?'isLatestGroup':''}`} key={name}>
      <div className="elementVerticalLabel"><span>{name}</span></div>
      <WaveNums numbers={FIVE_ELEMENTS[name]||[]} latestSpecial={latestSpecial}/>
    </article>)}</section>

    <section className="v32TextGrid three luxuryAttributeSection">{waves.map(([name,arr])=><article className={`v32ResourceCard textResourceCard ${name} ${latestWave===name?'isLatestGroup':''}`} key={name}><b>{name}</b><WaveNums numbers={[...arr]} latestSpecial={latestSpecial} strong/></article>)}</section>

    <section className="v32TextGrid two dynamicAttributeGrid luxuryAttributeSection">{groups.map(([name,arr])=><article className={`v32ResourceCard textResourceCard ${latestGroupSet.has(name)?'isLatestGroup':''}`} key={name}><b>{name}</b><WaveNums numbers={[...arr]} latestSpecial={latestSpecial}/></article>)}</section>

    <section className="v32TextGrid dynamicHeadGrid luxuryAttributeSection">{[0,1,2,3,4].map(h=>{const name=`${h}头`;return <article className={`v32ResourceCard textResourceCard ${latestHead===name?'isLatestGroup':''}`} key={h}><b>{name}</b><WaveNums numbers={all.filter(n=>Math.floor(n/10)===h)} latestSpecial={latestSpecial}/></article>})}</section>

    <section className="v32TextGrid two dynamicTailGrid luxuryAttributeSection">{Array.from({length:10},(_,t)=>t).map(t=>{const name=`${t}尾`;return <article className={`v32ResourceCard textResourceCard ${latestTail===name?'isLatestGroup':''}`} key={t}><b>{name}</b><WaveNums numbers={all.filter(n=>n%10===t)} latestSpecial={latestSpecial}/></article>})}</section>
  </main>;
}
