'use client';
import {useEffect,useState} from 'react';
import PublicationBoard from '@/components/PublicationBoard';
type Item={id:number;target_expect?:string;type:string;content:string;payload?:any;created_at:string;settlement?:any;version?:number};
export default function Recommend(){
  const [items,setItems]=useState<Item[]>([]);
  useEffect(()=>{let alive=true;const load=async()=>{try{const r=await fetch('/api/publish?ts='+Date.now(),{cache:'no-store'}),j=await r.json();if(alive&&j.ok)setItems(j.items||[])}catch{}};load();const t=setInterval(load,5000);return()=>{alive=false;clearInterval(t)}},[]);
  return <main className="wrap recommendPage v411Recommend v412Recommend"><PublicationBoard items={items}/></main>;
}
