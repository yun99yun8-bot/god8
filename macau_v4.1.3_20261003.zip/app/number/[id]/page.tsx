import {redirect} from 'next/navigation';
export default async function NumberPage({searchParams}:{searchParams:Promise<any>}){const p=await searchParams;redirect(p?.mode==='regular'?'/data/regular':'/data')}
