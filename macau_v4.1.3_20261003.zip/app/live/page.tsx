import Link from 'next/link';
import LivePlayer from '@/components/LivePlayer';
import LiveResults from '@/components/LiveResults';
import {db} from '@/lib/db';
export const dynamic='force-dynamic';
export default async function Live(){let d:any=null;try{d=(await db.query('SELECT expect,numbers,zodiacs FROM draws ORDER BY open_time DESC LIMIT 1')).rows[0]}catch{}return <main className="wrap v3Live v330Live"><div className="inlineBack"><Link href="/">‹ 返回</Link></div><section className="livePage v3LivePanel"><LivePlayer/><LiveResults initial={d}/></section></main>}
