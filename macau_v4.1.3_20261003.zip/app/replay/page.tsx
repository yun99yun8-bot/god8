import {redirect} from 'next/navigation';
export default function Replay(){redirect('/zodiac-jump')}
