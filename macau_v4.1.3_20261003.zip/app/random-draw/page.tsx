import RandomDrawMachine from '@/components/RandomDrawMachine';
export const dynamic='force-dynamic';
export default function Page(){return <RandomDrawMachine/>}
