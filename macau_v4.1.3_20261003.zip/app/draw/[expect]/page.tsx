import Link from 'next/link';
import {OfficialBall} from '@/components/Balls';
import {db} from '@/lib/db';
import {waveOf,oddEven,headOf,tailOf} from '@/lib/rules';
import {elementOf} from '@/lib/five-elements';
import {rowZodiacOffset,zodiacByNumber,normalizeZodiac} from '@/lib/zodiac-map';
const domestic=new Set(['牛','马','羊','鸡','狗','猪']);
function waveCn(n:number){const w=waveOf(n);return w==='red'?'红波':w==='blue'?'蓝波':'绿波'}
export default async function Draw({params}:{params:Promise<{expect:string}>}){
 const {expect}=await params;let d:any=null;try{d=(await db.query('SELECT expect,open_time,numbers,zodiacs,waves FROM draws WHERE expect=$1 LIMIT 1',[expect])).rows[0]}catch{}
 if(!d)return <main className="wrap v3DrawDetail v32DrawDetail v330DrawDetail"><div className="inlineBack"><Link href="/history">‹ 返回历史</Link><span>未找到该期记录</span></div></main>;
 const nums:number[]=(d.numbers||[]).map(Number),offset=rowZodiacOffset(nums,d.zodiacs||[],d.open_time),zs=nums.map((n,i)=>normalizeZodiac(d.zodiacs?.[i])||zodiacByNumber(n,offset));
 const rows=[
  ['位置',...nums.map((_,i)=>i===6?'特码':`正码${i+1}`)],
  ['生肖',...zs],
  ['波色',...nums.map(waveCn)],
  ['五行',...nums.map(elementOf)],
  ['单双',...nums.map(n=>oddEven(n)==='odd'?'单':'双')],
  ['大小',...nums.map(n=>n<=24?'小':'大')],
  ['家野',...zs.map(z=>domestic.has(z)?'家肖':'野肖')],
  ['头数',...nums.map(n=>`${headOf(n)}头`)],
  ['尾数',...nums.map(n=>`${tailOf(n)}尾`)],
 ];
 return <main className="wrap v3DrawDetail v32DrawDetail v330DrawDetail"><div className="inlineBack"><Link href="/history">‹ 返回历史</Link><span>第 {expect} 期 · {new Date(d.open_time).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false})}</span></div><section className="detailCardV32"><div className="detailBallsV32">{nums.map((n,i)=><div key={i}><OfficialBall n={n} special={i===6}/><small>{i===6?'特码':`正${i+1}`}</small></div>)}</div><div className="detailTableScroll"><table className="detailAttrTable"><thead><tr><th>属性</th>{nums.map((n,i)=><th key={i}>{String(n).padStart(2,'0')}</th>)}</tr></thead><tbody>{rows.map((r,ri)=><tr key={ri}><th>{r[0]}</th>{r.slice(1).map((v,i)=><td key={i} className={ri===2?`waveText wave-${waveOf(nums[i])}`:''}>{v}</td>)}</tr>)}</tbody></table></div></section></main>
}
