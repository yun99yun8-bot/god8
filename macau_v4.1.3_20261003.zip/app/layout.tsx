import './globals.css';
import Nav from '@/components/Nav';
import AISprite from '@/components/AISprite';
import type {Viewport} from 'next';
export const metadata={title:'澳门六合彩 · 数据中心',description:'开奖直播、历史开奖、资料与智能数据助手'};
export const viewport:Viewport={width:'device-width',initialScale:1,maximumScale:5,userScalable:true,viewportFit:'cover'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="zh-CN"><body><Nav/><AISprite/>{children}</body></html>}
