import ReportingOrders from '@/components/ReportingOrders';export const dynamic='force-dynamic';export default function Page(){return <ReportingOrders/>}
