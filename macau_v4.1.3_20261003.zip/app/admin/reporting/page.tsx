import ReportingAdminConsole from '@/components/ReportingAdminConsole';export const dynamic='force-dynamic';export default function Page(){return <ReportingAdminConsole/>}
