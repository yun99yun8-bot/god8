import ReportingWinners from '@/components/ReportingWinners';export const dynamic='force-dynamic';export default function Page(){return <ReportingWinners/>}
