import AdminConsole from '@/components/AdminConsole';
export const dynamic='force-dynamic';
export default function Admin(){return <AdminConsole/>}
