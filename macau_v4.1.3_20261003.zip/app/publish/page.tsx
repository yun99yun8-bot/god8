'use client';
import {useEffect,useState} from 'react';
import PublicationBoard from '@/components/PublicationBoard';
type Item={id:number;target_expect?:string;type:string;content:string;payload?:any;created_at:string;settlement?:any;version?:number};
export default function Publish(){const [items,setItems]=useState<Item[]>([]);const load=async()=>{try{const r=await fetch('/api/publish?ts='+Date.now(),{cache:'no-store'}),j=await r.json();if(j.ok)setItems(j.items||[])}catch{}};useEffect(()=>{load();const t=setInterval(load,5000);return()=>clearInterval(t)},[]);return <main className="wrap publishBoardV31 v328PublishPage v330PublishPage"><PublicationBoard items={items}/></main>}
