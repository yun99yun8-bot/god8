'use client';
import {useEffect,useMemo,useState} from 'react';
import Link from 'next/link';
import {ZODIAC_EMOJI,normalizePayload} from '@/lib/publication';
import {OfficialBall} from '@/components/Balls';
import ShareCardButton from '@/components/ShareCardButton';

type Item={id:number;target_expect?:string;type:string;content:string;payload?:any;created_at:string;open_time?:string;numbers?:number[];zodiacs?:string[];settlement?:any};
type Summary={expect:string;status:'settled'|'waiting';summary:{special_hit:boolean|null;ping_hit:boolean|null;zodiac_hit:boolean|null;multi_hit:boolean|null}};
const PAGE_SIZE=30;
const PLAY_ORDER:Record<string,number>={'特码':0,'平特一肖':1,'2连肖':2,'3连肖':3,'4连肖':4,'5连肖':5,'2中2码':6,'3中3码':7};
function sortRows(rows:Item[]){return [...rows].sort((a,b)=>(PLAY_ORDER[a.type]??99)-(PLAY_ORDER[b.type]??99)||Number(a.id)-Number(b.id))}
function mergeSummaries(base:Summary[],incoming:Summary[]){const map=new Map<string,Summary>();for(const x of [...base,...incoming])if(x?.expect)map.set(String(x.expect),x);return [...map.values()]}
function N({n,hit=false,dim=false,special=false}:{n:number,hit?:boolean,dim?:boolean,special?:boolean}){return <OfficialBall n={n} mini special={special} hit={hit} dim={dim} className="historyPublishBall"/>}
function outcomeClass(s:any){return s?.status!=='settled'?'wait':s?.hit?'hit':'miss'}
function typeTitle(type:string){if(type==='2中2码')return '二中二';if(type==='3中3码')return '三中三';return type}
function RequiredCount(type:string){return Number((/^(\d+)连肖$/.exec(type)||[])[1]||0)}
function mark(v:boolean|null){return v===null?'—':v?'✅':'❌'}

function PublishedContent({x}:{x:Item}){
 const p=normalizePayload(x.type,x.payload,x.content);
 if(x.type==='特码')return <div className="pubHistoryPublishedSpecial"><div><span>主攻6</span><div>{(p.main||[]).map(n=><N n={n} key={n}/>)}</div></div><div><span>防12</span><div>{(p.defense||[]).map(n=><N n={n} key={n}/>)}</div></div></div>;
 if(x.type==='平特一肖'||x.type.includes('连肖'))return <div className="pubHistoryPublishedZodiac">{(p.zodiacs||[]).map(z=><span key={z}><i>{ZODIAC_EMOJI[z]||'•'}</i><b>{z}</b></span>)}</div>;
 if(x.type.includes('中2')||x.type.includes('中3'))return <div className="pubHistoryPublishedGroups">{(p.groups||[]).map((g,i)=><div key={i}><small>{i+1}</small>{g.map(n=><N n={n} key={n}/>)}</div>)}</div>;
 return <p>{x.content}</p>;
}
function SettlementContent({x}:{x:Item}){
 const p=normalizePayload(x.type,x.payload,x.content),s=x.settlement||{};
 if(s.status!=='settled')return <div className="settlementWaiting">待开奖</div>;
 if(x.type==='特码'){
  const all=[...(p.main||[]),...(p.defense||[])];return <div className="settlementSpecial"><div className="settlementNumberRun">{all.map((n,i)=><N n={n} hit={!!s.itemHits?.[i]} dim={!s.itemHits?.[i]} key={n}/>)}</div><strong className={outcomeClass(s)}>{s.summary}</strong></div>;
 }
 if(x.type==='平特一肖'||x.type.includes('连肖')){
  const req=RequiredCount(x.type);return <div className="settlementZodiac"><div>{(p.zodiacs||[]).map((z,i)=><span className={`${s.itemHits?.[i]?'hit':'dim'}`} key={z}><i>{ZODIAC_EMOJI[z]||'•'}</i><b>{z}</b>{s.itemHits?.[i]?<em>✓</em>:<em>×</em>}</span>)}</div><strong className={outcomeClass(s)}>{x.type.includes('连肖')?`${typeTitle(x.type)} · ${s.hitCount||0}/${req||p.zodiacs?.length||0} ${s.hit?'正确':'错误'}`:s.summary}</strong></div>;
 }
 if(x.type.includes('中2')||x.type.includes('中3'))return <div className="settlementGroups">{(p.groups||[]).map((g,i)=>{const r=s.groupResults?.[i];return <div key={i}><small>{i+1}</small><div>{g.map((n,j)=><N n={n} hit={!!r?.itemHits?.[j]} dim={!!r&&!r?.itemHits?.[j]} key={n}/>)}</div><b className={r?.hit?'hit':'miss'}>{r?`${r.hitCount}/${g.length} ${r.hit?'✓':'×'}`:'—'}</b></div>})}<strong className={outcomeClass(s)}>{s.summary}</strong></div>;
 return <strong className={outcomeClass(s)}>{s.summary||'已核对'}</strong>;
}
function ActualDraw({rows}:{rows:Item[]}){
 const d=rows.find(x=>Array.isArray(x.numbers)&&x.numbers.length>=7);if(!d)return <div className="actualDrawWaiting">待开奖</div>;
 const nums=(d.numbers||[]).map(Number),zs=d.zodiacs||[];
 return <div className="publicationActualDraw"><div className="actualBalls">{nums.slice(0,6).map((n,i)=><div key={i}><N n={n}/><span>{zs[i]||''}</span></div>)}<i>＋</i><div className="specialActual"><N n={nums[6]} special/><span>{zs[6]||'特码'}</span></div></div></div>;
}
function SummaryChips({x}:{x:Summary}){return <div className="pubCompactResults"><span>特码<b>{mark(x.summary.special_hit)}</b></span><span>一肖<b>{mark(x.summary.ping_hit)}</b></span><span>连肖<b>{mark(x.summary.zodiac_hit)}</b></span><span>连码<b>{mark(x.summary.multi_hit)}</b></span></div>}

export default function PublishHistory(){
 const [summaries,setSummaries]=useState<Summary[]>([]),[page,setPage]=useState(1),[hasMore,setHasMore]=useState(false),[loading,setLoading]=useState(true),[expanded,setExpanded]=useState<string|null>(null),[details,setDetails]=useState<Record<string,Item[]>>({}),[detailLoading,setDetailLoading]=useState<string|null>(null);
 const loadPage=async(p:number,append=false)=>{setLoading(true);try{const r=await fetch(`/api/publish?mode=history-summary&page=${p}&page_size=${PAGE_SIZE}`,{cache:'no-store'}),j=await r.json();if(j.ok){const incoming=(j.items||[]) as Summary[];setSummaries(v=>append?mergeSummaries(v,incoming):mergeSummaries([],incoming));setPage(p);setHasMore(!!j.has_more)}}finally{setLoading(false)}};
 useEffect(()=>{loadPage(1)},[]);
 const toggle=async(expect:string)=>{if(expanded===expect){setExpanded(null);return}setExpanded(expect);if(details[expect])return;setDetailLoading(expect);try{const r=await fetch(`/api/publish?mode=history-detail&expect=${encodeURIComponent(expect)}`,{cache:'no-store'}),j=await r.json();if(j.ok)setDetails(v=>({...v,[expect]:sortRows((j.items||[]) as Item[])}))}finally{setDetailLoading(null)}};
 return <main className="wrap publishHistoryPage v324PubHistory v328PubHistory v330PubHistory v412PubHistory v413PubHistory"><div className="inlineBack"><Link href="/recommend">‹ 返回本站推荐</Link></div>
   <div className="pubHistoryFoldList">{summaries.map(s=>{const open=expanded===s.expect,rows=details[s.expect]||[];return <section className={`pubFoldCard v324PubFoldCard ${open?'open':''}`} key={s.expect}>
     <button className="pubFoldHead v324PubFoldHead v328PubFoldHead" type="button" onClick={()=>toggle(s.expect)} aria-expanded={open}><div className="pubFoldSummaryTop"><b className="pubCompactExpect">第 {s.expect} 期</b><i>{open?'−':'＋'}</i></div><SummaryChips x={s}/></button>
     {open&&<div className="pubFoldBody">{detailLoading===s.expect?<div className="pubDetailLoading">读取中…</div>:rows.length?<>
       <div className="pubHistoryShareLine"><ShareCardButton title="公布历史分享卡" subtitle={`第 ${s.expect} 期`} variant="publication" sections={[...rows.map(x=>{const p=normalizePayload(x.type,x.payload,x.content);const values=x.type==='特码'?[...(p.main||[]),...(p.defense||[])]:x.type==='平特一肖'||x.type.includes('连肖')?(p.zodiacs||[]):(p.groups||[]).flat();return {label:typeTitle(x.type),values}}),...((rows.find(x=>Array.isArray(x.numbers)&&x.numbers.length>=7)?.numbers||[]).length?[{label:'实际开奖',values:(rows.find(x=>Array.isArray(x.numbers)&&x.numbers.length>=7)?.numbers||[]).slice(0,7)}]:[]),...(rows.some(x=>x.settlement?.status==='settled')?[{label:'最终核对',values:rows.filter(x=>x.settlement?.status==='settled').map(x=>`${typeTitle(x.type)} ${x.settlement?.summary||''}`)}]:[])]} label="分享本期"/></div>
       <section className="pubHistoryLayer publishedLayer"><div className="pubLayerLabel"><b>当时公布</b></div><div className="publishedItems">{rows.map(x=><article key={x.id}><header><b>{typeTitle(x.type)}</b></header><PublishedContent x={x}/></article>)}</div></section>
       <section className="pubHistoryLayer actualLayer"><div className="pubLayerLabel"><b>实际开奖</b></div><ActualDraw rows={rows}/></section>
       <section className="pubHistoryLayer settlementLayer"><div className="pubLayerLabel"><b>最终核对</b></div><div className="settlementItems">{rows.map(x=><article key={x.id}><header><b>{typeTitle(x.type)}</b><strong className={outcomeClass(x.settlement)}>{x.settlement?.status==='settled'?(x.settlement?.hit?'正确':'错误'):'待开奖'}</strong></header><SettlementContent x={x}/></article>)}</div></section>
     </>:<div className="noCurrent">本期暂无公布内容</div>}</div>}
   </section>})}</div>
   {loading&&!summaries.length?<div className="pubDetailLoading">读取中…</div>:!summaries.length?<div className="noCurrent">暂无公布历史</div>:null}
   {hasMore&&<button type="button" className="pubHistoryMore" disabled={loading} onClick={()=>loadPage(page+1,true)}>{loading?'加载中…':'加载更多'}</button>}
 </main>;
}
