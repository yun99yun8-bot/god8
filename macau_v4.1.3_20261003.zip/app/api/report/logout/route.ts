import {NextRequest,NextResponse} from 'next/server';
import {db} from '@/lib/db';
import {clearRememberDevice,clearSession,hashRememberToken,REPORT_DEVICE_COOKIE} from '@/lib/report-auth';
export async function POST(req:NextRequest){const token=req.cookies.get(REPORT_DEVICE_COOKIE)?.value;try{if(token)await db.query('UPDATE report_devices SET active=FALSE WHERE token_hash=$1',[hashRememberToken(token)])}catch{}const res=NextResponse.json({ok:true});clearSession(res);clearRememberDevice(res);return res}
