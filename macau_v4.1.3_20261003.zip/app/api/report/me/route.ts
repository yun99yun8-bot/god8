import {NextRequest,NextResponse} from 'next/server';
import {db} from '@/lib/db';
import {parseSession} from '@/lib/report-auth';
import {statsForUser,settleReportOrders} from '@/lib/reporting';
import {getAutoPublishExpect} from '@/lib/target-expect';
export const dynamic='force-dynamic';
export async function GET(req:NextRequest){try{const u:any=await parseSession(req);if(!u)return NextResponse.json({ok:false,error:'未验证'},{status:401});await settleReportOrders();const auto=await getAutoPublishExpect();const [today,all,children,odds,div,pending,payouts]=await Promise.all([
 statsForUser(Number(u.id)),
 db.query(`WITH RECURSIVE t AS (SELECT id FROM report_users WHERE id=$1 UNION ALL SELECT x.id FROM report_users x JOIN t ON x.parent_id=t.id) SELECT COALESCE(SUM(o.amount),0)::numeric amount,COALESCE(SUM(CASE WHEN o.status='settled' THEN o.payout ELSE 0 END),0)::numeric payout,COUNT(DISTINCT o.user_id)::int participants,COUNT(o.id)::int orders FROM t LEFT JOIN report_orders o ON o.user_id=t.id AND o.status<>'void'`,[u.id]),
 db.query(`SELECT id,access_code,parent_remark,active,password_hash IS NOT NULL activated,created_at,last_login_at FROM report_users WHERE parent_id=$1 ORDER BY created_at DESC`,[u.id]),
 db.query(`SELECT play_type,odds FROM report_play_odds ORDER BY play_type`),
 db.query(`SELECT percent FROM report_dividend_rules WHERE user_id=$1 AND active=TRUE AND effective_from<=NOW() AND (effective_to IS NULL OR effective_to>NOW()) ORDER BY effective_from DESC,id DESC LIMIT 1`,[u.id]),
 db.query(`SELECT COALESCE(SUM(dividend_amount),0)::numeric amount FROM report_dividend_entries WHERE beneficiary_user_id=$1 AND settled=FALSE`,[u.id]),
 db.query(`SELECT COALESCE(SUM(amount),0)::numeric amount FROM report_dividend_payouts WHERE user_id=$1`,[u.id])
 ]);const ar:any=all.rows[0]||{};const total={amount:Number(ar.amount||0),payout:Number(ar.payout||0),net:Number(ar.amount||0)-Number(ar.payout||0),participants:Number(ar.participants||0),orders:Number(ar.orders||0)};const percent=Number(div.rows[0]?.percent||0);return NextResponse.json({ok:true,user:{id:u.id,code:u.access_code,remark:u.parent_remark,created_at:u.created_at,last_login_at:u.last_login_at},target_expect:auto.expect||'',today,total,children:children.rows,odds:odds.rows.map((x:any)=>({...x,odds:Number(x.odds)})),dividend:percent>0?{percent,pending:Number(pending.rows[0]?.amount||0),paid:Number(payouts.rows[0]?.amount||0)}:null},{headers:{'Cache-Control':'no-store'}})}catch(e){return NextResponse.json({ok:false,error:String(e)},{status:500})}}
