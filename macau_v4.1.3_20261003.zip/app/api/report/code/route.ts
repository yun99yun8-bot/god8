import {NextRequest,NextResponse} from 'next/server';
import {db} from '@/lib/db';
import {clearTicket,codeHash,ensureReportTestUser,ipHash,isReportTestCode,makeTicket,normalizeReportCode,setTicket} from '@/lib/report-auth';
export const dynamic='force-dynamic';
export async function POST(req:NextRequest){
 try{
  const body=await req.json();const code=normalizeReportCode(body?.code||'');const ip=ipHash(req),ch=codeHash(code);
  const rl=await db.query(`SELECT COUNT(*)::int c FROM report_auth_events WHERE success=FALSE AND created_at>NOW()-INTERVAL '15 minutes' AND (ip_hash=$1 OR code_hash=$2)`,[ip,ch]);
  if(Number(rl.rows[0]?.c||0)>=10){const res=NextResponse.json({ok:false},{status:429,headers:{'Cache-Control':'no-store'}});clearTicket(res);return res}
  const validFormat=code.length>=8&&code.length<=18&&/[A-Z]/.test(code)&&/\d/.test(code);
  let u:any=null;
  if(validFormat&&isReportTestCode(code))u=await ensureReportTestUser();
  else if(validFormat){const q=await db.query(`SELECT id FROM report_users WHERE access_code_norm=$1 AND active=TRUE LIMIT 1`,[code]);u=q.rows[0]}
  await db.query(`INSERT INTO report_auth_events(ip_hash,code_hash,success,stage) VALUES($1,$2,$3,'code')`,[ip,ch,!!u]);
  if(!u){const res=NextResponse.json({ok:false},{status:401,headers:{'Cache-Control':'no-store'}});clearTicket(res);return res}
  const res=NextResponse.json({ok:true,next:'/bm/password'},{headers:{'Cache-Control':'no-store'}});setTicket(res,makeTicket(Number(u.id)));return res;
 }catch{const res=NextResponse.json({ok:false},{status:400,headers:{'Cache-Control':'no-store'}});clearTicket(res);return res}
}
