import {NextRequest,NextResponse} from 'next/server';
import {answerHistoryQuestion} from '@/lib/ai-history';
export const dynamic='force-dynamic';
export async function POST(req:NextRequest){try{const b=await req.json();const limit=Math.min(5000,Math.max(30,Number(b.limit||500)));const mode=(['all','regular','special'].includes(b.mode)?b.mode:'special');return NextResponse.json(await answerHistoryQuestion(String(b.question||''),limit,mode,b.context||null))}catch(e){return NextResponse.json({error:String(e)},{status:500})}}
