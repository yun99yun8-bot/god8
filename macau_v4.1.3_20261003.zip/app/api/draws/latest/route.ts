import {db} from '@/lib/db'; import {NextResponse} from 'next/server';
export const dynamic='force-dynamic';export const revalidate=0;
export async function GET(){try{const {rows}=await db.query('SELECT expect,open_time,numbers,waves,zodiacs,received_at FROM draws ORDER BY open_time DESC,id DESC LIMIT 1');return NextResponse.json(rows[0]||null,{headers:{'Cache-Control':'no-store, no-cache, must-revalidate'}})}catch(e){return NextResponse.json({error:String(e)},{status:500,headers:{'Cache-Control':'no-store'}})}}
