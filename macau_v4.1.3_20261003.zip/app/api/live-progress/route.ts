import {NextResponse} from 'next/server';import {db} from '@/lib/db';
export const dynamic='force-dynamic';export const revalidate=0;
export async function GET(){try{const [{rows},latest]=await Promise.all([
  db.query(`SELECT key,value,updated_at FROM app_settings WHERE key IN ('live_partial_draw','live_partial_updated','live_sync_status','worker_heartbeat')`),
  db.query(`SELECT expect,open_time,received_at FROM draws ORDER BY open_time DESC,id DESC LIMIT 1`)
]);const m=Object.fromEntries(rows.map((r:any)=>[r.key,r.value]));return NextResponse.json({ok:true,partial:m.live_partial_draw||null,updatedAt:m.live_partial_updated||null,sync:m.live_sync_status||null,heartbeat:m.worker_heartbeat||null,dbLatest:latest.rows[0]||null},{headers:{'Cache-Control':'no-store, no-cache, must-revalidate'}})}catch(e){return NextResponse.json({ok:false,error:String(e)},{status:500,headers:{'Cache-Control':'no-store'}})}}
