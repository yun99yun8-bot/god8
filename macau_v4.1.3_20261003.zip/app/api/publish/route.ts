import {NextRequest,NextResponse} from 'next/server';
import {db} from '@/lib/db';
import {isAdmin} from '@/lib/admin-auth';
import {normalizePayload,payloadToContent,settleDetailed,validatePayload} from '@/lib/publication';
import {getAutoPublishExpect} from '@/lib/target-expect';
export const dynamic='force-dynamic';

async function loadRows(limit:number,targetExpect?:string){
 const params:any[]=[];let where="p.status='published'";
 if(targetExpect){params.push(targetExpect);where+=` AND p.target_expect=$${params.length}`}
 params.push(limit);
 const {rows}=await db.query(`SELECT p.id,p.target_expect,p.type,p.content,p.payload,p.status,p.published_by,p.created_at,p.updated_at,p.version,p.settlement,p.settled_at,d.expect AS draw_expect,d.numbers,d.zodiacs,d.open_time FROM published_predictions p LEFT JOIN draws d ON d.expect=p.target_expect WHERE ${where} ORDER BY COALESCE(p.target_expect,'' ) DESC,p.updated_at DESC,p.created_at DESC LIMIT $${params.length}`,params);
 return rows.map((x:any)=>{const exact=!!x.target_expect&&String(x.draw_expect||'')===String(x.target_expect);return {...x,settlement:exact?settleDetailed(x.type,x.payload,x.content,x):{status:'waiting',hit:false,summary:'待开奖'}}});
}
function dedupe(items:any[]){const seen=new Set<string>();return items.filter(x=>{const k=`${x.target_expect||''}|${x.type}`;if(seen.has(k))return false;seen.add(k);return true})}
function compactGroup(expect:string,rows:any[]){
 const isSettled=rows.some(x=>x.settlement?.status==='settled');
 const special=rows.find(x=>x.type==='特码');
 const ping=rows.find(x=>x.type==='平特一肖');
 const zodiacRows=rows.filter(x=>x.type.includes('连肖'));
 const multiRows=rows.filter(x=>x.type.includes('中2')||x.type.includes('中3'));
 const mark=(x:any)=>!x?null:x.settlement?.status!=='settled'?null:!!x.settlement?.hit;
 const aggregate=(xs:any[])=>!xs.length?null:!xs.some(x=>x.settlement?.status==='settled')?null:xs.some(x=>x.settlement?.hit===true);
 return {
   expect,status:isSettled?'settled':'waiting',created_at:rows[0]?.created_at||null,open_time:rows.find(x=>x.open_time)?.open_time||null,
   summary:{
     special_hit:mark(special),
     ping_hit:mark(ping),
     zodiac_hit:aggregate(zodiacRows),
     multi_hit:aggregate(multiRows)
   }
 };
}
export async function GET(r:NextRequest){
 try{
  const u=new URL(r.url),mode=u.searchParams.get('mode')||'current';
  if(mode==='history-summary'){
   const page=Math.max(1,Number(u.searchParams.get('page')||1)),pageSize=Math.min(50,Math.max(10,Number(u.searchParams.get('page_size')||24)));
   const items=dedupe(await loadRows(3000));const groups=new Map<string,any[]>();
   for(const x of items){const k=x.target_expect||'未指定期号';groups.set(k,[...(groups.get(k)||[]),x])}
   const all=[...groups.entries()].map(([expect,rows])=>compactGroup(expect,rows));const start=(page-1)*pageSize;
   return NextResponse.json({ok:true,items:all.slice(start,start+pageSize),page,page_size:pageSize,has_more:start+pageSize<all.length,total:all.length},{headers:{'Cache-Control':'no-store'}})
  }
  if(mode==='history-detail'){
   const expect=String(u.searchParams.get('expect')||'').trim();if(!expect)return NextResponse.json({ok:false,error:'缺少期号'},{status:400});
   const items=dedupe(await loadRows(80,expect));return NextResponse.json({ok:true,expect,items},{headers:{'Cache-Control':'no-store'}})
  }
  const raw=await loadRows(mode==='history'?2400:600),items=dedupe(raw);
  if(mode==='history')return NextResponse.json({ok:true,items:items.slice(0,1200)},{headers:{'Cache-Control':'no-store'}});
  const key=items.find((x:any)=>x.target_expect)?.target_expect||null;const current=key?items.filter((x:any)=>x.target_expect===key):items.filter((x:any)=>!x.target_expect);
  return NextResponse.json({ok:true,items:current,display_expect:key},{headers:{'Cache-Control':'no-store'}})
 }catch(e){return NextResponse.json({ok:false,error:String(e)},{status:500})}
}
export async function POST(r:NextRequest){if(!isAdmin(r))return NextResponse.json({ok:false,error:'未授权'},{status:401});try{const b=await r.json();const type=String(b.type||'').trim(),auto=await getAutoPublishExpect(),target=auto.expect||null,payload=normalizePayload(type,b.payload,b.content||''),error=validatePayload(type,payload);if(!target)return NextResponse.json({ok:false,error:'无法自动生成目标期号，请先确认开奖记录已同步'},{status:409});if(!type)return NextResponse.json({ok:false,error:'请选择发布类型'},{status:400});if(error)return NextResponse.json({ok:false,error},{status:400});const content=payloadToContent(type,payload),publisher=String(b.published_by||'admin').slice(0,80);const prev=await db.query(`SELECT * FROM published_predictions WHERE status='published' AND type=$1 AND target_expect IS NOT DISTINCT FROM $2 ORDER BY updated_at DESC,created_at DESC LIMIT 1`,[type,target]);let item:any,action='publish';if(prev.rows[0]){action='update';const v=Number(prev.rows[0].version||1)+1;item=(await db.query(`UPDATE published_predictions SET content=$1,payload=$2,published_by=$3,published_at=NOW(),updated_at=NOW(),version=$4,settlement=NULL,settled_at=NULL WHERE id=$5 RETURNING *`,[content,payload,publisher,v,prev.rows[0].id])).rows[0];await db.query(`INSERT INTO publication_revisions(prediction_id,version,type,target_expect,content,payload,action) VALUES($1,$2,$3,$4,$5,$6,'update')`,[item.id,item.version,type,target,content,payload])}else{item=(await db.query(`INSERT INTO published_predictions(target_expect,type,content,payload,published_by) VALUES($1,$2,$3,$4,$5) RETURNING *`,[target,type,content,payload,publisher])).rows[0];await db.query(`INSERT INTO publication_revisions(prediction_id,version,type,target_expect,content,payload,action) VALUES($1,1,$2,$3,$4,$5,'publish')`,[item.id,type,target,content,payload])}return NextResponse.json({ok:true,item,action,target_expect:target})}catch(e){return NextResponse.json({ok:false,error:String(e)},{status:500})}}
export async function DELETE(r:NextRequest){if(!isAdmin(r))return NextResponse.json({ok:false,error:'未授权'},{status:401});try{const u=new URL(r.url);if(u.searchParams.get('all')==='1'){await db.query('DELETE FROM publication_revisions');await db.query('DELETE FROM published_predictions');return NextResponse.json({ok:true,cleared:true})}const id=Number(u.searchParams.get('id'));if(!id)return NextResponse.json({ok:false,error:'缺少记录ID'},{status:400});const q=await db.query(`UPDATE published_predictions SET status='deleted',updated_at=NOW(),version=version+1 WHERE id=$1 RETURNING *`,[id]);if(q.rows[0])await db.query(`INSERT INTO publication_revisions(prediction_id,version,type,target_expect,content,payload,action) VALUES($1,$2,$3,$4,$5,$6,'withdraw')`,[id,q.rows[0].version,q.rows[0].type,q.rows[0].target_expect,q.rows[0].content,q.rows[0].payload]);return NextResponse.json({ok:true})}catch(e){return NextResponse.json({ok:false,error:String(e)},{status:500})}}
