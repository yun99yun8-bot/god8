import {NextRequest,NextResponse} from 'next/server';
import {db} from '@/lib/db';
import {isAdmin} from '@/lib/admin-auth';
export const dynamic='force-dynamic';
const defaults={siteName:'澳门六合彩',siteUrl:'https://macau-web-fkzm.onrender.com'};
async function load(){try{const q=await db.query(`SELECT value FROM app_settings WHERE key='site_brand' LIMIT 1`);return {...defaults,...(q.rows[0]?.value||{})}}catch{return defaults}}
export async function GET(){return NextResponse.json({ok:true,data:await load()},{headers:{'Cache-Control':'no-store'}})}
export async function POST(req:NextRequest){if(!isAdmin(req))return NextResponse.json({ok:false,error:'未授权'},{status:401});try{const b=await req.json();const siteName=String(b?.siteName||'').trim().slice(0,80),siteUrl=String(b?.siteUrl||'').trim().slice(0,240);if(!siteName||!/^https?:\/\//i.test(siteUrl))return NextResponse.json({ok:false,error:'名称或网址格式不正确'},{status:400});const value={siteName,siteUrl};await db.query(`INSERT INTO app_settings(key,value,updated_at) VALUES('site_brand',$1,NOW()) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=NOW()`,[value]);return NextResponse.json({ok:true,data:value})}catch(e){return NextResponse.json({ok:false,error:String(e)},{status:500})}}
