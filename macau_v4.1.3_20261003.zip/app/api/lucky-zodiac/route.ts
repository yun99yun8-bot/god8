import {NextResponse} from 'next/server';
import {db} from '@/lib/db';
export const dynamic='force-dynamic';
export const revalidate=0;
export async function GET(){
 try{
  const q=await db.query(`SELECT fortune_date,source,source_url,source_time,content,fetched_at FROM daily_zodiac_fortune ORDER BY fortune_date DESC,fetched_at DESC LIMIT 1`);
  const row=q.rows[0]||null;
  return NextResponse.json({ok:true,data:row},{headers:{'Cache-Control':'no-store, no-cache, must-revalidate'}});
 }catch(e){return NextResponse.json({ok:false,data:null,error:String(e)},{status:500,headers:{'Cache-Control':'no-store'}})}
}
