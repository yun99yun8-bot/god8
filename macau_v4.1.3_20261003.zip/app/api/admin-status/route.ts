import {NextRequest,NextResponse} from 'next/server';
import {db} from '@/lib/db';
import {isAdmin} from '@/lib/admin-auth';
import {getAutoPublishExpect} from '@/lib/target-expect';
export const dynamic='force-dynamic';
export async function GET(r:NextRequest){
 if(!isAdmin(r))return NextResponse.json({ok:false,authenticated:false,error:'未授权'},{status:401});
 const out:any={ok:true,authenticated:true,total:null,latest:null,nextExpect:'',publishExpect:'',latestPublished:'',published:null,workerLast:null,issues:[],dataError:null};
 try{const q=await db.query('SELECT COUNT(*)::int count FROM draws');out.total=q.rows[0]?.count||0}catch(e){out.dataError='开奖记录状态读取失败';out.issues.push('开奖记录数据库读取失败')}
 try{const q=await db.query('SELECT expect,open_time,received_at FROM draws ORDER BY open_time DESC,id DESC LIMIT 1');out.latest=q.rows[0]||null;const auto=await getAutoPublishExpect();out.nextExpect=auto.expect;out.publishExpect=auto.expect;out.latestPublished=auto.latestPublished;out.publishPending=auto.pending}catch{out.issues.push('自动公布期号读取失败')}
 try{const q=await db.query(`SELECT COUNT(*)::int count FROM published_predictions WHERE status='published'`);out.published=q.rows[0]?.count||0}catch{out.issues.push('发布记录读取失败')}
 try{const q=await db.query(`SELECT source,status,message,created_at FROM source_logs ORDER BY created_at DESC LIMIT 30`);out.workerLast=q.rows.find((x:any)=>x.source==='live-api')||q.rows[0]||null;for(const x of q.rows.filter((x:any)=>x.status!=='ok').slice(0,3))out.issues.push(`${x.source}: ${x.message||x.status}`)}catch{out.issues.push('采集状态读取失败')}
 try{const q=await db.query(`SELECT COUNT(*)::int waiting FROM published_predictions p LEFT JOIN draws d ON d.expect=p.target_expect WHERE p.status='published' AND p.target_expect IS NOT NULL AND d.expect IS NULL`);const n=Number(q.rows[0]?.waiting||0);if(n)out.issues.push(`${n} 条已发布资料尚未等到对应期开奖结果`)}catch{}
 return NextResponse.json(out,{headers:{'Cache-Control':'no-store'}})
}
