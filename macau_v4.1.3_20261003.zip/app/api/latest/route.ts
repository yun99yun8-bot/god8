import {NextResponse} from 'next/server';import {db} from '@/lib/db';
export const dynamic='force-dynamic';export const revalidate=0;
export async function GET(){try{const [{rows},settings]=await Promise.all([
  db.query(`SELECT expect,open_time,numbers,zodiacs,waves,received_at FROM draws ORDER BY open_time DESC,id DESC LIMIT 1`),
  db.query(`SELECT key,value FROM app_settings WHERE key IN ('live_sync_status','worker_heartbeat')`)
]);const m=Object.fromEntries(settings.rows.map((r:any)=>[r.key,r.value]));return NextResponse.json({ok:true,draw:rows[0]||null,sync:m.live_sync_status||null,heartbeat:m.worker_heartbeat||null,serverTime:new Date().toISOString()},{headers:{'Cache-Control':'no-store, no-cache, must-revalidate','Pragma':'no-cache'}})}catch(e){return NextResponse.json({ok:false,error:String(e)},{status:500,headers:{'Cache-Control':'no-store'}})}}
