import {NextRequest,NextResponse} from 'next/server'; import {parseFilter} from '@/lib/filter';
export function GET(req:NextRequest){return NextResponse.json(parseFilter(req.nextUrl.searchParams.get('q')||''))}
