import {NextResponse} from 'next/server';
import {getDailyOmission} from '@/lib/daily-omission';
export const dynamic='force-dynamic';
export const revalidate=0;
export async function GET(){try{return NextResponse.json({ok:true,...await getDailyOmission()},{headers:{'Cache-Control':'no-store, no-cache, must-revalidate'}})}catch(e){return NextResponse.json({ok:false,error:String(e)},{status:500,headers:{'Cache-Control':'no-store'}})}}
