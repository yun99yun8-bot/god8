import {NextResponse} from 'next/server';import {db} from '@/lib/db';
export const dynamic='force-dynamic';export const revalidate=0;
export async function GET(){try{const [c,l,g,s]=await Promise.all([
  db.query('SELECT COUNT(*)::int count FROM draws'),
  db.query('SELECT expect,open_time,received_at FROM draws ORDER BY open_time DESC,id DESC LIMIT 1'),
  db.query(`SELECT EXTRACT(YEAR FROM open_time)::int year,COUNT(*)::int count FROM draws GROUP BY 1 ORDER BY 1 DESC`),
  db.query(`SELECT key,value,updated_at FROM app_settings WHERE key IN ('live_sync_status','worker_heartbeat','live_partial_updated')`)
]);const m=Object.fromEntries(s.rows.map((r:any)=>[r.key,{value:r.value,updated_at:r.updated_at}]));return NextResponse.json({ok:true,total:c.rows[0]?.count||0,latest:l.rows[0]||null,years:g.rows,sync:m.live_sync_status?.value||null,worker:m.worker_heartbeat?.value||null,partialUpdatedAt:m.live_partial_updated?.updated_at||null,version:'4.1'},{headers:{'Cache-Control':'no-store, no-cache, must-revalidate'}})}catch(e){return NextResponse.json({ok:false,error:String(e),version:'4.1'},{status:500,headers:{'Cache-Control':'no-store'}})}}
