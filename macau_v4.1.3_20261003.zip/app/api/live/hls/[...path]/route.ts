import {NextRequest,NextResponse} from 'next/server';
import fs from 'node:fs/promises';
import path from 'node:path';
export const runtime='nodejs';export const dynamic='force-dynamic';export const revalidate=0;
const root=process.env.HLS_DIR||'/tmp/macau-hls';
const types:Record<string,string>={'.m3u8':'application/vnd.apple.mpegurl','.ts':'video/mp2t','.m4s':'video/iso.segment'};
export async function GET(_req:NextRequest,{params}:{params:Promise<{path:string[]}>}){
  try{
    const parts=(await params).path||[];if(!parts.length)return new NextResponse('not found',{status:404});
    const name=parts.join('/');if(name.includes('..')||name.startsWith('/'))return new NextResponse('bad path',{status:400});
    const file=path.resolve(root,name),base=path.resolve(root)+path.sep;if(!file.startsWith(base))return new NextResponse('bad path',{status:400});
    const data=await fs.readFile(file),ext=path.extname(file).toLowerCase();
    return new NextResponse(new Uint8Array(data),{headers:{'Content-Type':types[ext]||'application/octet-stream','Cache-Control':'no-store, no-cache, must-revalidate','Access-Control-Allow-Origin':'*'}});
  }catch{return new NextResponse('直播流准备中',{status:503,headers:{'Cache-Control':'no-store'}})}
}
