import {NextRequest,NextResponse} from 'next/server';
import {ADMIN_COOKIE,ADMIN_PASSPHRASE,adminToken} from '@/lib/admin-auth';
export const dynamic='force-dynamic';
export async function POST(req:NextRequest){
  try{
    const body=await req.json();
    if(String(body?.password||'')!==ADMIN_PASSPHRASE)return NextResponse.json({ok:false,error:'口令不正确'},{status:401});
    const token=adminToken();
    const res=NextResponse.json({ok:true,token});
    res.cookies.set(ADMIN_COOKIE,token,{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',path:'/',maxAge:60*60*24*30});
    return res;
  }catch{return NextResponse.json({ok:false,error:'验证失败'},{status:400})}
}
