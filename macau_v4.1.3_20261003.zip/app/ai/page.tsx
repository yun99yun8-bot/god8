import {redirect} from 'next/navigation';
export default function AI(){redirect('/')}
