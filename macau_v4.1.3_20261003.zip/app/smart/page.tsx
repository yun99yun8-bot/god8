import {redirect} from 'next/navigation';
export default function Smart(){redirect('/library')}
