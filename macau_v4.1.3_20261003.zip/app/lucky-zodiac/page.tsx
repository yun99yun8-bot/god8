import LuckyZodiacBoard from '@/components/LuckyZodiacBoard';
export default function Page(){return <LuckyZodiacBoard/>}
