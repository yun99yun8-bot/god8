import HomeDraw from '@/components/HomeDraw';
import {db} from '@/lib/db';
async function load(){try{return (await db.query('SELECT expect,open_time,numbers,zodiacs,waves FROM draws ORDER BY open_time DESC LIMIT 1')).rows[0]||null}catch{return null}}
export default async function Page(){const d=await load();return <main className="wrap v3Home v328Home v330Home"><HomeDraw initial={d}/></main>}
