import {createHmac,randomBytes,scryptSync,timingSafeEqual,createHash} from 'crypto';
import type {NextRequest,NextResponse} from 'next/server';
import {db} from './db';

export const REPORT_TICKET_COOKIE='macau_report_ticket_v41';
export const REPORT_SESSION_COOKIE='macau_report_session_v41';
export const REPORT_DEVICE_COOKIE='macau_report_device_v41';
const secret=()=>process.env.REPORT_SESSION_SECRET||process.env.ADMIN_SESSION_SECRET||process.env.ADMIN_PASSWORD||'change-me-v41';
function sign(body:string){return createHmac('sha256',secret()).update(body).digest('hex')}
function safe(a:string,b:string){const aa=Buffer.from(a),bb=Buffer.from(b);return aa.length===bb.length&&timingSafeEqual(aa,bb)}
export function normalizeReportCode(v:string){return String(v||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,18)}
export function hashPassword(password:string){const salt=randomBytes(16).toString('hex');const out=scryptSync(password,salt,64).toString('hex');return `scrypt$${salt}$${out}`}
export function verifyPassword(password:string,stored:string){try{const [kind,salt,hex]=String(stored||'').split('$');if(kind!=='scrypt'||!salt||!hex)return false;const got=scryptSync(password,salt,64);const expected=Buffer.from(hex,'hex');return got.length===expected.length&&timingSafeEqual(got,expected)}catch{return false}}
export function makeTicket(userId:number,minutes=10){const exp=Date.now()+minutes*60000;const body=`${userId}.${exp}`;return `${body}.${sign('ticket:'+body)}`}
export function parseTicket(v?:string|null){if(!v)return null;const [id,exp,sig]=v.split('.');const body=`${id}.${exp}`;if(!id||!exp||!sig||Number(exp)<Date.now()||!safe(sig,sign('ticket:'+body)))return null;return {userId:Number(id),exp:Number(exp)}}
export function makeSession(userId:number,version:number,days=30){const exp=Date.now()+days*86400000;const body=`${userId}.${version}.${exp}`;return `${body}.${sign('session:'+body)}`}
export async function parseSession(req:NextRequest){const raw=req.cookies.get(REPORT_SESSION_COOKIE)?.value;if(!raw)return null;const [id,version,exp,sig]=raw.split('.');const body=`${id}.${version}.${exp}`;if(!id||!version||!exp||!sig||Number(exp)<Date.now()||!safe(sig,sign('session:'+body)))return null;const q=await db.query(`SELECT id,parent_id,root_id,access_code,parent_remark,active,session_version,password_hash,created_at,last_login_at FROM report_users WHERE id=$1 LIMIT 1`,[Number(id)]);const u:any=q.rows[0];if(!u||!u.active||Number(u.session_version)!==Number(version))return null;return u}
export function setTicket(res:NextResponse,value:string){res.cookies.set(REPORT_TICKET_COOKIE,value,{httpOnly:true,secure:true,sameSite:'strict',path:'/',maxAge:600})}
export function clearTicket(res:NextResponse){res.cookies.set(REPORT_TICKET_COOKIE,'',{httpOnly:true,secure:true,sameSite:'strict',path:'/',maxAge:0})}
export function setSession(res:NextResponse,value:string){res.cookies.set(REPORT_SESSION_COOKIE,value,{httpOnly:true,secure:true,sameSite:'strict',path:'/',maxAge:30*86400})}
export function clearSession(res:NextResponse){res.cookies.set(REPORT_SESSION_COOKIE,'',{httpOnly:true,secure:true,sameSite:'strict',path:'/',maxAge:0})}
export function newRememberToken(){return randomBytes(32).toString('base64url')}
export function hashRememberToken(token:string){return createHash('sha256').update(secret()+':report-device:'+token).digest('hex')}
export function setRememberDevice(res:NextResponse,token:string,days=30){res.cookies.set(REPORT_DEVICE_COOKIE,token,{httpOnly:true,secure:true,sameSite:'strict',path:'/',maxAge:days*86400})}
export function clearRememberDevice(res:NextResponse){res.cookies.set(REPORT_DEVICE_COOKIE,'',{httpOnly:true,secure:true,sameSite:'strict',path:'/',maxAge:0})}
export async function userFromRememberedDevice(req:NextRequest){const token=req.cookies.get(REPORT_DEVICE_COOKIE)?.value;if(!token)return null;const hash=hashRememberToken(token);const q=await db.query(`SELECT d.id device_id,u.id,u.parent_id,u.root_id,u.access_code,u.parent_remark,u.active,u.session_version,u.password_hash,u.created_at,u.last_login_at FROM report_devices d JOIN report_users u ON u.id=d.user_id WHERE d.token_hash=$1 AND d.active=TRUE AND d.expires_at>NOW() AND d.session_version=u.session_version AND u.active=TRUE LIMIT 1`,[hash]);return q.rows[0]||null}
export function ipHash(req:NextRequest){const ip=(req.headers.get('x-forwarded-for')||req.headers.get('x-real-ip')||'unknown').split(',')[0].trim();return createHash('sha256').update(secret()+':ip:'+ip).digest('hex')}
export function codeHash(code:string){return createHash('sha256').update(secret()+':code:'+normalizeReportCode(code)).digest('hex')}
export const REPORT_TEST_CODE=normalizeReportCode(process.env.REPORT_TEST_CODE||'AAAA8888');
export const REPORT_TEST_PASSWORD=String(process.env.REPORT_TEST_PASSWORD||'99999998');
export function isReportTestCode(code:string){return normalizeReportCode(code)===REPORT_TEST_CODE}
export async function ensureReportTestUser(){
 const found=await db.query(`SELECT id,password_hash,session_version,active FROM report_users WHERE access_code_norm=$1 LIMIT 1`,[REPORT_TEST_CODE]);
 const u:any=found.rows[0];
 if(u){
  let version=Number(u.session_version||1);
  if(!u.active||!verifyPassword(REPORT_TEST_PASSWORD,u.password_hash||'')){
   const q=await db.query(`UPDATE report_users SET active=TRUE,password_hash=$1,activated_at=COALESCE(activated_at,NOW()),session_version=session_version+1,parent_remark='测试口令' WHERE id=$2 RETURNING id,session_version`,[hashPassword(REPORT_TEST_PASSWORD),u.id]);
   version=Number(q.rows[0]?.session_version||version+1);
  }
  return {id:Number(u.id),session_version:version};
 }
 const q=await db.query(`INSERT INTO report_users(access_code,access_code_norm,password_hash,parent_remark,active,created_by_admin,activated_at) VALUES($1,$1,$2,'测试口令',TRUE,TRUE,NOW()) RETURNING id,session_version`,[REPORT_TEST_CODE,hashPassword(REPORT_TEST_PASSWORD)]);
 return {id:Number(q.rows[0].id),session_version:Number(q.rows[0].session_version||1)};
}

