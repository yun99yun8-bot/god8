export const RED = new Set([1,2,7,8,12,13,18,19,23,24,29,30,34,35,40,45,46]);
export const BLUE = new Set([3,4,9,10,14,15,20,25,26,31,36,37,41,42,47,48]);
export const GREEN = new Set([5,6,11,16,17,21,22,27,28,32,33,38,39,43,44,49]);
export function waveOf(n:number){ return RED.has(n)?'red':BLUE.has(n)?'blue':'green'; }
export function headOf(n:number){ return Math.floor(n/10); }
export function tailOf(n:number){ return n%10; }
export function oddEven(n:number){ return n%2?'odd':'even'; }
export function numberUniverse(){ return Array.from({length:49},(_,i)=>i+1); }
