import { db } from './db';
import type { Draw } from './types';
export function parseNumbers(openCode:string){ return openCode.split(',').map(s=>Number(s.trim())).filter(n=>n>=1&&n<=49).slice(0,7); }
export async function saveDraw(draw:Draw){
 const numbers=parseNumbers(draw.openCode); if(numbers.length!==7) throw new Error('Invalid openCode');
 const waves=(draw.wave||'').split(',').map(s=>s.trim()).filter(Boolean);
 const zodiacs=(draw.zodiac||'').split(',').map(s=>s.trim()).filter(Boolean);
 await db.query(`INSERT INTO draws(expect,open_time,numbers,waves,zodiacs,raw_json) VALUES($1,$2,$3,$4,$5,$6)
 ON CONFLICT(expect) DO UPDATE SET open_time=EXCLUDED.open_time,numbers=EXCLUDED.numbers,waves=EXCLUDED.waves,zodiacs=EXCLUDED.zodiacs,raw_json=EXCLUDED.raw_json,received_at=NOW()`,
 [draw.expect, draw.openTime, numbers, waves, zodiacs, draw]);
}
