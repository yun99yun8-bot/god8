import {db} from './db';
export type Mode='all'|'regular'|'special';
function pick(a:any[],m:Mode){return m==='regular'?a.slice(0,6):m==='special'?[a[6]]:a}
export async function categoryStats(limit=500,mode:Mode='all'){
 const {rows}=await db.query('SELECT expect,numbers,waves,zodiacs FROM draws ORDER BY open_time DESC LIMIT $1',[limit]);
 const r=[...rows].reverse(); const defs:any={tail:Array.from({length:10},(_,i)=>`${i}尾`),head:Array.from({length:5},(_,i)=>`${i}头`),oddEven:['单','双'],wave:['红波','蓝波','绿波'],zodiac:['鼠','牛','虎','兔','龙','蛇','马','羊','猴','鸡','狗','猪']};
 const out:any={}; for(const [k,vals] of Object.entries(defs)) out[k]=(vals as string[]).map(name=>({name,count:0,currentMiss:0,longestMiss:0,lastExpect:null,appearances:[]}));
 const gaps:any={};for(const k of Object.keys(out))gaps[k]=Array(out[k].length).fill(0);
 for(const d of r){const nums=pick(d.numbers,mode);const indexes=mode==='regular'?[0,1,2,3,4,5]:mode==='special'?[6]:[0,1,2,3,4,5,6];
  const seen:any={tail:new Set(),head:new Set(),oddEven:new Set(),wave:new Set(),zodiac:new Set()};
  nums.forEach((n:number)=>{seen.tail.add(n%10);seen.head.add(Math.floor(n/10));seen.oddEven.add(n%2?0:1)});
  indexes.forEach((idx:number)=>{const w=d.waves?.[idx];seen.wave.add(w==='red'?0:w==='blue'?1:w==='green'?2:-1);const z=d.zodiacs?.[idx];const zi=defs.zodiac.indexOf(z);if(zi>=0)seen.zodiac.add(zi)});
  for(const k of Object.keys(out)) for(let i=0;i<out[k].length;i++){if(seen[k].has(i)){out[k][i].count++;out[k][i].lastExpect=d.expect;out[k][i].appearances.push(d.expect);out[k][i].longestMiss=Math.max(out[k][i].longestMiss,gaps[k][i]);gaps[k][i]=0}else gaps[k][i]++}
 }
 for(const k of Object.keys(out))for(let i=0;i<out[k].length;i++){out[k][i].currentMiss=gaps[k][i];out[k][i].longestMiss=Math.max(out[k][i].longestMiss,gaps[k][i])}return out;
}
