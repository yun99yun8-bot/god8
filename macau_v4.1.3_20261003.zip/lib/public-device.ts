import {createHash,randomBytes} from 'crypto';
import type {NextRequest,NextResponse} from 'next/server';

export const PUBLIC_DEVICE_COOKIE='macau_public_device_v41';
const secret=()=>process.env.REPORT_SESSION_SECRET||process.env.ADMIN_SESSION_SECRET||process.env.ADMIN_PASSWORD||'change-me-v41';
export function newPublicDeviceToken(){return randomBytes(24).toString('base64url')}
export function hashPublicDevice(token:string){return createHash('sha256').update(secret()+':public-device:'+token).digest('hex')}
export function getPublicDevice(req:NextRequest){const token=req.cookies.get(PUBLIC_DEVICE_COOKIE)?.value||'';return token?{token,hash:hashPublicDevice(token)}:null}
export function ensurePublicDevice(req:NextRequest,res:NextResponse){const old=getPublicDevice(req);if(old)return old;const token=newPublicDeviceToken();res.cookies.set(PUBLIC_DEVICE_COOKIE,token,{httpOnly:true,secure:true,sameSite:'lax',path:'/',maxAge:365*86400});return {token,hash:hashPublicDevice(token)}}
export function shanghaiDate(){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())}
