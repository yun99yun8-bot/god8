import {db} from './db';
import {inferZodiacOffset,zodiacByNumber} from './zodiac-map';
export type DailyOmission={number:number;regularMiss:number;specialMiss:number;zodiac:string};

// V3.3.0: omission is calculated from all valid history in the database.
// Front-end display ranges never reset the omission counter.
export async function getDailyOmission(){
 const {rows}=await db.query(`SELECT expect,open_time,numbers,zodiacs FROM draws ORDER BY open_time ASC,id ASC`);
 const reg=Array(50).fill(0),sp=Array(50).fill(0);
 for(const d of rows){
   const rs=new Set<number>((d.numbers||[]).slice(0,6).map(Number));
   const sn=Number(d.numbers?.[6]);
   for(let n=1;n<=49;n++){
     reg[n]=rs.has(n)?0:reg[n]+1;
     sp[n]=sn===n?0:sp[n]+1;
   }
 }
 const latest=rows[rows.length-1];
 const offset=inferZodiacOffset(latest?.numbers||[],latest?.zodiacs||[]);
 return {
   drawsWindow:rows.length,
   windowLimit:null,
   scope:'all-history',
   items:Array.from({length:49},(_,i)=>({number:i+1,regularMiss:reg[i+1],specialMiss:sp[i+1],zodiac:zodiacByNumber(i+1,offset)})) as DailyOmission[]
 };
}
