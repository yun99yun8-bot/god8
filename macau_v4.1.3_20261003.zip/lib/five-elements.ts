export const FIVE_ELEMENTS:Record<string,number[]>={
 '金':[4,5,12,13,26,27,34,35,42,43],
 '木':[8,9,16,17,24,25,38,39,46,47],
 '水':[1,14,15,22,23,30,31,44,45],
 '火':[2,3,10,11,18,19,32,33,40,41,48,49],
 '土':[6,7,20,21,28,29,36,37]
};
export function elementOf(n:number){for(const [k,v] of Object.entries(FIVE_ELEMENTS))if(v.includes(n))return k;return '—'}
