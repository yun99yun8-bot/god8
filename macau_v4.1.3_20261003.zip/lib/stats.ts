import { db } from './db';
export async function getNumberStats(limit=500, mode:'all'|'regular'|'special'='all'){
 const {rows}=await db.query('SELECT expect,numbers FROM draws ORDER BY open_time DESC LIMIT $1',[limit]);
 const chronological=[...rows].reverse();
 const out=Array.from({length:49},(_,i)=>({number:i+1,count:0,lastExpect:null as string|null,currentMiss:0,longestMiss:0,appearances:[] as string[]}));
 const gap=Array(49).fill(0);
 for(const r of chronological){
   const nums:number[]= mode==='regular'?r.numbers.slice(0,6):mode==='special'?[r.numbers[6]]:r.numbers;
   const set=new Set(nums);
   for(let i=0;i<49;i++){
     if(set.has(i+1)){ out[i].count++; out[i].lastExpect=r.expect; out[i].appearances.push(r.expect); out[i].longestMiss=Math.max(out[i].longestMiss,gap[i]); gap[i]=0; }
     else gap[i]++;
   }
 }
 for(let i=0;i<49;i++){ out[i].currentMiss=gap[i]; out[i].longestMiss=Math.max(out[i].longestMiss,gap[i]); }
 return out;
}
