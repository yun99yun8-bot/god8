import { numberUniverse, waveOf, oddEven, headOf, tailOf } from './rules';
export type FilterResult={query:string; criteria:string[]; numbers:number[]};
export function parseFilter(query:string):FilterResult{
 let nums=numberUniverse(); const c:string[]=[]; const q=query.replace(/\s+/g,'');
 if(/红波|红/.test(q)){ nums=nums.filter(n=>waveOf(n)==='red'); c.push('红波'); }
 if(/蓝波|蓝/.test(q)){ nums=nums.filter(n=>waveOf(n)==='blue'); c.push('蓝波'); }
 if(/绿波|绿/.test(q)){ nums=nums.filter(n=>waveOf(n)==='green'); c.push('绿波'); }
 if(/双数|双/.test(q)){ nums=nums.filter(n=>oddEven(n)==='even'); c.push('双数'); }
 else if(/单数|单/.test(q)){ nums=nums.filter(n=>oddEven(n)==='odd'); c.push('单数'); }
 const hm=q.match(/([0-4])头/); if(hm){ const h=Number(hm[1]); nums=nums.filter(n=>headOf(n)===h); c.push(`${h}头`); }
 const tm=q.match(/([0-9])尾/); if(tm){ const t=Number(tm[1]); nums=nums.filter(n=>tailOf(n)===t); c.push(`${t}尾`); }
 return {query,criteria:c,numbers:nums};
}
