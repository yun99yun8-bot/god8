import {createHash,timingSafeEqual} from 'crypto';
import type {NextRequest} from 'next/server';

export const ADMIN_PASSPHRASE=process.env.ADMIN_PASSWORD||'yun888';
export const ADMIN_COOKIE='macau_admin_v3';
export const ADMIN_TOKEN_HEADER='x-admin-token';
export const ADMIN_TOKEN_STORAGE='macau_admin_token_v3';

function safeEqual(a:string|undefined|null,b:string){
  if(!a)return false;
  const aa=Buffer.from(a),bb=Buffer.from(b);
  return aa.length===bb.length&&timingSafeEqual(aa,bb);
}

export function adminToken(){
  const secret=process.env.ADMIN_SESSION_SECRET||ADMIN_PASSPHRASE;
  return createHash('sha256').update(`macau-admin-v3:${secret}`).digest('hex');
}

export function isAdmin(req:NextRequest){
  const token=adminToken();
  const cookie=req.cookies.get(ADMIN_COOKIE)?.value;
  const header=req.headers.get(ADMIN_TOKEN_HEADER);
  const legacy=req.headers.get('x-admin-pin');
  return safeEqual(cookie,token)||safeEqual(header,token)||safeEqual(legacy,ADMIN_PASSPHRASE);
}
