import { ZODIACS, type Zodiac, type ZodiacDraw, jumpNumber, targetByJump, buildTransitions } from './zodiac-jump';

type ScoreMap = Record<Zodiac, number>;
export type ZodiacModelResult = {
  id: number;
  name: string;
  short: string;
  description: string;
  sample: number;
  scores: ScoreMap;
  top3: Array<{zodiac: Zodiac; score: number}>;
};

function blank(): ScoreMap { return Object.fromEntries(ZODIACS.map(z=>[z,0])) as ScoreMap; }
function counts(draws: ZodiacDraw[]): ScoreMap { const s=blank(); for(const d of draws)s[d.zodiac]++; return s; }
function normalize(raw: ScoreMap): ScoreMap {
  const vals=ZODIACS.map(z=>raw[z]); const min=Math.min(...vals), max=Math.max(...vals);
  const out=blank();
  for(const z of ZODIACS) out[z]=max===min ? (max===0?0:50) : ((raw[z]-min)/(max-min))*100;
  return out;
}
function top3(scores: ScoreMap){return [...ZODIACS].map(z=>({zodiac:z,score:scores[z]})).sort((a,b)=>b.score-a.score).slice(0,3)}
function result(id:number,name:string,short:string,description:string,raw:ScoreMap,sample:number):ZodiacModelResult{
  const scores=normalize(raw); return {id,name,short,description,sample,scores,top3:top3(scores)};
}
function freq(draws: ZodiacDraw[], n:number){return counts(draws.slice(-Math.min(n,draws.length)))}
function omission(draws: ZodiacDraw[]){ const s=blank(); for(const z of ZODIACS){let miss=draws.length;for(let i=draws.length-1;i>=0;i--){if(draws[i].zodiac===z){miss=draws.length-1-i;break;}}s[z]=miss;} return s; }
function intervalFit(draws: ZodiacDraw[]){
 const s=blank();
 for(const z of ZODIACS){ const pos:number[]=[];draws.forEach((d,i)=>{if(d.zodiac===z)pos.push(i)}); if(pos.length<2){s[z]=0;continue;} const gaps=pos.slice(1).map((p,i)=>p-pos[i]); const avg=gaps.reduce((a,b)=>a+b,0)/gaps.length; const miss=draws.length-1-pos[pos.length-1]; s[z]=100-Math.abs(miss+1-avg); }
 return s;
}
function transitionFrom(draws: ZodiacDraw[], current: Zodiac){ const s=blank(); for(let i=1;i<draws.length;i++)if(draws[i-1].zodiac===current)s[draws[i].zodiac]++; return s; }
function jumpFrequency(draws: ZodiacDraw[]){ const tr=buildTransitions(draws), jc=Array(13).fill(0); for(const t of tr)jc[t.jump]++; const s=blank(); const cur=draws.at(-1)?.zodiac; if(!cur)return s; for(let j=1;j<=12;j++)s[targetByJump(cur,j)]=jc[j]; return s; }
function jumpRecency(draws: ZodiacDraw[]){ const tr=buildTransitions(draws), last=tr.slice(-60), s=blank(); const cur=draws.at(-1)?.zodiac; if(!cur)return s; last.forEach((t,i)=>{s[targetByJump(cur,t.jump)]+=i+1}); return s; }
function pathFollow(draws: ZodiacDraw[], len:number){ const s=blank(); if(draws.length<=len)return s; const path=draws.slice(-len).map(d=>d.zodiac); for(let i=0;i+len<draws.length;i++){let ok=true;for(let j=0;j<len;j++)if(draws[i+j].zodiac!==path[j]){ok=false;break;} if(ok)s[draws[i+len].zodiac]++;} return s; }
function markov2(draws: ZodiacDraw[]){ const s=blank(); if(draws.length<3)return s; const a=draws.at(-2)!.zodiac,b=draws.at(-1)!.zodiac; for(let i=2;i<draws.length;i++)if(draws[i-2].zodiac===a&&draws[i-1].zodiac===b)s[draws[i].zodiac]++; return s; }
function jumpSeq(draws: ZodiacDraw[], len:number){ const tr=buildTransitions(draws), s=blank(); if(tr.length<=len)return s; const seq=tr.slice(-len).map(t=>t.jump); const cur=draws.at(-1)!.zodiac; for(let i=0;i+len<tr.length;i++){let ok=true;for(let j=0;j<len;j++)if(tr[i+j].jump!==seq[j]){ok=false;break;}if(ok)s[targetByJump(cur,tr[i+len].jump)]++;} return s; }
function momentum(draws: ZodiacDraw[]){ const a=freq(draws,30), b=freq(draws,100), s=blank(); const aN=Math.min(30,draws.length)||1,bN=Math.min(100,draws.length)||1; for(const z of ZODIACS)s[z]=a[z]/aN-b[z]/bN; return s; }
function coldRebound(draws: ZodiacDraw[]){ const long=freq(draws,Math.min(500,draws.length)), recent=freq(draws,50), s=blank(); const lN=Math.min(500,draws.length)||1,rN=Math.min(50,draws.length)||1; for(const z of ZODIACS)s[z]=(long[z]/lN)-(recent[z]/rN); return s; }
function weightedRecent(draws: ZodiacDraw[], n:number){ const s=blank(), arr=draws.slice(-n); arr.forEach((d,i)=>s[d.zodiac]+=i+1); return s; }
function sameJumpAfter(draws: ZodiacDraw[]){ const tr=buildTransitions(draws), s=blank(); if(tr.length<2)return s; const last=tr.at(-1)!.jump, cur=draws.at(-1)!.zodiac; for(let i=1;i<tr.length;i++)if(tr[i-1].jump===last)s[targetByJump(cur,tr[i].jump)]++; return s; }
function repeatAfterCurrent(draws: ZodiacDraw[]){ const s=blank(); const cur=draws.at(-1)?.zodiac; if(!cur)return s; for(let i=1;i<draws.length;i++)if(draws[i-1].zodiac===cur)s[draws[i].zodiac]+= (draws[i].zodiac===cur?1.25:1); return s; }
function ensemble(models: ZodiacModelResult[]){ const s=blank(); for(const m of models){m.top3.forEach((x,i)=>s[x.zodiac]+=3-i);} return s; }

export function build20ZodiacModels(draws: ZodiacDraw[]): ZodiacModelResult[]{
 const cur=draws.at(-1)?.zodiac || '鼠';
 const models: ZodiacModelResult[] = [
  result(1,'全历史频率','长期基准','统计当前数据库全部特码生肖的历史出现次数。',freq(draws,draws.length),draws.length),
  result(2,'近30期频率','短期热度','只观察最近30期的特码生肖分布。',freq(draws,30),Math.min(30,draws.length)),
  result(3,'近50期频率','近期稳定','观察最近50期的生肖频率。',freq(draws,50),Math.min(50,draws.length)),
  result(4,'近100期频率','中短周期','观察最近100期频率，降低极短期波动。',freq(draws,100),Math.min(100,draws.length)),
  result(5,'近200期频率','中周期','观察最近200期的生肖分布。',freq(draws,200),Math.min(200,draws.length)),
  result(6,'近500期频率','长期窗口','最多使用最近500期作为长期频率窗口。',freq(draws,500),Math.min(500,draws.length)),
  result(7,'当前遗漏','遗漏位置','按每个生肖距离最近一次出现的期数排序。',omission(draws),draws.length),
  result(8,'平均间隔贴近度','间隔结构','比较当前遗漏与该生肖自身历史平均出现间隔。',intervalFit(draws),draws.length),
  result(9,'当前生肖转移','一阶转移',`只统计历史上“${cur}”之后下一期实际出现的生肖。`,transitionFrom(draws,cur),draws.length),
  result(10,'12跳历史频率','跳数基准','把历史所有相邻两期转换成跳1–跳12，再映射到当前生肖。',jumpFrequency(draws),Math.max(0,draws.length-1)),
  result(11,'近期跳数加权','跳数趋势','最近60次跳转越接近当前权重越高。',jumpRecency(draws),Math.min(60,Math.max(0,draws.length-1))),
  result(12,'最近2期路径复现','路径2','寻找历史上与最近2期生肖完全一致的路径，并统计其后生肖。',pathFollow(draws,2),draws.length),
  result(13,'最近3期路径复现','路径3','寻找历史上与最近3期生肖完全一致的路径。',pathFollow(draws,3),draws.length),
  result(14,'最近4期路径复现','路径4','寻找历史上与最近4期生肖完全一致的路径。',pathFollow(draws,4),draws.length),
  result(15,'二阶生肖转移','二阶状态','同时使用最近两个生肖作为当前状态，寻找历史相同状态后的生肖。',markov2(draws),draws.length),
  result(16,'短期升温','趋势变化','比较近30期与近100期占比，识别近期上升的生肖。',momentum(draws),Math.min(100,draws.length)),
  result(17,'长期偏离','冷热偏差','比较近50期与长期窗口，显示近期低于长期基准的生肖。',coldRebound(draws),Math.min(500,draws.length)),
  result(18,'近期加权频率','时间权重','最近120期中，越新的开奖记录权重越高。',weightedRecent(draws,120),Math.min(120,draws.length)),
  result(19,'跳数组合复现','跳序列','按最近2次跳数组合寻找历史相同跳法之后的下一跳。',jumpSeq(draws,2),Math.max(0,draws.length-1)),
  result(20,'同跳后继','跳法后继','统计历史上最近一次相同跳数之后，下一跳通常落到哪些生肖。',sameJumpAfter(draws),Math.max(0,draws.length-1)),
 ];
 return models;
}

export function zodiacConsensus(models: ZodiacModelResult[]){
 const s=ensemble(models); const ranked=top3(normalize(s));
 const support=Object.fromEntries(ZODIACS.map(z=>[z,models.filter(m=>m.top3.some(x=>x.zodiac===z)).length])) as Record<Zodiac,number>;
 return ranked.map(x=>({...x,support:support[x.zodiac]}));
}
