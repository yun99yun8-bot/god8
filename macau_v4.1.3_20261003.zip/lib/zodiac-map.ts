export const ZODIACS=['鼠','牛','虎','兔','龙','蛇','马','羊','猴','鸡','狗','猪'] as const;

export function normalizeZodiac(v:any){
 const s=String(v||'').trim();
 const map:Record<string,string>={ '龍':'龙','馬':'马','雞':'鸡','豬':'猪' };
 return map[s]||s;
}

export function inferZodiacOffset(numbers:any[]=[],zodiacs:any[]=[]){
 for(let i=0;i<Math.min(numbers.length,zodiacs.length);i++){
  const n=Number(numbers[i]); const z=normalizeZodiac(zodiacs[i]); const zi=(ZODIACS as readonly string[]).indexOf(z);
  if(n>=1&&n<=49&&zi>=0) return (zi+n)%12;
 }
 return null;
}

export function chineseRelatedYear(input:any){
 try{
  const d=input instanceof Date?input:new Date(input);
  if(!Number.isFinite(d.getTime()))return null;
  const parts=new Intl.DateTimeFormat('zh-CN-u-ca-chinese',{timeZone:'Asia/Shanghai',year:'numeric',month:'numeric',day:'numeric'}).formatToParts(d);
  const relatedYearPart=parts.find(p=>String(p.type)==='relatedYear');
  const y=Number(relatedYearPart?.value||'');
  return Number.isFinite(y)&&y>1900?y:null;
 }catch{return null}
}

export function zodiacYearName(input:any){
 const y=chineseRelatedYear(input);if(!y)return null;
 const idx=((y-2020)%12+12)%12; // 2020 = 鼠年
 return ZODIACS[idx];
}

export function zodiacOffsetForDate(input:any){
 const y=chineseRelatedYear(input);if(!y)return null;
 const idx=((y-2020)%12+12)%12;
 return (idx+1)%12; // 1号对应当年生肖
}

export function rowZodiacOffset(numbers:any[]=[],zodiacs:any[]=[],openTime?:any){
 return inferZodiacOffset(numbers,zodiacs) ?? zodiacOffsetForDate(openTime);
}

export function zodiacByNumber(n:number,offset:number|null){
 if(offset===null||n<1||n>49)return '—';
 const i=((offset-n)%12+12)%12;
 return ZODIACS[i];
}

export function zodiacForDrawNumber(n:number,zodiac:any,openTime:any,numbers:any[]=[],zodiacs:any[]=[]){
 const direct=normalizeZodiac(zodiac);
 if((ZODIACS as readonly string[]).includes(direct))return direct;
 return zodiacByNumber(n,rowZodiacOffset(numbers,zodiacs,openTime));
}
