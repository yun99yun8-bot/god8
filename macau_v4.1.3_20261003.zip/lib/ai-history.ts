import {db} from './db';
import {waveOf,headOf,tailOf,oddEven} from './rules';
import {normalizeZodiac,ZODIACS} from './zodiac-map';
import {directionalJump} from './zodiac-jump';
type Mode='all'|'regular'|'special';
const modeLabel=(m:Mode)=>m==='regular'?'正码':m==='special'?'特码':'全部7码';
function pick(nums:number[],m:Mode){return m==='regular'?nums.slice(0,6):m==='special'?[nums[6]]:nums}
function modeFromQuestion(q:string,fallback:Mode):Mode{
 if(/特码|特碼/.test(q))return 'special';
 if(/正码|正碼/.test(q))return 'regular';
 if(/全部|七码|7码|七個|7個/.test(q))return 'all';
 return fallback;
}
function zodiacPick(zs:any[],m:Mode){
 const a=(Array.isArray(zs)?zs:[]).map(normalizeZodiac).filter(z=>(ZODIACS as readonly string[]).includes(z));
 return m==='regular'?a.slice(0,6):m==='special'?(a[6]?[a[6]]:[]):a.slice(0,7);
}
function pct(a:number,b:number){return b?`${(a/b*100).toFixed(1)}%`:'0.0%'}
function firstZodiac(q:string){return (ZODIACS as readonly string[]).find(z=>q.includes(z))||null}

export async function answerHistoryQuestion(question:string,limit=500,mode:Mode='all',context:any=null){
 let q=question.trim();
 if(context&&/^(它|这个|這個|那个|那個|它的|这个的|這個的)/.test(q)){if(context.zodiac)q=`${context.zodiac}${q}`;else if(context.number)q=`${String(context.number).padStart(2,'0')}${q}`}
 if(!q)return {answer:'请输入你想查询的历史数据问题。',evidence:[]};
 const effectiveMode=modeFromQuestion(q,mode);
 const {rows}=await db.query('SELECT expect,open_time,numbers,waves,zodiacs FROM draws ORDER BY open_time DESC LIMIT $1',[limit]);
 if(!rows.length)return {answer:'数据库里暂时没有可分析的历史开奖记录。',evidence:[]};
 const draws=rows.map((r:any)=>({...r,nums:pick((r.numbers||[]).map(Number),effectiveMode),zs:zodiacPick(r.zodiacs,effectiveMode)}));

 // 生肖跳转：以生肖本体为中心，左/右分开，左最多跳7、右最多跳6。
 const jumpNamed=firstZodiac(q);
 if(jumpNamed&&/跳|左|右|去向|跳转|跳轉/.test(q)){
   const chrono=[...rows].reverse().map((r:any)=>({expect:String(r.expect),z:normalizeZodiac(r.zodiacs?.[6])})).filter((x:any)=>x.z);
   const moves:any[]=[];
   for(let i=1;i<chrono.length;i++){const a=chrono[i-1],b=chrono[i];if(a.z!==jumpNamed)continue;const d=directionalJump(a.z as any,b.z as any);moves.push({to:b.z,direction:d.direction,jump:d.jump,expect:b.expect})}
   const side=/左/.test(q)?'left':/右/.test(q)?'right':null;const filtered=side?moves.filter(x=>x.direction===side):moves;
   if(!filtered.length)return {answer:`最近${rows.length}期特码历史里，${jumpNamed}${side==='left'?'向左':side==='right'?'向右':''}暂时没有可用跳转记录。`,evidence:[],meta:{zodiac:jumpNamed,kind:'jump'}};
   const m=new Map<string,{to:string,direction:string,jump:number,count:number,last:string}>();for(const x of filtered){const k=`${x.direction}-${x.jump}-${x.to}`,v=m.get(k);if(v)v.count++;else m.set(k,{...x,count:1,last:x.expect})}
   const top=[...m.values()].sort((a,b)=>b.count-a.count||a.jump-b.jump).slice(0,6);
   return {answer:`以${jumpNamed}为本体，最近${rows.length}期特码历史中${side==='left'?'向左':side==='right'?'向右':'左右合看'}最常见的去向是：${top.map(x=>`${x.direction==='left'?'左':x.direction==='right'?'右':'本体'}跳${x.jump}→${x.to}（${x.count}次）`).join('；')}。这里左、右分别计跳数，最大只到左7/右6。`,evidence:top.map(x=>x.last),meta:{zodiac:jumpNamed,kind:'jump',top}};
 }

 // 生肖问题优先识别，避免“明天特码什么生肖概率最大”落入兜底说明。
 const asksZodiac=/生肖|属相|屬相|三肖|平特一肖|连肖|連肖/.test(q)||(ZODIACS as readonly string[]).some(z=>q.includes(z));
 if(asksZodiac){
   const counts=new Map<string,number>((ZODIACS as readonly string[]).map(z=>[z,0]));let total=0;
   for(const r of draws)for(const z of r.zs){counts.set(z,(counts.get(z)||0)+1);total++}
   if(total===0)return {answer:`最近${draws.length}期${modeLabel(effectiveMode)}记录里暂时没有可用的生肖字段，无法直接计算生肖历史占比。`,evidence:[]};
   const named=firstZodiac(q);
   if(named&&/多少|几次|幾次|占比|比例|概率|機率|几率|多久|遗漏|遺漏|没出|未出/.test(q)){
     const c=counts.get(named)||0;let miss=0,found=false;
     for(const r of draws){if(r.zs.includes(named)){found=true;break}miss++}
     const recent=draws.filter((r:any)=>r.zs.includes(named)).slice(0,12).map((r:any)=>r.expect);
     return {answer:`${named}在最近${draws.length}期${modeLabel(effectiveMode)}历史中出现 ${c} 次，历史占比 ${pct(c,total)}；当前连续 ${miss} 期未出现${found?'':'（本窗口内未出现）'}。`,evidence:recent,meta:{zodiac:named,count:c,total,currentMiss:miss}};
   }
   const ranked=[...counts.entries()].map(([z,c])=>({z,c})).sort((a,b)=>b.c-a.c||ZODIACS.indexOf(a.z as any)-ZODIACS.indexOf(b.z as any));
   if(/概率|機率|几率|最大|最高|最多|热门|熱門|推荐|推薦|前三|三个|三個|三肖|明天|下期|下一期/.test(q)){
     const topN=/前三|三个|三個|三肖/.test(q)?3:3;
     const top=ranked.slice(0,topN);
     const first=top[0];
     return {answer:`按最近${draws.length}期${modeLabel(effectiveMode)}历史统计，当前历史占比最高的是${first.z}：${pct(first.c,total)}（${first.c}次）。前三为：${top.map((x,i)=>`${i+1}.${x.z} ${pct(x.c,total)}（${x.c}次）`).join('；')}。这是历史样本占比，不代表下一期开奖的真实概率。`,evidence:[],meta:{kind:'zodiac-ranking',mode:effectiveMode,total,top}};
   }
   return {answer:`最近${draws.length}期${modeLabel(effectiveMode)}生肖历史占比：${ranked.slice(0,6).map(x=>`${x.z} ${pct(x.c,total)}`).join('、')}。`,evidence:[]};
 }

 const nums=[...q.matchAll(/(?<!\d)(0?[1-9]|[1-4]\d)(?!\d)/g)].map(x=>Number(x[1])).filter(n=>n>=1&&n<=49);
 const n=nums[0];
 if(n){const hits=draws.filter((r:any)=>r.nums.includes(n));let miss=0;for(const r of draws){if(r.nums.includes(n))break;miss++}const recent=hits.slice(0,12).map((r:any)=>r.expect);return {answer:`${String(n).padStart(2,'0')}在最近${draws.length}期${modeLabel(effectiveMode)}中出现 ${hits.length} 次，当前遗漏 ${miss} 期${hits[0]?`，最近一次是第 ${hits[0].expect} 期`:''}。`,evidence:recent,meta:{number:n,count:hits.length,currentMiss:miss}}}
 const wantMiss=/遗漏|遺漏|没出|未出/.test(q), wantHot=/最多|高频|高頻|热门|熱門|常出|频率|頻率|概率最大|最高概率/.test(q), wantCold=/最少|低频|低頻|冷门|冷門/.test(q);
 const stats=Array.from({length:49},(_,i)=>({n:i+1,c:0,miss:0})); for(const r of draws){const s=new Set(r.nums);for(const x of stats)if(s.has(x.n))x.c++} for(const x of stats){for(const r of draws){if(r.nums.includes(x.n))break;x.miss++}}
 if(wantMiss){const a=[...stats].sort((a,b)=>b.miss-a.miss).slice(0,8);return {answer:`最近${draws.length}期${modeLabel(effectiveMode)}中，当前遗漏最长的是 ${String(a[0].n).padStart(2,'0')}（${a[0].miss}期）。其后为：${a.slice(1).map(x=>`${String(x.n).padStart(2,'0')}（${x.miss}期）`).join('、')}。`,evidence:[]}}
 if(wantHot||wantCold){const a=[...stats].sort((a,b)=>wantCold?a.c-b.c:b.c-a.c).slice(0,8);return {answer:`最近${draws.length}期${modeLabel(effectiveMode)}中，${wantCold?'出现最少':'出现最多'}的是 ${String(a[0].n).padStart(2,'0')}（${a[0].c}次）。${wantCold?'较冷':'较热'}前8：${a.map(x=>`${String(x.n).padStart(2,'0')} ${x.c}次`).join('、')}。`,evidence:[]}}
 const wave=/红波|蓝波|绿波/.exec(q)?.[0]; if(wave){const key=wave[0]==='红'?'red':wave[0]==='蓝'?'blue':'green';let count=0,total=0;for(const r of draws)for(const x of r.nums){total++;if(waveOf(x)===key)count++}return {answer:`最近${draws.length}期${modeLabel(effectiveMode)}共统计 ${total} 个号码，${wave}出现 ${count} 次，占 ${pct(count,total)}。`,evidence:[]}}
 if(/单数|双数|单双|單雙/.test(q)){let odd=0,total=0;for(const r of draws)for(const x of r.nums){total++;if(oddEven(x)==='odd')odd++}return {answer:`最近${draws.length}期${modeLabel(effectiveMode)}中，单数 ${odd} 次（${pct(odd,total)}），双数 ${total-odd} 次（${pct(total-odd,total)}）。`,evidence:[]}}
 const element=/[金木水火土]/.exec(q)?.[0]; if(element){const sets:Record<string,Set<number>>={金:new Set([4,5,12,13,26,27,34,35,42,43]),木:new Set([8,9,16,17,24,25,38,39,46,47]),水:new Set([1,14,15,22,23,30,31,44,45]),火:new Set([2,3,10,11,18,19,32,33,40,41,48,49]),土:new Set([6,7,20,21,28,29,36,37])};let c=0,total=0;for(const r of draws)for(const x of r.nums){total++;if(sets[element].has(x))c++}return {answer:`最近${draws.length}期${modeLabel(effectiveMode)}中，${element}行号码出现 ${c} 次，占 ${pct(c,total)}。`,evidence:[],meta:{element,count:c,total}}}
 const homeWild=/家肖|野肖/.exec(q)?.[0]; if(homeWild){const domestic=new Set(['牛','马','羊','鸡','狗','猪']);let c=0,total=0;for(const r of draws)for(const z of r.zs){total++;if(homeWild==='家肖'?domestic.has(z):!domestic.has(z))c++}return {answer:`最近${draws.length}期${modeLabel(effectiveMode)}中，${homeWild}出现 ${c} 次，占 ${pct(c,total)}。`,evidence:[],meta:{kind:'homeWild',name:homeWild,count:c,total}}}
 const tail=/([0-9])\s*尾/.exec(q);if(tail){const t=Number(tail[1]);let c=0,total=0;for(const r of draws)for(const x of r.nums){total++;if(tailOf(x)===t)c++}return {answer:`最近${draws.length}期${modeLabel(effectiveMode)}中，${t}尾共出现 ${c} 次，占 ${pct(c,total)}。`,evidence:[]}}
 const head=/([0-4])\s*头/.exec(q);if(head){const h=Number(head[1]);let c=0,total=0;for(const r of draws)for(const x of r.nums){total++;if(headOf(x)===h)c++}return {answer:`最近${draws.length}期${modeLabel(effectiveMode)}中，${h}头共出现 ${c} 次，占 ${pct(c,total)}。`,evidence:[]}}
 const hot=[...stats].sort((a,b)=>b.c-a.c).slice(0,3);const cold=[...stats].sort((a,b)=>b.miss-a.miss).slice(0,3);return {answer:`我先给你当前${draws.length}期${modeLabel(effectiveMode)}的数据概况：高频号码 ${hot.map(x=>String(x.n).padStart(2,'0')+'（'+x.c+'次）').join('、')}；当前遗漏较长 ${cold.map(x=>String(x.n).padStart(2,'0')+'（'+x.miss+'期）').join('、')}。如果你指的是某个生肖、波色、五行或号码，继续直接问即可。`,evidence:[],meta:{kind:'snapshot'}};
}
