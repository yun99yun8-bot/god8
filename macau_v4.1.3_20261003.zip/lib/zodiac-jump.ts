import { db } from './db';

export const ZODIACS = ['鼠','牛','虎','兔','龙','蛇','马','羊','猴','鸡','狗','猪'] as const;
export type Zodiac = typeof ZODIACS[number];

const TRAD_TO_SIMP: Record<string,string> = {
  '龍':'龙','馬':'马','雞':'鸡','豬':'猪',
};

export function normalizeZodiac(value: unknown): Zodiac | null {
  if (value == null) return null;
  const raw = String(value).trim();
  const simp = TRAD_TO_SIMP[raw] || raw;
  return (ZODIACS as readonly string[]).includes(simp) ? simp as Zodiac : null;
}

export function jumpNumber(from: Zodiac, to: Zodiac): number {
  const a = ZODIACS.indexOf(from);
  const b = ZODIACS.indexOf(to);
  return ((b - a + 12) % 12) + 1;
}

export function targetByJump(from: Zodiac, jump: number): Zodiac {
  const safe = Math.min(12, Math.max(1, Math.trunc(jump)));
  return ZODIACS[(ZODIACS.indexOf(from) + safe - 1) % 12];
}

export type ZodiacDraw = {
  expect: string;
  openTime: Date | string;
  zodiac: Zodiac;
  specialNumber: number | null;
};

export type ZodiacTransition = {
  from: Zodiac;
  to: Zodiac;
  jump: number;
  fromExpect: string;
  toExpect: string;
  toTime: Date | string;
};

export async function loadSpecialZodiacDraws(limit = 500): Promise<ZodiacDraw[]> {
  const safe = Math.min(5000, Math.max(3, Math.trunc(limit)));
  const { rows } = await db.query(
    'SELECT expect, open_time, numbers, zodiacs FROM draws ORDER BY open_time DESC LIMIT $1',
    [safe]
  );
  return rows.reverse().map((r: any) => {
    const z = Array.isArray(r.zodiacs) ? normalizeZodiac(r.zodiacs[6]) : null;
    return {
      expect: String(r.expect),
      openTime: r.open_time,
      zodiac: z,
      specialNumber: Array.isArray(r.numbers) && r.numbers.length >= 7 ? Number(r.numbers[6]) : null,
    };
  }).filter((x: any): x is ZodiacDraw => Boolean(x.zodiac));
}

export function buildTransitions(draws: ZodiacDraw[]): ZodiacTransition[] {
  const out: ZodiacTransition[] = [];
  for (let i = 1; i < draws.length; i++) {
    const a = draws[i - 1], b = draws[i];
    out.push({
      from: a.zodiac,
      to: b.zodiac,
      jump: jumpNumber(a.zodiac, b.zodiac),
      fromExpect: a.expect,
      toExpect: b.expect,
      toTime: b.openTime,
    });
  }
  return out;
}

export function jumpStats(transitions: ZodiacTransition[]) {
  return Array.from({ length: 12 }, (_, i) => {
    const jump = i + 1;
    const positions = transitions.map((t, idx) => t.jump === jump ? idx : -1).filter(x => x >= 0);
    const count = positions.length;
    let currentMiss = transitions.length;
    for (let k = transitions.length - 1, miss = 0; k >= 0; k--, miss++) {
      if (transitions[k].jump === jump) { currentMiss = miss; break; }
    }
    let longestMiss = 0;
    if (positions.length) {
      longestMiss = Math.max(longestMiss, positions[0]);
      for (let p = 1; p < positions.length; p++) longestMiss = Math.max(longestMiss, positions[p] - positions[p - 1] - 1);
      longestMiss = Math.max(longestMiss, transitions.length - 1 - positions[positions.length - 1]);
    } else longestMiss = transitions.length;
    const last = positions.length ? transitions[positions[positions.length - 1]] : null;
    return {
      jump,
      count,
      pct: transitions.length ? count / transitions.length * 100 : 0,
      currentMiss,
      longestMiss,
      lastExpect: last?.toExpect || null,
    };
  });
}

export function transitionMatrix(transitions: ZodiacTransition[]) {
  const matrix = ZODIACS.map(() => ZODIACS.map(() => 0));
  for (const t of transitions) matrix[ZODIACS.indexOf(t.from)][ZODIACS.indexOf(t.to)]++;
  return matrix;
}

export function exactTransitionHistory(transitions: ZodiacTransition[], from: Zodiac, jump: number) {
  const target = targetByJump(from, jump);
  return transitions.filter(t => t.from === from && t.to === target).reverse();
}

export function findPathMatches(draws: ZodiacDraw[], pathLength = 4) {
  if (draws.length <= pathLength) return { path: draws.map(d => d.zodiac), matches: [] as any[] };
  const path = draws.slice(-pathLength).map(d => d.zodiac);
  const matches: Array<{startExpect:string;endExpect:string;path:Zodiac[];next:Zodiac;nextExpect:string;jump:number}> = [];
  const maxStart = draws.length - pathLength - 1;
  for (let i = 0; i <= maxStart; i++) {
    const candidate = draws.slice(i, i + pathLength).map(d => d.zodiac);
    if (candidate.every((z, idx) => z === path[idx])) {
      const next = draws[i + pathLength];
      const end = draws[i + pathLength - 1];
      matches.push({
        startExpect: draws[i].expect,
        endExpect: end.expect,
        path: candidate,
        next: next.zodiac,
        nextExpect: next.expect,
        jump: jumpNumber(end.zodiac, next.zodiac),
      });
    }
  }
  return { path, matches: matches.reverse() };
}

export type DirectionalJump='left'|'right'|'center';
export type DirectionalTransition={from:Zodiac;to:Zodiac;direction:DirectionalJump;jump:number;fromExpect:string;toExpect:string;toTime:Date|string};
export function directionalJump(from:Zodiac,to:Zodiac):{direction:DirectionalJump;jump:number}{
  if(from===to)return {direction:'center',jump:1};
  const a=ZODIACS.indexOf(from),b=ZODIACS.indexOf(to);
  const left=(a-b+12)%12,right=(b-a+12)%12;
  if(left<=right)return {direction:'left',jump:left+1};
  return {direction:'right',jump:right+1};
}
export function directionalTarget(from:Zodiac,direction:'left'|'right',jump:number):Zodiac{
  const step=Math.max(2,Math.min(direction==='left'?7:6,Math.trunc(jump)))-1;
  const a=ZODIACS.indexOf(from);
  return ZODIACS[(a+(direction==='left'?-step:step)+12)%12];
}
export function directionalLayout(center:Zodiac){
  return {
    left:Array.from({length:6},(_,i)=>{const jump=i+2;return {jump,zodiac:directionalTarget(center,'left',jump)}}).reverse(),
    center:{jump:1,zodiac:center},
    right:Array.from({length:5},(_,i)=>{const jump=i+2;return {jump,zodiac:directionalTarget(center,'right',jump)}})
  };
}
export function buildDirectionalTransitions(draws:ZodiacDraw[]):DirectionalTransition[]{
  const out:DirectionalTransition[]=[];
  for(let i=1;i<draws.length;i++){const a=draws[i-1],b=draws[i],d=directionalJump(a.zodiac,b.zodiac);out.push({from:a.zodiac,to:b.zodiac,direction:d.direction,jump:d.jump,fromExpect:a.expect,toExpect:b.expect,toTime:b.openTime})}
  return out;
}
