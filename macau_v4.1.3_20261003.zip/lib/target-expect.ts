import {db} from './db';

export function incrementExpect(value:any){
  const s=String(value??'').trim();
  if(!/^\d+$/.test(s))return '';
  try{return (BigInt(s)+1n).toString().padStart(s.length,'0')}catch{return ''}
}
function numeric(v:any){const s=String(v??'').trim();return /^\d+$/.test(s)?BigInt(s):null}

/**
 * One authoritative publication target.
 * - If a published future period is still waiting for its draw, keep using it so all play types stay on one period.
 * - Otherwise advance from the newest real draw (or newest publication when no draw exists).
 */
export async function getAutoPublishExpect(){
  const [drawQ,pubQ]=await Promise.all([
    db.query(`SELECT expect FROM draws ORDER BY open_time DESC,id DESC LIMIT 1`),
    db.query(`SELECT target_expect FROM published_predictions WHERE status='published' AND target_expect IS NOT NULL ORDER BY updated_at DESC,created_at DESC LIMIT 300`)
  ]);
  const drawExpect=String(drawQ.rows[0]?.expect||'').trim();
  const dn=numeric(drawExpect);
  let publishedExpect='';let pn:bigint|null=null;
  for(const row of pubQ.rows){
    const s=String(row.target_expect||'').trim(),n=numeric(s);
    if(n!==null&&(pn===null||n>pn)){pn=n;publishedExpect=s}
  }
  // A publication ahead of the latest draw is the one currently waiting to open.
  if(pn!==null&&(dn===null||pn>dn))return {expect:publishedExpect,latestDraw:drawExpect,latestPublished:publishedExpect,pending:true};
  const base=dn!==null?drawExpect:publishedExpect;
  return {expect:incrementExpect(base),latestDraw:drawExpect,latestPublished:publishedExpect,pending:false};
}
