import {build20ZodiacModels, zodiacConsensus} from './zodiac-models';
import type {ZodiacDraw} from './zodiac-jump';

export type BacktestRow={expect:string;actual:string;picks:string[];hit:boolean};
export function rollingBacktest(draws:ZodiacDraw[], window=100){
 const rows:BacktestRow[]=[];
 const start=Math.max(30,draws.length-window);
 for(let i=start;i<draws.length;i++){
  const hist=draws.slice(0,i);
  if(hist.length<30)continue;
  const picks=zodiacConsensus(build20ZodiacModels(hist)).map(x=>x.zodiac);
  rows.push({expect:draws[i].expect,actual:draws[i].zodiac,picks,hit:picks.includes(draws[i].zodiac)});
 }
 const hits=rows.filter(x=>x.hit).length;
 return {rows,hits,total:rows.length,rate:rows.length?hits/rows.length*100:0,baseline:25};
}
