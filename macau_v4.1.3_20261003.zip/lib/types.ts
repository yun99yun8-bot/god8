export type Draw = { expect:string; openTime:string; openCode:string; wave?:string; zodiac?:string; [k:string]:unknown };
