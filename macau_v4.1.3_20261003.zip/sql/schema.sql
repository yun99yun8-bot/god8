CREATE TABLE IF NOT EXISTS draws (
 id BIGSERIAL PRIMARY KEY, expect VARCHAR(32) UNIQUE NOT NULL, open_time TIMESTAMP NOT NULL,
 numbers SMALLINT[] NOT NULL CHECK(array_length(numbers,1)=7), waves TEXT[], zodiacs TEXT[], raw_json JSONB NOT NULL,
 source VARCHAR(64) NOT NULL DEFAULT 'macaumarksix', received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS draws_open_time_idx ON draws(open_time DESC);
CREATE TABLE IF NOT EXISTS source_logs(id BIGSERIAL PRIMARY KEY,source VARCHAR(64) NOT NULL,status VARCHAR(16) NOT NULL,message TEXT,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE INDEX IF NOT EXISTS source_logs_created_idx ON source_logs(created_at DESC);
CREATE TABLE IF NOT EXISTS year_rules(year INT PRIMARY KEY,rules JSONB NOT NULL,updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS saved_filters(id BIGSERIAL PRIMARY KEY,name VARCHAR(100) NOT NULL,query TEXT NOT NULL,parsed JSONB NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS app_settings(key VARCHAR(80) PRIMARY KEY,value JSONB NOT NULL,updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS published_predictions (
 id BIGSERIAL PRIMARY KEY,
 target_expect VARCHAR(32),
 type VARCHAR(32) NOT NULL,
 content TEXT NOT NULL,
 status VARCHAR(16) NOT NULL DEFAULT 'published',
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS published_predictions_created_idx ON published_predictions(created_at DESC);
ALTER TABLE published_predictions ADD COLUMN IF NOT EXISTS payload JSONB NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE published_predictions ADD COLUMN IF NOT EXISTS published_by VARCHAR(80) NOT NULL DEFAULT 'admin';
ALTER TABLE published_predictions ADD COLUMN IF NOT EXISTS published_at TIMESTAMPTZ NOT NULL DEFAULT NOW();
ALTER TABLE published_predictions ADD COLUMN IF NOT EXISTS settlement JSONB;
ALTER TABLE published_predictions ADD COLUMN IF NOT EXISTS settled_at TIMESTAMPTZ;
ALTER TABLE published_predictions ADD COLUMN IF NOT EXISTS version INT NOT NULL DEFAULT 1;
CREATE TABLE IF NOT EXISTS publication_revisions(
 id BIGSERIAL PRIMARY KEY,prediction_id BIGINT NOT NULL REFERENCES published_predictions(id) ON DELETE CASCADE,
 version INT NOT NULL,type VARCHAR(32) NOT NULL,target_expect VARCHAR(32),content TEXT NOT NULL,payload JSONB NOT NULL DEFAULT '{}'::jsonb,
 action VARCHAR(24) NOT NULL DEFAULT 'publish',created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS publication_revisions_prediction_idx ON publication_revisions(prediction_id,version DESC);

CREATE TABLE IF NOT EXISTS daily_zodiac_fortune (
 id BIGSERIAL PRIMARY KEY,
 fortune_date DATE NOT NULL UNIQUE,
 source VARCHAR(120) NOT NULL,
 source_url TEXT NOT NULL,
 source_time TEXT,
 content JSONB NOT NULL DEFAULT '{}'::jsonb,
 fetched_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS daily_zodiac_fortune_date_idx ON daily_zodiac_fortune(fortune_date DESC);

-- V4.0 报幕专属系统 ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS report_users (
 id BIGSERIAL PRIMARY KEY,
 parent_id BIGINT REFERENCES report_users(id) ON DELETE RESTRICT,
 root_id BIGINT REFERENCES report_users(id) ON DELETE RESTRICT,
 access_code VARCHAR(18) UNIQUE NOT NULL,
 access_code_norm VARCHAR(18) UNIQUE NOT NULL,
 password_hash TEXT,
 session_version INT NOT NULL DEFAULT 1,
 parent_remark VARCHAR(80) NOT NULL DEFAULT '',
 active BOOLEAN NOT NULL DEFAULT TRUE,
 created_by_admin BOOLEAN NOT NULL DEFAULT FALSE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 activated_at TIMESTAMPTZ,
 last_login_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS report_users_parent_idx ON report_users(parent_id);
CREATE INDEX IF NOT EXISTS report_users_root_idx ON report_users(root_id);
CREATE INDEX IF NOT EXISTS report_users_active_idx ON report_users(active);

CREATE TABLE IF NOT EXISTS report_auth_events (
 id BIGSERIAL PRIMARY KEY,
 ip_hash VARCHAR(80),
 code_hash VARCHAR(80),
 success BOOLEAN NOT NULL DEFAULT FALSE,
 stage VARCHAR(24) NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS report_auth_events_time_idx ON report_auth_events(created_at DESC);

CREATE TABLE IF NOT EXISTS report_play_odds (
 play_type VARCHAR(40) PRIMARY KEY,
 odds NUMERIC(14,4) NOT NULL DEFAULT 0,
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 updated_by VARCHAR(80) NOT NULL DEFAULT 'admin'
);

CREATE TABLE IF NOT EXISTS report_orders (
 id BIGSERIAL PRIMARY KEY,
 user_id BIGINT NOT NULL REFERENCES report_users(id) ON DELETE RESTRICT,
 target_expect VARCHAR(32) NOT NULL,
 play_type VARCHAR(40) NOT NULL,
 payload JSONB NOT NULL DEFAULT '{}'::jsonb,
 content TEXT NOT NULL DEFAULT '',
 amount NUMERIC(16,2) NOT NULL CHECK(amount>0),
 odds NUMERIC(14,4) NOT NULL CHECK(odds>0),
 status VARCHAR(20) NOT NULL DEFAULT 'waiting',
 hit BOOLEAN,
 payout NUMERIC(16,2) NOT NULL DEFAULT 0,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 settled_at TIMESTAMPTZ,
 voided_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS report_orders_user_idx ON report_orders(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS report_orders_expect_idx ON report_orders(target_expect,status);
CREATE INDEX IF NOT EXISTS report_orders_created_idx ON report_orders(created_at DESC);

CREATE TABLE IF NOT EXISTS report_dividend_rules (
 id BIGSERIAL PRIMARY KEY,
 user_id BIGINT NOT NULL REFERENCES report_users(id) ON DELETE CASCADE,
 percent NUMERIC(8,4) NOT NULL CHECK(percent>0 AND percent<=100),
 active BOOLEAN NOT NULL DEFAULT TRUE,
 effective_from TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 effective_to TIMESTAMPTZ,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 created_by VARCHAR(80) NOT NULL DEFAULT 'admin'
);
CREATE INDEX IF NOT EXISTS report_dividend_rules_user_idx ON report_dividend_rules(user_id,active,effective_from DESC);

CREATE TABLE IF NOT EXISTS report_dividend_entries (
 id BIGSERIAL PRIMARY KEY,
 order_id BIGINT NOT NULL REFERENCES report_orders(id) ON DELETE CASCADE,
 beneficiary_user_id BIGINT NOT NULL REFERENCES report_users(id) ON DELETE CASCADE,
 percent NUMERIC(8,4) NOT NULL,
 base_amount NUMERIC(16,2) NOT NULL,
 dividend_amount NUMERIC(16,2) NOT NULL,
 settled BOOLEAN NOT NULL DEFAULT FALSE,
 payout_id BIGINT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 UNIQUE(order_id,beneficiary_user_id)
);
CREATE INDEX IF NOT EXISTS report_dividend_entries_user_idx ON report_dividend_entries(beneficiary_user_id,settled,created_at DESC);

CREATE TABLE IF NOT EXISTS report_dividend_payouts (
 id BIGSERIAL PRIMARY KEY,
 user_id BIGINT NOT NULL REFERENCES report_users(id) ON DELETE RESTRICT,
 amount NUMERIC(16,2) NOT NULL,
 period_start TIMESTAMPTZ,
 period_end TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 remark VARCHAR(200) NOT NULL DEFAULT '',
 created_by VARCHAR(80) NOT NULL DEFAULT 'admin',
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS report_dividend_payouts_user_idx ON report_dividend_payouts(user_id,created_at DESC);

CREATE TABLE IF NOT EXISTS report_daily_stats (
 stat_date DATE NOT NULL,
 scope_key VARCHAR(80) NOT NULL,
 payload JSONB NOT NULL DEFAULT '{}'::jsonb,
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 PRIMARY KEY(stat_date,scope_key)
);

CREATE TABLE IF NOT EXISTS report_audit_logs (
 id BIGSERIAL PRIMARY KEY,
 actor_type VARCHAR(24) NOT NULL,
 actor_id VARCHAR(80),
 action VARCHAR(80) NOT NULL,
 target_type VARCHAR(40),
 target_id VARCHAR(80),
 payload JSONB NOT NULL DEFAULT '{}'::jsonb,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS report_audit_logs_time_idx ON report_audit_logs(created_at DESC);

INSERT INTO report_play_odds(play_type,odds) VALUES
 ('特码',0),('平特一肖',0),('2连肖',0),('3连肖',0),('4连肖',0),('5连肖',0),('2中2码',0),('3中3码',0)
ON CONFLICT(play_type) DO NOTHING;

-- V4.1 设备级每日娱乐选择 ------------------------------------------------------
CREATE TABLE IF NOT EXISTS public_daily_choices (
 id BIGSERIAL PRIMARY KEY,
 device_hash VARCHAR(80) NOT NULL,
 choice_type VARCHAR(32) NOT NULL,
 choice_date DATE NOT NULL,
 payload JSONB NOT NULL DEFAULT '{}'::jsonb,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 UNIQUE(device_hash,choice_type,choice_date)
);
CREATE INDEX IF NOT EXISTS public_daily_choices_date_idx ON public_daily_choices(choice_date DESC,choice_type);

CREATE TABLE IF NOT EXISTS report_devices (
 id BIGSERIAL PRIMARY KEY,
 user_id BIGINT NOT NULL REFERENCES report_users(id) ON DELETE CASCADE,
 token_hash VARCHAR(80) UNIQUE NOT NULL,
 session_version INT NOT NULL DEFAULT 1,
 active BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 expires_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS report_devices_user_idx ON report_devices(user_id,active,expires_at DESC);
