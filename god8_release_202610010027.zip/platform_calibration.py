"""Reconcile already stored period rows against a confirmed platform mapping.

Never invent a result: re-materialize from the immutable raw block hashes.
The cursor is only a progress hint; every pass checks stored target blocks again.
"""
import time
from datetime import datetime, timezone

from core import (DB, fetch_block_range, from_index, get_meta, pindex, save_blocks_batch,
                  save_period, set_meta, target_block)

START_INDEX=pindex('2026-09-29',991)
TEMP_3_START=pindex('2026-09-30',1300)
TEMP_3_END=pindex('2026-10-01',120)
ZERO_REPAIR_END=pindex('2026-10-01',1440)


def mismatches(limit=25):
    with DB() as conn:
        q=conn.cursor()
        q.execute('''SELECT period_date::text,period_no,target_block,training_set
                     FROM periods WHERE period_date>=%s
                     ORDER BY period_date DESC,period_no DESC''',('2026-09-29',))
        found=[]
        for ds,no,tb,training in q.fetchall():
            if pindex(ds,no)>=START_INDEX and tb!=target_block(ds,no):
                found.append((ds,no,training))
                if len(found)>=limit:break
        q.close()
    return found


def _reuse_legacy_blocks(start,end,missing):
    """Reuse hashes already captured by older releases before network fetching."""
    if not missing:
        return 0
    with DB() as conn:
        q=conn.cursor()
        q.execute("SELECT to_regclass('public.historical_raw_blocks')")
        legacy=q.fetchone()[0]
        if legacy:
            q.execute('''SELECT block_number,block_hash FROM historical_raw_blocks
                         WHERE block_number BETWEEN %s AND %s''',(start,end))
            blocks=[{'number':int(n),'hash':h,'timestamp':None}
                    for n,h in q.fetchall() if int(n) in missing]
        else:
            blocks=[]
        # A previous period may also have retained the immutable hash even when
        # raw_blocks was pruned or never materialized during a rule correction.
        q.execute('''SELECT block_number,block_hash FROM groups
                     WHERE block_number BETWEEN %s AND %s''',(start,end))
        by_number={b['number']:b for b in blocks}
        for n,h in q.fetchall():
            if int(n) in missing:
                by_number[int(n)]={'number':int(n),'hash':h,'timestamp':None}
        q.close()
    return save_blocks_batch(by_number.values()) if by_number else 0


def _missing_temp3_periods(limit=25):
    """Find completed transition-window issues absent from formal history.

    This covers the full temporary 3-tail interval and the rest of Oct 1 after
    the 0121 switch to 0-tail, so a restart cannot leave a hole at the boundary.
    """
    head=(get_meta('chain_head') or {}).get('block')
    fast=(get_meta('fast_target_latest') or {}).get('targetBlock')
    head=max((int(x) for x in (head,fast) if x is not None),default=None)
    if head is None:
        return []
    candidates=[]
    capture=get_meta('historical_capture') or {}
    train_first=capture.get('firstIndex');train_last=capture.get('lastIndex')
    for idx in range(TEMP_3_START,ZERO_REPAIR_END+1):
        ds,no=from_index(idx)
        if target_block(ds,no)>head:
            break
        training=(train_first is not None and train_last is not None and
                  int(train_first)<=idx<=int(train_last))
        candidates.append((f'{ds}:{no:04d}',ds,no,training))
    if not candidates:
        return []
    keys=[x[0] for x in candidates]
    with DB() as conn:
        q=conn.cursor();q.execute('SELECT period_key FROM periods WHERE period_key=ANY(%s)',(keys,))
        existing={r[0] for r in q.fetchall()};q.close()
    return [(ds,no,training) for key,ds,no,training in candidates if key not in existing][:limit]


def reconcile_one(ds,no,training):
    target=target_block(ds,no)
    start=target-19
    with DB() as conn:
        q=conn.cursor()
        q.execute('''SELECT block_number FROM raw_blocks
                     WHERE block_number BETWEEN %s AND %s''',(start,target))
        have={int(r[0]) for r in q.fetchall()}
        q.close()
    missing=set(range(start,target+1))-have
    if missing:
        _reuse_legacy_blocks(start,target,missing)
        with DB() as conn:
            q=conn.cursor();q.execute('''SELECT block_number FROM raw_blocks
                         WHERE block_number BETWEEN %s AND %s''',(start,target))
            have={int(r[0]) for r in q.fetchall()};q.close()
        missing=set(range(start,target+1))-have
    if missing:
        fetched=fetch_block_range(start,target)
        save_blocks_batch(fetched.values())
    ok,missing=save_period(ds,no,'platform-calibrated',training)
    if not ok:
        raise RuntimeError(f'confirmed block range incomplete: {missing[:5]}')
    key=f'{ds}:{no:04d}'
    with DB() as conn:
        q=conn.cursor()
        q.execute('UPDATE periods SET audit_ok=FALSE WHERE period_key=%s',(key,))
        # Forecast choices/lock times remain immutable; correct only the
        # observed result used by all historical hit-rate displays.
        for table in ('replay_forecasts','lab_forecasts','ai_predictions'):
            q.execute(f'''UPDATE {table} f SET actual=p.single_count
                          FROM periods p WHERE f.period_key=p.period_key
                          AND p.period_key=%s AND f.actual IS DISTINCT FROM p.single_count''',(key,))
        q.close()
    return {'period':key,'targetBlock':target}



def _invalidate_future_views(changed):
    """Discard only not-yet-settled derived views after canonical history changes.

    Settled historical forecasts remain immutable. Future forecasts are regenerated
    from the corrected 3-tail/0-tail formal history on the next collector tick.
    """
    if not changed:
        return
    now=datetime.now(timezone.utc).isoformat()
    with DB() as conn:
        q=conn.cursor()
        q.execute("""DELETE FROM replay_forecasts f
                     WHERE f.settled_at IS NULL
                       AND NOT EXISTS (SELECT 1 FROM periods p WHERE p.period_key=f.period_key)""")
        replay_deleted=q.rowcount
        q.execute("""DELETE FROM lab_forecasts f
                     WHERE f.settled_at IS NULL
                       AND NOT EXISTS (SELECT 1 FROM periods p WHERE p.period_key=f.period_key)""")
        lab_deleted=q.rowcount
        q.close()
    set_meta('canonical_data_revision',{
        'updatedAt':now,
        'changedPeriods':[item['period'] for item in changed],
        'latestChanged':changed[0]['period'] if changed else None,
        'pendingReplayInvalidated':replay_deleted,
        'pendingLabInvalidated':lab_deleted,
        'reason':'platform-tail-reconciliation'
    })


def reconcile_priority_bootstrap(max_batches=20):
    """Repair newest canonical rows before replay/pattern workers are allowed to start."""
    batches=0
    changed_total=0
    while batches < max_batches:
        changed=reconcile_once()
        batches += 1
        changed_total += len(changed)
        if not changed or len(changed) < 25:
            break
    set_meta('platform_calibration_bootstrap',{
        'status':'ready',
        'batches':batches,
        'changed':changed_total,
        'updatedAt':datetime.now(timezone.utc).isoformat()
    })
    return changed_total

def reconcile_once():
    changed=[]
    pending=mismatches(limit=25)
    if len(pending)<25:
        known={(ds,no) for ds,no,_ in pending}
        for item in _missing_temp3_periods(limit=25-len(pending)):
            if (item[0],item[1]) not in known:
                pending.append(item)
    for ds,no,training in pending:
        changed.append(reconcile_one(ds,no,training))
    if changed:
        _invalidate_future_views(changed)
        set_meta('platform_calibration',{'status':'corrected',
                 'confirmed':{'2026-09-29:0991':86666063,
                              '2026-09-29:0992':86666082,
                              '2026-09-30:1299':86700994,
                              '2026-09-30:1300':86701013,
                              '2026-09-30:1306':86701133},
                 'inferredBoundary':{'2026-09-29:1201':86670260,
                                     '2026-10-01:0121':target_block('2026-10-01',121)},
                 'batch':changed,'updatedAt':datetime.now(timezone.utc).isoformat()})
    return changed


def reconcile_forever():
    while True:
        try:
            changed=reconcile_once()
            time.sleep(.5 if len(changed)==25 else 30)
        except Exception as exc:
            set_meta('platform_calibration',{'status':'retrying','error':str(exc)[:300],
                     'updatedAt':datetime.now(timezone.utc).isoformat()})
            time.sleep(5)
