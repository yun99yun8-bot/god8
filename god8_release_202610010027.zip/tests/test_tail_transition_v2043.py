import os,sys,unittest
sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))
from core import pindex,from_index,target_block

class TailTransitionV2043(unittest.TestCase):
    def test_entire_temp_window_is_three_tail(self):
        for idx in range(pindex('2026-09-30',1300),pindex('2026-10-01',120)+1):
            ds,no=from_index(idx)
            self.assertEqual(target_block(ds,no)%10,3,(ds,no))

    def test_zero_tail_boundary_is_exact(self):
        self.assertEqual(target_block('2026-10-01',120)%10,3)
        self.assertEqual(target_block('2026-10-01',121)%10,0)
        self.assertEqual(target_block('2026-10-01',122)%10,0)

    def test_temp_three_does_not_shift_original_phase_clock(self):
        self.assertEqual(target_block('2026-10-01',481)%10,8)

if __name__=='__main__':unittest.main()
