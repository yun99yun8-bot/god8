from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def test_worker_publishes_startup_before_lock_and_runtime_after_lock():
    s=(ROOT/'worker_ai.py').read_text()
    assert "god8_worker_startup_heartbeat','starting'" in s
    assert "god8_worker_startup_heartbeat','waiting-for-leader-lock'" in s
    assert "god8_worker_handoff','waiting-for-previous-instance'" in s
    assert "god8_worker_heartbeat','running'" in s
    assert "time.sleep(5)" in s

def test_service_api_exposes_worker_boot_handoff_and_release():
    s=(ROOT/'web.py').read_text()
    for key in ('workerStartupHeartbeat','workerHandoff','workerRelease'):
        assert key in s

def test_check_center_displays_worker_and_manual_tail_heartbeats():
    s=(ROOT/'static/app.js').read_text()
    for label in ('运行状态','运行版本','启动状态','交接状态','手动尾数线程心跳'):
        assert label in s

def test_render_still_launches_worker_ai():
    s=(ROOT/'render.yaml').read_text()
    assert 'name: god8-worker-ai' in s
    assert 'startCommand: python worker_ai.py' in s
