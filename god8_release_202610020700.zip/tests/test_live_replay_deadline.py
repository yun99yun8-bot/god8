"""A pending forecast must disappear as soon as its target block is known."""
import unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import patch
import web
from live_replay import target_for_latest


class ReplayDeadlineTests(unittest.TestCase):
    def request(self, *, head, age, raw_known=False, head_age=0):
        now=datetime.now(timezone.utc)
        source='2026-10-01:0100'
        target,block=target_for_latest(source)
        canonical=(source,'2026-10-01',100,block-20,'a'*64,[1,2,3,4,5,6,7],4,
                   now-timedelta(seconds=age),True)
        saved=(target,source,[1,6],{'selectionPolicy':'replay'},
               now-timedelta(seconds=max(0,age-1)),None,None)

        def query(sql,args=()):
            if 'FROM replay_forecasts ORDER BY' in sql:return [saved]
            if 'FROM raw_blocks WHERE block_number' in sql:return [(1,)] if raw_known else []
            if 'COUNT(*) FILTER' in sql:return [(0,0,0,0)]
            raise AssertionError(sql)
        with patch.object(web,'canonical_load',return_value=[canonical]), \
             patch.object(web,'rows',side_effect=query), \
             patch.object(web,'get_meta',side_effect=lambda key,default=None: {
                 'block':head,'seenAt':(now-timedelta(seconds=head_age)).isoformat()
             } if key=='chain_head' else {}), \
             patch.object(web,'schedule_replay_heal',return_value={'status':'scheduled'}):
            return web.app.test_client().get('/api/replay/live').json

    def test_forecast_visible_before_target(self):
        target,block=target_for_latest('2026-10-01:0100')
        report=self.request(head=block-9,age=25)
        self.assertEqual(report['forecast']['period'],target)
        self.assertEqual(report['forecast']['targetBlock'],block)

    def test_early_reveal_when_source_arrives_late(self):
        _,block=target_for_latest('2026-10-01:0100')
        report=self.request(head=block-8,age=12)
        self.assertEqual(report['phase'],'predicted')
        self.assertIsNotNone(report['forecast'])

    def test_target_head_or_raw_hides_pending_forecast(self):
        _,block=target_for_latest('2026-10-01:0100')
        for head,raw in ((block,False),(block-1,True)):
            with self.subTest(head=head,raw=raw):
                report=self.request(head=head,age=25,raw_known=raw)
                self.assertIsNone(report['forecast'])
                self.assertEqual(report['phase'],'waiting-result')

    def test_stale_head_hides_pending_card(self):
        _,block=target_for_latest('2026-10-01:0100')
        report=self.request(head=block-9,age=25,head_age=10)
        self.assertIsNone(report['forecast'])
        self.assertEqual(report['phase'],'waiting-result')


if __name__=='__main__':unittest.main()
