import random
import unittest
from unittest.mock import patch

import core
import history_simulation


class PredictionFallbackTests(unittest.TestCase):
    def setUp(self):
        self.cfg=core._normalize_runtime_config(core.DEFAULT_RUNTIME_CONFIG)

    def test_unseen_four_period_context_still_predicts_adaptively(self):
        start=core.pindex('2026-01-01',1)
        rng=random.Random(17)
        rows=[]
        for i in range(996):
            ds,no=core.from_index(start+i)
            rows.append((f'{ds}:{no:04d}',rng.choice([1,2,3,4,5,6]),None))
        # This exact 0,7,0,7 suffix never appeared in the earlier history.
        for j,value in enumerate([0,7,0,7]):
            ds,no=core.from_index(start+996+j)
            rows.append((f'{ds}:{no:04d}',value,None))
        with patch.object(core,'runtime_config',return_value=self.cfg), \
             patch.object(history_simulation,'runtime_config',return_value=self.cfg):
            report=history_simulation.simulate(rows)
        self.assertIsNotNone(report['preview'])
        self.assertEqual(report['preview']['match']['selectionPolicy'],'adaptive-no-exact-replay')
        self.assertEqual(len(report['preview']['predictions']),2)
        self.assertNotEqual(report['preview']['predictions'][0],report['preview']['predictions'][1])

    def test_exact_replay_still_has_priority_when_available(self):
        start=core.pindex('2026-01-01',1)
        pattern=[1,2,5,6]
        rows=[]
        values=[]
        for _ in range(180):
            values.extend(pattern+[1])
        for i,value in enumerate(values):
            ds,no=core.from_index(start+i)
            rows.append((f'{ds}:{no:04d}',value,None))
        with patch.object(core,'runtime_config',return_value=self.cfg), \
             patch.object(history_simulation,'runtime_config',return_value=self.cfg):
            report=history_simulation.simulate(rows)
        self.assertIsNotNone(report['preview'])
        self.assertGreaterEqual(report['preview']['match']['length'],4)
        self.assertNotEqual(report['preview']['match']['selectionPolicy'],'adaptive-no-exact-replay')

if __name__=='__main__': unittest.main()
