# God8 v2.0.51

- Web /api/replay/live becomes a third DB-locked prediction watchdog when the current source has no visible forecast.
- Pending stale replay rows whose source_period no longer matches the current canonical source are removed only while the target result is still unknown, then relocked from the current source.
- Collector + Worker remain the primary schedulers; Web self-heal removes the final single dependency on background scheduler startup.
- API exposes webSelfHeal, workerWatchdog and predictionError for direct diagnosis.

- Homepage two-choice replay is now always-on; it is no longer gated by the local Smart Sprite switch.
- The Smart Sprite switch controls only optional memory/toast reminders.
- Every visible homepage polls /api/replay/live, which also provides Web self-heal when background schedulers miss a lock.
