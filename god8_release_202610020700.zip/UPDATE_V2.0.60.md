# God8 v2.0.60

- 修复检查中心仍显示 Worker 未见心跳：手动尾数状态现在同时读取主 Worker 的启动、交接、运行心跳。
- 手动尾数线程在 cycle-start / live-sync / settle / backfill / prediction / sleep 各阶段持续写心跳。
- 历史回填每轮总量仍最多 2500 条，但拆成 5 个 500 条子批次，子批次之间刷新心跳，避免长事务被误判离线。
- 明确区分“主 Worker 等待旧实例交接”和“尾数线程未启动”。
- 不修改 target_block()、360 尾数规则或手动尾数数据源逻辑。
