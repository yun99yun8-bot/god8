# v2.0.54

- Fix `/api/replay/live` request starvation: Web self-heal now runs asynchronously instead of doing a 10,000-period simulation inside the HTTP request.
- Keep Collector and Worker as primary replay watchdogs; Web remains a third self-heal path without blocking the UI.
- Add a 6.5-second client timeout to replay polling so one stalled request cannot permanently keep `replayRequestPending=true`.
- Replay polling uses `cache: no-store` and automatically resumes after timeout/error.
- Preserve v2.0.53 real 10-second settled-card hold behavior and all tail/runtime rules.
