import os, sys, unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import live_replay

class PredictionRuntimeV2050Tests(unittest.TestCase):
    def test_forecast_due_uses_chain_future_not_wall_clock_minute(self):
        now=datetime.now(timezone.utc)
        # Source may be older than the wall-clock minute; chain-future target is sufficient.
        self.assertTrue(live_replay.forecast_due(now,'2026-10-01:0100',now-timedelta(minutes=3),200,199))
        self.assertFalse(live_replay.forecast_due(now,'2026-10-01:0100',now-timedelta(minutes=3),200,200))

    def test_guarded_tick_skips_when_other_service_is_computing(self):
        lease=MagicMock();cur=MagicMock();lease.cursor.return_value=cur
        cur.fetchone.return_value=(False,)
        pool=MagicMock();pool.getconn.return_value=lease
        with patch.object(live_replay,'pool',return_value=pool), patch.object(live_replay,'advance') as advance:
            result=live_replay.advance_guarded()
        self.assertEqual(result['status'],'busy-other-watchdog')
        advance.assert_not_called()

    def test_guarded_tick_runs_and_unlocks(self):
        lease=MagicMock();cur=MagicMock();lease.cursor.return_value=cur
        cur.fetchone.return_value=(True,)
        pool=MagicMock();pool.getconn.return_value=lease
        with patch.object(live_replay,'pool',return_value=pool), patch.object(live_replay,'advance',return_value={'status':'locked'}) as advance:
            result=live_replay.advance_guarded()
        self.assertEqual(result['status'],'locked')
        advance.assert_called_once()
        sqls=[c.args[0] for c in cur.execute.call_args_list]
        self.assertTrue(any('pg_try_advisory_lock' in x for x in sqls))
        self.assertTrue(any('pg_advisory_unlock' in x for x in sqls))

if __name__=='__main__':unittest.main()
