# God8 v2.0.29 Web stability

- Render `/health` is now process-only liveness. A brief PostgreSQL hiccup no longer removes the only Web instance from routing.
- Database-aware diagnostics moved to `/api/health/deep`; the checks page uses that endpoint.
- `/api/manual-tail/live` adds a 250 ms per-tail server cache so multiple phones share the same DB read.
- Gunicorn remains threaded (no gevent dependency), with 32 threads and a Web-only DB pool ceiling of 12.
- Manual-tail live polling is adaptive: 250 ms only around the draw boundary, 1100 ms otherwise; full snapshots/history are slower.
- Chat conversation/call polling backs off when WebSocket is healthy and switches back immediately if WebSocket drops.
- No changes to manual-tail mapping, prediction engines, platform calibration, collector, or AI worker.
