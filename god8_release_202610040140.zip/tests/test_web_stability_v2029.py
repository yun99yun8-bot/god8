from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def text(name): return (ROOT/name).read_text()

def test_render_health_is_process_only_and_deep_check_is_separate():
    web=text('web.py'); render=text('render.yaml'); js=text('static/app.js')
    assert "@app.get('/health')" in web
    assert "processAlive':True" in web
    assert "@app.get('/api/health/deep')" in web
    assert "fetch('/api/health/deep'" in js
    assert 'healthCheckPath: /health' in render

def test_manual_live_polling_has_backpressure_and_boundary_fast_path():
    js=text('static/app.js'); web=text('web.py')
    assert 'scheduleManualTailLiveLoop();' in js
    assert "return (p.remaining<=4||p.remaining>=54)?250:1100;" in js
    assert '_manual_live_cache' in web
    assert 'now-cached[0] < 0.25' in web

def test_chat_polling_backs_off_when_websocket_is_healthy():
    js=text('static/app.js')
    assert 'realtime?(box.hidden?20000:15000)' in js
    assert "callStateTimer=setInterval(()=>{if(me&&!document.hidden&&(!socket||socket.readyState!==1))syncCallState()},4000)" in js

def test_gunicorn_has_thread_and_db_pool_headroom_without_gevent():
    cfg=text('gunicorn.conf.py')
    assert "DB_POOL_MAX','12'" in cfg
    assert 'threads = 32' in cfg
    assert 'timeout = 90' in cfg
    assert 'worker_class' not in cfg
