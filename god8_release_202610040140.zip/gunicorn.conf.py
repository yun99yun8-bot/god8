# v2.0.29 web stability: keep the Web process independent of optional gevent.
# WebSocket clients consume threaded worker slots, so give the single 512 MB Web
# instance enough thread headroom while keeping DB concurrency bounded.
import os
os.environ.setdefault('DB_POOL_MAX','12')
workers = 1
threads = 32
timeout = 90
graceful_timeout = 30
keepalive = 5
